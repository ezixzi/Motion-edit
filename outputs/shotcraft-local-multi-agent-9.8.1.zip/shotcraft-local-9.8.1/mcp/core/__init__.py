"""Shotcraft Pro v9.6.0 — Modular MCP Shared Core (`mcp.core`)."""
from .config import SERVER_VERSION, PROTOCOL_VERSION, DEFAULT_FPS, DEFAULT_ASPECT, ASPECT_PRESETS
from .paths import get_claude_dir, get_skills_dir, get_repo_path
from .style_map import STYLE_GALLERY_MAP, get_style_spec
from .utils import run_quiet

__all__ = [
    "SERVER_VERSION",
    "PROTOCOL_VERSION",
    "DEFAULT_FPS",
    "DEFAULT_ASPECT",
    "ASPECT_PRESETS",
    "get_claude_dir",
    "get_skills_dir",
    "get_repo_path",
    "STYLE_GALLERY_MAP",
    "get_style_spec",
    "run_quiet",
]
