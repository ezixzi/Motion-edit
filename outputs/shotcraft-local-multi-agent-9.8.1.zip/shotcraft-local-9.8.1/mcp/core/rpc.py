"""Small stdio MCP transport: one JSON object per line, resilient per-request errors."""
import contextlib
import json
import sys

VERSIONS = ('2025-06-18', '2025-03-26', '2024-11-05')


def validate(value, schema, label='arguments'):
    expected=schema.get('type')
    checks={'object':lambda x:isinstance(x,dict),'array':lambda x:isinstance(x,list),
            'string':lambda x:isinstance(x,str),'boolean':lambda x:isinstance(x,bool),
            'integer':lambda x:isinstance(x,int) and not isinstance(x,bool),
            'number':lambda x:isinstance(x,(int,float)) and not isinstance(x,bool)}
    if expected in checks and not checks[expected](value): raise ValueError(label+' must be '+expected)
    if 'enum' in schema and value not in schema['enum']:raise ValueError(label+' is not an allowed value')
    if isinstance(value,dict):
        for key in schema.get('required',[]):
            if key not in value:raise ValueError(label+' missing '+key)
        for key,child in value.items():
            if key in schema.get('properties',{}): validate(child,schema['properties'][key],label+'.'+key)
    if isinstance(value,list) and 'items' in schema:
        for item in value:validate(item,schema['items'],label+'[]')
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        if 'minimum' in schema and value<schema['minimum']:raise ValueError(label+' below minimum')
        if 'maximum' in schema and value>schema['maximum']:raise ValueError(label+' above maximum')


def serve(name, version, tools, handler):
    catalog={tool['name']:tool for tool in tools}
    output=sys.stdout
    def send(ident,result=None,error=None):
        data={'jsonrpc':'2.0','id':ident}
        data['error' if error else 'result']=error if error else result
        output.write(json.dumps(data,ensure_ascii=False,allow_nan=False)+'\n');output.flush()
    for line in sys.stdin:
        if not line.strip():continue
        try:request=json.loads(line)
        except (ValueError,TypeError):
            send(None,error={'code':-32700,'message':'Parse error'});continue
        if not isinstance(request,dict) or request.get('jsonrpc')!='2.0' or not isinstance(request.get('method'),str):
            send(request.get('id') if isinstance(request,dict) else None,error={'code':-32600,'message':'Invalid request'});continue
        if 'id' not in request:continue
        ident=request['id'];method=request['method'];params=request.get('params',{})
        if not isinstance(params,dict):
            send(ident,error={'code':-32602,'message':'params must be an object'});continue
        if method=='initialize':
            proposed=params.get('protocolVersion')
            send(ident,{'protocolVersion':proposed if proposed in VERSIONS else VERSIONS[0], 'capabilities':{'tools':{}}, 'serverInfo':{'name':name,'version':version}})
        elif method=='ping':send(ident,{})
        elif method=='tools/list':send(ident,{'tools':tools})
        elif method=='tools/call':
            tool=params.get('name');args=params.get('arguments',{})
            if not isinstance(tool,str) or tool not in catalog:
                send(ident,error={'code':-32602,'message':'Unknown tool'});continue
            try:validate(args,catalog[tool]['inputSchema'])
            except ValueError as exc:
                send(ident,error={'code':-32602,'message':str(exc)});continue
            try:
                with contextlib.redirect_stdout(sys.stderr): result=handler(tool,args)
                send(ident,{'content':[{'type':'text','text':json.dumps(result,ensure_ascii=False,allow_nan=False)}], 'isError':result.get('ok',True) is False})
            except Exception as exc:
                send(ident,{'content':[{'type':'text','text':json.dumps({'ok':False,'error':f'{type(exc).__name__}: {exc}'})}], 'isError':True})
        else:send(ident,error={'code':-32601,'message':'Method not found: '+method})
