"""Shotcraft Pro v9.6.0 — Shared MCP Path Resolution."""
import json
import os
from pathlib import Path


def get_claude_dir() -> Path:
    return Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home() / ".claude"))).expanduser().resolve()


def get_skills_dir() -> Path:
    if os.environ.get('SHOTCRAFT_SKILLS_DIR'):
        return Path(os.environ['SHOTCRAFT_SKILLS_DIR']).expanduser().resolve()
    here = Path(__file__).resolve().parent.parent
    if (here.parent / "shotcraft-local").is_dir():
        return here.parent
    if (here.parent / "skills" / "shotcraft-local").is_dir():
        return here.parent / "skills"
    if (here / "shotcraft-local").is_dir():
        return here
    return get_claude_dir() / "skills"


def get_repo_path(skills_dir: Path = None) -> str:
    explicit = os.environ.get('VIDEO_SHOTCRAFT_ROOT')
    if explicit:
        return str(Path(explicit).expanduser().resolve())
    sd = skills_dir or get_skills_dir()
    cfg = sd / "shotcraft-local" / "config.json"
    if cfg.is_file():
        try:
            rp = json.loads(cfg.read_text(encoding="utf-8")).get("repo_path", "")
            if rp and Path(rp).is_dir():
                return rp
        except Exception:
            pass
    for cand in [
        sd / "video-shotcraft",
        sd / "local-upstream" / "video-shotcraft",
        sd.parent / "local-upstream" / "video-shotcraft",
    ]:
        if cand.is_dir():
            return str(cand.resolve())
    return str(sd / "video-shotcraft")
