"""
Shotcraft Pro v9.7.0 — Capability Registry, Scene Contract Validator & 4 Reference Style Families (`style_map.py`).

Implements:
- F04 & RQ01: Central Capability Registry for engines (`pillow`, `remotion`), 4 benchmark style families
  (`ref1-voxel-evidence`, `ref2-cinematic-character`, `ref3-cutaway-mechanism`, `ref4-minimal-ui`),
  plus legacy style aliases (`ref5-editorial-cutaway`, `ref1-tutorial-deck`, `ref4-tape-mascot`, `neural-network`, `coffee-editorial-3d`).
- Section 6: Scene Contract Validator separating `Identity`, `Content`, `Visual`, `Motion`, `Timing`, `Audio`, and `Capability`.
- F07: Explicit Transition Contract (`cut`, `crossfade`, `slide`, `zoom`, `object-match`, `cutaway-peel`).
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

VALID_TRANSITION_TYPES = {
    "cut",
    "crossfade",
    "slide",
    "zoom",
    "object-match",
    "cutaway-peel",
}

TRANSITION_ALIAS_MAP = {
    "cut": "cut",
    "none": "cut",
    "hard-cut": "cut",
    "crossfade": "crossfade",
    "fade": "crossfade",
    "dissolve": "crossfade",
    "slide": "slide",
    "whip": "slide",
    "whip-left": "slide",
    "whip-right": "slide",
    "whip-up": "slide",
    "whip-down": "slide",
    "slide-left": "slide",
    "slide-right": "slide",
    "slide-up": "slide",
    "zoom": "zoom",
    "zoom-snap": "zoom",
    "zoom-in": "zoom",
    "zoom-out": "zoom",
    "object-match": "object-match",
    "match-cut": "object-match",
    "shared-element": "object-match",
    "cutaway-peel": "cutaway-peel",
    "peel": "cutaway-peel",
}

VALID_ENGINES = {"auto", "pillow", "cinema-pil", "remotion"}

ENGINE_CAPABILITIES = {
    "pillow": {
        "engine_id": "pillow",
        "display_name": "Shotcraft Deterministic 2.5D/3D Canvas Renderer (Pillow + NumPy)",
        "supports_gltf_mesh_projection": True,
        "supports_full_pbr_shader_pipeline": False,
        "supported_style_families": [
            "ref1-voxel-evidence",
            "ref2-cinematic-character",
            "ref3-cutaway-mechanism",
            "ref4-minimal-ui",
            "ref5-editorial-cutaway",
            "ref1-tutorial-deck",
            "ref2-floating-glass",
            "ref3-pricing-voxel",
            "ref4-tape-mascot",
            "coffee-editorial-3d",
            "neural-network",
            "talking-head",
        ] + list(OPUS_55_PROCEDURAL_MODES.keys()) if "OPUS_55_PROCEDURAL_MODES" in globals() else [
            "ref1-voxel-evidence",
            "ref2-cinematic-character",
            "ref3-cutaway-mechanism",
            "ref4-minimal-ui",
            "ref5-editorial-cutaway",
            "ref1-tutorial-deck",
            "ref2-floating-glass",
            "ref3-pricing-voxel",
            "ref4-tape-mascot",
            "coffee-editorial-3d",
            "neural-network",
            "talking-head",
        ],
        "supported_subjects": [
            "lawnmower-rotary",
            "geothermal-earth-pipe",
            "combustion-engine",
            "solar-panel",
            "food-chain-ecology",
            "water-thermodynamics",
            "coffee-extraction",
            "neural-network-ai",
            "voxel-presenter",
            "cinematic-character",
            "ui-workflow-cards",
            "system-mechanism",
        ],
        "supported_transitions": sorted(VALID_TRANSITION_TYPES),
        "supported_fonts": ["sans", "serif", "mono", "editorial", "display", "handwritten"],
        "supported_aspects": ["9:16", "16:9", "1:1", "4:5", "2:3"],
    },
    "remotion": {
        "engine_id": "remotion",
        "display_name": "Remotion v4 React + SVG/GLB Stage Renderer",
        "supports_gltf_mesh_projection": True,
        "supports_full_pbr_shader_pipeline": False,
        "supported_style_families": [
            "ref1-voxel-evidence",
            "ref2-cinematic-character",
            "ref3-cutaway-mechanism",
            "ref4-minimal-ui",
            "ref5-editorial-cutaway",
            "ref1-tutorial-deck",
            "ref2-floating-glass",
            "ref3-pricing-voxel",
            "ref4-tape-mascot",
            "coffee-editorial-3d",
            "neural-network",
            "talking-head",
        ] + list(OPUS_55_PROCEDURAL_MODES.keys()) if "OPUS_55_PROCEDURAL_MODES" in globals() else [
            "ref1-voxel-evidence",
            "ref2-cinematic-character",
            "ref3-cutaway-mechanism",
            "ref4-minimal-ui",
            "ref5-editorial-cutaway",
            "ref1-tutorial-deck",
            "ref2-floating-glass",
            "ref3-pricing-voxel",
            "ref4-tape-mascot",
            "coffee-editorial-3d",
            "neural-network",
            "talking-head",
        ],
        "supported_subjects": [
            "lawnmower-rotary",
            "combustion-engine",
            "coffee-extraction",
            "neural-network-ai",
            "voxel-presenter",
            "cinematic-character",
            "ui-workflow-cards",
            "system-mechanism",
        ],
        "supported_transitions": sorted(VALID_TRANSITION_TYPES),
        "supported_fonts": ["sans", "serif", "mono", "editorial", "display", "handwritten"],
        "supported_aspects": ["9:16", "16:9", "1:1", "4:5", "2:3"],
    },
}

STYLE_FAMILIES = {
    "ref1-voxel-evidence": {
        "family_id": "ref1-voxel-evidence",
        "benchmark_ref": "R1 (snapgram.io_bls6ci1y8rpw.mp4)",
        "world": "voxel-dark-evidence",
        "description": "Presenter voxel konsisten di bagian bawah dengan bukti browser/UI/tabel di atas dan caption pendek di tengah dengan aksen biru.",
        "best_for": ["tools-list", "app-tutorial", "service-comparison", "developer-api"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "sans",
        "caption_style": "karaoke-pill",
        "word_animation": "scale-bounce",
        "camera_preset": "dolly-push",
        "camera_orbit_rad_s": 0.08,
        "camera_dolly": 0.05,
        "particles": {"kind": "cyber-data-packets", "density": 18, "god_rays": False, "vignette": 0.22},
        "gradient_stops": ["#060A17", "#0B132B", "#111C38", "#2563EB"],
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
        "model_3d": "assets/models/voxel_presenter.glb",
        "representation": "2.5d",
    },
    "ref2-cinematic-character": {
        "family_id": "ref2-cinematic-character",
        "benchmark_ref": "R2 (snapgram.io_cqcrqnxorkqy.mp4)",
        "world": "tape-mascot",
        "description": "Karakter 3D konsisten di ruang hangat gelap (terakota/krem), headline pita kertas (masking tape) di atas, dan caption potongan kertas.",
        "best_for": ["character-story", "product-storytelling", "creative-promo", "opinion"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "serif",
        "caption_style": "handwritten",
        "word_animation": "pop-rotate",
        "camera_preset": "breathing-float",
        "camera_orbit_rad_s": 0.09,
        "camera_dolly": 0.04,
        "particles": {"kind": "warm-dust", "density": 16, "god_rays": False, "vignette": 0.20},
        "gradient_stops": ["#141418", "#1E1B18", "#2C2520", "#D97757"],
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "model_3d": "assets/models/character_mascot.glb",
        "representation": "procedural-3d",
    },
    "ref3-cutaway-mechanism": {
        "family_id": "ref3-cutaway-mechanism",
        "benchmark_ref": "R3 (snapgram.io_xa8zgeyyv9wv.mp4)",
        "world": "cutaway-environment",
        "description": "Cutaway lintas lapisan (permukaan rumput/tanah/alat), komponen ber-ID tetap dengan state machine mekanisme, aliran partikel, dan pill caption putih bersih di atas.",
        "best_for": ["how-it-works", "mechanical-explainer", "science-process", "ecology"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "sans",
        "caption_style": "karaoke-pill",
        "word_animation": "scale-bounce",
        "camera_preset": "focus-pull",
        "camera_orbit_rad_s": 0.10,
        "camera_dolly": 0.06,
        "particles": {"kind": "mechanism-flow", "density": 20, "god_rays": False, "vignette": 0.12},
        "gradient_stops": ["#5AB2F7", "#8ED0F9", "#74B843", "#9E6230"],
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "mechanical",
        "model_3d": "assets/models/lawnmower_rotary.glb",
        "representation": "2.5d",
    },
    "ref4-minimal-ui": {
        "family_id": "ref4-minimal-ui",
        "benchmark_ref": "R4 (snapgram.io_rjbniockibb0.mp4)",
        "world": "minimal-offwhite-ui",
        "description": "Latar off-white terang (#F5F4F0), pill progres di atas, kartu UI bersih dengan bayangan lembut di tengah, dan tipografi kontras di bawah.",
        "best_for": ["software-workflow", "product-explainer", "automation", "data-summary"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "serif",
        "caption_style": "minimal",
        "word_animation": "scale-bounce",
        "camera_preset": "dolly-push",
        "camera_orbit_rad_s": 0.06,
        "camera_dolly": 0.04,
        "particles": {"kind": "editorial-paper-grain", "density": 10, "god_rays": False, "vignette": 0.08},
        "gradient_stops": ["#F5F4F0", "#EEEDE8", "#E4E2DC", "#EC4899"],
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "minimal",
        "model_3d": "assets/models/ui_card_stack.glb",
        "representation": "2d",
    },
}

STYLE_GALLERY_MAP = {
    **STYLE_FAMILIES,
    "ref5-editorial-cutaway": {
        **STYLE_FAMILIES["ref3-cutaway-mechanism"],
        "family_id": "ref3-cutaway-mechanism",
        "world": "cream-editorial",
        "heading_font": "serif",
        "mono_font": "mono",
        "body_font": "sans",
        "caption_style": "karaoke-pill",
        "gradient_stops": ["#F2EDE0", "#E5DEC9", "#D4CBB4", "#1D7A46"],
        "model_3d": "assets/models/lawnmower_rotary.glb",
    },
    "ref1-tutorial-deck": {
        **STYLE_FAMILIES["ref1-voxel-evidence"],
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "caption_style": "typewriter",
        "gradient_stops": ["#121210", "#1C1C18", "#292524", "#D97757"],
        "model_3d": "assets/models/voxel_presenter.glb",
    },
    "ref2-floating-glass": {
        **STYLE_FAMILIES["ref4-minimal-ui"],
        "family_id": "ref4-minimal-ui",
        "world": "cosmic-glass",
        "caption_style": "neon",
        "gradient_stops": ["#130D26", "#1E1B4B", "#3B0764", "#EC4899"],
        "model_3d": "assets/models/ui_card_stack.glb",
    },
    "ref3-pricing-voxel": {
        **STYLE_FAMILIES["ref1-voxel-evidence"],
        "family_id": "ref1-voxel-evidence",
        "world": "dark-science",
        "caption_style": "slide-up",
        "gradient_stops": ["#060A12", "#0F172A", "#1E293B", "#3B82F6"],
        "model_3d": "assets/models/voxel_presenter.glb",
    },
    "ref4-tape-mascot": {
        **STYLE_FAMILIES["ref2-cinematic-character"],
        "family_id": "ref2-cinematic-character",
    },
    "coffee-editorial-3d": {
        **STYLE_FAMILIES["ref3-cutaway-mechanism"],
        "family_id": "ref3-cutaway-mechanism",
        "world": "coffee-editorial",
        "heading_font": "serif",
        "caption_style": "slide-up",
        "gradient_stops": ["#F6EFE4", "#EDE0CE", "#D6C2A8", "#B45309"],
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "model_3d": "assets/models/coffee_cup.glb",
    },
        "talking-head": {
        "family_id": "talking-head",
        "benchmark_ref": "Talking Head 3-Zone + Alight Motion XML Text Presets",
        "world": "dark-science",
        "description": "Talking head 3-zona (Top Overlay 8-36%, Center Face-Aware 36-75%, Bottom XML Animated Subtitle 75-88%) dengan efek 4-Color Gradient, Smooth Bevel, Deep Glow, Long Shadow, dan Shimmer.",
        "best_for": ["talking-head", "presenter", "spokesperson", "education", "opinion", "ai-tutorial"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "sans",
        "caption_style": "xml-4color-gold",
        "word_animation": "scale-bounce",
        "camera_preset": "focus-pull",
        "camera_orbit_rad_s": 0.06,
        "camera_dolly": 0.06,
        "particles": {"kind": "cyber-data-packets", "density": 14, "god_rays": False, "vignette": 0.18},
        "gradient_stops": ["#60A5FA", "#A855F7", "#EC4899", "#F97316"],
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
        "model_3d": "assets/models/voxel_presenter.glb",
        "representation": "talking-head-3zone",
    },
    "neural-network": {
        "family_id": "ref3-cutaway-mechanism",
        "benchmark_ref": "AI / Neuroscience Specialized View",
        "world": "dark-science",
        "description": "Visualisasi jaringan saraf (khusus untuk topik AI, machine learning, atau neurosains).",
        "best_for": ["ai-explainer", "neuroscience"],
        "heading_font": "sans",
        "mono_font": "mono",
        "body_font": "sans",
        "caption_style": "karaoke-pill",
        "word_animation": "scale-bounce",
        "camera_preset": "cinematic-orbit",
        "camera_orbit_rad_s": 0.15,
        "camera_dolly": 0.08,
        "particles": {"kind": "neural-synapse-bokeh", "density": 28, "god_rays": True, "vignette": 0.25},
        "gradient_stops": ["#060B18", "#0F172A", "#1E1B4B", "#38BDF8"],
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "scifi",
        "model_3d": "assets/models/neuron.glb",
    },
}

STYLE_ALIAS_MAP = {
    "r1": "ref1-voxel-evidence",
    "voxel-presenter": "ref1-voxel-evidence",
    "voxel-evidence": "ref1-voxel-evidence",
    "ref1-voxel-evidence": "ref1-voxel-evidence",
    "r2": "ref2-cinematic-character",
    "cinematic-character": "ref2-cinematic-character",
    "cinematic-product": "ref2-cinematic-character",
    "tape-mascot": "ref2-cinematic-character",
    "ali-abdaal-desk": "ref2-cinematic-character",
    "ref2-cinematic-character": "ref2-cinematic-character",
    "ref4-tape-mascot": "ref2-cinematic-character",
    "r3": "ref3-cutaway-mechanism",
    "cutaway-mechanism": "ref3-cutaway-mechanism",
    "mechanical-cutaway": "ref3-cutaway-mechanism",
    "ref3-cutaway-mechanism": "ref3-cutaway-mechanism",
    "r4": "ref4-minimal-ui",
    "minimal-ui": "ref4-minimal-ui",
    "motion-ui": "ref4-minimal-ui",
    "ref4-minimal-ui": "ref4-minimal-ui",
    "cream-editorial": "ref5-editorial-cutaway",
    "editorial-cutaway": "ref5-editorial-cutaway",
    "vox-explainer": "ref5-editorial-cutaway",
    "ref5-editorial-cutaway": "ref5-editorial-cutaway",
    "blueprint-mechanical": "ref1-tutorial-deck",
    "charcoal-terminal": "ref1-tutorial-deck",
    "fireship-kinetic": "ref1-tutorial-deck",
    "ref1-tutorial-deck": "ref1-tutorial-deck",
    "coffee-editorial": "coffee-editorial-3d",
    "coffee-editorial-3d": "coffee-editorial-3d",
    "cosmic-glass": "ref2-floating-glass",
    "ref2-floating-glass": "ref2-floating-glass",
    "ref3-pricing-voxel": "ref3-pricing-voxel",
    "dark-science": "neural-network",
    "apple-bento": "neural-network",
    "talking-head": "talking-head",
    "talkinghead": "talking-head",
    "presenter": "talking-head",
    "spokesperson": "talking-head",
    "neural-network": "neural-network",
}


def resolve_style_id(
    requested_style: str,
    default_style: str = "ref3-cutaway-mechanism",
    strict: bool = False,
) -> str:
    raw = (requested_style or "").strip().lower()
    if not raw or raw in ("auto-context", "auto"):
        return default_style
    if raw in STYLE_ALIAS_MAP:
        return STYLE_ALIAS_MAP[raw]
    if raw in STYLE_GALLERY_MAP:
        return raw
    # Unrestricted style selection: never block custom or procedural style names
    return raw if raw else default_style


def get_style_spec(style_mode: str) -> dict:
    resolved = resolve_style_id(style_mode)
    return STYLE_GALLERY_MAP.get(resolved, STYLE_GALLERY_MAP["ref3-cutaway-mechanism"])


# RAR14: Dynamic locale support — locale-aware font and caption configuration for the rendering engine
LOCALE_FONT_MAP = {
    "id-ID": {
        "heading_font": "sans",
        "body_font": "sans",
        "mono_font": "mono",
        "voice_id": "id-ID-GadisNeural",  # Fixed: Default natural female voice
    },
    "en-US": {
        "heading_font": "sans",
        "body_font": "serif",
        "mono_font": "mono",
        "voice_id": "en-US-AndrewNeural",
    },
    "default": {
        "heading_font": "sans",
        "body_font": "sans",
        "mono_font": "mono",
        "voice_id": "id-ID-GadisNeural",  # Fixed: Default natural female voice
    },
}


def get_locale_config(locale: str = "id-ID") -> dict:
    """RAR14: Return locale-aware font and caption configuration for a given locale."""
    return LOCALE_FONT_MAP.get(locale, LOCALE_FONT_MAP["default"])


def normalize_transition_spec(raw_transition: str | dict | None, default_type: str = "crossfade") -> dict:
    """
    F07: Validates and normalizes transition specification.
    Rejects unknown transition motifs explicitly if strict, or records a structured warning.
    """
    if isinstance(raw_transition, dict):
        t_raw = str(raw_transition.get("type") or default_type).strip().lower()
        canonical = TRANSITION_ALIAS_MAP.get(t_raw)
        if not canonical:
            raise ValueError(f"Unknown transition type '{t_raw}'. Supported: {sorted(VALID_TRANSITION_TYPES)}")
        direction = str(raw_transition.get("direction") or ("up" if "up" in t_raw else ("right" if "right" in t_raw else "left")))
        return {
            "type": canonical,
            "raw_requested": t_raw,
            "duration_frames": max(4, min(30, int(raw_transition.get("duration_frames", 12)))),
            "direction": direction,
            "easing": str(raw_transition.get("easing", "ease-in-out-cubic")),
            "subject_anchor": str(raw_transition.get("subject_anchor", "center")),
        }

    t_raw = str(raw_transition or default_type).strip().lower()
    canonical = TRANSITION_ALIAS_MAP.get(t_raw)
    if not canonical:
        raise ValueError(f"Unknown transition motif '{t_raw}'. Supported: {sorted(VALID_TRANSITION_TYPES)}")
    direction = "up" if "up" in t_raw else ("down" if "down" in t_raw else ("right" if "right" in t_raw else "left"))
    return {
        "type": canonical,
        "raw_requested": t_raw,
        "duration_frames": 12 if canonical != "cut" else 0,
        "direction": direction,
        "easing": "ease-in-out-cubic",
        "subject_anchor": "center",
    }


def check_engine_preflight(
    requested_engine: str,
    workspace: Path | None = None,
    mode: str = "draft",
    required_features: list[str] | None = None,
) -> dict:
    """
    F04: Preflight capability check for requested rendering engine (`pillow` vs `remotion` vs `auto`).
    - In `final` mode (or when `--strict-engine` is set), if the requested engine or required features
      are unavailable, returns `ok: False` with an explicit reason instead of silently pretending.
    - In `draft` / `auto` mode, allows fallback to `pillow` while recording `requested_engine`,
      `actual_engine`, `fallback_reason`, and `missing_features`.
    """
    req = (requested_engine or os.environ.get("SHOTCRAFT_ENGINE") or "auto").strip().lower()
    if req == "cinema-pil":
        req = "pillow"
    if req not in ("auto", "pillow", "remotion"):
        return {
            "ok": False,
            "requested_engine": req,
            "actual_engine": None,
            "fallback_occurred": False,
            "fallback_reason": f"Unsupported engine '{req}'. Valid engines: auto, pillow, remotion.",
            "missing_features": [],
        }

    req_feats = list(required_features or [])
    missing_features = []
    for feat in req_feats:
        if feat in ("full_pbr_shader", "raytracing", "realtime_webgl_shader"):
            missing_features.append(feat)

    if missing_features and mode == "final":
        return {
            "ok": False,
            "requested_engine": req,
            "actual_engine": None,
            "fallback_occurred": False,
            "fallback_reason": f"Required features not supported by local renderers: {missing_features}",
            "missing_features": missing_features,
        }

    npx_ok = bool(shutil.which("npx"))
    remotion_pkg_ok = bool(workspace and (Path(workspace) / "node_modules" / "@remotion").is_dir())
    remotion_ready = npx_ok and remotion_pkg_ok

    if req == "remotion":
        if remotion_ready:
            return {
                "ok": True,
                "requested_engine": "remotion",
                "actual_engine": "remotion",
                "fallback_occurred": False,
                "fallback_reason": None,
                "missing_features": missing_features,
                "capabilities": ENGINE_CAPABILITIES["remotion"],
            }
        reason = (
            "Remotion CLI (`npx` and `node_modules/@remotion`) is not installed in workspace."
            if not remotion_pkg_ok else "npx binary not found on PATH."
        )
        if mode == "final":
            return {
                "ok": False,
                "requested_engine": "remotion",
                "actual_engine": None,
                "fallback_occurred": False,
                "fallback_reason": reason,
                "missing_features": missing_features,
            }
        return {
            "ok": True,
            "requested_engine": "remotion",
            "actual_engine": "pillow",
            "fallback_occurred": True,
            "fallback_reason": f"{reason} Falling back to deterministic Pillow renderer in draft mode.",
            "missing_features": missing_features,
            "capabilities": ENGINE_CAPABILITIES["pillow"],
        }

    actual = "remotion" if (req == "auto" and os.environ.get("SHOTCRAFT_ENGINE") == "remotion" and remotion_ready) else "pillow"
    return {
        "ok": True,
        "requested_engine": req,
        "actual_engine": actual,
        "fallback_occurred": (req == "auto" and os.environ.get("SHOTCRAFT_ENGINE") == "remotion" and not remotion_ready),
        "fallback_reason": (
            "SHOTCRAFT_ENGINE=remotion was set but node_modules/@remotion is unavailable; using pillow."
            if (req == "auto" and os.environ.get("SHOTCRAFT_ENGINE") == "remotion" and not remotion_ready)
            else None
        ),
        "missing_features": missing_features,
        "capabilities": ENGINE_CAPABILITIES[actual],
    }



def clean_narration_leakage(text: str) -> str:
    """
    Fixes narration/prompt metadata leakage on screen and in TTS:
    Strips leaked labels like 'Narration:', 'Narasi:', 'NARATOR:', '[Scene 01]',
    stage directions in brackets, JSON key fragments, and SSML tags.
    """
    if not text:
        return ""
    s = str(text)
    s = re.sub(r"<[^>]+>", " ", s)
    # Strip speaker/script prefixes like "Narration:", "Narasi:", "Voiceover:", "VO:", "Scene 1 - Narration:"
    s = re.sub(
        r"^(?:\[?\s*(?:scene|shot|tahap|bagian)\s*\d+\s*\]?\s*[-:—]?\s*)*"
        r"(?:narration|narasi|narrator|narator|voiceover|vo|audio|script|teks|subcopy|caption|prompt)\s*[:=—-]+\s*",
        "",
        s,
        flags=re.IGNORECASE,
    )
    # Strip inline leaked labels like "(Narration: ...)" or "[Narasi: ...]" or "[SFX: ...]"
    s = re.sub(r"\[(?:narration|narasi|vo|sfx|bgm|musik|pause|jedah|intonasi|tone|emotion)[^\]]*\]", "", s, flags=re.IGNORECASE)
    s = re.sub(r"\((?:narration|narasi|vo|sfx|bgm|intonasi|nada)[^\)]*\)", "", s, flags=re.IGNORECASE)
    # Strip raw JSON/dict key leaks like '"narration":' or 'narration_text:'
    s = re.sub(r"[\"']?(?:narration_text|display_text|narration|subcopy|headline)[\"']?\s*:\s*", "", s, flags=re.IGNORECASE)
    s = re.sub(r"\s+", " ", s).strip().strip('"').strip("'")
    return s


def normalize_and_validate_scene_contract(
    scene: dict,
    idx: int = 0,
    default_subject_id: str = "system-mechanism",
    default_style_id: str = "ref3-cutaway-mechanism",
    fps: int = 30,
) -> dict:
    """
    Section 6: Normalizes a scene dictionary into the validated Shotcraft v9.7 Scene Contract
    while maintaining backward compatibility with flat fields used by existing templates.
    Separates:
    - Identity: id, subject_id, intent, assumption
    - Content: narration_text, display_text, factual_claims, sources
    - Visual: asset_id, mechanism_step, visual_style_id, layout_id
    - Motion: action, camera, transition_in, transition_out
    - Timing: start_frame, duration_frames, word_timestamps
    - Audio: voice_id, language, emotion, pronunciation_overrides, sfx_cues
    - Capability: required_features, renderer, fallback_policy
    """
    sc = dict(scene or {})
    sc_id = str(sc.get("id") or f"scene-{idx + 1:02d}")

    identity = sc.get("identity") if isinstance(sc.get("identity"), dict) else {}
    content = sc.get("content") if isinstance(sc.get("content"), dict) else {}
    visual = sc.get("visual") if isinstance(sc.get("visual"), dict) else {}
    motion = sc.get("motion") if isinstance(sc.get("motion"), dict) else {}
    timing = sc.get("timing") if isinstance(sc.get("timing"), dict) else {}
    audio = sc.get("audio") if isinstance(sc.get("audio"), dict) else {}
    capability = sc.get("capability") if isinstance(sc.get("capability"), dict) else {}

    subject_id = str(
        identity.get("subject_id")
        or sc.get("subjectId")
        or sc.get("subject_id")
        or default_subject_id
    )
    intent = str(identity.get("intent") or sc.get("intent") or "mechanism-explainer")
    assumption = str(identity.get("assumption") or sc.get("assumption") or "")

    raw_style = str(
        visual.get("visual_style_id")
        or sc.get("visualStyleId")
        or sc.get("visualMode")
        or default_style_id
    )
    visual_style_id = resolve_style_id(raw_style, default_style=default_style_id)
    style_spec = get_style_spec(visual_style_id)

    asset_id = str(
        visual.get("asset_id")
        or sc.get("assetId")
        or sc.get("cutawayKind")
        or subject_id
    )
    mechanism_step = str(
        visual.get("mechanism_step")
        or sc.get("mechanismStep")
        or f"step-{idx + 1}"
    )
    layout_id = str(
        visual.get("layout_id")
        or sc.get("layoutId")
        or ("cutaway-stage" if visual_style_id in ("ref3-cutaway-mechanism", "ref5-editorial-cutaway") else "structured-stage")
    )

    raw_narr = str(
        content.get("narration_text")
        or sc.get("narration")
        or sc.get("subcopy")
        or sc.get("headline")
        or ""
    )
    narration_text = clean_narration_leakage(raw_narr)
    raw_disp = str(
        content.get("display_text")
        or sc.get("displayText")
        or narration_text
    )
    display_text = clean_narration_leakage(raw_disp)
    factual_claims = list(content.get("factual_claims") or sc.get("factualClaims") or [])
    sources = list(content.get("sources") or sc.get("sources") or [])

    trans_in_raw = motion.get("transition_in") or sc.get("transitionIn") or sc.get("transitionMotif") or ("cut" if idx == 0 else "crossfade")
    trans_out_raw = motion.get("transition_out") or sc.get("transitionOut") or sc.get("transitionMotif") or "crossfade"
    trans_in = normalize_transition_spec(trans_in_raw, default_type="cut" if idx == 0 else "crossfade")
    trans_out = normalize_transition_spec(trans_out_raw, default_type="crossfade")

    action_spec = motion.get("action") or sc.get("action") or f"animate:{mechanism_step}"
    camera_spec = motion.get("camera") or sc.get("camera") or {
        "preset": style_spec.get("camera_preset", "focus-pull"),
        "target_component": mechanism_step,
        "zoom": 1.0,
    }

    dur_frames = max(30, int(timing.get("duration_frames") or sc.get("durationInFrames") or int(4.0 * fps)))
    start_frame = int(timing.get("start_frame") or sc.get("startFrame") or 0)
    word_timestamps = list(timing.get("word_timestamps") or sc.get("words") or [])

    lang = str(audio.get("language") or sc.get("language") or "id-ID")
    voice_id = str(audio.get("voice_id") or sc.get("voice") or ("en-US-AvaNeural" if lang.startswith("en") else "id-ID-GadisNeural"))
    emotion = str(audio.get("emotion") or sc.get("emotion") or "conversational")
    pron_overrides = dict(audio.get("pronunciation_overrides") or sc.get("pronunciationOverrides") or {})
    sfx_cues = list(audio.get("sfx_cues") or sc.get("sfxCues") or [])

    req_features = list(capability.get("required_features") or sc.get("requiredFeatures") or [])
    renderer_pref = str(capability.get("renderer") or sc.get("renderer") or "auto")
    fallback_policy = str(capability.get("fallback_policy") or sc.get("fallbackPolicy") or "report-and-fallback-in-draft")

    sc["id"] = sc_id
    sc["subjectId"] = subject_id
    sc["assetId"] = asset_id
    sc["mechanismStep"] = mechanism_step
    sc["visualStyleId"] = visual_style_id
    sc["visualMode"] = visual_style_id
    sc["layoutId"] = layout_id
    # Fixed: Separate Talking Head (Raw Video / Presenter -> 33 XML+MOGRT Premium Text presets)
    # from Motion/3D Procedural (clean built-in motion captions, or any user-selected preset)
    is_th_scene = (
        visual_style_id in ("talking-head", "talkinghead", "presenter", "spokesperson")
        or subject_id == "talking-head-presenter"
        or bool(sc.get("videoSrc") or sc.get("rawVideoPath") or visual.get("video_src"))
    )
    req_cap_raw = str(sc.get("captionStyle") or "").strip()
    if not req_cap_raw or req_cap_raw in ("karaoke-pill", "auto", "default"):
        if is_th_scene:
            sc["captionStyle"] = resolve_caption_style("", idx=idx, is_talking_head=True)
        else:
            spec_cap = style_spec.get("caption_style", "slide-up")
            if spec_cap in ("karaoke-pill", "", "auto"):
                sc["captionStyle"] = resolve_caption_style("", idx=idx, is_talking_head=False)
            else:
                sc["captionStyle"] = resolve_caption_style(spec_cap, idx=idx, is_talking_head=False)
    else:
        sc["captionStyle"] = resolve_caption_style(req_cap_raw, idx=idx, is_talking_head=is_th_scene)
    sc["durationInFrames"] = dur_frames
    sc["narration"] = narration_text
    sc["displayText"] = display_text
    if sc.get("headline"):
        sc["headline"] = clean_narration_leakage(str(sc["headline"]))
    if sc.get("subcopy"):
        sc["subcopy"] = clean_narration_leakage(str(sc["subcopy"]))
    if sc.get("eyebrow"):
        sc["eyebrow"] = clean_narration_leakage(str(sc["eyebrow"]))
    sc["language"] = lang
    sc["transitionMotif"] = trans_out["type"]
    sc["transitionIn"] = trans_in
    sc["transitionOut"] = trans_out
    # F03: Do not force decorative fake metrics if none were supplied
    if "metric" not in sc:
        sc["metric"] = ""
    if "unit" not in sc:
        sc["unit"] = ""

    sc["identity"] = {
        "id": sc_id,
        "subject_id": subject_id,
        "intent": intent,
        "assumption": assumption,
    }
    sc["content"] = {
        "narration_text": narration_text,
        "display_text": display_text,
        "factual_claims": factual_claims,
        "sources": sources,
    }
    sc["visual"] = {
        "asset_id": asset_id,
        "mechanism_step": mechanism_step,
        "visual_style_id": visual_style_id,
        "layout_id": layout_id,
    }
    sc["motion"] = {
        "action": action_spec,
        "camera": camera_spec,
        "transition_in": trans_in,
        "transition_out": trans_out,
    }
    sc["timing"] = {
        "start_frame": start_frame,
        "duration_frames": dur_frames,
        "word_timestamps": word_timestamps,
    }
    sc["audio"] = {
        "voice_id": voice_id,
        "language": lang,
        "emotion": emotion,
        "pronunciation_overrides": pron_overrides,
        "sfx_cues": sfx_cues,
    }
    sc["capability"] = {
        "required_features": req_features,
        "renderer": renderer_pref,
        "fallback_policy": fallback_policy,
    }
    return sc


# ============================================================================
# OPUS 5.5 PROCEDURAL CREATIVE-CODING MODES & DOCUMENTED VISUAL WORLDS
# (Fixes pebaikan claude.txt Sections 3.2, 3.3, Error #5, and Section 5)
# ============================================================================

OPUS_55_PROCEDURAL_MODES = {
    "cutaway-turbofan": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cyber-neon",
        "description": "Opus 5.5 3D High-Bypass Turbofan / Rotary Turbine Exploded Cutaway with volumetric streamlines.",
        "caption_style": "glitch",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "mechanical",
    },
    "wave-interference": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Opus 5.5 Multi-Source Phase Wave Interference & Harmonic Field Simulation.",
        "caption_style": "neon",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
    },
    "energy-waves": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cyber-neon",
        "description": "Opus 5.5 Radial Energy Spectrum & Oscillating Frequency Waves.",
        "caption_style": "neon",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
    },
    "speed-pulse": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cosmic-glass",
        "description": "Opus 5.5 High-Velocity Telemetry Gauge & Kinetic Speed Pulse.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
    },
    "supercomputer-core": {
        "family_id": "ref1-voxel-evidence",
        "world": "dark-science",
        "description": "Opus 5.5 Isometric 3D Voxel Compute Cluster & Tensor Core Matrix.",
        "caption_style": "glitch",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
    },
    "3d-isometric-growth": {
        "family_id": "ref1-voxel-evidence",
        "world": "dark-science",
        "description": "Opus 5.5 Procedural 3D Isometric City & Tower Growth Simulation.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
    },
    "stress-heatmap": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Opus 5.5 Finite-Element Thermal & Mechanical Stress Heatmap.",
        "caption_style": "karaoke-pill",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "mechanical",
    },
    "audio-reactive-rings": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Opus 5.5 Audio-Reactive Concentric Frequency Rings & Vocal Pulse.",
        "caption_style": "neon",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "glass",
    },
    "deconstructed-ui": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "Opus 5.5 Exploded Deconstructed UI Layers & Interactive Component Stack.",
        "caption_style": "minimal",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "minimal",
    },
    "dual-device-showreel": {
        "family_id": "ref4-minimal-ui",
        "world": "charcoal-terminal",
        "description": "Opus 5.5 Synchronized Desktop Browser + Mobile Viewport Product Showreel.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
    },
    "gear-train-cutaway": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cream-editorial",
        "description": "Opus 5.5 3D Mechanical Watch Escapement & Planetary Gear Train Cutaway.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "mechanical",
    },
    "optical-ray-cutaway": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Opus 5.5 Multi-Element Camera Lens Cutaway & Chromatic Raytracing Diagram.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "glass",
    },
    "bio-pulse-flow": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Opus 5.5 Hemodynamic Pulse & Vascular Flow Simulation.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "organic",
    },
    "matrix-bit-decoder": {
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "description": "Opus 5.5 Reed-Solomon QR Bit Matrix & Error-Correction Stepper.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "arcade",
    },
    "node-network": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Opus 5.5 Directed Force-Graph & Topology Node Network.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "scifi",
    },
    "algorithm-stepper": {
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "description": "Opus 5.5 State-Machine Algorithm & Memory Pointer Visualizer.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
    },
    "hud-terminal-neural": {
        "family_id": "ref1-voxel-evidence",
        "world": "cyber-neon",
        "description": "Opus 5.5 Cybernetic Bounding-Box Vision HUD & Telemetry Overlay.",
        "caption_style": "glitch",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
    },
    "retro-crt-shader": {
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "description": "Opus 5.5 Phosphor Scanline CRT Monitor & Retro Terminal Launch.",
        "caption_style": "typewriter",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "arcade",
    },
    "liquid-metaballs": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Opus 5.5 Iso-Surface Liquid Metaballs & Frosted Glass Morph.",
        "caption_style": "neon",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "dreamy",
    },
    "luxury-editorial-glass": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Luxury Editorial Serif + Frosted Glass & High-Contrast Telemetry.",
        "caption_style": "slide-up",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "glass",
    },
    "saas-product-launch": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "SaaS Product Launch & Feature Card Showcase.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
    },
    "ink-press-vertical": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "warm-paper",
        "description": "High-Contrast Editorial Ink-Press & Technical Engraving Print.",
        "caption_style": "minimal",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
    },
    "single-line-relay": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cream-editorial",
        "description": "Opus 5.5 Single-Line Continuous Vector Relay & Baton Path.",
        "caption_style": "minimal",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "minimal",
    },
    "halftone-eye-anchor": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "warm-paper",
        "description": "Opus 5.5 Halftone Iris Focus & Optical Anchor Reveal.",
        "caption_style": "minimal",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
    },
    "narrated-phrase-sync": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "Opus 5.5 Acoustic Phrase-Synced Kinetic Typography & Beat Cards.",
        "caption_style": "karaoke-pill",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
    },
    "timeline-camera-flight": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Opus 5.5 Z-Axis 3D Timeline Camera Flight & Milestone Portals.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "glass",
    },
    "chronicle-morph": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "cream-editorial",
        "description": "Opus 5.5 Era-to-Era Chronicle Shape Morph & Historical Dial.",
        "caption_style": "handwritten",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
    },
    "physics-pill-drop": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "Opus 5.5 Rigid-Body Gravity Pill Drop & Elastic Collision Stack.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
    },
    "deterministic-stepper": {
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "description": "Opus 5.5 Deterministic Frame-Clock Pipeline & State Verifier.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
    },
    "kaca-gelap": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Staikhouse #01 Kaca Gelap: Gelap (#121212), kaca buram (glassmorphism), bersih, aksen sian/biru lembut.",
        "caption_style": "mogrt-05-clean-apple",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "glass",
        "staikhouse_category": "Gelap & Teknologi",
    },
    "arang-lime": {
        "family_id": "ref1-tutorial-deck",
        "world": "charcoal-terminal",
        "description": "Staikhouse #02 Arang Lime: Editorial majalah bisnis santai, latar arang, judul serif besar di belakang kepala (rotoscope), satu kata aksen lime (#A3E635).",
        "caption_style": "mogrt-20-sliding-lime",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "staikhouse_category": "Gelap & Teknologi",
    },
    "futuristic": {
        "family_id": "ref1-voxel-evidence",
        "world": "cyber-neon",
        "description": "Staikhouse #03 Futuristic: Cyberpunk neon sian & magenta, kotak pembatas subjek, teks terminal monospace.",
        "caption_style": "xml-text4-tactic-cyber",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "staikhouse_category": "Gelap & Teknologi",
    },
    "rts-modern": {
        "family_id": "ref2-floating-glass",
        "world": "gold-luxury",
        "description": "Staikhouse #04 RTS Modern: Layar game strategi modern, panel kaca gelap dengan bingkai emas (#F59E0B) & indikator taktis.",
        "caption_style": "xml-text1-gold-bevel",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "mechanical",
        "staikhouse_category": "Gelap & Teknologi",
    },
    "sci-fi": {
        "family_id": "ref2-floating-glass",
        "world": "sapphire-blueprint",
        "description": "Staikhouse #05 Sci-Fi: Kokpit masa depan bersih, panel hologram biru muda & penomoran sekuens (01, 02).",
        "caption_style": "xml-text3-cobalt-cyan",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "staikhouse_category": "Gelap & Teknologi",
    },
    "paper-motion": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "Staikhouse #06 Paper Motion: Studio terang dot-grid, satu objek krom 3D per ide, lembaran kertas melayang & gerak pegas mantul.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "staikhouse_category": "Terang & Editorial",
    },
    "minimalism": {
        "family_id": "ref4-minimal-ui",
        "world": "minimal-offwhite-ui",
        "description": "Staikhouse #07 Minimalism: Poster desain Swiss monokrom hitam-putih tegas, banyak ruang kosong, titik aksen merah menyala.",
        "caption_style": "minimal",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "minimal",
        "staikhouse_category": "Terang & Editorial",
    },
    "roman-empire": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Staikhouse #08 Roman Empire: Dokumenter sejarah epik, latar perkamen gading, bingkai emas klasik & teks serif merah marun.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "staikhouse_category": "Terang & Editorial",
    },
    "variety-show": {
        "family_id": "ref2-cinematic-character",
        "world": "cream-editorial",
        "description": "Staikhouse #09 Variety Show!: Acara variety Korea reaktif, warna kuning cerah & magenta, teks efek suara (TAK!, JRENG!) ber-outline tebal.",
        "caption_style": "mogrt-02-bounce-green",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "staikhouse_category": "Ceria & Pop",
    },
    "blocks": {
        "family_id": "ref3-pricing-voxel",
        "world": "vox-grid",
        "description": "Staikhouse #10 Blocks: Balok mainan isometrik 3D warna pastel (biru muda, mint, kuning lembut) dengan sudut membulat.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "arcade",
        "staikhouse_category": "Ceria & Pop",
    },
    "y2k-desktop": {
        "family_id": "ref1-voxel-evidence",
        "world": "sapphire-blueprint",
        "description": "Staikhouse #11 Y2K Desktop: Jendela komputer retro tahun 2000-an (Win98/XP), kotak dialog perak, & bilah progres.",
        "caption_style": "typewriter",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "staikhouse_category": "Ceria & Pop",
    },
    "y2k-glam-pop": {
        "family_id": "ref2-floating-glass",
        "world": "magenta-sonic",
        "description": "Staikhouse #12 Y2K Glam Pop: Pop 2000-an bubblegum pink & magenta mengkilap, teks gelembung 3D & stiker kilau.",
        "caption_style": "xml-text2-magenta-stroke",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "glass",
        "staikhouse_category": "Ceria & Pop",
    },
    "retro-arcade": {
        "family_id": "ref1-voxel-evidence",
        "world": "crt-phosphor",
        "description": "Staikhouse #13 Retro Arcade: Game arcade 8-bit/16-bit penuh warna neon, health bar piksel & penghitung skor.",
        "caption_style": "glitch",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "arcade",
        "staikhouse_category": "Ceria & Pop",
    },
    "pop-magazine": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Staikhouse #14 Pop Magazine: Majalah tren pop modern kontras tinggi (kuning elektrik, biru kobalt, hot pink) & kolase foto.",
        "caption_style": "mogrt-24-super-trendy",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "staikhouse_category": "Ceria & Pop",
    },
    "comic-book": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "warm-paper",
        "description": "Staikhouse #15 Comic Book: Komik klasik CMYK pop-art dengan titik halftone Ben-Day, panel cerita & balon aksi.",
        "caption_style": "mogrt-25-trending-1-anton",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "staikhouse_category": "Ceria & Pop",
    },
    "kolase-kertas": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Staikhouse #16 Kolase Kertas: Explainer kolase potongan koran halftone abu-abu, sobekan kertas & sorotan spidol merah.",
        "caption_style": "typewriter",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "staikhouse_category": "Kertas & Tangan",
    },
    "doodle-art": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Staikhouse #17 Doodle Art: Buku catatan bergaris hidup dengan panah gambar tangan, stabilo kuning & tulisan tangan ramah.",
        "caption_style": "handwritten",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "organic",
        "staikhouse_category": "Kertas & Tangan",
    },
    "sketch-art": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "vox-grid",
        "description": "Staikhouse #18 Sketch Art: Buku gambar arsitek di atas kertas grafik/blueprint, garis pensil grafit & dimensi skala 1:1.",
        "caption_style": "minimal",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "minimal",
        "staikhouse_category": "Kertas & Tangan",
    },
    "coffee-lofi": {
        "family_id": "coffee-editorial-3d",
        "world": "coffee-editorial",
        "description": "Staikhouse #19 Coffee Lofi: Sudut kafe hangat saat hujan, tekstur meja kayu, sticky notes krem & noda cincin kopi.",
        "caption_style": "handwritten",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "staikhouse_category": "Kertas & Tangan",
    },
    "kertas-tipografi": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Staikhouse #20 Kertas & Tipografi: Dokumenter hangat untuk berita & opini, tekstur kertas krem, tinta gelap & coretan koreksi merah.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "staikhouse_category": "Kertas & Tangan",
    },
    "caption-news": {
        "family_id": "ref4-minimal-ui",
        "world": "charcoal-terminal",
        "description": "Awesome-Motion #01 Caption News (lemo-opuscar): Berita cepat yang tetap jelas tanpa suara, strap headline tegas, ticker data & grafik bar langsung.",
        "caption_style": "mogrt-25-trending-1-anton",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Edit & Documentary",
    },
    "live-countdown-grid": {
        "family_id": "ref1-voxel-evidence",
        "world": "cyber-neon",
        "description": "Awesome-Motion #02 Live Countdown Split-Screen: Satu sel membelah menjadi matriks 9 layar telemetri dengan jam hitung mundur presisi.",
        "caption_style": "xml-text4-tactic-cyber",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Edit & Documentary",
    },
    "visual-investigation": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Awesome-Motion #03 Visual Investigation: Dossier investigasi visual dengan bukti arsip, benang merah penghubung, & kronologi waktu.",
        "caption_style": "typewriter",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Edit & Documentary",
    },
    "constructivist-montage": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Awesome-Motion #04 Constructivist Montage: Montase geometris diagonal merah-hitam-krem bergaya poster konstruktivis.",
        "caption_style": "mogrt-25-trending-1-anton",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "mechanical",
        "motion_category": "Edit & Documentary",
    },
    "sports-telestrator": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "emerald-matrix",
        "description": "Awesome-Motion #05 Sports Telestrator: Analisis taktik freeze-frame dengan panah telestrator kuning menyala, zona radar & peta tembakan.",
        "caption_style": "mogrt-20-sliding-lime",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Edit & Documentary",
    },
    "broadcast-news-package": {
        "family_id": "ref4-minimal-ui",
        "world": "sapphire-blueprint",
        "description": "Awesome-Motion #06 Broadcast News Package: Paket siaran berita TV lengkap dengan rundown sidebar, lower-third strap & papan spesifikasi.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Edit & Documentary",
    },
    "satellite-briefing": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "sapphire-blueprint",
        "description": "Awesome-Motion #07 Satellite Briefing: Peta penginderaan jauh satelit dengan grid koordinat GPS, kontur topografi & pemindaian radar.",
        "caption_style": "typewriter",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Evidence Films",
    },
    "engineering-briefing-board": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "slate-studio",
        "description": "Awesome-Motion #08 Engineering Briefing Board: Papan perbandingan uji rekayasa 4 prototipe dengan matriks skor & simulasi beban.",
        "caption_style": "minimal",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "mechanical",
        "motion_category": "Evidence Films",
    },
    "lidar-survey": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "emerald-matrix",
        "description": "Awesome-Motion #09 LiDAR Survey: Pemindaian awan titik (point-cloud) laser 3D yang menyingkap struktur tersembunyi di bawah permukaan.",
        "caption_style": "neon",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Evidence Films",
    },
    "data-physicalization": {
        "family_id": "ref3-pricing-voxel",
        "world": "amber-forge",
        "description": "Awesome-Motion #10 Data Physicalization: Visualisasi data spiral 3D berlapis lempeng fisik di atas piringan kayu & logam.",
        "caption_style": "slide-up",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Evidence Films",
    },
    "exploded-teardown": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "sapphire-blueprint",
        "description": "Awesome-Motion #11 Exploded Teardown: Bedah komponen perangkat keras yang terurai secara radial (exploded view) lengkap dengan ukuran presisi.",
        "caption_style": "minimal",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "mechanical",
        "motion_category": "Evidence Films",
    },
    "microscope-story": {
        "family_id": "ref2-floating-glass",
        "world": "cyan-plasma",
        "description": "Awesome-Motion #12 Microscope Story: Kamera makro optik dari preparat kaca hingga inti seluler dengan penghitung piksel & cincin lensa.",
        "caption_style": "slide-up",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "glass",
        "motion_category": "Evidence Films",
    },
    "archive-light-table": {
        "family_id": "ref5-editorial-cutaway",
        "world": "gold-luxury",
        "description": "Awesome-Motion #13 Archive Light Table: Meja cahaya arsiparis dengan kaca pembesar (loupe) yang memeriksa klise foto & dokumen sejarah.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Evidence Films",
    },
    "whiteboard-explainer": {
        "family_id": "ref5-editorial-cutaway",
        "world": "vox-grid",
        "description": "Awesome-Motion #14 Whiteboard Explainer: Papan tulis bersih dengan diagram spidol hitam-biru-merah & rumus yang digambar bertahap.",
        "caption_style": "handwritten",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "minimal",
        "motion_category": "Hand-Drawn & Print",
    },
    "watercolor-brush": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Awesome-Motion #15 Watercolor Brush: Sapuan kuas cat air lembut di atas kertas bertekstur dengan gradasi warna organik.",
        "caption_style": "handwritten",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Hand-Drawn & Print",
    },
    "chinese-ink-wash": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Awesome-Motion #16 Chinese Ink Wash (Shanshui): Lukisan tinta hitam kaligrafi di atas kertas xuan dengan stempel merah tradisional.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Hand-Drawn & Print",
    },
    "ukiyo-e": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Awesome-Motion #17 Ukiyo-e Woodblock: Cetakan cukil kayu Jepang klasik dengan kontur gelombang biru Prusia & langit senja hangat.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Hand-Drawn & Print",
    },
    "papercut-lightbox": {
        "family_id": "ref2-floating-glass",
        "world": "amber-forge",
        "description": "Awesome-Motion #18 Paper-cut Lightbox (papercut-explainer): Kotak cahaya potongan kertas berlapis (multi-plane parallax) dengan pendar hangat dari belakang.",
        "caption_style": "slide-up",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Hand-Drawn & Print",
    },
    "risograph-print": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Awesome-Motion #19 Risograph Print: Cetakan risograf 3 tinta (fluorescent pink, biru elektrik, kuning) dengan tekstur grain & overprint.",
        "caption_style": "mogrt-24-super-trendy",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Hand-Drawn & Print",
    },
    "halftone-dossier": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Awesome-Motion #20 Halftone Dossier: Map berkas kasus bergaya cetakan titik halftone dengan stempel bukti & label klasifikasi.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Hand-Drawn & Print",
    },
    "swiss-motion-grid": {
        "family_id": "ref4-minimal-ui",
        "world": "vox-grid",
        "description": "Awesome-Motion #21 Swiss Motion Graphics: Grid tipografi Swiss presisi, satu warna sinyal oranye/merah, setiap pergerakan terkunci pada ketukan.",
        "caption_style": "minimal",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "minimal",
        "motion_category": "Graphic & Launch Motion",
    },
    "material-grid-3d": {
        "family_id": "ref3-pricing-voxel",
        "world": "slate-studio",
        "description": "Awesome-Motion #22 Material Grid 3D: Grid poster Swiss yang dimiringkan menjadi meja objek 3D berbahan tanah liat, kaca, krom & akrilik.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "glass",
        "motion_category": "Graphic & Launch Motion",
    },
    "onetake-fluid-flow": {
        "family_id": "ref2-floating-glass",
        "world": "cyan-plasma",
        "description": "Awesome-Motion #23 Onetake Continuous Flow (feitangyuan/onetake): Film satu bidikan tanpa putus (continuous camera) di mana setiap ide tumbuh dari bentuk sebelumnya.",
        "caption_style": "slide-up",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "dreamy",
        "motion_category": "Graphic & Launch Motion",
    },
    "dribbble-cursor-launch": {
        "family_id": "ref4-minimal-ui",
        "world": "indigo-glass",
        "description": "Awesome-Motion #24 Dribbble Product Launch (AbubakrChan/product-launch-motion): Kursor interaktif menggerakkan transisi pegas UI & morfologi bentuk ala video peluncuran SaaS.",
        "caption_style": "mogrt-05-clean-apple",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Graphic & Launch Motion",
    },
    "motionmaxxing-kinetic": {
        "family_id": "ref1-tutorial-deck",
        "world": "crimson-velocity",
        "description": "Awesome-Motion #25 Motionmaxxing Kinetic (Tejashmakwana/motionmaxxing): Tipografi kinetik berenergi tinggi, kurva kecepatan tajam, & aksen visual desainer motion.",
        "caption_style": "mogrt-09-devin-jatho-ult",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Graphic & Launch Motion",
    },
    "explainroo-fast": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "teal-architect",
        "description": "Awesome-Motion #26 Explainroo Fast Explainer (explainroo): Explainer visual cepat & kontras tinggi dengan kartu progres tahapan & ikon vektor tegas.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Graphic & Launch Motion",
    },
    "blueprint-patent": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "sapphire-blueprint",
        "description": "Awesome-Motion #27 Blueprint Patent (lemo-opuscar): Gambar paten biru sian (cyanotype) dengan garis konstruksi putih, panah ukuran & penampang terurai.",
        "caption_style": "typewriter",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "mechanical",
        "motion_category": "Graphic & Launch Motion",
    },
    "pictogram-motion": {
        "family_id": "ref4-minimal-ui",
        "world": "vox-grid",
        "description": "Awesome-Motion #28 Pictogram Motion: Piktogram geometris dinamis yang bergerak serempak mengikuti irama untuk menjelaskan aksi & konsep.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Graphic & Launch Motion",
    },
    "data-storytelling": {
        "family_id": "ref1-tutorial-deck",
        "world": "charcoal-terminal",
        "description": "Awesome-Motion #29 Data Storytelling (iart-ai/data-animation-skills): Grafik tren beranimasi presisi, kurva anomali & anotasi tonggak data.",
        "caption_style": "slide-up",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Information & Keynote",
    },
    "isometric-infographic": {
        "family_id": "ref3-pricing-voxel",
        "world": "teal-architect",
        "description": "Awesome-Motion #30 Isometric Infographic: Dunia infografis 3D isometrik yang menghubungkan hulu ke hilir dalam satu peta utuh.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Information & Keynote",
    },
    "dark-tech-keynote": {
        "family_id": "ref2-floating-glass",
        "world": "indigo-glass",
        "description": "Awesome-Motion #31 Dark Tech Keynote: Presentasi peluncuran produk bergaya Apple/Linear Keynote gelap dengan bento grid bercahaya.",
        "caption_style": "mogrt-05-clean-apple",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "glass",
        "motion_category": "Information & Keynote",
    },
    "chat-message-story": {
        "family_id": "ref4-minimal-ui",
        "world": "slate-studio",
        "description": "Awesome-Motion #32 Chat Message Story (iart-ai/text-message-video-skills): Animasi percakapan balon chat interaktif (iMessage/WhatsApp) dengan indikator mengetik.",
        "caption_style": "slide-up",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "minimal",
        "motion_category": "Information & Keynote",
    },
    "manim-3b1b-math": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "dark-science",
        "description": "Explainers #01 Manim 3Blue1Brown (adithya-s-k/manim_skill & 3brown1blue): Latar hitam pekat dengan bidang koordinat, kurva fungsi matematika sian/kuning, vektor & transformasi matriks.",
        "caption_style": "minimal",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "minimal",
        "motion_category": "Explainers & Science",
    },
    "khan-blackboard-pen": {
        "family_id": "ref1-tutorial-deck",
        "world": "charcoal-terminal",
        "description": "Explainers #03 Khan Academy Blackboard (haiderfarooq3/khan-explainer): Papan tulis hitam klasik dengan goresan pena kapur warna-warni (sian, kuning, magenta, hijau) bertahap.",
        "caption_style": "handwritten",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Explainers & Science",
    },
    "git-commit-tree": {
        "family_id": "ref1-voxel-evidence",
        "world": "charcoal-terminal",
        "description": "Explainers #04 Git Story Film & Diagram Tour (EverMind-AI/git-story-film): Pohon cabang commit Git, diff kode warna hijau/merah & alur arsitektur repositori.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Explainers & Science",
    },
    "arxiv-paper-breakdown": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Explainers #05 Paper2Video & PaperView (Lunamos/paper2video): Bedah jurnal ilmiah & makalah riset dengan blok abstrak, teorema & grafik bukti empiris.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "minimal",
        "motion_category": "Explainers & Science",
    },
    "zackd-curiosity-3d": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "sapphire-blueprint",
        "description": "Explainers #06 Zack D Films 3D Curiosity Cutaway: Simulasi 3D bedah anatomi/mekanisme ekstrem dengan kamera makro & penunjuk panah merah.",
        "caption_style": "mogrt-25-trending-1-anton",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "mechanical",
        "motion_category": "Explainers & Science",
    },
    "typewriter-vscode": {
        "family_id": "ref1-tutorial-deck",
        "world": "charcoal-terminal",
        "description": "Explainers #07 Typewriter VS Code (yammaku/typewriter-video): Editor kode VS Code gelap dengan nomor baris, syntax highlighting & kursor ketik aktif.",
        "caption_style": "typewriter",
        "bgm_track": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Explainers & Science",
    },
    "map-globe-route": {
        "family_id": "ref3-cutaway-mechanism",
        "world": "sapphire-blueprint",
        "description": "Explainers #08 Map Motion & Globe Route (SpaceZephyr/map-motion & iart-ai/map-animation-skills): Animasi rute peta GPS, garis penerbangan melengkung & titik lokasi berkedip.",
        "caption_style": "slide-up",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Explainers & Science",
    },
    "live-panel-architecture": {
        "family_id": "ref1-voxel-evidence",
        "world": "emerald-matrix",
        "description": "Explainers #09 Live Panel Architecture (ythx-101/live-panel-skill): Diagram arsitektur sistem yang terus berdenyut dengan telemetri trafik langsung.",
        "caption_style": "typewriter",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Explainers & Science",
    },
    "diary-comic-wipes": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Stories #10 Story-to-Handdrawn Diary Comic (gnipbao & liangdabiao): Komik buku harian 3 panel horizontal (teks -> sketsa hitam-putih -> ilustrasi penuh warna).",
        "caption_style": "handwritten",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "crayon-picture-book": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Stories #11 Crayon Picture Book (lemo-opuscar): Buku cerita bergambar tekstur krayon pastel hangat di atas kertas gambar tebal.",
        "caption_style": "handwritten",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "impasto-oil-canvas": {
        "family_id": "ref5-editorial-cutaway",
        "world": "gold-luxury",
        "description": "Stories #12 Impasto Oil Painting (lemo-opuscar & functional-emotions-video): Sapuan kuas cat minyak tebal bertekstur kanvas dengan kontras warna dramatis.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "shadow-puppetry-stage": {
        "family_id": "ref2-floating-glass",
        "world": "amber-forge",
        "description": "Stories #13 Shadow Puppetry Stage (lemo-opuscar): Panggung layar wayang kulit bercahaya hangat dari belakang dengan siluet dramatis.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "woodcut-copperplate": {
        "family_id": "ref5-editorial-cutaway",
        "world": "warm-paper",
        "description": "Stories #14 Woodcut & Copperplate Engraving (lemo-opuscar): Ukiran pelat tembaga & cukil kayu klasik dengan arsiran garis presisi.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "silkscreen-travel-poster": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Stories #15 Silkscreen Travel Poster (lemo-opuscar): Poster perjalanan cetak saring (sablon) berlapis warna senja, siluet pegunungan & tipografi retro.",
        "caption_style": "mogrt-22-smooth-fade-bebas",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "stained-glass-cathedral": {
        "family_id": "ref2-floating-glass",
        "world": "prism-dark",
        "description": "Stories #16 Stained Glass Window (lemo-opuscar): Jendela kaca patri mosaik berkilau dengan bingkai timah hitam & berkas cahaya warna-warni.",
        "caption_style": "xml-text1-gold-bevel",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "glass",
        "motion_category": "Stories, Cinema & Games",
    },
    "art-deco-golden": {
        "family_id": "ref2-floating-glass",
        "world": "gold-luxury",
        "description": "Stories #17 Art Deco 1930s Grand Hotel (lemo-opuscar): Ornamen geometris simetris emas & hitam mengkilap bergaya Art Deco tahun 1930-an.",
        "caption_style": "xml-text1-gold-bevel",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "glass",
        "motion_category": "Stories, Cinema & Games",
    },
    "spy-60s-title": {
        "family_id": "ref1-tutorial-deck",
        "world": "crimson-velocity",
        "description": "Stories #18 60s Spy Title Sequence (lemo-opuscar): Sekuens pembuka film mata-mata tahun 1960-an dengan potongan bentuk kontras tinggi & garis bidik.",
        "caption_style": "mogrt-22-smooth-fade-bebas",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Stories, Cinema & Games",
    },
    "rubber-hose-1930s": {
        "family_id": "ref2-cinematic-character",
        "world": "warm-paper",
        "description": "Stories #19 1930s Rubber Hose Cartoon (lemo-opuscar): Kartun klasik tahun 1930-an bernuansa sepia/vintage dengan mata pie-cut & gerak memantul.",
        "caption_style": "mogrt-02-bounce-green",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Stories, Cinema & Games",
    },
    "cel-anime-80s": {
        "family_id": "ref2-floating-glass",
        "world": "magenta-sonic",
        "description": "Stories #20 80s Cel Anime City Lights (lemo-opuscar): Estetika anime seluloid tahun 1987 dengan pantulan lampu neon kota malam & garis kecepatan.",
        "caption_style": "xml-text2-magenta-stroke",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Stories, Cinema & Games",
    },
    "pixel-rpg-16bit": {
        "family_id": "ref1-voxel-evidence",
        "world": "indigo-glass",
        "description": "Games #21 16-Bit Pixel RPG Save Point (lemo-opuscar & pixel-diary): Kotak dialog RPG 16-bit biru klasik dengan bar HP/MP, sprite piksel & menu status.",
        "caption_style": "typewriter",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Stories, Cinema & Games",
    },
    "hd-2d-diorama": {
        "family_id": "ref2-floating-glass",
        "world": "amber-forge",
        "description": "Games #22 HD-2D Torchlight Diorama (lemo-opuscar): Panggung diorama berlapis kedalaman dengan efek vignette bokeh & sumber cahaya obor hangat.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "ambient-dreamscape-72bpm.wav",
        "sfx_pack": "dreamy",
        "motion_category": "Stories, Cinema & Games",
    },
    "game-show-rhythm": {
        "family_id": "ref3-pricing-voxel",
        "world": "violet-quantum",
        "description": "Games #23 Game Show Flat & Microgame Frenzy (lemo-opuscar): Papan skor kuis panggung neon, indikator combo ritme & kartu rapor akhir.",
        "caption_style": "mogrt-24-super-trendy",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Stories, Cinema & Games",
    },
    "silent-film-1920s": {
        "family_id": "ref1-tutorial-deck",
        "world": "charcoal-terminal",
        "description": "Cinema #24 1920s Silent Film Intertitle (lemo-opuscar): Bingkai ornamen film bisu tahun 1920-an hitam-putih dengan efek grain proyektor & tipografi klasik.",
        "caption_style": "mogrt-15-hero-garamond",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "liminal-vhs-footage": {
        "family_id": "ref1-voxel-evidence",
        "world": "crt-phosphor",
        "description": "Cinema #25 Liminal Found Footage VHS (lemo-opuscar): Tampilan camcorder VHS dengan timestamp REC berkedip, garis tracking & pencahayaan kuning fluoresen.",
        "caption_style": "glitch",
        "bgm_track": "suspense-tech-110bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Stories, Cinema & Games",
    },
    "brick-toy-lego": {
        "family_id": "ref3-pricing-voxel",
        "world": "vox-grid",
        "description": "Materials #26 Brick Toy Modular (lemo-opuscar): Balok susun 3D lengkap dengan tonjolan stud silinder di bagian atas seperti mainan konstruksi.",
        "caption_style": "karaoke-pill",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "arcade",
        "motion_category": "Stories, Cinema & Games",
    },
    "paper-popup-book": {
        "family_id": "ref5-editorial-cutaway",
        "world": "cream-editorial",
        "description": "Materials #27 Paper Pop-Up Book (lemo-opuscar): Buku pop-up 3D yang terbuka di atas meja dengan lipatan kertas tegak berlapis.",
        "caption_style": "handwritten",
        "bgm_track": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
        "motion_category": "Stories, Cinema & Games",
    },
    "podcast-audiogram-wave": {
        "family_id": "ref2-floating-glass",
        "world": "magenta-sonic",
        "description": "Social & Music #28 Podcast Audiogram & Music MV (podcast-to-video & youtube-video-skills): Spektrum gelombang audio melingkar/bar simetris dengan kartu pembicara & lirik.",
        "caption_style": "neon",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Social, Avatars & Music MV",
    },
    "reddit-thread-story": {
        "family_id": "ref4-minimal-ui",
        "world": "charcoal-terminal",
        "description": "Social #29 Reddit / X Thread Story Card (purffle-shorts & SoloMCN): Kartu utas media sosial lengkap dengan tombol upvote, lencana penulis & komentar berantai.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Social, Avatars & Music MV",
    },
    "vocaloid-lyric-mv": {
        "family_id": "ref2-floating-glass",
        "world": "violet-quantum",
        "description": "Music MV #30 Vocaloid Kinetic Lyric MV (vocaloid-style-mv-pipeline & PDoomVideo): Tipografi lirik kinetik diagonal berenergi tinggi dengan partikel bintang & equalizer.",
        "caption_style": "xml-text5-purple-shimmer",
        "bgm_track": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
        "motion_category": "Social, Avatars & Music MV",
    },
    "appstore-device-showcase": {
        "family_id": "ref4-minimal-ui",
        "world": "indigo-glass",
        "description": "Promo #31 App Store & Play Store Device Showcase (trunghaiy/appshot & surajshetty3416/demo-video-skill): Bingkai perangkat iPhone/MacBook 3D dengan lencana fitur & rating bintang.",
        "caption_style": "mogrt-05-clean-apple",
        "bgm_track": "kinetic-120bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Promo & App Demos",
    },
    "ai-presenter-studio": {
        "family_id": "ref2-floating-glass",
        "world": "slate-studio",
        "description": "Avatars #32 AI Presenter Broadcast Studio (lanshu-create-ai-presenter-video & avatar-mix): Bingkai presenter avatar bundar/potret di samping layar presentasi & teleprompter.",
        "caption_style": "xml-text1-gold-bevel",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
        "motion_category": "Social, Avatars & Music MV",
    },
    "kurzgesagt-flat-cosmos": {
        "family_id": "ref2-floating-glass",
        "world": "cosmic-glass",
        "description": "Explainers #02 Kurzgesagt Flat Cosmos (animated-explainer-skills): Ilustrasi vektor datar warna kosmik vibrant, planet & orbit berlapis dengan koreografi pegas.",
        "caption_style": "slide-up",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "dreamy",
        "motion_category": "Explainers & Science",
    },
    "mascot-story": {
        "family_id": "ref2-cinematic-character",
        "world": "tape-mascot",
        "description": "Opus 5.5 Expressive Mascot Character Arc & Storyboard Stage.",
        "caption_style": "karaoke-pill",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "organic",
    },
}

for _om_key, _om_spec in OPUS_55_PROCEDURAL_MODES.items():
    base_fam = STYLE_FAMILIES.get(_om_spec["family_id"], STYLE_FAMILIES["ref3-cutaway-mechanism"])
    STYLE_GALLERY_MAP[_om_key] = {**base_fam, **_om_spec, "mode_id": _om_key, "representation": "procedural-3d"}
    STYLE_ALIAS_MAP[_om_key] = _om_key

for _eng_key in ("pillow", "remotion"):
    if _eng_key in ENGINE_CAPABILITIES:
        _existing_fams = list(ENGINE_CAPABILITIES[_eng_key].get("supported_style_families", []))
        for _om_k in OPUS_55_PROCEDURAL_MODES.keys():
            if _om_k not in _existing_fams:
                _existing_fams.append(_om_k)
        ENGINE_CAPABILITIES[_eng_key]["supported_style_families"] = _existing_fams
        _existing_subj = list(ENGINE_CAPABILITIES[_eng_key].get("supported_subjects", []))
        for _extra_s in ("combustion-fire-triangle", "software-api-system", "diesel-engine-vehicle", "building-structure"):
            if _extra_s not in _existing_subj:
                _existing_subj.append(_extra_s)
        ENGINE_CAPABILITIES[_eng_key]["supported_subjects"] = _existing_subj


# Ensure all documented world names in `pebaikan claude.txt` Error #5 & Section 5 resolve directly as valid `--style` choices!
for _world_alias, _target_style in {
    "cosmic-glass": "ref2-floating-glass",
    "dark-science": "wave-interference",
    "charcoal-terminal": "ref1-tutorial-deck",
    "cream-editorial": "ref5-editorial-cutaway",
    "coffee-editorial": "coffee-editorial-3d",
    "tape-mascot": "ref2-cinematic-character",
    "cyber-neon": "cutaway-turbofan",
    "warm-paper": "ink-press-vertical",
    "manim": "manim-3b1b-math",
    "3b1b": "manim-3b1b-math",
    "3blue1brown": "manim-3b1b-math",
    "kurzgesagt": "kurzgesagt-flat-cosmos",
    "khan": "khan-blackboard-pen",
    "khan-academy": "khan-blackboard-pen",
    "git-story": "git-commit-tree",
    "paper2video": "arxiv-paper-breakdown",
    "zackd": "zackd-curiosity-3d",
    "vscode": "typewriter-vscode",
    "map-motion": "map-globe-route",
    "live-panel": "live-panel-architecture",
    "diary-comic": "diary-comic-wipes",
    "crayon": "crayon-picture-book",
    "impasto": "impasto-oil-canvas",
    "shadow-puppet": "shadow-puppetry-stage",
    "woodcut": "woodcut-copperplate",
    "silkscreen": "silkscreen-travel-poster",
    "stained-glass": "stained-glass-cathedral",
    "art-deco": "art-deco-golden",
    "spy-60s": "spy-60s-title",
    "rubber-hose": "rubber-hose-1930s",
    "cel-anime": "cel-anime-80s",
    "pixel-rpg": "pixel-rpg-16bit",
    "hd-2d": "hd-2d-diorama",
    "game-show": "game-show-rhythm",
    "silent-film": "silent-film-1920s",
    "vhs": "liminal-vhs-footage",
    "brick-toy": "brick-toy-lego",
    "lego": "brick-toy-lego",
    "popup-book": "paper-popup-book",
    "audiogram": "podcast-audiogram-wave",
    "podcast": "podcast-audiogram-wave",
    "reddit-story": "reddit-thread-story",
    "vocaloid": "vocaloid-lyric-mv",
    "appshot": "appstore-device-showcase",
    "ai-avatar": "ai-presenter-studio",
    "onetake": "onetake-fluid-flow",
    "explainroo": "explainroo-fast",
    "motionmaxxing": "motionmaxxing-kinetic",
    "papercut": "papercut-lightbox",
    "papercut-explainer": "papercut-lightbox",
    "product-launch": "dribbble-cursor-launch",
    "swiss-grid": "swiss-motion-grid",
    "material-grid": "material-grid-3d",
    "whiteboard": "whiteboard-explainer",
    "watercolor": "watercolor-brush",
    "ink-wash": "chinese-ink-wash",
    "risograph": "risograph-print",
    "blueprint": "blueprint-patent",
    "keynote": "dark-tech-keynote",
    "chat-story": "chat-message-story",
    "text-message": "chat-message-story",
    "lidar": "lidar-survey",
    "teardown": "exploded-teardown",
    "telestrator": "sports-telestrator",
    "kaca_gelap": "kaca-gelap",
    "arang_lime": "arang-lime",
    "rts_modern": "rts-modern",
    "scifi": "sci-fi",
    "paper_motion": "paper-motion",
    "roman_empire": "roman-empire",
    "variety_show": "variety-show",
    "y2k_desktop": "y2k-desktop",
    "y2k_glam_pop": "y2k-glam-pop",
    "retro_arcade": "retro-arcade",
    "pop_magazine": "pop-magazine",
    "maximalism": "pop-magazine",
    "k-pop": "y2k-glam-pop",
    "kpop": "y2k-glam-pop",
    "comic_book": "comic-book",
    "kolase_kertas": "kolase-kertas",
    "doodle_art": "doodle-art",
    "sketch_art": "sketch-art",
    "coffee_lofi": "coffee-lofi",
    "kertas_tipografi": "kertas-tipografi",
    "kertas-dan-tipografi": "kertas-tipografi",
}.items():
    STYLE_ALIAS_MAP[_world_alias] = _target_style
    if _world_alias not in STYLE_GALLERY_MAP:
        STYLE_GALLERY_MAP[_world_alias] = {**STYLE_GALLERY_MAP[_target_style], "world": _world_alias}

ALL_VALID_STYLE_CHOICES = sorted(set(list(STYLE_GALLERY_MAP.keys()) + list(STYLE_ALIAS_MAP.keys()) + ["auto", "auto-context", "showcase-all-styles", "mix-4-refs"]))


# ============================================================================
# UNRESTRICTED CAPTION STYLES & ALIGHT MOTION XML / MOGRT PRESETS
# ============================================================================
# Complete 33 Premium Text.rar Presets (2 Alight Motion XML + 31 After Effects MOGRT) + 7 Built-in Styles
PREMIUM_TALKING_HEAD_PRESETS = [
    # File 1: Copy of Text Animation (1).xml (5 Alight Motion Text Layers)
    "xml-text1-gold-bevel",
    "xml-text2-magenta-stroke",
    "xml-text3-cobalt-cyan",
    "xml-text4-tactic-cyber",
    "xml-text5-purple-shimmer",
    # File 2: Copy of Text animation .xml (Alight Motion Ridges2 + UnifrakturCook)
    "xml2-ridges-purple",
    # Files 3-33: All 31 After Effects MOGRT Presets from Premium Text.rar
    "mogrt-01-blur-fade-shine",
    "mogrt-02-bounce-green",
    "mogrt-03-broken-shatter",
    "mogrt-04-cinematic-blur",
    "mogrt-05-clean-apple",
    "mogrt-06-davin-jatho-1",
    "mogrt-07-davin-jatho-2",
    "mogrt-08-davin-jatho-3",
    "mogrt-09-devin-jatho-ult",
    "mogrt-10-fast-wip",
    "mogrt-11-fast-wip-shine",
    "mogrt-12-flicker-glowing",
    "mogrt-13-flicker-shine",
    "mogrt-14-gradient-amber",
    "mogrt-15-hero-garamond",
    "mogrt-16-regular-clean",
    "mogrt-17-shadow-3d",
    "mogrt-18-shine-text",
    "mogrt-19-shiny-cyan",
    "mogrt-20-sliding-lime",
    "mogrt-21-smooth-cross",
    "mogrt-22-smooth-fade-bebas",
    "mogrt-23-smooth-slide-teal",
    "mogrt-24-super-trendy",
    "mogrt-25-trending-1-anton",
    "mogrt-26-trending-2-arthemis",
    "mogrt-27-trending-3-proelium",
    "mogrt-28-viral-caption-1",
    "mogrt-29-viral-caption-2",
    "mogrt-30-white-bevel",
    "mogrt-31-metallic-script",
]

VALID_CAPTION_STYLES = list(PREMIUM_TALKING_HEAD_PRESETS) + [
    # Legacy aliases kept for 100% backward compatibility
    "xml-4color-gold",
    "xml-magenta-stroke",
    "xml-cyan-cobalt",
    "xml-cyber-longshadow",
    "xml-purple-shimmer",
    "xml-ridges-glow",
    "clean-apple",
    "viral-bounce",
    "cinematic-blur",
    "shiny-metallic",
    # 7 Built-in Motion Caption Styles
    "slide-up",
    "minimal",
    "neon",
    "handwritten",
    "typewriter",
    "glitch",
    "karaoke-pill",
]

CAPTION_STYLE_ALIAS_MAP = {
    "default": "slide-up",
    "auto": "slide-up",
    "karaoke": "karaoke-pill",
    "pill": "karaoke-pill",
    "slide": "slide-up",
    "slide_up": "slide-up",
    "type": "typewriter",
    "terminal": "typewriter",
    "code": "typewriter",
    "script": "handwritten",
    "serif": "handwritten",
    "cyber": "neon",
    "glow": "neon",
    "xml": "xml-text1-gold-bevel",
    "xml-gold": "xml-text1-gold-bevel",
    "4color-gold": "xml-text1-gold-bevel",
    "gold-bevel": "xml-text1-gold-bevel",
    "xml-4color-gold": "xml-text1-gold-bevel",
    "xml-magenta": "xml-text2-magenta-stroke",
    "magenta-stroke": "xml-text2-magenta-stroke",
    "xml-magenta-stroke": "xml-text2-magenta-stroke",
    "xml-cyan": "xml-text3-cobalt-cyan",
    "cyan-cobalt": "xml-text3-cobalt-cyan",
    "xml-cyan-cobalt": "xml-text3-cobalt-cyan",
    "xml-cyber": "xml-text4-tactic-cyber",
    "cyber-longshadow": "xml-text4-tactic-cyber",
    "longshadow": "xml-text4-tactic-cyber",
    "xml-cyber-longshadow": "xml-text4-tactic-cyber",
    "xml-purple": "xml-text5-purple-shimmer",
    "purple-shimmer": "xml-text5-purple-shimmer",
    "shimmer": "xml-text5-purple-shimmer",
    "xml-purple-shimmer": "xml-text5-purple-shimmer",
    "xml-ridges": "xml2-ridges-purple",
    "ridges-glow": "xml2-ridges-purple",
    "xml-ridges-glow": "xml2-ridges-purple",
    "apple": "mogrt-05-clean-apple",
    "clean-apple": "mogrt-05-clean-apple",
    "bounce": "mogrt-02-bounce-green",
    "viral-bounce": "mogrt-02-bounce-green",
    "blur": "mogrt-04-cinematic-blur",
    "cinematic-blur": "mogrt-04-cinematic-blur",
    "metallic": "mogrt-31-metallic-script",
    "shiny-metallic": "mogrt-19-shiny-cyan",
    "shiny": "mogrt-19-shiny-cyan",
    "davin-1": "mogrt-06-davin-jatho-1",
    "davin-2": "mogrt-07-davin-jatho-2",
    "davin-3": "mogrt-08-davin-jatho-3",
    "devin": "mogrt-09-devin-jatho-ult",
    "broken": "mogrt-03-broken-shatter",
    "hero": "mogrt-15-hero-garamond",
    "shadow": "mogrt-17-shadow-3d",
    "sliding": "mogrt-20-sliding-lime",
    "smooth-cross": "mogrt-21-smooth-cross",
    "smooth-fade": "mogrt-22-smooth-fade-bebas",
    "smooth-slide": "mogrt-23-smooth-slide-teal",
    "super-trendy": "mogrt-24-super-trendy",
    "trending-1": "mogrt-25-trending-1-anton",
    "trending-2": "mogrt-26-trending-2-arthemis",
    "trending-3": "mogrt-27-trending-3-proelium",
    "viral-1": "mogrt-28-viral-caption-1",
    "viral-2": "mogrt-29-viral-caption-2",
    "white": "mogrt-30-white-bevel",
}


def resolve_caption_style(raw_caption: str, idx: int = 0, is_talking_head: bool = False) -> str:
    """
    Resolves any caption style without restriction.
    - When `is_talking_head=True` (real raw video talking-head edit or talking-head mode),
      cycles across all 37 presets from the 33 files in `Premium Text.rar` by default.
    - When `is_talking_head=False` (procedural motion/3D mode), uses clean motion captions
      or any user-selected preset.
    """
    c = (raw_caption or "").strip().lower()
    if c in CAPTION_STYLE_ALIAS_MAP and c not in ("default", "auto"):
        return CAPTION_STYLE_ALIAS_MAP[c]
    if c in VALID_CAPTION_STYLES:
        return c
    if c and c not in ("default", "auto"):
        return c
    if is_talking_head:
        return PREMIUM_TALKING_HEAD_PRESETS[idx % len(PREMIUM_TALKING_HEAD_PRESETS)]
    std_rot = [
        "slide-up",
        "minimal",
        "neon",
        "handwritten",
        "typewriter",
        "glitch",
    ]
    return std_rot[idx % len(std_rot)]

# ============================================================================
# MAKE A STYLE YOUR OWN (lemo-opuscar MY-STYLES Engine)
# ============================================================================
def _get_my_styles_path() -> Path:
    return Path(__file__).resolve().parent / "my_styles.json"


def load_user_custom_styles() -> dict:
    p = _get_my_styles_path()
    if p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, spec in data.items():
                    if isinstance(spec, dict):
                        OPUS_55_PROCEDURAL_MODES[k] = spec
                        base_f = STYLE_FAMILIES.get(spec.get("family_id", "ref3-cutaway-mechanism"), STYLE_FAMILIES["ref3-cutaway-mechanism"])
                        STYLE_GALLERY_MAP[k] = {**base_f, **spec, "mode_id": k, "representation": "procedural-3d", "is_custom_user_style": True}
                        STYLE_ALIAS_MAP[k] = k
                        if k not in ALL_VALID_STYLE_CHOICES:
                            ALL_VALID_STYLE_CHOICES.append(k)
                return data
        except Exception:
            pass
    return {}


def save_user_custom_style(
    name: str,
    base_style: str = "kaca-gelap",
    world: str = "",
    caption_style: str = "",
    accent_color: str = "",
    font_family: str = "",
    bgm_track: str = "",
    sfx_pack: str = "",
    description: str = "",
) -> dict:
    clean_name = re.sub(r"[^a-z0-9_-]", "-", name.strip().lower()).strip("-")
    if not clean_name:
        raise ValueError("Style name cannot be empty")
    resolved_base = resolve_style_id(base_style, default_style="ref3-cutaway-mechanism")
    base_spec = dict(OPUS_55_PROCEDURAL_MODES.get(resolved_base) or STYLE_GALLERY_MAP.get(resolved_base) or {})
    new_spec = {
        "family_id": base_spec.get("family_id", "ref3-cutaway-mechanism"),
        "base_style": resolved_base,
        "world": world or base_spec.get("world", "dark-science"),
        "description": description or f"Custom User Style '{clean_name}' (derived from {resolved_base})",
        "caption_style": caption_style or base_spec.get("caption_style", "slide-up"),
        "bgm_track": bgm_track or base_spec.get("bgm_track", "explainer-groove-104bpm.wav"),
        "sfx_pack": sfx_pack or base_spec.get("sfx_pack", "studio"),
        "accent_color": accent_color or base_spec.get("accent_color", "#38BDF8"),
        "font_family": font_family or base_spec.get("font_family", ""),
        "motion_category": "Custom User Styles (My-Styles)",
    }
    existing = load_user_custom_styles()
    existing[clean_name] = new_spec
    for target_json in (
        Path(__file__).resolve().parent / "my_styles.json",
        Path(__file__).resolve().parent.parent.parent / "reels-templates" / "scripts" / "my_styles.json",
        Path(__file__).resolve().parent.parent.parent / "mcp" / "core" / "my_styles.json",
    ):
        try:
            target_json.parent.mkdir(parents=True, exist_ok=True)
            target_json.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
    load_user_custom_styles()
    return {"ok": True, "style_id": clean_name, "spec": new_spec}


load_user_custom_styles()
