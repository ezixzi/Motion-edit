#!/usr/bin/env python3
"""
Shotcraft Pro MCP Server #3: `shotcraft-media` (v9.7.0 Turbo)
Dedicated Media Processing, Drop-Folder Auto-Editor, Indonesian TTS Narration,
16-Category Procedural SFX/BGM Studio, and 3D Depth Parallax Engine for Claude Code.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import json
import sys
from pathlib import Path

from shotcraft_mcp_server import PROTOCOL_VERSION, get_skills_dir, run_quiet, send_response

SERVER_NAME = "shotcraft-media"
SERVER_VERSION = "9.7.0"

TOOLS = [
    {
        "name": "media_auto_folder",
        "description": "One-command Drop-Folder Auto-Editor: scans a folder containing Voiceover (.mp3/.wav/.m4a), Raw Video (.mp4/.mov), or Images (.png/.jpg), auto-cuts dead air (>0.45s below -35dB), builds a storyboard (`timeline.json`), slices 3D depth clips, and (when `render_final_mp4=true`) renders + audits the finished 1080x1920 MP4 in 1 call!",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_dir": {"type": "string", "description": "Folder containing raw voiceover, video, or images"},
                "out_dir": {"type": "string", "description": "Target workspace directory"},
                "aspect": {"type": "string", "enum": ["9:16", "16:9", "1:1"], "default": "9:16"},
                "style": {
                    "type": "string",
                    "enum": ["ref1-tutorial-deck", "ref2-floating-glass", "ref3-pricing-voxel", "ref4-tape-mascot", "mix-4-refs", "neural-network"],
                    "default": "ref1-tutorial-deck",
                },
                "generate_3d_clips": {"type": "boolean", "default": True},
                "render_final_mp4": {"type": "boolean", "default": True},
                "output_mp4": {"type": "string", "description": "Optional output MP4 path"},
            },
            "required": ["input_dir", "out_dir"],
        },
    },
    {
        "name": "media_narrate_tts",
        "description": "Synthesize Indonesian narration with automatic offline fallback (`auto`/`local-synth`/`edge`/`elevenlabs`/`piper`), Indonesian number normalization (`terbilang`), word-level karaoke `remotion-subtitles.json`, and BGM auto-ducking.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "manifest_json": {"type": "string", "description": "Path to narration_manifest.json"},
                "out_dir": {"type": "string", "description": "Output directory for narration.wav and subtitles"},
                "allow_cloud": {"type": "boolean", "default": False},
                "strict_provider": {"type": "boolean", "default": False},
                "model": {"type": "string", "description": "Local Piper model path"},
                "voice": {"type": "string"},
                "provider": {"type": "string", "enum": ["auto", "coqui", "edge", "gtts-http", "elevenlabs", "piper", "os-native", "local-synth"], "default": "auto"},
                "bgm_wav": {"type": "string"},
                "duck_db": {"type": "number", "default": -10.0},
            },
            "required": ["manifest_json", "out_dir"],
        },
    },
    {
        "name": "media_sfx_studio",
        "description": "Initialize the 32 WAV SFX (16 categories) + 4 BGM loops library or mix frame-accurate audio cues from `timeline.json` into a stereo master WAV with auto-ducked BGM.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "timeline_or_cues": {"type": "string", "description": "Path to timeline.json or audio-cues.json"},
                "output_wav": {"type": "string", "description": "Output mixed WAV path"},
                "duration": {"type": "number", "default": 15.0},
                "fps": {"type": "number", "default": 30.0},
                "narration_wav": {"type": "string"},
                "bgm_wav": {"type": "string"},
                "duck_db": {"type": "number", "default": -10.0},
            },
            "required": ["timeline_or_cues", "output_wav"],
        },
    },
    {
        "name": "media_depth_3d",
        "description": "Convert a static 2D image into a 3D depth-parallax MP4 clip (8 camera presets + DoF rack focus) or export 3 multi-plane RGBA layers (`foreground.png`, `midground.png`, `background.png`, `depth_map.png`).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_image": {"type": "string"},
                "output_mp4": {"type": "string"},
                "export_layers_dir": {"type": "string"},
                "preset": {
                    "type": "string",
                    "enum": [
                        "cinematic-orbit",
                        "dolly-push",
                        "vertigo-contra-zoom",
                        "crane-rise",
                        "parallax-drift",
                        "breathing-float",
                        "cutaway-peel",
                        "hero-pullback",
                    ],
                    "default": "cinematic-orbit",
                },
                "frames": {"type": "integer", "default": 90},
                "fps": {"type": "integer", "default": 30},
            },
            "required": ["input_image"],
        },
    },
]


def handle_tool_call(name: str, args: dict) -> dict:
    sd = get_skills_dir()

    if name == "media_auto_folder":
        script = sd / "reels-auto-editor" / "scripts" / "auto_media_pipeline.py"
        cmd = [
            sys.executable,
            str(script),
            "--input-dir",
            args["input_dir"],
            "--out-dir",
            args["out_dir"],
            "--aspect",
            args.get("aspect", "9:16"),
            "--style",
            args.get("style", "ref1-tutorial-deck"),
        ]
        if args.get("generate_3d_clips", True):
            cmd.append("--generate-3d-clips")
        if args.get("render_final_mp4", True):
            cmd.append("--render-mp4")
        if args.get("output_mp4"):
            cmd.extend(["--output-mp4", args["output_mp4"]])
        return run_quiet(cmd)

    if name == "media_narrate_tts":
        narr_script = sd / "reels-narration" / "scripts" / "narrate.py"
        cmd = [
            sys.executable,
            str(narr_script),
            "--manifest",
            args["manifest_json"],
            "--out-dir",
            args["out_dir"],
            "--provider",
            args.get("provider", "auto"),
            "--normalize-id",
            "--overwrite",
            "--duck-db",
            str(args.get("duck_db", -10.0)),
        ]
        if args.get("bgm_wav"):
            cmd.extend(["--bgm", args["bgm_wav"]])
        if args.get('allow_cloud'): cmd.append('--allow-cloud')
        if args.get('strict_provider'): cmd.append('--strict-provider')
        if args.get('model'): cmd.extend(['--model', args['model']])
        if args.get('voice'): cmd.extend(['--voice', args['voice']])
        return run_quiet(cmd)

    if name == "media_sfx_studio":
        sfx_script = sd / "reels-sfx-studio" / "scripts" / "sfx_engine.py"
        cmd = [
            sys.executable,
            str(sfx_script),
            "--mix-timeline",
            args["timeline_or_cues"],
            "--output",
            args["output_wav"],
            "--duration",
            str(args.get("duration", 15.0)),
            "--fps",
            str(args.get("fps", 30.0)),
            "--duck-db",
            str(args.get("duck_db", -10.0)),
        ]
        if args.get("narration_wav"):
            cmd.extend(["--narration", args["narration_wav"]])
        if args.get("bgm_wav"):
            cmd.extend(["--bgm", args["bgm_wav"]])
        return run_quiet(cmd)

    if name == "media_depth_3d":
        script = sd / "reels-depth-motion" / "scripts" / "depth_engine.py"
        cmd = [
            sys.executable,
            str(script),
            "--input",
            args["input_image"],
            "--preset",
            args.get("preset", "cinematic-orbit"),
            "--frames",
            str(args.get("frames", 90)),
            "--fps",
            str(args.get("fps", 30)),
        ]
        if args.get("output_mp4"):
            cmd.extend(["--output", args["output_mp4"]])
        if args.get("export_layers_dir"):
            cmd.extend(["--export-layers", args["export_layers_dir"]])
        return run_quiet(cmd)

    return {"ok": False, "error": f"Unknown tool: {name}"}


def main():
    from core.rpc import serve
    serve(SERVER_NAME, '9.8.1', TOOLS, handle_tool_call)


if __name__ == "__main__":
    main()
