#!/usr/bin/env python3
"""Shotcraft Pro v9.7.0 — Modular QA MCP Domain (`mcp/qa.py`, `[P3-3]`)."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import BaseMcpTool
import shotcraft_qa_mcp as _srv


class QaFullVerifyTool(BaseMcpTool):
    name = "qa_full_verify"
    description = "Full technical, LUFS/MOS audio, safe-zone, and ML retention verification."

    def execute(self, args: dict) -> dict:
        return _srv.handle_tool_call(self.name, args)


if __name__ == "__main__":
    _srv.main()
