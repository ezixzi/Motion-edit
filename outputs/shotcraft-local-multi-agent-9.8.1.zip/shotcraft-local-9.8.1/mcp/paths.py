from core.paths import get_claude_dir, get_skills_dir, get_repo_path
