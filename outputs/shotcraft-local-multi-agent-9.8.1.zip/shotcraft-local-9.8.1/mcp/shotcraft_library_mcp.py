#!/usr/bin/env python3
"""
Shotcraft Pro MCP Server #2: `shotcraft-library` (v9.7.0 Turbo)
Dedicated Zero-Token-Waste Catalog, Opus 5.5 Gallery & Viral Reference Preset MCP Server.
Allows Claude Code to search 150+ video-shotcraft shots, 24 Awesome Opus 5.5 recipes,
8 continuity recipes, 8 blueprint templates, and 4 viral reference styles (`ref1..ref4`)
in <50ms without reading large Markdown/JSON files into context.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import json
import tempfile
import sys
from pathlib import Path

from shotcraft_mcp_server import PROTOCOL_VERSION, get_repo_path, get_skills_dir, run_quiet, send_response

SERVER_NAME = "shotcraft-library"
SERVER_VERSION = "9.7.0"

REFERENCE_STYLE_CATALOG = {
    "ref1-tutorial-deck": {
        "id": "ref1-tutorial-deck",
        "title": "Reference #1: @galihry Remotion × Claude Dark Dot-Grid Terminal Deck",
        "best_for": ["Tutorial coding/CLI", "Panduan langkah demi langkah", "Workflow developer"],
        "visual_elements": [
            "Dark dot-grid canvas (#121210) + radial ambient glow",
            "Top brand pills [✳ REMOTION × CLAUDE] & [✳ Brand]",
            "Step badge [1 LANGKAH] + 2-tone uppercase headline",
            "macOS terminal window with CLI commands, animated progress bar, and tilted sticker [WAJIB!]",
            "Bottom word-by-word dim-to-lit uppercase karaoke subtitle",
        ],
    },
    "ref2-floating-glass": {
        "id": "ref2-floating-glass",
        "title": "Reference #2: Talking-Head Studio + Upper Headroom Floating Frosted Glass UI",
        "best_for": ["Konten edukasi kreator", "Tips AI & produktivitas", "Monolog talking-head"],
        "visual_elements": [
            "Lower studio creator silhouette (y: 660..1920) leaving upper headroom 100% clear",
            "Upper floating frosted glass card (y: 230..590) with blur & subtle border",
            "Purple-pink-cyan gradient headline + numbered glass pills [1 · Claude] [2 · Guidebook]",
            "Bottom high-contrast word karaoke subtitle over torso",
        ],
    },
    "ref3-pricing-voxel": {
        "id": "ref3-pricing-voxel",
        "title": "Reference #3: @classai_id Split-Screen Browser Pricing Inspector + 3D Voxel Presenter",
        "best_for": ["Listicle 5 layanan gratis / top tools", "Bedah harga website / SaaS", "Review platform tech"],
        "visual_elements": [
            "Dark blueprint grid (#060A12) + giant chapter number (01..05) + service icon",
            "Browser pricing card with highlighted feature row + floating metric pill [∞ GRATIS]",
            "Middle electric-blue speech caption",
            "Bottom 3D Voxel presenter character wearing blue beanie pointing up at the browser card",
        ],
    },
    "ref4-tape-mascot": {
        "id": "ref4-tape-mascot",
        "title": "Reference #4: 3D Blocky Claude Mascot at Desk + Masking-Tape Banner & Torn-Paper Stickers",
        "best_for": ["Reels 'Pasang 3 Skill Ini'", "Showcase fitur singkat & mencolok", "Storytelling maskot 3D"],
        "visual_elements": [
            "Top cream masking-tape ribbon banner [CLAUDE JADI VIDEO EDITOR KAMU]",
            "3D blocky terracotta Claude mascot at studio desk + dark monitor with animated timeline bars",
            "Middle cream hole-punch skill card with orange circular number badge (1)(2)(3)",
            "Bottom tilted terracotta & cream torn-paper ransom word stickers",
        ],
    },
    "mix-4-refs": {
        "id": "mix-4-refs",
        "title": "Combo Showreel: Rotates across Ref #1, Ref #3, and Ref #4 per scene",
        "best_for": ["Showreel dinamis", "Video edukasi multi-gaya yang anti-bosan"],
        "visual_elements": ["Scene 1: ref1-tutorial-deck", "Scene 2: ref3-pricing-voxel", "Scene 3: ref4-tape-mascot"],
    },
}

TOOLS = [
    {
        "name": "library_search_all",
        "description": "Fast keyword search across 150+ video-shotcraft shots, 24 Opus 5.5 procedural recipes, 8 continuity recipes, and 8 blueprint templates. Returns compact JSON matches (<200 tokens).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search keywords in Indonesian or English (e.g. 'otak', 'terminal', 'cutaway', 'produk')"},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "library_opus_gallery",
        "description": "List, search, or fetch full recipe details from the bundled local yihui-dev/awesome-opus5-5-videos gallery (`reels-opus-craft/catalog.json`).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["list", "search", "get"], "default": "list"},
                "query": {"type": "string", "description": "Recipe ID (for get) or search query (for search)"},
                "limit": {"type": "integer", "default": 6},
            },
            "required": ["action"],
        },
    },
    {
        "name": "library_reference_styles",
        "description": "Inspect the 4 viral reference video styles (`ref1-tutorial-deck`, `ref2-floating-glass`, `ref3-pricing-voxel`, `ref4-tape-mascot`, `mix-4-refs`) and optionally generate a ready-to-render `scenes` array for a given topic.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "style": {
                    "type": "string",
                    "enum": ["all", "ref1-tutorial-deck", "ref2-floating-glass", "ref3-pricing-voxel", "ref4-tape-mascot", "mix-4-refs"],
                    "default": "all",
                },
                "generate_preset_for_topic": {"type": "string", "description": "Optional topic to auto-build a 3-scene preset JSON"},
                "duration": {"type": "number", "default": 12.0},
            },
        },
    },
]


def handle_tool_call(name: str, args: dict) -> dict:
    sd = get_skills_dir()
    repo = get_repo_path(sd)

    if name == "library_search_all":
        q = args.get("query", "remotion")
        lim = str(args.get("limit", 5))
        opus_script = sd / "reels-opus-craft" / "scripts" / "search_opus_prompts.py"
        res_opus = run_quiet([sys.executable, str(opus_script), "--query", q, "--limit", lim])
        find_script = sd / "shotcraft-local" / "scripts" / "find_motion.py"
        with tempfile.TemporaryDirectory(prefix='shotcraft-search-') as td:
            inv = str(Path(td) / 'inventory.json')
            discovery = run_quiet([sys.executable, str(sd/'shotcraft-local/scripts/discover.py'), '--repo', repo, '--out', inv])
            if not discovery.get('ok'):
                return discovery
            res_shot = run_quiet([sys.executable, str(find_script), '--inventory', inv, '--query', q, '--limit', lim])
        return {
            "ok": bool(res_opus.get("ok") and res_shot.get("ok")),
            "errors": [x.get("error") for x in [res_opus,res_shot] if not x.get("ok")],
            "query": q,
            "opus_and_template_matches": res_opus.get("results", []),
            "shotcraft_upstream_matches": res_shot.get("candidates", [])[: int(lim)],
        }

    if name == "library_opus_gallery":
        action = args.get("action", "list")
        q = args.get("query", "")
        lim = str(args.get("limit", 6))
        gal_script = sd / "reels-opus-craft" / "scripts" / "opus_gallery.py"
        if action == "list":
            return run_quiet([sys.executable, str(gal_script), "--list"])
        if action == "get" and q:
            return run_quiet([sys.executable, str(gal_script), "--get", q])
        opus_script = sd / "reels-opus-craft" / "scripts" / "search_opus_prompts.py"
        return run_quiet([sys.executable, str(opus_script), "--query", q or "remotion", "--limit", lim])

    if name == "library_reference_styles":
        st = args.get("style", "all")
        topic = args.get("generate_preset_for_topic", "")
        dur = float(args.get("duration", 12.0))
        styles_out = REFERENCE_STYLE_CATALOG if st == "all" else {st: REFERENCE_STYLE_CATALOG.get(st, REFERENCE_STYLE_CATALOG["ref1-tutorial-deck"])}
        out = {"ok": True, "styles": styles_out}
        if topic:
            prod_script = sd / "reels-production" / "scripts" / "one_shot_produce.py"
            sys.path.insert(0, str(prod_script.parent))
            import one_shot_produce as osp

            chosen_style = "ref1-tutorial-deck" if st == "all" else st
            out["preset_scenes"] = osp.build_default_scenes(topic, chosen_style, 30, dur)
        return out

    return {"ok": False, "error": f"Unknown tool: {name}"}


def main():
    from core.rpc import serve
    serve(SERVER_NAME, '9.8.1', TOOLS, handle_tool_call)


if __name__ == "__main__":
    main()
