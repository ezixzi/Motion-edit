#!/usr/bin/env python3
"""Shotcraft Pro v9.7.0 — Modular Director MCP Domain (`mcp/director.py`, `[P3-3]`)."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import BaseMcpTool
import shotcraft_mcp_server as _srv


class OneShotVideoTool(BaseMcpTool):
    name = "shotcraft_one_shot_video"
    description = "End-to-end 1-call video producer with AI semantic scenes, 3D Blinn-Phong + SSS, and QA."

    def execute(self, args: dict) -> dict:
        return _srv.handle_tool_call(self.name, args)


class GenerateCompositionTool(BaseMcpTool):
    name = "shotcraft_generate_composition"
    description = "Compile MainReel.template.tsx via Handlebars template engine."

    def execute(self, args: dict) -> dict:
        return _srv.generate_clean_3zone_composition(
            target_tsx=args["target_tsx"],
            scenes=args["scenes"],
            title_badge=args.get("title_badge", ""),
            fps=int(args.get("fps", 30)),
        )


if __name__ == "__main__":
    _srv.main()
