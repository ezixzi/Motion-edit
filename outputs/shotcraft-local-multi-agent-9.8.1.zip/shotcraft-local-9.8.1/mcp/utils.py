import re
"""Shotcraft Pro v9.7.0 — Shared MCP Subprocess & JSON Helpers."""
import json
import subprocess


def run_quiet(cmd: list, cwd: str = None, timeout: int = 300) -> dict:
    try:
        res = subprocess.run(
            cmd,
            cwd=cwd,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        out = res.stdout.strip()
        try:
            parsed = json.loads(out) if out.startswith("{") else {"stdout": out[-500:]}
        except Exception:
            parsed = {"stdout": out[-500:]}
        if res.returncode != 0:
            return {**parsed, "ok": False, "exit_code": res.returncode, "error": res.stderr.strip()[-450:]}
        return {"ok": True, **parsed}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


class BaseMcpTool:
    """Testable class interface for every Shotcraft Pro MCP tool ([P3-3])."""
    name: str = "base_tool"
    description: str = ""
    input_schema: dict = {}

    def execute(self, args: dict) -> dict:
        raise NotImplementedError


def render_handlebars_template(template_str: str, context: dict) -> str:
    """
    [P3-1]: Mustache/Handlebars-compatible template renderer (`{{KEY}}` expressions).
    """
    def _repl(match):
        key = match.group(1).strip()
        if key in context:
            val = context[key]
            return val if isinstance(val, str) else json.dumps(val, indent=2, ensure_ascii=False)
        return match.group(0)

    return re.sub(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}", _repl, template_str)
