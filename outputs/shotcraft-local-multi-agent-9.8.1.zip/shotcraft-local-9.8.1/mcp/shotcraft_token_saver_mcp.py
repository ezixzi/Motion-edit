#!/usr/bin/env python3
"""
Shotcraft Pro MCP Server #0: `shotcraft-token-saver` (v9.7.0)
Ultra-Compact Project Map, Context-Aware Style & Font Resolver, and 1-Call Token-Saving Router for Claude Code.
Provides bounded capability routing; actual token usage is not benchmarked.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import json
import re
import sys

SERVER_NAME = "shotcraft-token-saver"
SERVER_VERSION = "9.7.0"
PROTOCOL_VERSION = "2024-11-05"

STYLE_GALLERY_MAP = {
    "auto-context": {
        "description": "Automatically selects 3D object geometry (3D Neuron / 3D Engine Cutaway / 3D Ceramic Coffee / 3D Voxel), color palette, and font family (Serif vs Clean Sans vs Mono) based on the topic!",
        "bgm": "explainer-groove-104bpm.wav",
        "sfx_pack": "organic",
    },
    "ref5-editorial-cutaway": {
        "description": "Warm Cream Editorial Paper (#F4EFE2) + 3D Shaded Cross-Section Cutaway + Yellow Leader Callouts + Floating White Evidence Cards (`bars`, `quote`, `checklist`) + Compact Dark/Yellow Pill Subtitles.",
        "bgm": "explainer-groove-104bpm.wav",
        "sfx_pack": "organic",
    },
    "coffee-editorial-3d": {
        "description": "Warm Roast Cream & Espresso Editorial + Editorial Serif Typography (DejaVuSerif-Bold) + 3D Shaded Ceramic Cup, Crema & Roasted Coffee Beans + Volumetric Steam.",
        "bgm": "warm-editorial-96bpm.wav",
        "sfx_pack": "organic",
    },
    "neural-network": {
        "description": "Bioluminescent Dark Science Lab + Clean Sans Typography + True 3D Blinn-Phong Shaded Neural Soma, Cylindrical Myelinated Axons, and Z-Sorted Synaptic Spheres.",
        "bgm": "cyber-pulse-128bpm.wav",
        "sfx_pack": "scifi",
    },
    "ref1-tutorial-deck": {
        "description": "Warm Charcoal Dot-Grid (#121210) + Terracotta (#D97757) + macOS Dark Terminal Deck + Monospace Code/Data + Tilted Cream Sticker.",
        "bgm": "lofi-study-chill-84bpm.wav",
        "sfx_pack": "studio",
    },
    "ref2-floating-glass": {
        "description": "Cosmic Violet Aurora (#130D26) + 270° Cyber Tachometer Gauge + 3 Racing Velocity Telemetry Bars.",
        "bgm": "kinetic-120bpm.wav",
        "sfx_pack": "glass",
    },
    "ref3-pricing-voxel": {
        "description": "Blueprint Navy Grid (#071120) + 3D Shaded Isometric Voxel Towers + Side-by-Side VS Split Comparison Cards.",
        "bgm": "suspense-tech-110bpm.wav",
        "sfx_pack": "mechanical",
    },
    "ref4-tape-mascot": {
        "description": "Warm Craft Studio (#181614) + Top Masking-Tape Cream Banner + Hole-Punch Index Card + 3D Shaded Mascot.",
        "bgm": "explainer-groove-104bpm.wav",
        "sfx_pack": "rubber",
    },
    "showcase-all-styles": {
        "description": "Multi-Style Showreel: Cycles across distinct full-canvas visual worlds per scene.",
        "bgm": "explainer-groove-104bpm.wav",
        "sfx_pack": "organic",
    },
}

TOOLS = [
    {
        "name": "shotcraft_project_map",
        "description": "Compact capability routing. Read selected skill instructions and verify assets before production.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Optional user topic to auto-recommend the best 3D visual world, font family, and BGM"},
            },
        },
    },
    {
        "name": "shotcraft_recommend_style",
        "description": "Given any video topic, returns the context-matched 3D style, font family (Serif/Sans/Mono), color palette, SFX pack, and BGM track.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {"type": "string"},
            },
            "required": ["topic"],
        },
    },
]


def recommend_for_topic(topic: str) -> dict:
    t = (topic or "").lower()
    def contains(k): return re.search(r"(?<!\w)"+re.escape(k)+r"(?!\w)", t) is not None
    if any(contains(k) for k in ("kopi", "coffee", "espresso", "kafein", "seduh", "kuliner", "teh", "cokelat")):
        return {
            "recommended_style": "coffee-editorial-3d",
            "font_family": "Editorial Serif (DejaVuSerif-Bold) + Clean Sans",
            "3d_object": "True 3D Shaded Ceramic Espresso/Pour-Over Vessel + 3D Roasted Coffee Beans + Volumetric Steam",
            "bgm_track": "warm-editorial-96bpm.wav",
            "sfx_pack": "organic",
        }
    if any(contains(k) for k in ("otak", "brain", "saraf", "neuron", "ai")):
        return {
            "recommended_style": "neural-network",
            "font_family": "Clean Geometric Sans (DejaVuSans-Bold)",
            "3d_object": "True 3D Blinn-Phong Shaded Neuron Soma + 3D Cylindrical Myelinated Axons + Z-Sorted Synapses",
            "bgm_track": "explainer-groove-104bpm.wav",
            "sfx_pack": "scifi",
        }
    if any(contains(k) for k in ("motor", "mesin", "mobil", "oli", "bensin", "piston", "injeksi", "mekanik", "teknik", "cara kerja")):
        return {
            "recommended_style": "ref5-editorial-cutaway",
            "font_family": "Editorial Sans + Technical Callout Mono",
            "3d_object": "True 3D Extruded Engine Cutaway + 3D Shaded Cylindrical Piston & Crankshaft + Volumetric Oil Sump",
            "bgm_track": "explainer-groove-104bpm.wav",
            "sfx_pack": "organic",
        }
    return {
        "recommended_style": "auto-context",
        "font_family": "Context-Adaptive (Sans / Serif / Mono)",
        "3d_object": "Context-Matched 3D Shaded Volumetric Stage",
        "bgm_track": "explainer-groove-104bpm.wav",
        "sfx_pack": "studio",
    }


def send_response(msg_id, result=None, error=None):
    payload = {"jsonrpc": "2.0", "id": msg_id}
    if error is not None:
        payload["error"] = error
    else:
        payload["result"] = result
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def handle_tool_call(name, args):
    if name == 'shotcraft_project_map':
        return {'ok': True, 'routing': 'Read the relevant skill and selected recipe only. Respect the current audio brief; check dependencies with doctor.py.', 'topic_recommendation': recommend_for_topic(args.get('topic','')), 'available_styles': list(STYLE_GALLERY_MAP)}
    if name == 'shotcraft_recommend_style':
        return {'ok': True, **recommend_for_topic(args['topic'])}
    return {'ok': False, 'error': 'Unknown tool'}

def main():
    from core.rpc import serve
    serve(SERVER_NAME, '9.8.1', TOOLS, handle_tool_call)


if __name__ == "__main__":
    main()
