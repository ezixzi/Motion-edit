#!/usr/bin/env python3
"""Shotcraft Pro v9.7.0 — Modular Token Saver MCP Domain (`mcp/token_saver.py`, `[P3-3]`)."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import BaseMcpTool
import shotcraft_token_saver_mcp as _srv


class TokenMapTool(BaseMcpTool):
    name = "shotcraft_token_map"
    description = "Ultra-compact 200-token style, BGM, SFX, and hook routing map."

    def execute(self, args: dict) -> dict:
        return _srv.handle_tool_call(self.name, args)


if __name__ == "__main__":
    _srv.main()
