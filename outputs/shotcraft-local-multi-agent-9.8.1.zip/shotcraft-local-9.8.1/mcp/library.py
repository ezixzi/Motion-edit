#!/usr/bin/env python3
"""Shotcraft Pro v9.7.0 — Modular Library MCP Domain (`mcp/library.py`, `[P3-3]`)."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import BaseMcpTool
import shotcraft_library_mcp as _srv


class LibrarySearchTool(BaseMcpTool):
    name = "library_search_all"
    description = "Search across 150+ shots, 24 Opus recipes, and templates."

    def execute(self, args: dict) -> dict:
        return _srv.handle_tool_call(self.name, args)


if __name__ == "__main__":
    _srv.main()
