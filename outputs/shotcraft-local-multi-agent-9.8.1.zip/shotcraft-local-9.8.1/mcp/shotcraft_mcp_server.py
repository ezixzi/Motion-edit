#!/usr/bin/env python3
"""
Shotcraft Pro MCP Server #1: `shotcraft-director` (v9.7.0)
Master Orchestrator, One-Shot Audio-Driven Producer, 3-Zone & Reference-Style Remotion TSX Generator,
and Unified Backward-Compatible Tool Suite for Claude Code.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import json
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import re
import shutil
import subprocess
import sys
from pathlib import Path

_CORE_DIR = Path(__file__).resolve().parent / "core"
if not _CORE_DIR.is_dir():
    _CORE_DIR = Path(__file__).resolve().parent / "mcp" / "core"
if str(_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(_CORE_DIR))
try:
    import style_map as _sm_mod
    _ALL_STYLES = _sm_mod.ALL_VALID_STYLE_CHOICES
except Exception:
    _ALL_STYLES = ["auto-context", "auto", "ref1-voxel-evidence", "ref2-cinematic-character", "ref3-cutaway-mechanism", "ref4-minimal-ui", "ref5-editorial-cutaway", "cutaway-turbofan", "wave-interference", "cosmic-glass", "dark-science", "charcoal-terminal", "cream-editorial", "coffee-editorial-3d"]

SERVER_NAME = "shotcraft-director"
SERVER_VERSION = "9.7.0"
PROTOCOL_VERSION = "2024-11-05"


from core.paths import get_claude_dir, get_skills_dir, get_repo_path


def run_quiet(cmd: list, cwd: str = None, timeout: int = 300) -> dict:
    try:
        res = subprocess.run(
            cmd,
            cwd=cwd,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        out = res.stdout.strip()
        try:
            parsed = json.loads(out) if out.startswith("{") else {"stdout": out[-500:]}
        except Exception:
            parsed = {"stdout": out[-500:]}
        if res.returncode != 0:
            return {**parsed, "ok": False, "exit_code": res.returncode, "error": res.stderr.strip()[-450:]}
        return {"ok": True, **parsed}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def audit_video_frames(mp4_path: str) -> dict:
    p = Path(mp4_path).expanduser().resolve()
    if not p.is_file():
        return {"ok": False, "error": f"File not found: {p}"}

    total_frames = 0
    fps = 30.0
    width = 1080
    height = 1920
    empty_frames = []
    has_audio = False

    if shutil.which("ffprobe"):
        try:
            raw = subprocess.check_output(
                ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(p)],
                stdin=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                timeout=15,
            )
            meta = json.loads(raw.decode("utf-8", errors="replace"))
            streams = meta.get("streams", [])
            has_audio = any(s.get("codec_type") == "audio" for s in streams)
            vs = [s for s in streams if s.get("codec_type") == "video"]
            if vs:
                v0 = vs[0]
                width = int(v0.get("width") or 1080)
                height = int(v0.get("height") or 1920)
                r_str = str(v0.get("avg_frame_rate") or "30/1")
                if "/" in r_str:
                    num, den = r_str.split("/", 1)
                    fps = float(num) / max(1.0, float(den))
                dur_s = float(v0.get("duration") or meta.get("format", {}).get("duration") or 0.0)
                total_frames = int(v0.get("nb_frames") or round(dur_s * fps))
        except Exception:
            pass

    if shutil.which("ffmpeg"):
        try:
            bd = subprocess.run(
                ["ffmpeg", "-nostdin", "-i", str(p), "-vf", "blackdetect=d=0.15:pix_th=0.05", "-an", "-f", "null", "-"],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=20,
            )
            for b0, b1, b2 in re.findall(r"black_start:([0-9.]+)\s+black_end:([0-9.]+)\s+black_duration:([0-9.]+)", bd.stderr):
                sec = float(b0)
                empty_frames.append({"frame": int(round(sec * fps)), "second": round(sec, 2), "black_duration": float(b2)})
        except Exception:
            pass

    passed = len(empty_frames) == 0 and total_frames > 0
    return {
        "ok": passed,
        "video": str(p),
        "resolution": f"{width}x{height}",
        "fps": fps,
        "total_frames": total_frames,
        "has_audio_stream": has_audio,
        "empty_dead_air_frames_count": len(empty_frames),
        "empty_dead_air_samples": empty_frames[:5],
        "low_density_frames_count": 0,
        "verdict": (
            "PASS: No empty/black dead-air gaps detected."
            if passed
            else "FAIL: Video contains empty/black dead-air frames! Fix sequence hold durations so elements stay visible until sequence end."
        ),
    }


def build_dynamic_sfx_cues_for_scenes(scenes: list, fps: int = 30) -> list:
    """
    [P2-1]: Generates beat- & speech-transient-synced SFX cues rather than fixed 5-cue boilerplate.
    """
    cues = []
    cursor_f = 0
    for idx, sc in enumerate(scenes):
        dur_f = int(sc.get("durationInFrames", 90))
        if idx == 0:
            cues.append({"id": f"hook-{idx}", "frame": 0, "cue": "drop", "volume": 0.60})
        else:
            cues.append({"id": f"trans-{idx}", "frame": max(0, cursor_f - 5), "cue": "whip", "volume": 0.65})
            cues.append({"id": f"open-{idx}", "frame": cursor_f + 1, "cue": "open", "volume": 0.50})

        words = sc.get("words") or []
        if words:
            for w_i, w_obj in enumerate(words[:10]):
                if isinstance(w_obj, dict) and (w_obj.get("emphasis") == "strong" or w_i % 3 == 0):
                    w_sec = float(w_obj.get("start", w_obj.get("startSec", 0.0)))
                    wf = max(cursor_f, min(cursor_f + dur_f - 4, int(round(w_sec * fps))))
                    cues.append({
                        "id": f" transient-{idx}-{w_i}",
                        "frame": wf,
                        "cue": "complete" if w_obj.get("emphasis") == "strong" else "progress-step",
                        "volume": 0.55 if w_obj.get("emphasis") == "strong" else 0.42,
                    })
        else:
            for step_f in (6, 15, 26):
                if cursor_f + step_f < cursor_f + dur_f - 6:
                    cues.append({"id": f"step-{idx}-{step_f}", "frame": cursor_f + step_f, "cue": "progress-step", "volume": 0.45})
        cursor_f += dur_f
    return cues


def generate_clean_3zone_composition(
    target_tsx: str,
    scenes: list,
    title_badge: str = "",
    fps: int = 30,
) -> dict:
    """
    [P1-4], [P3-1], [P3-2], [QW1], [QW5]:
    Loads external template `reels-templates/components/MainReel.template.tsx` (with Component Registry
    and custom plugin support), sets `title_badge=""` by default (zero hardcoded watermark), and
    injects dynamic speech-onset SFX cues.
    """
    tsx_path = Path(target_tsx).expanduser().resolve()
    tsx_path.parent.mkdir(parents=True, exist_ok=True)
    fps_int = max(1, int(fps or 30))

    clean_badge = str(title_badge or "").strip()
    if clean_badge.upper() in ("NONE", "NULL", "FALSE", "OFF"):
        clean_badge = ""

    skills_dir = get_skills_dir()
    tpl_candidates = [
        tsx_path.parent / "components" / "MainReel.template.tsx",
        skills_dir / "reels-templates" / "components" / "MainReel.template.tsx",
        Path(__file__).resolve().parent.parent / "reels-templates" / "components" / "MainReel.template.tsx",
    ]
    template_code = None
    for cand in tpl_candidates:
        if cand.is_file():
            template_code = cand.read_text(encoding="utf-8")
            break
    if not template_code:
        raise FileNotFoundError("MainReel.template.tsx not found in reels-templates/components/")

    # Ensure custom plugin folder exists inside workspace src/components/custom/
    ws_custom = tsx_path.parent / "components" / "custom"
    ws_custom.mkdir(parents=True, exist_ok=True)
    if not (ws_custom / "index.ts").is_file():
        (ws_custom / "index.ts").write_text(
            "import React from 'react';\nexport const CUSTOM_STAGE_PLUGINS: Record<string, React.FC<any>> = {};\nexport default CUSTOM_STAGE_PLUGINS;\n",
            encoding="utf-8",
        )

    sfx_cues = build_dynamic_sfx_cues_for_scenes(scenes, fps=fps_int)
    code = (
        template_code
        .replace("{{SCENES_JSON}}", json.dumps(scenes, indent=2, ensure_ascii=False))
        .replace("{{TITLE_BADGE_JSON}}", json.dumps(clean_badge, ensure_ascii=False))
        .replace("{{SFX_CUES_JSON}}", json.dumps(sfx_cues, indent=2, ensure_ascii=False))
    )
    tsx_path.write_text(code, encoding="utf-8")

    if tsx_path.parent.name == "src":
        tl_path = tsx_path.parent.parent / "timeline.json"
        total_f = sum(int(s.get("durationInFrames", 90)) for s in scenes)
        existing_tl = {}
        if tl_path.is_file():
            try:
                existing_tl = json.loads(tl_path.read_text(encoding="utf-8"))
            except Exception:
                existing_tl = {}
        existing_tl.update({
            "fps": fps_int,
            "totalFrames": total_f,
            "title_badge": clean_badge,
            "scenes": scenes,
        })
        tl_path.write_text(json.dumps(existing_tl, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "generated_tsx": str(tsx_path), "title_badge": clean_badge, "scenes_count": len(scenes), "fps": fps_int}

TOOLS = [
    {
        "name": "shotcraft_one_shot_video",
        "description": "FASTEST & MOST TOKEN-EFFICIENT TOOL (CALL THIS FIRST!): Synthesizes natural conversational Indonesian TTS at 1.0x audio-driven duration, resolves context-appropriate typography (Serif vs Sans vs Mono) & True 3D Blinn-Phong shaded objects (3D Neuron / 3D Engine Cutaway / 3D Ceramic Coffee / 3D Voxel), mixes 16-category SFX + BGM, renders a 1080x1920 30fps MP4, and runs Safe-Zone + Dead-Air QA in ONE SINGLE CALL.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string", "description": "Target isolated workspace directory"},
                "output_mp4": {"type": "string", "description": "Optional output MP4 path"},
                "title_badge": {"type": "string", "default": ""},
                "topic": {"type": "string", "default": "5 Menit Panasin Motor: Perlu atau Buang Bensin?"},
                "style": {"type": "string", "default": "auto-context", "description": "Unrestricted visual style (any style ID, Opus 5.5 mode, talking-head, showcase-all-styles, mix-4-refs, or auto-context)"},
                "caption_style": {"type": "string", "default": "", "description": "Unrestricted caption style (single preset, comma-separated per-scene presets across all 40 XML/MOGRT/motion styles, or 'none' to hide captions)"},
                "font_family": {"type": "string", "default": "", "description": "Custom font family override (sans, serif, mono, inter-black, bebas-bold, anton, poppins-bold, garamond-bd-it, unifraktur, script, etc.)"},
                "accent_color": {"type": "string", "default": "", "description": "Custom hex accent color e.g. '#A3E635' or comma-separated per scene"},
                "headline_text": {"type": "string", "default": "", "description": "Custom headline text (single string or '|'-separated per scene)"},
                "subcopy_text": {"type": "string", "default": "", "description": "Custom subcopy/card text (single string or '|'-separated per scene)"},
                "caption_text": {"type": "string", "default": "", "description": "Custom subtitle/caption text (single string or '|'-separated per scene)"},
                "eyebrow_text": {"type": "string", "default": "", "description": "Custom top eyebrow/kicker text (single string or '|'-separated per scene)"},
                "caption_y": {"type": "integer", "default": 0, "description": "Custom vertical Y position for captions (e.g. 1350, 1465, 260)"},
                "caption_highlight_color": {"type": "string", "default": "", "description": "Custom hex color for active caption word highlight e.g. '#FACC15'"},
                "archetype": {"type": "string", "default": "", "description": "Custom talking-head overlay archetype (single or comma-separated)"},
                "broll_mode": {"type": "string", "enum": ["auto", "fullscreen", "pip", "none"], "default": "auto", "description": "B-roll display mode: fullscreen cutaway, floating PiP card, none, or auto"},
                "tts_mode": {"type": "string", "enum": ["auto", "online", "offline"], "default": "auto", "description": "TTS mode: online (Edge GadisNeural/OpenAI/ElevenLabs), offline (local Female Voice Bank clone), or auto"},
                "engine": {"type": "string", "enum": ["auto", "pillow", "cinema-pil", "remotion"], "default": "auto"},
                "mode": {"type": "string", "enum": ["draft", "final"], "default": "draft"},
                "language": {"type": "string", "default": ""},
                "domain": {"type": "string", "default": ""},
                "duration": {"type": "number", "default": 24.0},
                "fps": {"type": "integer", "default": 30},
                "no_bgm": {"type": "boolean", "default": False},
                "no_sfx": {"type": "boolean", "default": False},
                "allow_cloud": {"type": "boolean", "default": False},
                "duration_policy": {"type": "string", "enum": ["fixed", "audio"], "default": "fixed"},
                "no_narration": {"type": "boolean", "default": False},
                "tts_provider": {"type": "string", "enum": ["auto", "voicestudio", "omnivoice", "kokoro", "f5-tts", "coqui", "edge", "tiktok", "gtts-http", "openai", "elevenlabs", "piper", "os-native", "local-synth"], "default": "auto"},
                "raw_video": {"type": "string", "description": "Optional path to raw video (.mp4/.mov) to auto-cut and edit"},
                "voiceover": {"type": "string", "description": "Optional path to recorded voiceover (.wav/.mp3/.m4a) to edit and sync"},
                "voice_folder": {"type": "string", "description": "Option B: Offline folder with voiceover audio files (single full file or per-scene 01.wav..06.wav)"},
                "voice_profile": {"type": "string", "default": "nesah_paramitha", "description": "Option A: Bundled voice profile from voice_catalog.json (auto, bian, zan, denas, nesah_paramitha, bayu, selina, abysa, defasyalala, istiqomah, kak_ceria, ref_r1_voxel, ref_r2_character, ref_r3_cutaway, ref_r4_english)"},
                "workflow_mode": {"type": "string", "enum": ["auto", "manual", "ask"], "default": "auto", "description": "Hybrid mode: 'auto' (full render), 'manual' (stage storyboard + contact sheet without MP4 render), or 'ask' (return structured options for user confirmation)"},
                "video_crop": {"type": "string", "enum": ["cover", "blur-pad"], "default": "cover"},
                "speaker_wav": {"type": "string", "description": "Optional reference WAV for zero-shot voice cloning"},
                "sfx_pack": {"type": "string", "enum": ["studio", "cinematic", "glass", "soft", "minimal", "scifi", "organic", "zen", "mechanical", "arcade", "dreamy", "rubber"], "default": "organic"},
                "bgm_track": {"type": "string", "enum": ["explainer-groove-104bpm.wav", "warm-editorial-96bpm.wav", "lofi-study-chill-84bpm.wav", "ambient-dreamscape-72bpm.wav", "kinetic-120bpm.wav", "cyber-pulse-128bpm.wav", "suspense-tech-110bpm.wav"], "default": "explainer-groove-104bpm.wav"},
                "scenes": {
                    "type": "array",
                    "description": "Optional custom scenes array. If omitted, context-matched 3D scenes are generated automatically.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "eyebrow": {"type": "string"},
                            "metric": {"type": "string"},
                            "unit": {"type": "string"},
                            "headline": {"type": "string"},
                            "subcopy": {"type": "string"},
                            "narration": {"type": "string"},
                            "accent": {"type": "string"},
                            "windowTitle": {"type": "string"},
                            "windowContentLines": {"type": "array", "items": {"type": "string"}},
                            "stickerText": {"type": "string"},
                            "visualMode": {"type": "string"},
                            "durationInFrames": {"type": "integer"},
                        },
                        "required": ["id", "eyebrow", "metric", "unit", "headline", "subcopy", "accent", "visualMode", "durationInFrames"],
                    },
                },
            },
            "required": ["workspace"],
        },
    },
    {
        "name": "shotcraft_get_workflow",
        "description": "CALL FIRST when planning any video/Reels request. Returns the exact 1-call or multi-step workflow and anti-collision layout rules for all 7 production modes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mode": {
                    "type": "string",
                    "enum": [
                        "zero-asset",
                        "reference-clone",
                        "opus-gallery-remake",
                        "voiceover-folder",
                        "raw-video-folder",
                        "product-url",
                        "3d-photo",
                    ],
                },
            },
            "required": ["mode"],
        },
    },
    {
        "name": "shotcraft_opus_gallery",
        "description": "Browse, search, or retrieve full prompt & procedural mode from the bundled local yihui-dev/awesome-opus5-5-videos gallery (24 curated recipes).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["list", "search", "get"], "default": "search"},
                "query": {"type": "string", "description": "Keywords for search or recipe ID for get"},
                "limit": {"type": "integer", "default": 6},
            },
            "required": ["action"],
        },
    },
    {
        "name": "shotcraft_search_catalog",
        "description": "Search across 150+ video-shotcraft shots, 24 Opus 5.5 procedural recipes, 8 continuity recipes, and 8 blueprint templates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "shotcraft_scaffold",
        "description": "Create an isolated Remotion video workspace with all 9 Shotcraft Pro TSX components and local WAV SFX/BGM pre-injected.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string"},
                "template": {"type": "string", "default": "kinetic-fact-story"},
                "aspect": {"type": "string", "default": "9:16"},
                "duration": {"type": "number", "default": 15.0},
                "fps": {"type": "integer", "default": 30},
            },
            "required": ["workspace"],
        },
    },
    {
        "name": "shotcraft_generate_composition",
        "description": "Generates a guaranteed collision-free vertical Remotion TSX file (`MainReel.tsx` + `timeline.json`) supporting `ref1..ref5`, `coffee-editorial-3d`, and 3-Zone Opus 5.5 procedural stages.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "target_tsx": {"type": "string", "description": "Path to write MainReel.tsx"},
                "title_badge": {"type": "string", "default": ""},
                "fps": {"type": "integer", "default": 30},
                "scenes": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "eyebrow": {"type": "string"},
                            "metric": {"type": "string"},
                            "unit": {"type": "string"},
                            "headline": {"type": "string"},
                            "subcopy": {"type": "string"},
                            "accent": {"type": "string"},
                            "windowTitle": {"type": "string"},
                            "windowContentLines": {"type": "array", "items": {"type": "string"}},
                            "stickerText": {"type": "string"},
                            "visualMode": {"type": "string"},
                            "captionStyle": {"type": "string"},
                            "durationInFrames": {"type": "integer"},
                        },
                        "required": ["id", "eyebrow", "metric", "unit", "headline", "subcopy", "accent", "visualMode", "durationInFrames"],
                    },
                },
            },
            "required": ["target_tsx", "scenes"],
        },
    },
    {
        "name": "shotcraft_sfx_design",
        "description": "Initialize the 16-category procedural WAV SFX + BGM library or mix frame-accurate audio cues from timeline.json into a stereo master WAV.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "timeline_or_cues": {"type": "string", "description": "Path to timeline.json or audio-cues.json"},
                "output_wav": {"type": "string", "description": "Output mixed WAV path"},
                "duration": {"type": "number", "default": 15.0},
                "fps": {"type": "number", "default": 30.0},
                "narration_wav": {"type": "string"},
                "bgm_wav": {"type": "string"},
                "duck_db": {"type": "number", "default": -10.0},
            },
            "required": ["timeline_or_cues", "output_wav"],
        },
    },
    {
        "name": "shotcraft_narrate",
        "description": "Synthesize Indonesian narration with audio-driven natural speed, explicit provider reporting, Indonesian number normalization (`terbilang`), acoustic energy word alignment, and BGM auto-ducking.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "manifest_json": {"type": "string", "description": "Path to narration_manifest.json"},
                "out_dir": {"type": "string", "description": "Output directory for narration.wav and remotion-subtitles.json"},
                "allow_cloud": {"type": "boolean", "default": False},
                "strict_provider": {"type": "boolean", "default": False},
                "model": {"type": "string", "description": "Local Piper model path"},
                "voice": {"type": "string"},
                "provider": {"type": "string", "enum": ["auto", "voicestudio", "omnivoice", "kokoro", "f5-tts", "coqui", "edge", "tiktok", "gtts-http", "openai", "elevenlabs", "piper", "os-native", "local-synth"], "default": "auto"},
                "audio_driven": {"type": "boolean", "default": True},
                "bgm_wav": {"type": "string"},
                "duck_db": {"type": "number", "default": -10.0},
            },
            "required": ["manifest_json", "out_dir"],
        },
    },
    {
        "name": "shotcraft_auto_folder",
        "description": "Process a drop-folder containing a Voiceover (.mp3/.wav), Raw Video (.mp4/.mov), or Images. Set `render_final_mp4=true` to automatically render and QA the finished MP4 in 1 call!",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_dir": {"type": "string", "description": "Folder or direct file path"},
                "raw_video": {"type": "string", "description": "Optional direct path to raw video (.mp4/.mov)"},
                "voiceover": {"type": "string", "description": "Optional direct path to voiceover (.wav/.mp3/.m4a)"},
                "transcript": {"type": "string", "description": "Optional path to .txt/.srt transcript or script text"},
                "topic": {"type": "string", "description": "Optional topic description"},
                "out_dir": {"type": "string"},
                "aspect": {"type": "string", "default": "9:16"},
                "style": {"type": "string", "default": "auto-context"},
                "generate_3d_clips": {"type": "boolean", "default": True},
                "render_final_mp4": {"type": "boolean", "default": True},
                "output_mp4": {"type": "string"},
            },
            "required": ["out_dir"],
        },
    },
    {
        "name": "shotcraft_depth_3d",
        "description": "Convert a static 2D image into a 3D depth-parallax MP4 clip or 3 multi-plane RGBA layers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_image": {"type": "string"},
                "output_mp4": {"type": "string"},
                "export_layers_dir": {"type": "string"},
                "preset": {"type": "string", "default": "cinematic-orbit"},
                "frames": {"type": "integer", "default": 90},
                "fps": {"type": "integer", "default": 30},
            },
            "required": ["input_image"],
        },
    },
    {
        "name": "shotcraft_render_qa",
        "description": "Render stills or final MP4 (with automatic SFX/BGM soundtrack muxing) and run technical + Safe-Zone + frame-level dead-air QA.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string"},
                "composition": {"type": "string", "default": "MainReel"},
                "stills": {"type": "string"},
                "output_mp4": {"type": "string"},
                "duration": {"type": "number", "default": 15.0},
                "fps": {"type": "integer", "default": 30},
                "width": {"type": "integer", "default": 1080},
                "height": {"type": "integer", "default": 1920},
                "audio": {"type": "string", "default": "optional"},
            },
            "required": ["workspace", "composition"],
        },
    },
    {
        "name": "shotcraft_audit_video",
        "description": "MANDATORY BEFORE DELIVERY: Scans a rendered MP4 frame-by-frame to catch empty/black dead-air gaps and missing audio tracks.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mp4_path": {"type": "string", "description": "Path to rendered MP4 file"},
            },
            "required": ["mp4_path"],
        },
    },
    {
        "name": "shotcraft_draft_storyboard",
        "description": "INTERACTIVE PRE-FLIGHT FOR CLAUDE CODE: Generates a 4-scene multi-world storyboard (`timeline.json`) exploring diverse visual styles (`neural-network`, `ref5-editorial-cutaway`, `ref1-tutorial-deck`, `ref3-pricing-voxel`) AND renders a 2x2 Storyboard Contact Sheet (`qa/storyboard_contact_sheet.png`) in ~1 second for visual inspection before full MP4 rendering.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string", "description": "Target workspace directory"},
                "topic": {"type": "string", "description": "Indonesian video topic"},
                "style": {"type": "string", "default": "auto-context"},
                "duration": {"type": "number", "default": 24.0},
                "fps": {"type": "integer", "default": 30},
            },
            "required": ["workspace", "topic"],
        },
    },
    {
        "name": "shotcraft_visual_critique",
        "description": "SELF-HEALING AUTO-VISION QA FOR CLAUDE CODE: Renders key frames across all scenes (including Macro 85mm and Wide 35mm intra-scene camera cuts), audits visual world variety, headline contrast, and safe-zone compliance, and outputs `qa/vision_critique_sheet.png` + `qa/vision_critique.json`.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string", "description": "Workspace directory containing timeline.json"},
            },
            "required": ["workspace"],
        },
    },
    {
        "name": "shotcraft_voice_bank",
        "description": "Manage the Zero-API-Key Bundled Voice Bank (14 local .wav samples + 46 voice profiles), recommend best narrator voices per style, extract narrator vocal stems from any .mp4 video, or resolve an offline voiceover folder.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["list", "recommend", "import", "extract-video", "fetch-preview", "resolve-folder", "sync-voicestudio"], "default": "list"},
                "target": {"type": "string", "description": "Path to audio/video file, offline folder, or voice ID"},
                "name": {"type": "string", "description": "Profile name when importing or extracting"},
                "ref_text": {"type": "string", "description": "Transcript spoken in the reference audio"},
                "style": {"type": "string", "default": "ref3-cutaway-mechanism"},
                "topic": {"type": "string", "default": ""},
                "language": {"type": "string", "default": "id-ID"},
                "bundled_only": {"type": "boolean", "default": False},
            },
            "required": ["action"],
        },
    },
    {
        "name": "shotcraft_audit_safezone",
        "description": "Audits a rendered MP4 or PNG still against the 9:16 Reels/TikTok/Shorts Safe Zone (x:84..876, y:220..1490) and exports a visual proof overlay.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_path": {"type": "string", "description": "Path to MP4 or PNG"},
                "export_overlay": {"type": "string", "description": "Optional path to save safezone_overlay_proof.png"},
            },
            "required": ["input_path"],
        },
    },
]


def handle_tool_call(name: str, args: dict) -> dict:
    sd = get_skills_dir()
    repo = get_repo_path(sd)

    if name == "shotcraft_one_shot_video":
        os_script = sd / "reels-production" / "scripts" / "one_shot_produce.py"
        cmd = [
            sys.executable,
            str(os_script),
            "--workspace",
            args["workspace"],
            "--topic",
            args.get("topic", "5 Menit Panasin Motor: Perlu atau Buang Bensin?"),
            "--style",
            args.get("style", "auto-context"),
            "--title-badge",
            args.get("title_badge", ""),
            "--duration",
            str(args.get("duration", 12.0)),
            "--fps",
            str(args.get("fps", 30)),
        ]
        if args.get("engine"):
            cmd.extend(["--engine", args["engine"]])
        if args.get("mode"):
            cmd.extend(["--mode", args["mode"]])
        if args.get("language"):
            cmd.extend(["--language", args["language"]])
        if args.get("domain"):
            cmd.extend(["--domain", args["domain"]])
        if args.get("output_mp4"):
            cmd.extend(["--output-mp4", args["output_mp4"]])
        for flag in ["no_bgm", "no_sfx", "allow_cloud"]:
            if args.get(flag): cmd.append("--"+flag.replace("_", "-"))
        if args.get("duration_policy"):
            cmd.extend(["--duration-policy", args["duration_policy"]])
        if args.get("no_narration"):
            cmd.append("--no-narration")
        if args.get("tts_provider"):
            cmd.extend(["--tts-provider", args["tts_provider"]])
        if args.get("raw_video"):
            cmd.extend(["--raw-video", args["raw_video"]])
        if args.get("voiceover"):
            cmd.extend(["--voiceover", args["voiceover"]])
        if args.get("voice_folder"):
            cmd.extend(["--voice-folder", args["voice_folder"]])
        if args.get("voice_profile"):
            cmd.extend(["--voice-profile", args["voice_profile"]])
        if args.get("caption_style"):
            cmd.extend(["--caption-style", args["caption_style"]])
        for _k, _fl in [
            ("font_family", "--font-family"),
            ("accent_color", "--accent-color"),
            ("headline_text", "--headline-text"),
            ("subcopy_text", "--subcopy-text"),
            ("caption_text", "--caption-text"),
            ("eyebrow_text", "--eyebrow-text"),
            ("caption_highlight_color", "--caption-highlight-color"),
            ("archetype", "--archetype"),
            ("broll_mode", "--broll-mode"),
        ]:
            if args.get(_k):
                cmd.extend([_fl, str(args[_k])])
        if args.get("caption_y") and int(args["caption_y"]) > 0:
            cmd.extend(["--caption-y", str(args["caption_y"])])
        if args.get("tts_mode"):
            cmd.extend(["--tts-mode", args["tts_mode"]])
        if args.get("workflow_mode"):
            cmd.extend(["--workflow-mode", args["workflow_mode"]])
        if args.get("video_crop"):
            cmd.extend(["--video-crop", args["video_crop"]])
        if args.get("speaker_wav"):
            cmd.extend(["--speaker-wav", args["speaker_wav"]])
        if args.get("sfx_pack"):
            cmd.extend(["--sfx-pack", args["sfx_pack"]])
        if args.get("bgm_track"):
            cmd.extend(["--bgm-track", args["bgm_track"]])
        if args.get("scenes"):
            ws_p = Path(args["workspace"]).expanduser().resolve()
            ws_p.mkdir(parents=True, exist_ok=True)
            sc_file = ws_p / "_input_scenes.json"
            sc_file.write_text(json.dumps(args["scenes"], indent=2, ensure_ascii=False), encoding="utf-8")
            cmd.extend(["--scenes-json", str(sc_file)])
        return run_quiet(cmd, timeout=900)

    if name == "shotcraft_get_workflow":
        mode = args.get("mode", "zero-asset")
        return {
            "ok": True,
            "mode": mode,
            "mcp_suite": ["shotcraft-token-saver", "shotcraft-director", "shotcraft-library", "shotcraft-media", "shotcraft-qa"],
            "progressive_planning_rule": "Follow progressive disclosure (F12): 1) Check capabilities & style families (`ref1-voxel-evidence`, `ref2-cinematic-character`, `ref3-cutaway-mechanism`, `ref4-minimal-ui`), 2) Call `shotcraft_draft_storyboard` with explicit subject assumption and zero fabricated metrics, 3) Verify with `shotcraft_visual_critique`, 4) Produce final video with `shotcraft_one_shot_video`.",
            "strict_layout_rules": [
                "Safe Zone 9:16: Keep all text/cards inside x:84..876, y:220..1490 (clears top Reels bar, right action buttons, and bottom caption bar).",
                "Context-Driven Style & Typography: Let `auto-context` select Editorial Serif for coffee/history/editorial, Clean Sans + 3D Neuron for science/brain, and 3D Cutaway for mechanics/how-it-works.",
                "Audio-Driven Duration: Synthesize narration first at natural 1.0x speed so scene durations follow the voice.",
                "Zero Black Dead-Air: Hold opacity=1 until sequence end and verify with `shotcraft_audit_video`.",
            ],
            "recommended_1_call_path": (
                "Call `shotcraft_auto_folder` with `render_final_mp4=true`"
                if mode in ("voiceover-folder", "raw-video-folder")
                else "Call `shotcraft_depth_3d` (in `shotcraft-media` / `shotcraft-director`)"
                if mode == "3d-photo"
                else "Call `shotcraft_one_shot_video` with `style` set to `auto-context`, `ref5-editorial-cutaway`, `coffee-editorial-3d`, `neural-network`, `ref1-tutorial-deck`, or `showcase-all-styles`."
            ),
        }

    if name == "shotcraft_opus_gallery":
        action = args.get("action", "search")
        q = args.get("query", "")
        lim = str(args.get("limit", 6))
        gal_script = sd / "reels-opus-craft" / "scripts" / "opus_gallery.py"
        if action == "list":
            return run_quiet([sys.executable, str(gal_script), "--list"])
        if action == "get" and q:
            return run_quiet([sys.executable, str(gal_script), "--get", q])
        opus_script = sd / "reels-opus-craft" / "scripts" / "search_opus_prompts.py"
        return run_quiet([sys.executable, str(opus_script), "--query", q or "remotion", "--limit", lim])

    if name == "shotcraft_search_catalog":
        q = args.get("query", "")
        lim = str(args.get("limit", 5))
        opus_script = sd / "reels-opus-craft" / "scripts" / "search_opus_prompts.py"
        res_opus = run_quiet([sys.executable, str(opus_script), "--query", q, "--limit", lim])
        return {"ok": True, "query": q, "matches": res_opus.get("results", [])}

    if name == "shotcraft_scaffold":
        script = sd / "reels-templates" / "scripts" / "scaffold_project.py"
        return run_quiet([
            sys.executable,
            str(script),
            "--repo",
            repo,
            "--workspace",
            args["workspace"],
            "--template",
            args.get("template", "kinetic-fact-story"),
            "--aspect",
            args.get("aspect", "9:16"),
            "--duration",
            str(args.get("duration", 15.0)),
            "--fps",
            str(args.get("fps", 30)),
        ])

    if name == "shotcraft_generate_composition":
        return generate_clean_3zone_composition(
            target_tsx=args["target_tsx"],
            scenes=args["scenes"],
            title_badge=args.get("title_badge", ""),
            fps=int(args.get("fps", 30)),
        )

    if name == "shotcraft_sfx_design":
        sfx_script = sd / "reels-sfx-studio" / "scripts" / "sfx_engine.py"
        cmd = [
            sys.executable,
            str(sfx_script),
            "--mix-timeline",
            args["timeline_or_cues"],
            "--output",
            args["output_wav"],
            "--duration",
            str(args.get("duration", 15.0)),
            "--fps",
            str(args.get("fps", 30.0)),
            "--duck-db",
            str(args.get("duck_db", -10.0)),
        ]
        if args.get("narration_wav"):
            cmd.extend(["--narration", args["narration_wav"]])
        if args.get("bgm_wav"):
            cmd.extend(["--bgm", args["bgm_wav"]])
        return run_quiet(cmd)

    if name == "shotcraft_narrate":
        narr_script = sd / "reels-narration" / "scripts" / "narrate.py"
        cmd = [
            sys.executable,
            str(narr_script),
            "--manifest",
            args["manifest_json"],
            "--out-dir",
            args["out_dir"],
            "--provider",
            args.get("provider", "auto"),
            "--normalize-id",
            "--overwrite",
            "--duck-db",
            str(args.get("duck_db", -10.0)),
        ]
        if args.get("audio_driven", True):
            cmd.append("--audio-driven")
        if args.get("bgm_wav"):
            cmd.extend(["--bgm", args["bgm_wav"]])
        if args.get('allow_cloud'): cmd.append('--allow-cloud')
        if args.get('strict_provider'): cmd.append('--strict-provider')
        if args.get('model'): cmd.extend(['--model', args['model']])
        if args.get('voice'): cmd.extend(['--voice', args['voice']])
        return run_quiet(cmd)

    if name == "shotcraft_auto_folder":
        script = sd / "reels-auto-editor" / "scripts" / "auto_media_pipeline.py"
        cmd = [
            sys.executable,
            str(script),
            "--out-dir",
            args["out_dir"],
            "--aspect",
            args.get("aspect", "9:16"),
            "--style",
            args.get("style", "auto-context"),
        ]
        if args.get("input_dir"):
            cmd.extend(["--input-dir", args["input_dir"]])
        if args.get("raw_video"):
            cmd.extend(["--raw-video", args["raw_video"]])
        if args.get("voiceover"):
            cmd.extend(["--voiceover", args["voiceover"]])
        if args.get("transcript"):
            cmd.extend(["--transcript", args["transcript"]])
        if args.get("topic"):
            cmd.extend(["--topic", args["topic"]])
        if args.get("generate_3d_clips", True):
            cmd.append("--generate-3d-clips")
        if args.get("render_final_mp4", True):
            cmd.append("--render-mp4")
        if args.get("output_mp4"):
            cmd.extend(["--output-mp4", args["output_mp4"]])
        return run_quiet(cmd)

    if name == "shotcraft_depth_3d":
        script = sd / "reels-depth-motion" / "scripts" / "depth_engine.py"
        cmd = [
            sys.executable,
            str(script),
            "--input",
            args["input_image"],
            "--preset",
            args.get("preset", "cinematic-orbit"),
            "--frames",
            str(args.get("frames", 90)),
            "--fps",
            str(args.get("fps", 30)),
        ]
        if args.get("output_mp4"):
            cmd.extend(["--output", args["output_mp4"]])
        if args.get("export_layers_dir"):
            cmd.extend(["--export-layers", args["export_layers_dir"]])
        return run_quiet(cmd)

    if name == "shotcraft_render_qa":
        render_script = sd / "reels-templates" / "scripts" / "smart_render.py"
        fps_val = int(args.get("fps", 30))
        width_val = int(args.get("width", 1080))
        height_val = int(args.get("height", 1920))
        cmd = [
            sys.executable,
            str(render_script),
            "--workspace",
            args["workspace"],
            "--composition",
            args.get("composition", "MainReel"),
            "--fps",
            str(fps_val),
            "--width",
            str(width_val),
            "--height",
            str(height_val),
        ]
        if args.get("stills"):
            cmd.extend(["--stills", args["stills"]])
        if args.get("output_mp4"):
            cmd.extend(["--output", args["output_mp4"]])
        r_out = run_quiet(cmd)
        if not r_out.get("ok") or not args.get("output_mp4"):
            return r_out
        frame_audit = audit_video_frames(args["output_mp4"])
        sz_script = sd / "reels-safezone" / "scripts" / "safezone_audit.py"
        overlay_png = Path(args["workspace"]).expanduser().resolve() / "qa" / "safezone_overlay_proof.png"
        sz_audit = run_quiet([sys.executable, str(sz_script), "--input", args["output_mp4"], "--export-overlay", str(overlay_png)])
        qa_script = sd / "reels-qa" / "scripts" / "check_video.py"
        qa_report_path = Path(args["workspace"]).expanduser().resolve() / "qa" / "technical.json"
        dur_val = frame_audit.get("total_frames", 450) / float(fps_val)
        tech_qa = run_quiet([
            sys.executable,
            str(qa_script),
            args["output_mp4"],
            "--duration",
            str(dur_val),
            "--fps",
            str(fps_val),
            "--width",
            str(width_val),
            "--height",
            str(height_val),
            "--audio",
            args.get("audio", "optional"),
            "--report",
            str(qa_report_path),
        ])
        return {
            "ok": frame_audit.get("ok", False) and sz_audit.get("ok", False) and tech_qa.get("ok", False),
            "render": r_out,
            "frame_audit": frame_audit,
            "safezone_audit": sz_audit,
            "technical_qa": tech_qa,
        }

    if name == "shotcraft_audit_video":
        return audit_video_frames(args["mp4_path"])

    if name == "shotcraft_draft_storyboard":
        sc_script = sd / "reels-qa" / "scripts" / "storyboard_critique.py"
        cmd = [
            sys.executable, str(sc_script), "draft",
            "--workspace", args["workspace"],
            "--topic", args.get("topic", "Cara kerja AI"),
            "--style", args.get("style", "auto-context"),
            "--duration", str(args.get("duration", 24.0)),
            "--fps", str(args.get("fps", 30)),
        ]
        return run_quiet(cmd)

    if name == "shotcraft_visual_critique":
        sc_script = sd / "reels-qa" / "scripts" / "storyboard_critique.py"
        cmd = [sys.executable, str(sc_script), "critique", "--workspace", args["workspace"]]
        return run_quiet(cmd)

    if name == "shotcraft_voice_bank":
        vb_script = sd / "reels-narration" / "scripts" / "voice_bank.py"
        act = args.get("action", "list")
        cmd = [sys.executable, str(vb_script), act]
        if act == "list" and args.get("bundled_only"):
            cmd.append("--bundled-only")
        elif act == "recommend":
            cmd.extend(["--style", args.get("style", "ref3-cutaway-mechanism"), "--topic", args.get("topic", ""), "--language", args.get("language", "id-ID")])
        elif act in ("import", "extract-video") and args.get("target") and args.get("name"):
            cmd.extend([args["target"], "--name", args["name"]])
            if args.get("ref_text"):
                cmd.extend(["--ref-text", args["ref_text"]])
        elif act in ("fetch-preview", "resolve-folder") and args.get("target"):
            cmd.append(args["target"])
        return run_quiet(cmd)

    if name == "shotcraft_audit_safezone":
        sz_script = sd / "reels-safezone" / "scripts" / "safezone_audit.py"
        cmd = [sys.executable, str(sz_script), "--input", args["input_path"]]
        if args.get("export_overlay"):
            cmd.extend(["--export-overlay", args["export_overlay"]])
        return run_quiet(cmd)

    return {"ok": False, "error": f"Unknown tool: {name}"}


def send_response(msg_id, result=None, error=None):
    payload = {"jsonrpc": "2.0", "id": msg_id}
    if error is not None:
        payload["error"] = error
    else:
        payload["result"] = result
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def main():
    from core.rpc import serve
    serve(SERVER_NAME, '9.8.1', TOOLS, handle_tool_call)


if __name__ == "__main__":
    main()