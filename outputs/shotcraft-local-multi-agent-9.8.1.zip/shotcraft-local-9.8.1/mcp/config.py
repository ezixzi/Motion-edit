"""Shotcraft Pro v9.7.0 — Shared MCP Configuration Constants."""

SERVER_VERSION = "9.7.0"
PROTOCOL_VERSION = "2024-11-05"
DEFAULT_FPS = 30
DEFAULT_ASPECT = "9:16"
DEFAULT_TITLE_BADGE = ""  # Empty by default (no hardcoded watermark unless requested)

ASPECT_PRESETS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
    "2:3": (1080, 1620),
}
