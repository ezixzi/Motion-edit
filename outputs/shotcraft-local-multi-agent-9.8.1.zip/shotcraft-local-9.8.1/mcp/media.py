#!/usr/bin/env python3
"""Shotcraft Pro v9.7.0 — Modular Media MCP Domain (`mcp/media.py`, `[P3-3]`)."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import BaseMcpTool
import shotcraft_media_mcp as _srv


class MediaNarrateTool(BaseMcpTool):
    name = "media_narrate_tts"
    description = "Conversational Indonesian SSML TTS & acoustic word alignment."

    def execute(self, args: dict) -> dict:
        return _srv.handle_tool_call(self.name, args)


if __name__ == "__main__":
    _srv.main()
