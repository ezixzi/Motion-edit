#!/usr/bin/env python3
"""
Shotcraft Pro MCP Server #4: `shotcraft-qa` (v9.7.0 Turbo)
Dedicated Smart Renderer, Frame-by-Frame Dead-Air Auditor, Mobile 9:16 Safe-Zone Guardian,
and Technical MP4 Stream/LUFS Verifier for Claude Code.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import json
import sys
from pathlib import Path

from shotcraft_mcp_server import PROTOCOL_VERSION, audit_video_frames, get_skills_dir, run_quiet, send_response

SERVER_NAME = "shotcraft-qa"
SERVER_VERSION = "9.7.0"

TOOLS = [
    {
        "name": "qa_smart_render",
        "description": "Hardware-tuned Remotion / FastRGBDraw deterministic 1080x1920 30fps renderer with automatic 16-category SFX + BGM soundtrack muxing.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string", "description": "Workspace directory"},
                "composition": {"type": "string", "default": "MainReel"},
                "stills": {"type": "string", "description": "Optional comma-separated frame numbers e.g. '15,135,255'"},
                "output_mp4": {"type": "string", "description": "Target MP4 output path"},
                "fps": {"type": "integer", "default": 30},
                "width": {"type": "integer", "default": 1080},
                "height": {"type": "integer", "default": 1920},
            },
            "required": ["workspace"],
        },
    },
    {
        "name": "qa_audit_dead_air",
        "description": "Scans a rendered MP4 frame-by-frame to verify zero empty/black dead-air gaps (<1.5% lit pixels) and presence of an audio stream.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mp4_path": {"type": "string", "description": "Path to rendered MP4"},
            },
            "required": ["mp4_path"],
        },
    },
    {
        "name": "qa_audit_safezone",
        "description": "Audits a rendered MP4 or PNG still against the 9:16 Reels/TikTok/Shorts Safe Zone (x:84..876, y:220..1490) and exports a visual proof image (`safezone_overlay_proof.png`).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "input_path": {"type": "string", "description": "Path to MP4 or PNG"},
                "export_overlay": {"type": "string", "description": "Optional path to save safezone_overlay_proof.png"},
            },
            "required": ["input_path"],
        },
    },
    {
        "name": "qa_full_verify",
        "description": "Runs all 3 mandatory QA gates in ONE call: (1) Frame Dead-Air Audit, (2) Reels 9:16 Safe-Zone Audit + overlay proof, and (3) Technical Stream/Decode/Audio QA (`check_video.py`).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mp4_path": {"type": "string", "description": "Path to rendered MP4"},
                "workspace": {"type": "string", "description": "Optional workspace folder for saving QA reports"},
                "fps": {"type": "integer", "default": 30},
                "width": {"type": "integer", "default": 1080},
                "height": {"type": "integer", "default": 1920},
            },
            "required": ["mp4_path"],
        },
    },
]


def handle_tool_call(name: str, args: dict) -> dict:
    sd = get_skills_dir()

    if name == "qa_smart_render":
        render_script = sd / "reels-templates" / "scripts" / "smart_render.py"
        cmd = [
            sys.executable,
            str(render_script),
            "--workspace",
            args["workspace"],
            "--composition",
            args.get("composition", "MainReel"),
            "--fps",
            str(args.get("fps", 30)),
            "--width",
            str(args.get("width", 1080)),
            "--height",
            str(args.get("height", 1920)),
        ]
        if args.get("stills"):
            cmd.extend(["--stills", args["stills"]])
        if args.get("output_mp4"):
            cmd.extend(["--output", args["output_mp4"]])
        return run_quiet(cmd)

    if name == "qa_audit_dead_air":
        return audit_video_frames(args["mp4_path"])

    if name == "qa_audit_safezone":
        sz_script = sd / "reels-safezone" / "scripts" / "safezone_audit.py"
        cmd = [sys.executable, str(sz_script), "--input", args["input_path"]]
        if args.get("export_overlay"):
            cmd.extend(["--export-overlay", args["export_overlay"]])
        return run_quiet(cmd)

    if name == "qa_full_verify":
        mp4 = Path(args["mp4_path"]).expanduser().resolve()
        ws = Path(args.get("workspace") or mp4.parent.parent).expanduser().resolve()
        qa_dir = ws / "qa"
        qa_dir.mkdir(parents=True, exist_ok=True)

        fps_val = int(args.get("fps", 30))
        width_val = int(args.get("width", 1080))
        height_val = int(args.get("height", 1920))

        frame_audit = audit_video_frames(str(mp4))
        sz_script = sd / "reels-safezone" / "scripts" / "safezone_audit.py"
        overlay_png = qa_dir / "safezone_overlay_proof.png"
        sz_audit = run_quiet([sys.executable, str(sz_script), "--input", str(mp4), "--export-overlay", str(overlay_png)])

        qa_script = sd / "reels-qa" / "scripts" / "check_video.py"
        qa_report = qa_dir / "technical.json"
        dur_val = max(0.1, frame_audit.get("total_frames", 360) / float(fps_val))
        tech_qa = run_quiet([
            sys.executable,
            str(qa_script),
            str(mp4),
            "--duration",
            str(dur_val),
            "--fps",
            str(fps_val),
            "--width",
            str(width_val),
            "--height",
            str(height_val),
            "--audio",
            "required",
            "--report",
            str(qa_report),
        ])
        all_ok = frame_audit.get("ok", False) and sz_audit.get("ok", False) and tech_qa.get("ok", False)
        return {
            "ok": all_ok,
            "video": str(mp4),
            "dead_air_verdict": frame_audit.get("verdict"),
            "safezone_verdict": sz_audit.get("verdict"),
            "safezone_overlay_proof": str(overlay_png),
            "technical_pass": tech_qa.get("ok", False),
            "technical_report": str(qa_report),
        }

    return {"ok": False, "error": f"Unknown tool: {name}"}


def main():
    from core.rpc import serve
    serve(SERVER_NAME, '9.8.1', TOOLS, handle_tool_call)


if __name__ == "__main__":
    main()
