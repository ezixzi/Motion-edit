---
name: reels-safezone
description: Enforce and audit Instagram Reels, TikTok, and YouTube Shorts UI Safe Zones (x: 84..876px, y: 220..1490px at 1080x1920). Detects text/card collisions with platform buttons, headers, right-side action rails, and bottom captions, and generates visual overlay proofs.
---

# Reels, TikTok & Shorts Safe-Zone Auditor (`reels-safezone` v5.8)

Guarantees that no headline, subtitle, metric badge, or UI card is ever covered by Instagram Reels, TikTok, or YouTube Shorts interface overlays (`x: 84..876px, y: 220..1490px` at `1080×1920`).
