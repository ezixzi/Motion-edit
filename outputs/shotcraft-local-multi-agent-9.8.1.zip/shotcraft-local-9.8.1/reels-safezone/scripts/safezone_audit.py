#!/usr/bin/env python3
"""
Reels/TikTok/Shorts 9:16 Safe-Zone Auditor (`safezone_audit.py` — v9.5).
Uses fast PIL + FFmpeg single-frame extraction (zero `cv2.VideoCapture` C-extension deadlocks!).
Audits top UI bar (`y < 220`), right action rail (`x > 876, y: 780..1490`), and bottom caption zone (`y > 1490`),
and exports `safezone_overlay_proof.png`.
Never reports a false PASS if the image/video cannot be decoded.
"""
import sys as _sys

if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


def extract_sample_image(input_path: Path):
    from PIL import Image

    is_video = input_path.suffix.lower() in (".mp4", ".mov", ".mkv", ".webm")
    if not is_video:
        return Image.open(input_path).convert("RGB")

    if shutil.which("ffmpeg"):
        with tempfile.TemporaryDirectory(prefix="sz-frm-") as td:
            out_png = Path(td) / "sample.png"
            subprocess.run(
                ["ffmpeg", "-nostdin", "-y", "-v", "error", "-ss", "0.5", "-i", str(input_path), "-frames:v", "1", str(out_png)],
                stdin=subprocess.DEVNULL,
                capture_output=True,
                timeout=15,
                check=False,
            )
            if out_png.is_file() and out_png.stat().st_size > 128:
                return Image.open(out_png).convert("RGB").copy()
    return None


ASPECT_SAFE_ZONE_RATIOS = {
    # (x_min_ratio, x_max_ratio, y_min_ratio, y_max_ratio) relative to reference W x H
    "9:16":  (84.0 / 1080.0,  876.0 / 1080.0,  220.0 / 1920.0,  1490.0 / 1920.0),
    "16:9":  (220.0 / 1920.0, 1698.0 / 1920.0, 84.0 / 1080.0,   996.0 / 1080.0),
    "1:1":   (204.0 / 1080.0, 876.0 / 1080.0,  204.0 / 1080.0,  876.0 / 1080.0),
    "4:5":   (102.0 / 1080.0, 876.0 / 1080.0,  176.0 / 1350.0,  1174.0 / 1350.0),
    "2:3":   (137.0 / 1080.0, 876.0 / 1080.0,  220.0 / 1620.0,  1400.0 / 1620.0),
}


def audit_safezone(input_path: Path, export_overlay: Path = None, aspect_ratio: str = "9:16") -> dict:
    if not input_path.is_file():
        return {"ok": False, "error": f"File not found: {input_path}", "verdict": f"FAIL: File not found: {input_path}"}
    try:
        from PIL import Image, ImageDraw, ImageFilter

        img = extract_sample_image(input_path)
        if img is None:
            return {
                "ok": False,
                "input": str(input_path),
                "safe_rect": {"x_min": 84, "x_max": 876, "y_min": 220, "y_max": 1490},
                "violations_count": 1,
                "error": "Could not decode image or extract video frame for Safe-Zone audit.",
                "verdict": "FAIL: Could not decode image or extract video frame for Safe-Zone audit.",
            }

        w, h = img.size
        xr_min, xr_max, yr_min, yr_max = ASPECT_SAFE_ZONE_RATIOS.get(
            aspect_ratio, ASPECT_SAFE_ZONE_RATIOS["9:16"]
        )
        x_min = int(round(w * xr_min))
        x_max = int(round(w * xr_max))
        y_min = int(round(h * yr_min))
        y_max = int(round(h * yr_max))

        gray = img.convert("L")
        edges = gray.filter(ImageFilter.FIND_EDGES)

        def zone_sharp_bright_ratio(box):
            g_crop = gray.crop(box).getdata()
            e_crop = edges.crop(box).getdata()
            total = max(1, len(g_crop))
            hits = sum(1 for gv, ev in zip(g_crop, e_crop) if gv > 195 and ev > 95)
            return hits / float(total)

        top_danger = zone_sharp_bright_ratio((0, 0, w, int(y_min * 0.82)))
        right_rail_danger = zone_sharp_bright_ratio((int(x_max + w * 0.03), int(h * 0.42), w, y_max))
        bot_caption_danger = zone_sharp_bright_ratio((0, int(y_max + h * 0.04), x_max, h))

        violations = []
        if top_danger > 0.035:
            violations.append({"zone": "top_ui_bar", "density": round(top_danger, 4)})
        if right_rail_danger > 0.035:
            violations.append({"zone": "right_action_rail", "density": round(right_rail_danger, 4)})
        if bot_caption_danger > 0.045:
            violations.append({"zone": "bottom_caption_bar", "density": round(bot_caption_danger, 4)})

        if export_overlay:
            export_overlay.parent.mkdir(parents=True, exist_ok=True)
            base_rgba = img.convert("RGBA")
            tint = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            tdraw = ImageDraw.Draw(tint)
            tdraw.rectangle([0, 0, w, y_min], fill=(220, 40, 40, 72))
            tdraw.rectangle([0, y_max, w, h], fill=(220, 40, 40, 72))
            tdraw.rectangle([x_max, y_min, w, y_max], fill=(220, 80, 40, 72))
            tdraw.rectangle([0, y_min, x_min, y_max], fill=(220, 80, 40, 72))
            tdraw.rectangle([x_min, y_min, x_max, y_max], outline=(80, 230, 80, 255), width=4)
            blended = Image.alpha_composite(base_rgba, tint).convert("RGB")
            blended.save(str(export_overlay), format="PNG")

        passed = len(violations) == 0
        return {
            "ok": passed,
            "scope": "single-frame edge-density heuristic, not OCR or complete text validation",
            "human_review_required": True,
            "input": str(input_path),
            "resolution": f"{w}x{h}",
            "safe_rect": {"x_min": x_min, "x_max": x_max, "y_min": y_min, "y_max": y_max},
            "violations_count": len(violations),
            "violations": violations,
            "overlay_preview": str(export_overlay) if export_overlay else None,
            "verdict": (
                f"No dense bright-edge warnings in the sampled frame; text containment requires visual review (x:{x_min}..{x_max}, y:{y_min}..{y_max})."
                if passed
                else f"WARN/FAIL: Detected bright text/card edges inside Reels UI danger zones: {violations}"
            ),
        }
    except Exception as exc:
        return {
            "ok": False,
            "input": str(input_path),
            "safe_rect": {"x_min": 84, "x_max": 876, "y_min": 220, "y_max": 1490},
            "violations_count": 1,
            "error": f"{type(exc).__name__}: {exc}",
            "verdict": f"FAIL: Safe-Zone audit exception ({type(exc).__name__}: {exc})",
        }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--export-overlay")
    p.add_argument("--report")
    p.add_argument("--aspect", default="9:16", choices=["9:16", "16:9", "1:1", "4:5", "2:3"])
    a = p.parse_args()
    res = audit_safezone(
        Path(a.input).expanduser().resolve(),
        Path(a.export_overlay).expanduser().resolve() if a.export_overlay else None,
        aspect_ratio=a.aspect,
    )
    if a.report:
        Path(a.report).expanduser().resolve().write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(res, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
