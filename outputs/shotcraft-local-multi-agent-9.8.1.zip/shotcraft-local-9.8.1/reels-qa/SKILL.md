---
name: reels-qa
description: Verify a final Reels or promo MP4 with ffprobe/ffmpeg and independent visual/audio review; check duration, decoded frame count, resolution, fps, strict decode integrity, sample peak/clipping, EBU R128 integrated loudness (LUFS), and black-frame detection.
---

# Reels & Video Technical + Visual QA (v4.0)

Run `check_video.py` with actual brief parameters:

```sh
python "<this-skill>/scripts/check_video.py" "<final.mp4>" \
  --duration 45 \
  --fps 30 \
  --width 1080 \
  --height 1920 \
  --audio required \
  --check-lufs \
  --check-black \
  --report "<qa>/technical.json"
```

## What `check_video.py` Verifies

1. **Stream & Container Integrity**: Single video stream, expected audio stream presence (`required`, `forbidden`, `optional`), exact resolution (`width × height`), exact `avg_frame_rate`, integral frame count (`nb_read_frames == duration * fps`), and container/stream duration within `±0.5` frame.
2. **Strict Decode (`ffmpeg -xerror`)**: Decodes every video and audio packet to catch corrupt frames or truncated streams.
3. **Sample Peak & Clipping**: Scans all decoded 32-bit float PCM samples for `>= 1.0` clipping or non-finite values.
4. **EBU R128 Integrated Loudness (`--check-lufs`)**: Measures integrated loudness (`integrated_lufs`, target `-14 LUFS` for Reels/TikTok/YouTube) and True Peak (`true_peak_dbfs`).
5. **Accidental Black Frame Detection (`--check-black`)**: Detects unintended blank/black intervals (`blackdetect`) caused by failed asset loads or gap errors between Remotion sequences.

## Visual & Independent Review

Metadata checks never replace visual inspection. Extract and inspect key boundary stills (hook, transition midpoint, max 3D parallax displacement, dense caption frame, final CTA hold). Use a fresh `reels-reviewer` agent from the parent Claude session for independent review before delivering the MP4.
