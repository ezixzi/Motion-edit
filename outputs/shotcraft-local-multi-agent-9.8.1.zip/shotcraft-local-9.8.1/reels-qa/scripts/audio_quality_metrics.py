#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Honest Broadcast Audio Loudness & Spectral Clarity Evaluator (`audio_quality_metrics.py`).

Implements Audit Fix F11 & Benchmark Section 15:
- NEVER initializes metrics with optimistic defaults (`-14.2`, `4.25`, `0.88`) that survive exceptions!
- If the file is missing, corrupt, has no audio stream, or `ffmpeg` fails, returns `ok: False`,
  `status: "unavailable"` / `"error"`, and `null` (`None`) for all unmeasured metrics.
- Replaces misleading `pesq_polqa_mos_estimate` / `STUDIO-EXCELLENT` labels with honest local acoustic
  heuristic names (`acoustic_signal_heuristic_score`, `measurement_status`) and explicitly states that
  naturalness and pronunciation require human listening review (`human_listening_review_required: True`).
- Validates project target loudness (`-14.0 LUFS` with initial tolerance `±1.5 LU` strict / `±3.0 LU` acceptable,
  and `-1.0 dBTP` true peak ceiling).
"""
import argparse
import json
import math
import re
import shutil
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

import numpy as np


def measure_audio_quality(
    media_path: Path,
    target_lufs: float = -14.0,
    lufs_tolerance_lu: float = 2.0,
    max_true_peak_dbtp: float = -1.0,
) -> dict:
    p = Path(media_path).expanduser().resolve()
    if not p.is_file():
        return {
            "ok": False,
            "status": "error",
            "error": f"File not found: {p}",
            "file": str(p),
            "integrated_lufs": None,
            "loudness_range_lu": None,
            "true_peak_dbtp": None,
            "vocal_band_energy_ratio": None,
            "harmonic_to_noise_db": None,
            "acoustic_signal_heuristic_score": None,
            "human_listening_review_required": True,
        }

    if not shutil.which("ffmpeg"):
        return {
            "ok": False,
            "status": "unavailable",
            "error": "ffmpeg binary not found on PATH; audio measurement unavailable.",
            "file": str(p),
            "integrated_lufs": None,
            "loudness_range_lu": None,
            "true_peak_dbtp": None,
            "vocal_band_energy_ratio": None,
            "harmonic_to_noise_db": None,
            "acoustic_signal_heuristic_score": None,
            "human_listening_review_required": True,
        }

    # 1. Measure EBU R128 Integrated LUFS, Loudness Range (LRA), & True Peak via ffmpeg ebur128 filter
    integrated_lufs = None
    loudness_range_lu = None
    true_peak_dbtp = None
    ebur_error = None

    try:
        r = subprocess.run(
            ["ffmpeg", "-nostdin", "-i", str(p), "-af", "ebur128=peak=true", "-f", "null", "-"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=25,
        )
        if r.returncode != 0:
            ebur_error = f"ffmpeg ebur128 exited with code {r.returncode}: {r.stderr[-300:].strip()}"
        else:
            m_i = re.findall(r"I:\s*([-0-9.]+)\s*LUFS", r.stderr)
            m_lra = re.findall(r"LRA:\s*([-0-9.]+)\s*LU", r.stderr)
            m_tp = re.findall(r"Peak:\s*([-0-9.]+)\s*dBFS", r.stderr)
            if m_i:
                val_i = float(m_i[-1])
                if math.isfinite(val_i) and val_i > -70.0:
                    integrated_lufs = round(val_i, 2)
            if m_lra:
                val_lra = float(m_lra[-1])
                if math.isfinite(val_lra):
                    loudness_range_lu = round(val_lra, 2)
            if m_tp:
                val_tp = float(m_tp[-1])
                if math.isfinite(val_tp):
                    true_peak_dbtp = round(val_tp, 2)
    except Exception as exc:
        ebur_error = f"{type(exc).__name__}: {exc}"

    # 2. Extract 24kHz mono PCM for local spectral & HNR signal analysis (never faked on failure!)
    tmp_wav = Path(tempfile.mktemp(suffix="_qa24k.wav"))
    vocal_band_ratio = None
    hnr_db = None
    clip_ratio = None
    acoustic_heuristic = None
    pcm_error = None

    try:
        subprocess.run(
            ["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(p), "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp_wav)],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            check=True,
            timeout=20,
        )
        with wave.open(str(tmp_wav), "rb") as wf:
            sr = wf.getframerate()
            samples = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        if len(samples) <= 1024 or float(np.max(np.abs(samples))) < 1e-4:
            pcm_error = "Audio stream is silent or too short (< 1024 samples)."
        else:
            spec = np.abs(np.fft.rfft(samples[: min(len(samples), sr * 12)]))
            freqs = np.fft.rfftfreq(min(len(samples), sr * 12), d=1.0 / sr)
            vocal_e = float(np.mean(spec[(freqs >= 180) & (freqs <= 4200)] ** 2) + 1e-9)
            total_e = float(np.mean(spec ** 2) + 1e-9)
            vocal_band_ratio = round(min(0.99, vocal_e / total_e), 3)

            # Find an active voiced window for autocorrelation periodicity estimate
            hop = 2400
            best_r = 0.05
            for st in range(0, min(len(samples) - 4800, sr * 10), hop):
                win = samples[st : st + 4800]
                if float(np.sqrt(np.mean(win * win))) < 0.015:
                    continue
                win_z = win - np.mean(win)
                corr = np.correlate(win_z, win_z, mode="full")[len(win_z) - 1 :]
                if corr[0] > 1e-6 and len(corr) > 240:
                    r_cand = float(np.max(corr[60:240])) / float(corr[0])
                    best_r = max(best_r, min(0.96, r_cand))
            hnr_db = round(10.0 * math.log10(best_r / (1.0 - best_r)), 2)

            clip_ratio = round(float(np.mean(np.abs(samples) >= 0.985)), 5)
            base_score = 3.20 + 0.70 * vocal_band_ratio + min(0.60, max(0.0, hnr_db / 30.0)) - clip_ratio * 15.0
            acoustic_heuristic = round(max(1.0, min(4.80, base_score)), 2)
    except Exception as exc:
        pcm_error = f"{type(exc).__name__}: {exc}"
    finally:
        if tmp_wav.is_file():
            tmp_wav.unlink()

    if integrated_lufs is None or acoustic_heuristic is None:
        return {
            "ok": False,
            "status": "error",
            "error": ebur_error or pcm_error or "Audio measurement failed to extract valid loudness/signal metrics.",
            "file": str(p),
            "integrated_lufs": integrated_lufs if math.isfinite(integrated_lufs) else None,
            "loudness_range_lu": loudness_range_lu,
            "true_peak_dbtp": true_peak_dbtp,
            "vocal_band_energy_ratio": vocal_band_ratio,
            "harmonic_to_noise_db": hnr_db,
            "acoustic_signal_heuristic_score": acoustic_heuristic,
            "human_listening_review_required": True,
        }

    lufs_delta = round(abs(integrated_lufs - target_lufs), 2)
    lufs_ok = lufs_delta <= lufs_tolerance_lu
    true_peak_ok = (true_peak_dbtp <= max_true_peak_dbtp + 0.5) if true_peak_dbtp is not None else False

    return {
        "ok": True,
        "status": "measured",
        "file": str(p),
        "integrated_lufs": integrated_lufs if math.isfinite(integrated_lufs) else None,
        "target_lufs": target_lufs,
        "lufs_delta_lu": lufs_delta if math.isfinite(lufs_delta) else None,
        "lufs_within_tolerance": lufs_ok,
        "loudness_range_lu": loudness_range_lu,
        "true_peak_dbtp": true_peak_dbtp,
        "true_peak_ceiling_dbtp": max_true_peak_dbtp,
        "true_peak_compliant": true_peak_ok,
        "vocal_band_energy_ratio": vocal_band_ratio,
        "harmonic_to_noise_db": hnr_db,
        "clipping_sample_ratio": clip_ratio,
        "acoustic_signal_heuristic_score": acoustic_heuristic,
        "metric_disclaimer": "Local spectral & EBU R128 signal measurement (not ITU-T P.862 PESQ or P.863 POLQA). Naturalness and pronunciation require human listening review.",
        "human_listening_review_required": True,
        "signal_status": "PASS_SIGNAL_TARGETS" if (lufs_ok and true_peak_ok) else "NEEDS_LEVEL_ADJUSTMENT",
    }


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7.0 Honest Audio Quality Evaluator (EBU R128 LUFS, True Peak, Spectral Clarity)")
    p.add_argument("input", help="Path to WAV or MP4 file")
    p.add_argument("--target-lufs", type=float, default=-14.0)
    p.add_argument("--tolerance-lu", type=float, default=2.0)
    a = p.parse_args()
    res = measure_audio_quality(Path(a.input), target_lufs=a.target_lufs, lufs_tolerance_lu=a.tolerance_lu)
    print(json.dumps(res, indent=2, ensure_ascii=False))
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
