#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Honest Editorial & Visual Readability Heuristic Scorer (`retention_model.py`).

Implements Audit Fix F14:
- Renames misleading "ML Viewer Retention Prediction" / "S-TIER VIRAL POTENTIAL" claims to
  `editorial_heuristic_score`.
- Explicitly states `is_empirical_ab_test: False` and `score_type: "editorial_heuristic_score"`.
- Does NOT reward fabricated numbers or chaotic multi-style switching.
- Evaluates:
  1. `hook_clarity_score`: Whether scene 1 introduces a clear question or explanatory premise.
  2. `visual_continuity_score`: Coherence of style family and subject identity across scenes.
  3. `caption_readability_score`: Comfortable words-per-second (1.4 - 3.5 WPS) without overcrowding.
  4. `pacing_balance_score`: Balanced shot duration.
  5. `visual_clarity_index`: Edge/contrast clarity from rendered stills if provided.
"""
import argparse
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image


def compute_image_features(still_paths: list[str]) -> dict:
    edge_scores = []
    entropies = []
    for sp in still_paths[:6]:
        p = Path(sp)
        if not p.is_file():
            continue
        try:
            im = Image.open(str(p)).convert("RGB").resize((270, 480))
            arr = np.asarray(im, dtype=np.float32)
            gray = 0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]
            gx = np.abs(np.diff(gray, axis=1))
            gy = np.abs(np.diff(gray, axis=0))
            edge_density = float(np.mean(gx) + np.mean(gy)) / 32.0
            edge_scores.append(min(1.0, edge_density))

            hist, _ = np.histogram(arr.ravel(), bins=64, range=(0, 256), density=True)
            hist = hist[hist > 1e-9]
            ent = -float(np.sum(hist * np.log2(hist * 4.0)))
            entropies.append(min(1.0, max(0.2, abs(ent) / 6.0)))
        except Exception:
            continue

    return {
        "visual_complexity": round(float(np.mean(edge_scores)) if edge_scores else 0.70, 4),
        "color_entropy": round(float(np.mean(entropies)) if entropies else 0.72, 4),
    }


def compute_editorial_heuristic_score(
    scenes: list,
    fps: int = 30,
    still_paths: list[str] = None,
    audio_env_path: Path = None,
) -> dict:
    if not scenes:
        return {
            "score_type": "editorial_heuristic_score",
            "is_empirical_ab_test": False,
            "editorial_heuristic_score": 50.0,
        }

    img_feats = compute_image_features(still_paths or [])

    s0 = scenes[0]
    h0 = f"{s0.get('headline', '')} {s0.get('narration', '')}".lower()
    has_q = "?" in h0 or any(w in h0 for w in ("bagaimana", "kenapa", "pernah", "cara", "proses", "alur", "how", "why"))
    hook_clarity = 0.88 if has_q else 0.76

    modes_used = len({s.get("visualMode") for s in scenes})
    subjects_used = len({s.get("subjectId", "default") for s in scenes})
    continuity_feat = 0.95 if (subjects_used == 1 and 1 <= modes_used <= 6) else max(0.72, 0.95 - max(0, subjects_used - 1) * 0.08)

    # Penalize ungrounded numbers when no sources are attached (F03 / F14)
    ungrounded_penalty = 0.0
    for s in scenes:
        m_val = str(s.get("metric") or "").strip()
        sources = (s.get("content") or {}).get("sources") or s.get("sources") or []
        if m_val and any(ch.isdigit() for ch in m_val) and not sources:
            ungrounded_penalty += 4.0

    avg_dur = sum(int(s.get("durationInFrames", 90)) / float(fps) for s in scenes) / max(1, len(scenes))
    pacing_feat = 0.94 if 2.5 <= avg_dur <= 6.5 else max(0.55, 0.94 - abs(avg_dur - 4.5) * 0.06)

    wps_list = []
    for s in scenes:
        txt = re.sub(r"<[^>]+>", " ", str(s.get("narration") or s.get("subcopy") or s.get("headline", "")))
        wc = len(txt.split())
        dur_s = max(1.0, int(s.get("durationInFrames", 90)) / float(fps))
        wps_list.append(wc / dur_s)
    avg_wps = sum(wps_list) / max(1, len(wps_list))
    cap_opt = 0.95 if 1.4 <= avg_wps <= 3.6 else max(0.60, 0.95 - abs(avg_wps - 2.5) * 0.12)

    raw_score = (
        25.0 * hook_clarity
        + 25.0 * continuity_feat
        + 25.0 * cap_opt
        + 25.0 * pacing_feat
        - ungrounded_penalty
    )
    final_score = round(max(40.0, min(98.0, raw_score)), 1)

    return {
        "score_type": "editorial_heuristic_score",
        "is_empirical_ab_test": False,
        "note": "Skor heuristik editorial (kejelasan hook, kontinuitas style/objek, keterbacaan teks, dan tempo); bukan prediksi retensi penonton empiris.",
        "editorial_heuristic_score": final_score,
        "hook_in_first_3s": has_q,
        "hook_clarity_score": int(round(hook_clarity * 100)),
        "visual_continuity_score": int(round(continuity_feat * 100)),
        "visual_pacing_score": int(round(pacing_feat * 100)),
        "avg_scene_duration_sec": round(avg_dur, 2),
        "caption_readability_score": int(round(cap_opt * 100)),
        "ungrounded_metric_penalty": round(ungrounded_penalty, 1),
        "features": {
            "visual_complexity": img_feats["visual_complexity"],
            "color_entropy": img_feats["color_entropy"],
            "caption_density_wps": round(avg_wps, 2),
        },
        # Backward compatibility key mapped to the honest score
        "overall_predicted_retention_pct": final_score,
    }


# Keep backward-compatible function name alias
predict_retention_ml = compute_editorial_heuristic_score


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7.0 Editorial Heuristic Scorer (F14)")
    p.add_argument("--timeline", required=True, help="Path to timeline.json")
    p.add_argument("--stills", default="", help="Comma-separated paths to rendered still PNGs")
    p.add_argument("--audio-envelope", default="", help="Optional path to audio_envelope.json")
    a = p.parse_args()

    tl = json.loads(Path(a.timeline).expanduser().read_text(encoding="utf-8"))
    stills = [x.strip() for x in a.stills.split(",") if x.strip()]
    res = compute_editorial_heuristic_score(
        tl.get("scenes", []),
        fps=int(tl.get("fps", 30)),
        still_paths=stills,
        audio_env_path=Path(a.audio_envelope) if a.audio_envelope else None,
    )
    print(json.dumps(res, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
