#!/usr/bin/env python3
"""
Shotcraft Pro v9.8.0 — Visual Regression Testing & Percy/Chromatic Snapshot Engine (`visual_regression.py`, `[T1]`).

Renders golden styleframes across all visual modes (`neural-network`, `coffee-editorial-3d`,
`ref5-editorial-cutaway`, `ref1-tutorial-deck`, `ref2-floating-glass`, `ref3-pricing-voxel`, `ref4-tape-mascot`),
computes structural similarity (SSIM / normalized pixel RMSE) against golden baselines, and exports
a Percy / Chromatic compatible snapshot manifest (`percy_snapshots.json`).

RAR15: Versioned visual regression baselines — golden frames are stored per-version
(`golden_frames/v<major>.<minor>/`) with a `baseline_manifest.json` recording the
Shotcraft version that produced each baseline, so regressions are always compared
against the correct release's reference frames.

RAR16: Separate release gates — this module's `visual_pass` result feeds the
release eligibility gate alongside technical_pass, content_pass,
audio_measurement_pass, listening_pass, and leakage_pass.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
sys.path.insert(0, str(SKILLS_ROOT / "reels-templates" / "scripts"))
import smart_render as sr_mod

SHOTCRAFT_VERSION = "9.8.0"

STYLES_TO_TEST = [
    "neural-network",
    "coffee-editorial-3d",
    "ref5-editorial-cutaway",
    "ref1-tutorial-deck",
    "ref2-floating-glass",
    "ref3-pricing-voxel",
    "ref4-tape-mascot",
]

# Release gate names tracked by the Shotcraft Pro release pipeline (RAR16).
RELEASE_GATES = [
    "pipeline_completed",
    "technical_pass",
    "content_pass",
    "audio_measurement_pass",
    "listening_pass",
    "visual_pass",
    "leakage_pass",
    "release_eligible",
]


def _version_dir_name(version: str) -> str:
    """Normalize a version string like '9.8.0' into a directory-safe 'v9.8.0'."""
    v = version.strip().lstrip("v")
    if not re.match(r"^\d+(\.\d+)*$", v):
        raise ValueError(f"Invalid version '{version}'. Expected semantic version like '9.8.0'.")
    return f"v{v}"


def _golden_root() -> Path:
    return HERE.parent / "golden_frames"


def _baseline_manifest_path(version_dir: Path) -> Path:
    return version_dir / "baseline_manifest.json"


def _load_baseline_manifest(version_dir: Path) -> dict:
    mp = _baseline_manifest_path(version_dir)
    if mp.is_file():
        try:
            return json.loads(mp.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"version": version_dir.name, "shotcraft_version": SHOTCRAFT_VERSION, "baselines": {}}


def _save_baseline_manifest(version_dir: Path, manifest: dict) -> None:
    manifest["version"] = version_dir.name
    manifest["shotcraft_version"] = SHOTCRAFT_VERSION
    _baseline_manifest_path(version_dir).write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def list_available_versions() -> list[str]:
    """Return sorted list of available baseline version directories (e.g. ['v9.7.0', 'v9.8.0'])."""
    root = _golden_root()
    if not root.is_dir():
        return []
    versions = []
    for child in root.iterdir():
        if child.is_dir() and child.name.startswith("v") and _baseline_manifest_path(child).is_file():
            versions.append(child.name)
    return sorted(versions, key=lambda v: tuple(map(int,v.lstrip("v").split("."))))


def latest_version() -> str | None:
    versions = list_available_versions()
    return versions[-1] if versions else None


def compute_image_similarity(img_a: Image.Image, img_b: Image.Image) -> dict:
    a = np.asarray(img_a.convert("RGB"), dtype=np.float32)
    b = np.asarray(img_b.convert("RGB").resize(img_a.size), dtype=np.float32)
    diff = np.abs(a - b)
    mae = float(np.mean(diff))
    rmse = float(np.sqrt(np.mean(diff * diff)))
    # Approximate SSIM on luminance
    ya = 0.299 * a[:, :, 0] + 0.587 * a[:, :, 1] + 0.114 * a[:, :, 2]
    yb = 0.299 * b[:, :, 0] + 0.587 * b[:, :, 1] + 0.114 * b[:, :, 2]
    mu_a, mu_b = float(np.mean(ya)), float(np.mean(yb))
    var_a, var_b = float(np.var(ya)), float(np.var(yb))
    cov_ab = float(np.mean((ya - mu_a) * (yb - mu_b)))
    c1, c2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
    ssim = ((2 * mu_a * mu_b + c1) * (2 * cov_ab + c2)) / ((mu_a ** 2 + mu_b ** 2 + c1) * (var_a + var_b + c2))
    return {"ssim": round(float(ssim), 5), "rmse": round(rmse, 3), "mae": round(mae, 3), "passed": ssim >= 0.96}


def run_visual_regression(
    out_dir: Path,
    update_golden: bool = False,
    version: str | None = None,
    target_version: str | None = None,
) -> dict:
    """
    Run visual regression against a specific baseline version.

    Args:
        out_dir: Directory to write current frames and percy manifest.
        update_golden: If True, overwrite golden baselines for the given version.
        version: The baseline version to compare against (e.g. 'v9.8.0' or '9.8.0').
                 Defaults to the latest available version, or creates v<SHOTCRAFT_VERSION> if none exist.
        target_version: Alias for `version` (kept for caller compatibility).
    """
    target = target_version or version
    target_dir_name = _version_dir_name(target) if target else None

    golden_root = _golden_root()
    version_dir = golden_root / (target_dir_name or latest_version() or _version_dir_name(SHOTCRAFT_VERSION))
    if update_golden:
        version_dir.mkdir(parents=True, exist_ok=True)
    missing = [str(version_dir / f'golden_{style}.png') for style in STYLES_TO_TEST if not (version_dir / f'golden_{style}.png').is_file()]
    if missing and not update_golden:
        return {'ok': False, 'visual_pass': False, 'status': 'missing_baseline', 'missing': missing, 'results': []}

    out_dir.mkdir(parents=True, exist_ok=True)

    manifest = _load_baseline_manifest(version_dir)
    results = []
    percy_snapshots = []

    for style in STYLES_TO_TEST:
        sample_scene = {
            "id": f"golden-{style}",
            "eyebrow": f"GOLDEN TEST · {style.upper()}",
            "metric": "175",
            "unit": "MILIAR",
            "headline": f"Uji Regresi Visual Gaya {style}",
            "subcopy": "Memastikan konsistensi piksel, pencahayaan 3D Blinn-Phong, dan tipografi aman.",
            "captionStyle": "glitch" if style == "neural-network" else "karaoke-pill",
            "emphasisWords": ["VISUAL", "175"],
            "accent": "#38BDF8",
            "visualMode": style,
            "durationInFrames": 90,
        }
        img = sr_mod.render_single_scene_frame(1080, 1920, sample_scene, 0, 3, 24, 30.0, "")
        cur_png = out_dir / f"current_{style}.png"
        img.save(str(cur_png), format="PNG")
        gold_png = version_dir / f"golden_{style}.png"

        if update_golden:
            img.save(str(gold_png), format="PNG")
            manifest.setdefault("baselines", {})[style] = {
                "golden_png": str(gold_png),
                "sha256": hashlib.sha256(cur_png.read_bytes()).hexdigest()[:16],
                "shotcraft_version": SHOTCRAFT_VERSION,
            }

        gold_img = Image.open(str(gold_png))
        sim = compute_image_similarity(img, gold_img)
        sha = hashlib.sha256(cur_png.read_bytes()).hexdigest()[:16]
        results.append(
            {
                "style": style,
                "baseline_version": version_dir.name,
                "current_png": str(cur_png),
                "golden_png": str(gold_png),
                "sha256": sha,
                **sim,
            }
        )
        percy_snapshots.append(
            {"name": f"ShotcraftPro-{style}-frame24", "url": str(cur_png), "widths": [1080], "minHeight": 1920}
        )

    if update_golden:
        _save_baseline_manifest(version_dir, manifest)

    percy_file = out_dir / "percy_snapshots.json"
    percy_file.write_text(
        json.dumps(
            {
                "version": 1,
                "shotcraft_version": SHOTCRAFT_VERSION,
                "baseline_version": version_dir.name,
                "snapshots": percy_snapshots,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    all_passed = all(r["passed"] for r in results)
    visual_pass = all_passed
    return {
        "ok": all_passed,
        "visual_pass": visual_pass,
        "total_styles_tested": len(results),
        "baseline_version": version_dir.name,
        "baseline_dir": str(version_dir),
        "percy_manifest": str(percy_file),
        "results": results,
    }


def evaluate_release_gates(
    pipeline_completed: bool = False,
    technical_pass: bool = False,
    content_pass: bool = False,
    audio_measurement_pass: bool = False,
    listening_pass: bool = False,
    visual_pass: bool = False,
    leakage_pass: bool = False,
) -> dict:
    """
    RAR16: Evaluate all separate release gates and determine release eligibility.

    Gates:
      - pipeline_completed:   The full production pipeline ran end-to-end without hard failures.
      - technical_pass:       Technical QA (frame audit, safezone, check_video, resolution/fps).
      - content_pass:         Semantic QA — content matches topic, no subject/style mismatches.
      - audio_measurement_pass: Audio quality metrics (LUFS, stem measurements, TTS latency) within bounds.
      - listening_pass:       Human listening review completed (manual gate, defaults to False unless explicitly set).
      - visual_pass:          Visual regression — all golden frame SSIM comparisons passed.
      - leakage_pass:         No technical metadata (asset paths, hex colors, font names) leaked into display output.
      - release_eligible:     True only when ALL of the above gates are True.

    Returns a dict with each gate's status plus an overall `release_eligible` boolean.
    """
    gates = {
        "pipeline_completed": bool(pipeline_completed),
        "technical_pass": bool(technical_pass),
        "content_pass": bool(content_pass),
        "audio_measurement_pass": bool(audio_measurement_pass),
        "listening_pass": bool(listening_pass),
        "visual_pass": bool(visual_pass),
        "leakage_pass": bool(leakage_pass),
    }
    release_eligible = all(gates.values())
    gates["release_eligible"] = release_eligible
    return {
        "ok": release_eligible,
        "release_eligible": release_eligible,
        "gates": gates,
        "failing_gates": [k for k, v in gates.items() if k != "release_eligible" and not v],
        "shotcraft_version": SHOTCRAFT_VERSION,
    }


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.8.0 Visual Regression & Golden Frame QA (`[T1]`)")
    p.add_argument("--out-dir", default="/tmp/shotcraft_visual_regression")
    p.add_argument("--update-golden", action="store_true", help="Update golden reference frames for the selected version")
    p.add_argument("--version", default=None, help="Baseline version to compare against (e.g. 9.8.0). Defaults to latest available.")
    p.add_argument("--list-versions", action="store_true", help="List all available baseline versions and exit")
    a = p.parse_args()

    if a.list_versions:
        print(json.dumps({"available_versions": list_available_versions(), "latest": latest_version()}, indent=2))
        return 0

    res = run_visual_regression(
        Path(a.out_dir).expanduser().resolve(),
        update_golden=a.update_golden,
        version=a.version,
    )
    print(json.dumps(res, indent=2))
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
