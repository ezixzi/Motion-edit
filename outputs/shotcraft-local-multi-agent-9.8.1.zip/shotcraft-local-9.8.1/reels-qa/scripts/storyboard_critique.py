#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Claude Code Storyboard Draft & Semantic + Visual Critique Engine (`storyboard_critique.py`).

Implements Audit Fixes F08, F11, F12 & Benchmark RQ01:
1. `draft` (`shotcraft_draft_storyboard`):
   - Generates a domain-accurate, coherent storyboard (`timeline.json`) using `script_writer.py`.
   - Renders a 2x2 or 2x3 Storyboard Contact Sheet (`storyboard_contact_sheet.png`) + 360px mobile readability preview.
2. `critique` (`shotcraft_visual_critique`):
   - Runs both Visual QA (contrast, camera motion, safe-zone, 360px mobile readability) AND Semantic QA
     (`run_semantic_storyboard_qa`) so that a video showing a neuron for a lawnmower topic FAILS explicitly!
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
for _p in (
    SKILLS_ROOT / "mcp" / "core",
    SKILLS_ROOT / "reels-templates" / "scripts",
    SKILLS_ROOT / "reels-narration" / "scripts",
    SKILLS_ROOT / "reels-production" / "scripts",
):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import style_map as sm_mod
import smart_render as sr_mod
import script_writer as sw_mod
import one_shot_produce as osp_mod


def build_contact_sheet(frames_with_meta: list[tuple[Image.Image, dict]], title: str, out_png: Path) -> Path:
    """
    Composites up to 6 1080x1920 frames into a crisp Storyboard Contact Sheet (2x2 for 3-4 scenes, 3x2 for 5-6 scenes)
    plus a 360px-wide mobile preview strip for F13 mobile readability verification.
    """
    n_f = len(frames_with_meta)
    cols = 3 if n_f >= 5 else 2
    rows = 2
    cell_w, cell_h = (360, 640) if cols == 3 else (540, 960)
    cw = cols * cell_w + (cols + 1) * 32
    ch = 136 + rows * cell_h + (rows + 1) * 32

    sheet = Image.new("RGB", (cw, ch), (9, 13, 24))
    draw = ImageDraw.Draw(sheet, "RGBA")

    f_hdr = sr_mod.load_font(26, bold=True)
    f_sub = sr_mod.load_font(17, bold=False, mono=True)
    f_lbl = sr_mod.load_font(15, bold=True, mono=True)

    draw.rounded_rectangle([32, 24, cw - 32, 112], radius=20, fill=(17, 24, 42, 245), outline=(56, 189, 248, 200), width=2)
    draw.text((52, 36), f"SHOTCRAFT v9.7 STORYBOARD — {title[:42].upper()}", fill=(248, 250, 252, 255), font=f_hdr)
    draw.text((52, 74), f"{n_f} Shots · Coherent Style Family · Mobile preview — review required", fill=(148, 163, 184, 255), font=f_sub)

    for idx, (im, meta) in enumerate(frames_with_meta[: cols * rows]):
        r_i = idx // cols
        c_i = idx % cols
        px = 32 + c_i * (cell_w + 32)
        py = 136 + r_i * (cell_h + 32)

        thumb = im.resize((cell_w, cell_h), Image.Resampling.LANCZOS)
        sheet.paste(thumb, (px, py))

        acc_rgb = sr_mod.hex_to_rgb(meta.get("accent", "#38BDF8"))
        draw.rounded_rectangle([px - 2, py - 2, px + cell_w + 2, py + cell_h + 2], radius=14, outline=(*acc_rgb, 235), width=3)

        step_m = meta.get("mechanismStep") or (meta.get("visual") or {}).get("mechanism_step") or f"step-{idx+1}"
        tag_txt = f"S0{idx+1} · {meta.get('visualMode', 'ref3')[:16]} · {step_m[:16]}"
        tw = min(cell_w - 20, int(draw.textlength(tag_txt, font=f_lbl)) + 24)
        draw.rounded_rectangle([px + 10, py + 10, px + 10 + tw, py + 38], radius=8, fill=(9, 13, 24, 230), outline=(*acc_rgb, 220), width=2)
        draw.text((px + 22, py + 15), tag_txt[:36], fill=(248, 250, 252, 255), font=f_lbl)

    out_png.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(str(out_png), format="PNG")
    return out_png


def draft_storyboard(
    workspace: Path,
    topic: str,
    style: str = "auto-context",
    duration_sec: float = 24.0,
    fps: int = 30,
    scenes_json: str = None,
    language: str = "",
) -> dict:
    t0 = time.time()
    ws = Path(workspace).expanduser().resolve()
    ws.mkdir(parents=True, exist_ok=True)

    sem = osp_mod.analyze_content_semantically(topic, requested_style=style)
    if scenes_json:
        p_sj = Path(scenes_json)
        raw = json.loads(p_sj.read_text(encoding="utf-8")) if p_sj.is_file() else json.loads(scenes_json)
        scenes_raw = raw.get("scenes", raw) if isinstance(raw, dict) else raw
        scenes = [
            sm_mod.normalize_and_validate_scene_contract(s, i, sem["subject_id"], sem["visual_mode"], fps)
            for i, s in enumerate(scenes_raw)
        ]
    else:
        gen = sw_mod.generate_indonesian_scenes(topic, style=style, duration_sec=duration_sec, fps=fps, language=language)
        scenes = gen["scenes"]

    sem_qa = osp_mod.run_semantic_storyboard_qa(topic, scenes, sem)

    tl_path = ws / "timeline.json"
    tl_data = {
        "schema_version": "9.7.0",
        "fps": fps,
        "width": 1080,
        "height": 1920,
        "title_badge": "",
        "topic": topic,
        "semantic_analysis": sem,
        "semantic_qa": sem_qa,
        "scenes": scenes,
    }
    tl_path.write_text(json.dumps(tl_data, indent=2, ensure_ascii=False), encoding="utf-8")

    frames_meta = []
    stills_dir = ws / "qa" / "stills"
    stills_dir.mkdir(parents=True, exist_ok=True)
    for idx, sc in enumerate(scenes[:6]):
        dur_f = int(sc.get("durationInFrames", 120))
        mid_f = max(12, dur_f // 2)
        im = sr_mod.render_single_scene_frame(1080, 1920, sc, idx, len(scenes), mid_f, fps, "")
        still_p = stills_dir / f"draft_scene_{idx+1:02d}.png"
        im.save(str(still_p), format="PNG")
        if idx == 0:
            # Save 360x640 mobile preview proof (F13)
            mob_p = stills_dir / "mobile_preview_360px.png"
            im.resize((360, 640), Image.Resampling.LANCZOS).save(str(mob_p), format="PNG")
        frames_meta.append((im, sc))

    sheet_path = ws / "qa" / "storyboard_contact_sheet.png"
    build_contact_sheet(frames_meta, topic, sheet_path)

    elapsed_ms = round((time.time() - t0) * 1000.0, 1)
    return {
        "ok": sem_qa["ok"],
        "mode": "draft-storyboard",
        "topic": topic,
        "workspace": str(ws),
        "timeline_json": str(tl_path),
        "contact_sheet_png": str(sheet_path),
        "mobile_preview_360px_png": str(stills_dir / "mobile_preview_360px.png"),
        "scenes_count": len(scenes),
        "subject_id": sem["subject_id"],
        "assumption": sem["assumption"],
        "visual_modes_used": [s.get("visualMode") for s in scenes],
        "semantic_qa": sem_qa,
        "elapsed_ms": elapsed_ms,
        "scenes_summary": [
            {
                "id": s.get("id"),
                "subjectId": s.get("subjectId"),
                "mechanismStep": s.get("mechanismStep"),
                "visualMode": s.get("visualMode"),
                "transitionIn": (s.get("transitionIn") or {}).get("type") if isinstance(s.get("transitionIn"), dict) else s.get("transitionIn"),
                "transitionOut": (s.get("transitionOut") or {}).get("type") if isinstance(s.get("transitionOut"), dict) else s.get("transitionOut"),
                "headline": s.get("headline"),
                "narration": s.get("narration"),
            }
            for s in scenes
        ],
    }


def run_visual_critique(workspace: Path) -> dict:
    t0 = time.time()
    ws = Path(workspace).expanduser().resolve()
    scenes, badge = sr_mod.extract_scenes_from_workspace(ws)
    tl_file = ws / "timeline.json"
    tl_data = json.loads(tl_file.read_text(encoding="utf-8")) if tl_file.is_file() else {}
    topic = tl_data.get("topic") or (scenes[0].get("headline", "Topik") if scenes else "Topik")
    sem = tl_data.get("semantic_analysis") or osp_mod.analyze_content_semantically(topic)

    # F11: Semantic QA Check (Fails if neuron is used for lawnmower or motorcycle oil text appears on non-motorcycle)
    sem_qa = osp_mod.run_semantic_storyboard_qa(topic, scenes, sem)

    fps = float(tl_data.get("fps", 30))
    frames_meta = []
    scene_diagnostics = []
    distinct_modes = set()

    for idx, sc in enumerate(scenes[:6]):
        v_mode = sc.get("visualMode", "ref3-cutaway-mechanism")
        distinct_modes.add(v_mode)
        dur_f = int(sc.get("durationInFrames", 120))

        f_early = sr_mod.render_single_scene_frame(1080, 1920, sc, idx, len(scenes), max(4, int(dur_f * 0.15)), fps, badge)
        f_mid = sr_mod.render_single_scene_frame(1080, 1920, sc, idx, len(scenes), max(14, int(dur_f * 0.55)), fps, badge)
        frames_meta.append((f_mid, sc))

        arr = np.asarray(f_mid, dtype=np.float32)
        hdr_patch = arr[190:520, 84:876]
        hdr_luma = 0.2126 * hdr_patch[:, :, 0] + 0.7152 * hdr_patch[:, :, 1] + 0.0722 * hdr_patch[:, :, 2]
        hdr_contrast_std = float(np.std(hdr_luma))

        arr_early = np.asarray(f_early, dtype=np.float32)
        motion_delta = float(np.mean(np.abs(arr[450:1150, 100:860] - arr_early[450:1150, 100:860])))

        # Mobile 360px readability check (edge sharpness at 360x640)
        mob_arr = np.asarray(f_mid.resize((360, 640), Image.Resampling.LANCZOS), dtype=np.float32)
        mob_edge = float(np.mean(np.abs(np.diff(mob_arr, axis=1))))

        right_gutter_std = float(np.std(arr[300:1500, 930:1070]))

        scene_diagnostics.append({
            "scene_id": sc.get("id", f"scene-0{idx+1}"),
            "subjectId": sc.get("subjectId", sem.get("subject_id")),
            "mechanismStep": sc.get("mechanismStep", f"step-{idx+1}"),
            "visualMode": v_mode,
            "headline_contrast_std": round(hdr_contrast_std, 2),
            "stage_motion_delta": round(motion_delta, 2),
            "mobile_360px_edge_clarity": round(mob_edge, 2),
            "right_ui_gutter_clean": right_gutter_std < 32.0,
            "status": "PASS" if (round(hdr_contrast_std, 2) >= 14.0 and round(motion_delta, 2) >= 0.4 and round(mob_edge, 2) >= 2.0) else "WARN",
        })

    sheet_path = ws / "qa" / "vision_critique_sheet.png"
    build_contact_sheet(frames_meta, topic, sheet_path)

    visual_pass = all(d["status"] == "PASS" for d in scene_diagnostics)
    overall_pass = visual_pass and sem_qa["ok"]

    report = {
        "ok": overall_pass,
        "verdict": "HEURISTICS_PASS_REVIEW_REQUIRED" if overall_pass else ("FAIL_SEMANTIC_MISMATCH" if not sem_qa["ok"] else "NEEDS_VISUAL_REVIEW"),
        "workspace": str(ws),
        "topic": topic,
        "vision_critique_sheet_png": str(sheet_path),
        "semantic_qa": sem_qa,
        "visual_qa_pass": visual_pass,
        "style_coherence": "SINGLE_FAMILY_COHERENT" if len(distinct_modes) == 1 else "MULTI_STYLE_MIX",
        "distinct_visual_modes": list(distinct_modes),
        "scene_diagnostics": scene_diagnostics,
        "elapsed_ms": round((time.time() - t0) * 1000.0, 1),
    }
    out_json = ws / "qa" / "vision_critique.json"
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7 Storyboard Draft & Semantic + Visual Critique Engine")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_draft = sub.add_parser("draft", help="Generate domain-accurate storyboard + contact sheet PNG")
    p_draft.add_argument("--workspace", required=True)
    p_draft.add_argument("--topic", required=True)
    p_draft.add_argument("--style", default="auto-context")
    p_draft.add_argument("--language", default="")
    p_draft.add_argument("--duration", type=float, default=24.0)
    p_draft.add_argument("--fps", type=int, default=30)
    p_draft.add_argument("--scenes-json", help="Optional custom scenes JSON")

    p_crit = sub.add_parser("critique", help="Run automated semantic & visual critique")
    p_crit.add_argument("--workspace", required=True)

    a = p.parse_args()
    if a.cmd == "draft":
        res = draft_storyboard(
            Path(a.workspace), a.topic, style=a.style, duration_sec=a.duration, fps=a.fps, scenes_json=a.scenes_json, language=a.language
        )
    else:
        res = run_visual_critique(Path(a.workspace))
    print(json.dumps(res, indent=2, ensure_ascii=False))
    return 0 if res.get("ok") else 2


if __name__ == "__main__":
    sys.exit(main())
