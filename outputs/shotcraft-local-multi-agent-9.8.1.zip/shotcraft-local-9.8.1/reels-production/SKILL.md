---
name: reels-production
description: Produce Reels from a simple Indonesian prompt, script or assets using local Shotcraft in Claude Code, Codex or OpenCode. Load only relevant recipes; honor exact timing, audio and visual constraints; render and review the actual output.
---

# Local production router

Accept ordinary language; JSON and shot IDs are optional. Infer routine layout, palette and shot choices from the topic and reference. Ask only for essential missing content/provider access. Keep audio per brief: voice, music, SFX, combinations or silence. Resolve installed paths through sibling shotcraft-local/config.json, not a hard-coded client home.

1. Run the installed doctor.py/shotcraft-doctor.py or inspect prerequisite presence. The kit includes scripts/assets; third-party TTS servers/models, Node dependencies and browser may be missing. Never promise they are installed based on a profile name.
2. Use MCP library search or bounded local discovery; read selected recipes and implementation before promising a named style. Load reels-motion/reels-templates for visuals, reels-narration only for voice, reels-qa at verification. Keep concise decisions in the project workspace.
3. Build a content-specific storyboard. No mandatory four-world pattern, no required fabricated metric, no brain graphic for every science topic. Topic-only CLI scaffolds can be generic: the agent must research or use supplied evidence and replace generic content. Real UI/footage requests need real assets.
4. Produce in an isolated workspace. `shotcraft_one_shot_video` or `shotcraft.py create` can orchestrate available engines. Use `duration_policy=fixed` by default; select `audio` only when duration may follow speech. Use `no_narration`, `no_bgm`, `no_sfx` as needed. Cloud TTS needs authorized `allow_cloud`; provider errors must be surfaced, not disguised as natural speech.
5. Render a contact sheet and difficult transitions. Review legibility, framing, meaningful motion and object identity before final encode. Current `rendered_needs_review` is successful rendering, not publication approval. Library golden regression and edge-density safe-zone heuristics do not inspect every frame or verify scientific facts.
6. Verify exact frame count, dimensions, decoding and audio scope. Inspect the encoded artifact. Record genuine visual/listening reviews; never pass the manual flags merely to silence a failure. Use an independent reviewer if the host supports it; otherwise label self-review.

Use one producer and a reviewer when available. Specialists are optional for meaningful subtasks. Client model, permissions and provider settings remain controlled by the user. For references/calibration read sibling reels-motion/references/reference-calibration.md; this is improving recipes/evaluation, not training model weights.
