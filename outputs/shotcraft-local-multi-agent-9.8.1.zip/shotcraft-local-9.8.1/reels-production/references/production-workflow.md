# Reels production

Apply with `shotcraft-local`; read its config to locate the complete upstream repo. User instructions override preferences below. This skill adds production guidance, not replacement shot recipes. Read sibling `production-playbook.md` for geometry, timing and sound requirements.

## Execute without losing scope

1. Read latest explicit brief plus persistent user decisions. Create `brief.json`, exact `timeline.json`, `shot-map.md`, `audio-cues.json`, `assets.md`, and `qa/`. Capture duration/fps/resolution, copy, styles, layout, exclusions and output destination. Do not ask again for choices already specified.
2. Inventory repository with shotcraft-local discovery. Read actual catalog entries, recipe cards, demo source/helpers and available previews for requested motions. Consult upstream pipeline, sound-design and music-beat-sync where relevant. Route optional Workbench, JianYing and publishing only when requested. Do not claim support from a directory name alone.
3. Preserve source repositories. Create a per-video isolated project; check Git status before/after. Use local npm dependencies and relevant lockfiles. Separate static assets, composition source, reports and deliverables. Keep output revisions instead of deleting user files.
4. Choose framing, type sizes, shot families and transition motives from the content. When user leaves style open, prefer a cohesive palette and alternate typography, spatial/object and diagram shots. Do not automatically add neon, cards or parallax to every topic. If user specifies the sequence, follow it faithfully.
5. Lay out safe-zone guides and timing before detailed polish. Render a hook, a dense fact, a peak transition, and the longest CTA. Inspect rendered pixels. Test all requested text alignment including nested components that override CSS inheritance.
6. Implement full motion and sound with explicit frame cue mapping. Use native recipe timing where possible; document necessary retiming for user segment lengths. Never relabel a generic animation as a named shot. Reconcile factual copy before final typography, especially unsupported percentages.
7. Render and review boundary frames and holds, then the full MP4. Run `reels-qa` technical checks and visual/audio review. Ask the parent Claude session to invoke `reels-reviewer` independently if this skill runs inside a subagent. Fix blocking defects, rerender and recheck affected areas plus final container integrity.
8. Deliver the verified file. No Workbench command, extra uploads or source publication unless requested. Silent-output mode returns only the real file path/confirmed URL. Never promise identical cloud results on untested local hardware.

## Revision discipline

A changed shot order changes transition context and audio timing. Recompute the frame timeline and cue table; do not reuse old scene offsets. A new theme requires checking both light and dark states, masks, text fill and glows. A new safe-zone transform requires matching inverse full-frame background geometry. A textScale change must be measured at final output scale; avoid accidental double-scaling. Retain valid prior assets/checks, but verify every changed boundary in the final encode.

## Companion continuity recipes

The installed sibling `reels-continuity-lab` contains seven opt-in recipes: six from supplied Prompt Motion texts and one technical cutaway from an inspected user video. Read its catalog.json and selected card when relevant. Names are local recipe IDs, not upstream shot IDs. Prefer actual upstream demos for shared primitives; record missing previews. Its style bans/audio/aspect defaults never override the current user brief.

## Audio follows the brief

Treat audio as a per-project plan: narration, music, SFX, combinations or silence. A voiceover script can imply narration; SFX-only is a scoped exclusion, never a permanent user setting. Choose according to the current prompt and authorized creative freedom, respecting provider availability and existing cloud/paid-service authorization. For narration-first films, finalize speech before locking emphasis beats; for music-led films use the actual musical grid; for SFX-only films use visual event times. Do not make users restate decisions already resolved for the same project.
