# Reels production playbook

## Layout and typography

At1080x1920, a conservative starting rectangle for essential copy is x90..870,y250..1500. This is a working guide, not a guarantee for every Instagram UI, crop or device. Let the explicit user layout win; preview platform overlays if supplied. Backgrounds may bleed to canvas edges; essential words/numbers cannot. At another resolution scale these coordinates proportionally.

Keep one readable focal block per shot. Use deliberate ragged edges for asymmetric left/right typography, not random positions. Center alignment means centered within the requested safe region, which may differ from the screen center. Preserve a consistent baseline/grid across alternating alignments. At1080p, aim for primary text54–96px and secondary36–48px as starting points; long copy and explicit textScale may require exceptions. Validate at phone-size previews rather than claiming a font size guarantees readability.

Avoid long single-line CTAs and hyphenated eyebrow wraps. Reflow into semantic clauses. Place labels near their object, and do not force every dimension/specification on screen. The CTA deserves a visible hold after assembly; target at least2 seconds fully readable when timeline permits. Budget enough time before animating. Never silently shorten user text to solve overflow.

## Motion grammar

Define each shot's anticipation, main movement, settle and reading hold. Prefer changes motivated by meaning: tunnel for context shift, scale shock for perception/data, exploded view for layers/structure. Decorative graphs must be labeled illustrative when no real measurements support them. Avoid three identical transitions by default, but obey explicitly repeated recipes.

Maintain material/light continuity while varying spatial scale, camera direction or dominant shape. Use selective emphasis rather than shaking the entire screen. Keep text readable after the action settles; continuous idle motion should be subtle. Avoid rapid high-contrast repeated flashes; follow selected recipe and inspect intensity and rhythm.

For text masks: keep the masked world inverse-transformed and full-canvas through zoom takeover. Distinguish intentional glyph silhouette from a rectangular content-bounds seam. For palette ripples: use one fixed origin for dot/ring/mask and a radius covering the farthest output corner after safe-stage transforms. For3D: inspect maximumZ and corner projection, clipping, backfaces and text occlusion. Check first/last frames on either side of every transition.

## Exact timing and sound

Compute scene boundaries from integer frames. At30fps,60s=1800frames; every frame belongs to the intended sequence. Preserve requested decimal-second boundaries when exactly representable, or disclose rounding. Do not stretch audio blindly to fix visual timing.

SFX cues reference frame events and real licensed assets. Trim silence, use short fades, and control overlaps. Quiet reading holds are intentional; constant noise is not a quality target. SFX-only means no BGM or speech. BGM-only/VO/music permissions come from the user. Do not infer permission for paid TTS or generation from a request that explicitly excludes it.

Use headroom and inspect the final decoded audio for clipping. Measure transient alignment after encoding when precise sync matters. Do not copy the old cloud2048sample correction: it was pipeline-specific. Distinguish encoder priming and tail padding from actual presentation timing. If audio perception cannot be checked, record that limit.

## Verification and completion

Check styleframes before rendering1800frames. Final verification covers exact artifact, not a stale earlier MP4. Record SHA256, ffprobe metadata, strict decode, boundary/hold contact sheets, audio evidence and resolved blockers. The technical checker does not prove artistic quality, factual accuracy, shot fidelity or SFX-only. Independent review must inspect those separately.

Once required checks pass, deliver. Do not repeatedly expand scope into unrelated tests or alternate styles. No public upload, git push or modification of application code without session authorization.
