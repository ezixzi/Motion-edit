---
name: reels-depth-motion
description: Convert static 2D images into 3D depth-parallax MP4 clips or 3 multi-plane RGBA layers (foreground, midground, background) with Telea background inpainting, 8 camera trajectories, and Depth-of-Field rack focus bokeh.
---

# 3D Depth Parallax & Multi-Layer RGBA Engine (`reels-depth-motion` v5.0)

Upgraded from `MotionDepthSkill` into a production-grade 2.5D/3D depth engine (`scripts/depth_engine.py`) paired with `reels-templates/components/DepthParallaxStage.tsx`.

## Capabilities

1. **Depth Estimation with Automatic Offline Fallback**:
   - The current depth_engine.py uses a multi-cue image heuristic with edge-preserving filtering. It does not load MiDaS or Depth-Anything. Treat its output as illustrative 2.5D depth, not measured geometry.
2. **8 Camera Trajectory Presets (`--preset`)**:
   - `cinematic-orbit`, `dolly-push`, `vertigo-contra-zoom`, `crane-rise`, `parallax-drift`, `breathing-float`, `cutaway-peel`, `hero-pullback`.
3. **Two Output Modes**:
   - **Mode A — Pre-rendered 3D Pixel-Warped MP4 (`--output clip.mp4`)**: Dense per-pixel `cv2.remap` parallax with dynamic Depth-of-Field rack-focus bokeh (`yuv420p` H.264 MP4).
   - **Mode B — Multi-Plane RGBA Slicing (`--export-layers ./layers`)**: Slices image into `foreground.png`, `midground.png`, `background.png` (with Telea inpainting to prevent background holes), `depth_map.png`, and `layers_manifest.json` for `<DepthParallaxStage />`.
