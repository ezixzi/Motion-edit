#!/usr/bin/env python3
"""
Shotcraft Pro v9.6 — True 3D Camera Orbit, Real-Time Normal-Map Lighting,
Depth-Occluded 3D Text Interaction & Multi-Plane RGBA Slicing Engine (`depth_engine.py`).

Upgrades implementing SHOTCRAFT_PRO_v9.5_IMPROVEMENT_REPORT (Section 3.2):
- Computes surface normal vectors (Nx, Ny, Nz) directly from the depth map and applies
  real-time orbiting 3D point lighting (Blinn-Phong diffuse + specular highlights) as the camera moves.
- Supports true 3D perspective camera orbit (yaw, pitch, roll, dolly zoom, and rack-focus DoF).
- Supports depth interaction with text (`--depth-text`, `--depth-text-z`): renders 3D headline/metric
  layers at an intermediate Z-depth plane so foreground objects naturally occlude and cast shadows on the text!
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path

try:
    import cv2
    cv2.setNumThreads(1)
    import numpy as np
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


# [P2-2]: Per-Visual-Mode Camera Trajectory Mapping
VISUAL_MODE_CAMERA_MAP = {
    "neural-network": {"preset": "cinematic-orbit", "orbit_rad_s": 0.15, "dolly_zoom": 0.08, "focus_pull": True},
    "coffee-editorial-3d": {"preset": "crane-rise", "orbit_rad_s": 0.10, "dolly_zoom": 0.06, "focus_pull": True},
    "ref5-editorial-cutaway": {"preset": "vertigo-contra-zoom", "orbit_rad_s": 0.12, "dolly_zoom": 0.09, "focus_pull": True},
    "ref1-tutorial-deck": {"preset": "dolly-push", "orbit_rad_s": 0.08, "dolly_zoom": 0.05, "focus_pull": False},
    "ref2-floating-glass": {"preset": "parallax-drift", "orbit_rad_s": 0.14, "dolly_zoom": 0.06, "focus_pull": True},
}


def export_camera_keyframes_for_mode(visual_mode: str, frames: int = 120, fps: int = 30, intensity: float = 18.0) -> dict:
    cfg = VISUAL_MODE_CAMERA_MAP.get(visual_mode, VISUAL_MODE_CAMERA_MAP["neural-network"])
    preset = cfg["preset"]
    keyframes = []
    for f in range(0, frames, max(1, frames // 15)):
        u = f / max(1, frames - 1)
        kf = camera_trajectory(preset, u, intensity=intensity)
        kf["frame"] = f
        kf["orbit_rad"] = round((f / float(fps)) * cfg["orbit_rad_s"], 4)
        keyframes.append(kf)
    return {"visual_mode": visual_mode, "preset": preset, "orbit_rad_s": cfg["orbit_rad_s"], "keyframes": keyframes}

PRESETS = [
    "cinematic-orbit",
    "dolly-push",
    "vertigo-contra-zoom",
    "crane-rise",
    "parallax-drift",
    "breathing-float",
    "cutaway-peel",
    "hero-pullback",
]


def estimate_depth_heuristic(img_bgr: np.ndarray) -> np.ndarray:
    """
    Deterministic multi-cue heuristic depth estimator (0.0 = far background, 1.0 = near foreground).
    Combines center-weighted subject saliency, local contrast/sharpness, vertical ground plane ramp,
    and bilateral edge-preserving smoothing.
    """
    h, w = img_bgr.shape[:2]
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0

    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.COLOR_32F if hasattr(cv2, "COLOR_32F") else cv2.CV_32F, 0, 1, ksize=3)
    grad = np.hypot(gx, gy)
    grad = cv2.GaussianBlur(grad, (31, 31), 0)
    if grad.max() > 1e-5:
        grad /= grad.max()

    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    nx = (xx - w * 0.5) / (w * 0.45)
    ny = (yy - h * 0.48) / (h * 0.45)
    radial = np.exp(-0.65 * (nx * nx + ny * ny))

    v_ramp = (yy / max(1.0, float(h - 1))) ** 0.85

    raw_depth = 0.48 * radial + 0.34 * grad + 0.18 * v_ramp
    raw_depth = np.clip(raw_depth, 0.0, 1.0)

    depth_u8 = (raw_depth * 255.0).astype(np.uint8)
    smooth_u8 = cv2.bilateralFilter(depth_u8, d=9, sigmaColor=45, sigmaSpace=45)
    depth01 = smooth_u8.astype(np.float32) / 255.0
    d_min, d_max = float(depth01.min()), float(depth01.max())
    if d_max - d_min > 1e-4:
        depth01 = (depth01 - d_min) / (d_max - d_min)
    return depth01


def compute_surface_normals(depth01: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Section 3.2:
    Computes per-pixel 3D unit surface normals (nx, ny, nz) from the depth map for real-time relighting.
    """
    dzdx = cv2.Sobel(depth01, cv2.CV_32F, 1, 0, ksize=3) * 3.5
    dzdy = cv2.Sobel(depth01, cv2.CV_32F, 0, 1, ksize=3) * 3.5
    nx = -dzdx
    ny = -dzdy
    nz = np.ones_like(depth01, dtype=np.float32)
    norm = np.sqrt(nx * nx + ny * ny + nz * nz + 1e-8)
    return nx / norm, ny / norm, nz / norm


def camera_trajectory(preset: str, u: float, intensity: float = 18.0) -> dict:
    """Returns 3D camera orbit, zoom, focus, and dynamic light vector at normalized progress u in [0, 1]."""
    theta = 2.0 * math.pi * u
    ease = 1.0 - (1.0 - u) ** 4

    # Dynamic 3D light direction orbiting smoothly
    lx = math.sin(theta) * 0.55
    ly = -0.38 + math.cos(theta) * 0.25
    lz = 0.78
    l_len = math.sqrt(lx * lx + ly * ly + lz * lz)
    light_dir = (lx / l_len, ly / l_len, lz / l_len)

    if preset == "cinematic-orbit":
        return {
            "cam_x": math.cos(theta) * intensity,
            "cam_y": math.sin(theta) * (intensity * 0.55),
            "yaw_deg": math.sin(theta) * 8.5,
            "pitch_deg": math.cos(theta) * 4.2,
            "zoom": 1.07 + 0.04 * math.sin(theta * 0.5),
            "focal_depth": 0.45,
            "focus_depth": 0.78,
            "dof": 0.35,
            "light_dir": light_dir,
        }
    if preset == "dolly-push":
        p = min(1.0, u / 0.78) if u < 0.78 else 1.0
        ep = 1.0 - (1.0 - p) ** 4
        return {
            "cam_x": math.sin(theta * 0.5) * (intensity * 0.25),
            "cam_y": -ep * (intensity * 0.35),
            "yaw_deg": math.sin(theta * 0.5) * 4.0,
            "pitch_deg": -ep * 3.0,
            "zoom": 1.04 + 0.12 * ep,
            "focal_depth": 0.50,
            "focus_depth": 0.55 + 0.25 * ep,
            "dof": 0.45,
            "light_dir": light_dir,
        }
    if preset == "vertigo-contra-zoom":
        return {
            "cam_x": 0.0,
            "cam_y": (u - 0.5) * (intensity * 0.3),
            "yaw_deg": 0.0,
            "pitch_deg": (u - 0.5) * 4.0,
            "zoom": 1.14 - 0.08 * ease,
            "focal_depth": 0.80,
            "focus_depth": 0.82,
            "dof": 0.60,
            "light_dir": light_dir,
        }
    if preset == "crane-rise":
        return {
            "cam_x": math.sin(theta * 0.5) * (intensity * 0.2),
            "cam_y": (0.5 - ease) * (intensity * 1.25),
            "yaw_deg": math.sin(theta * 0.5) * 3.0,
            "pitch_deg": (0.5 - ease) * 6.0,
            "zoom": 1.06 + 0.05 * ease,
            "focal_depth": 0.48,
            "focus_depth": 0.72,
            "dof": 0.30,
            "light_dir": light_dir,
        }
    if preset == "parallax-drift":
        return {
            "cam_x": (ease - 0.5) * (intensity * 1.4),
            "cam_y": math.sin(theta) * (intensity * 0.18),
            "yaw_deg": (ease - 0.5) * 9.0,
            "pitch_deg": 0.0,
            "zoom": 1.08,
            "focal_depth": 0.50,
            "focus_depth": 0.76,
            "dof": 0.30,
            "light_dir": light_dir,
        }
    if preset == "breathing-float":
        return {
            "cam_x": math.sin(theta) * (intensity * 0.28),
            "cam_y": math.cos(theta) * (intensity * 0.22),
            "yaw_deg": math.sin(theta) * 3.2,
            "pitch_deg": math.cos(theta) * 2.4,
            "zoom": 1.05 + 0.015 * math.sin(theta),
            "focal_depth": 0.50,
            "focus_depth": 0.75,
            "dof": 0.20,
            "light_dir": light_dir,
        }
    if preset == "cutaway-peel":
        return {
            "cam_x": ease * (intensity * 0.85),
            "cam_y": -ease * (intensity * 0.40),
            "yaw_deg": ease * 7.5,
            "pitch_deg": -ease * 3.5,
            "zoom": 1.05 + 0.08 * ease,
            "focal_depth": 0.45,
            "focus_depth": 0.65,
            "dof": 0.35,
            "light_dir": light_dir,
        }
    return {
        "cam_x": (1.0 - ease) * (intensity * 0.45),
        "cam_y": (1.0 - ease) * (intensity * 0.30),
        "yaw_deg": (1.0 - ease) * 5.0,
        "pitch_deg": 0.0,
        "zoom": 1.18 - 0.12 * ease,
        "focal_depth": 0.55,
        "focus_depth": 0.80,
        "dof": 0.35,
        "light_dir": light_dir,
    }


def render_depth_occluded_text_layer(
    frame_bgr: np.ndarray,
    warped_depth: np.ndarray,
    text: str,
    text_z: float,
    cam: dict,
) -> np.ndarray:
    """
    Section 3.2:
    Depth Interaction with Text:
    Renders 3D parallax-shifted text at depth plane `text_z` (e.g. 0.58) so pixels with
    `warped_depth > text_z + 0.04` naturally occlude the text in front of it!
    """
    if not text:
        return frame_bgr
    h, w = frame_bgr.shape[:2]
    overlay = np.zeros((h, w, 3), dtype=np.uint8)
    mask = np.zeros((h, w), dtype=np.float32)

    rel_z = text_z - cam["focal_depth"]
    dx = int(round(-cam["cam_x"] * rel_z * 0.85))
    dy = int(round(-cam["cam_y"] * rel_z * 0.85))

    font = cv2.FONT_HERSHEY_DUPLEX
    scale = max(1.2, w / 540.0)
    thickness = max(3, int(round(scale * 2.2)))
    (tw, th), _ = cv2.getTextSize(text, font, scale, thickness)
    tx = (w - tw) // 2 + dx
    ty = int(h * 0.44) + th // 2 + dy

    cv2.putText(overlay, text, (tx, ty), font, scale, (248, 250, 252), thickness, cv2.LINE_AA)
    cv2.putText(mask, text, (tx, ty), font, scale, 1.0, thickness, cv2.LINE_AA)

    # Soft occlusion mask: foreground objects with depth > text_z occlude the 3D text
    fg_occlusion = np.clip((warped_depth - (text_z + 0.02)) / 0.06, 0.0, 1.0)
    vis_alpha = (mask * (1.0 - fg_occlusion * 0.92))[..., None]

    out = frame_bgr.astype(np.float32) * (1.0 - vis_alpha) + overlay.astype(np.float32) * vis_alpha
    return np.clip(out, 0, 255).astype(np.uint8)


def export_rgba_layers(img_bgr: np.ndarray, depth01: np.ndarray, out_dir: Path) -> dict:
    """Slices image into foreground.png, midground.png, background.png (inpainted), depth_map.png, normal_map.png, and layers_manifest.json."""
    out_dir.mkdir(parents=True, exist_ok=True)
    h, w = img_bgr.shape[:2]

    depth_u8 = (depth01 * 255.0).astype(np.uint8)
    cv2.imwrite(str(out_dir / "depth_map.png"), depth_u8)

    nx, ny, nz = compute_surface_normals(depth01)
    normal_bgr = np.dstack([
        ((nz * 0.5 + 0.5) * 255.0).astype(np.uint8),
        ((ny * 0.5 + 0.5) * 255.0).astype(np.uint8),
        ((nx * 0.5 + 0.5) * 255.0).astype(np.uint8),
    ])
    cv2.imwrite(str(out_dir / "normal_map.png"), normal_bgr)

    fg_mask = np.clip((depth01 - 0.62) / 0.08, 0.0, 1.0)
    fg_mask = cv2.GaussianBlur(fg_mask, (7, 7), 0)

    mid_mask = np.clip((depth01 - 0.30) / 0.08, 0.0, 1.0) * (1.0 - fg_mask * 0.85)
    mid_mask = cv2.GaussianBlur(mid_mask, (7, 7), 0)

    inpaint_mask = (depth01 > 0.58).astype(np.uint8) * 255
    inpaint_mask = cv2.dilate(inpaint_mask, np.ones((9, 9), np.uint8), iterations=1)
    bg_inpainted = cv2.inpaint(img_bgr, inpaint_mask, inpaintRadius=7, flags=cv2.INPAINT_TELEA)

    def _write_rgba(bgr: np.ndarray, alpha01: np.ndarray, target: Path):
        bgra = cv2.cvtColor(bgr, cv2.COLOR_BGR2BGRA)
        bgra[:, :, 3] = (np.clip(alpha01, 0.0, 1.0) * 255.0).astype(np.uint8)
        cv2.imwrite(str(target), bgra)

    _write_rgba(img_bgr, fg_mask, out_dir / "foreground.png")
    _write_rgba(img_bgr, mid_mask, out_dir / "midground.png")
    _write_rgba(bg_inpainted, np.ones((h, w), dtype=np.float32), out_dir / "background.png")

    manifest = {
        "width": w,
        "height": h,
        "layers": {
            "foreground": str(out_dir / "foreground.png"),
            "midground": str(out_dir / "midground.png"),
            "background": str(out_dir / "background.png"),
            "depth_map": str(out_dir / "depth_map.png"),
            "normal_map": str(out_dir / "normal_map.png"),
        },
        "depth_planes": {"foreground": 0.85, "midground": 0.52, "background": 0.15},
    }
    manifest_path = out_dir / "layers_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def render_warped_mp4(
    img_bgr: np.ndarray,
    depth01: np.ndarray,
    out_mp4: Path,
    preset: str,
    frames: int,
    fps: int,
    intensity: float,
    depth_text: str = None,
    depth_text_z: float = 0.58,
    realtime_lighting: bool = True,
) -> dict:
    out_mp4.parent.mkdir(parents=True, exist_ok=True)
    h, w = img_bgr.shape[:2]
    w_even = w - (w % 2)
    h_even = h - (h % 2)
    if (w_even, h_even) != (w, h):
        img_bgr = cv2.resize(img_bgr, (w_even, h_even), interpolation=cv2.INTER_AREA)
        depth01 = cv2.resize(depth01, (w_even, h_even), interpolation=cv2.INTER_LINEAR)
        h, w = h_even, w_even

    base_y, base_x = np.mgrid[0:h, 0:w].astype(np.float32)
    blurred_bgr = cv2.GaussianBlur(img_bgr, (15, 15), 0)
    nx, ny, nz = compute_surface_normals(depth01)

    cmd = [
        "ffmpeg",
        "-y",
        "-v",
        "error",
        "-f",
        "rawvideo",
        "-vcodec",
        "rawvideo",
        "-s",
        f"{w}x{h}",
        "-pix_fmt",
        "bgr24",
        "-r",
        str(fps),
        "-i",
        "-",
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-preset",
        "veryfast",
        "-crf",
        "18",
        str(out_mp4),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)

    cx, cy = w * 0.5, h * 0.5
    for f_idx in range(frames):
        u = f_idx / max(1, frames - 1)
        cam = camera_trajectory(preset, u, intensity=intensity)
        rel_d = depth01 - cam["focal_depth"]
        zoom = cam["zoom"]

        # True 3D perspective + parallax remap
        persp_scale = 1.0 + 0.08 * rel_d * math.sin(math.radians(cam.get("yaw_deg", 0.0)))
        map_x = ((base_x - cx) / (zoom * persp_scale)) + cx + cam["cam_x"] * rel_d
        map_y = ((base_y - cy) / (zoom * persp_scale)) + cy + cam["cam_y"] * rel_d

        warped_sharp = cv2.remap(img_bgr, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)
        warped_blur = cv2.remap(blurred_bgr, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)
        warped_d = cv2.remap(depth01, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)

        dof_weight = np.clip(np.abs(warped_d - cam["focus_depth"]) * cam["dof"] * 2.2, 0.0, 1.0)[..., None]
        frame_f = warped_sharp.astype(np.float32) * (1.0 - dof_weight) + warped_blur.astype(np.float32) * dof_weight

        # Section 3.2: Real-time 3D normal-mapped lighting
        if realtime_lighting and "light_dir" in cam:
            lx, ly, lz = cam["light_dir"]
            ndotl = np.maximum(0.0, nx * lx + ny * ly + nz * lz)
            shade_mult = (0.86 + 0.24 * ndotl)[..., None]
            spec = ((np.maximum(0.0, ndotl) ** 16.0) * 18.0)[..., None]
            frame_f = frame_f * shade_mult + spec

        frame_out = np.clip(frame_f, 0, 255).astype(np.uint8)

        if depth_text:
            frame_out = render_depth_occluded_text_layer(frame_out, warped_d, depth_text, depth_text_z, cam)

        proc.stdin.write(frame_out.tobytes())

    proc.stdin.close()
    err = proc.stderr.read().decode("utf-8", errors="replace")
    rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"ffmpeg encode failed ({rc}): {err[-400:]}")

    return {
        "ok": True,
        "output_mp4": str(out_mp4),
        "preset": preset,
        "realtime_lighting": realtime_lighting,
        "depth_text": depth_text,
        "frames": frames,
        "fps": fps,
        "resolution": f"{w}x{h}",
    }


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.6 True 3D Depth Orbit, Real-Time Lighting & Occluded Text Engine")
    p.add_argument("--input", required=False, help="Path to input 2D image")
    p.add_argument("--visual-mode-keyframes", help="Export camera keyframes for a visual mode (e.g. neural-network)")
    p.add_argument("--output", help="Optional path to output 3D warped MP4")
    p.add_argument("--export-layers", help="Optional directory to export RGBA layers + depth_map.png + normal_map.png")
    p.add_argument("--preset", choices=PRESETS, default="cinematic-orbit")
    p.add_argument("--frames", type=int, default=90)
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--intensity", type=float, default=18.0)
    p.add_argument("--depth-text", help="Optional 3D text to insert at depth plane (--depth-text-z) with foreground occlusion")
    p.add_argument("--depth-text-z", type=float, default=0.58, help="Depth plane [0..1] for 3D occluded text")
    p.add_argument("--no-lighting", action="store_true", help="Disable real-time 3D normal-map relighting")
    a = p.parse_args()

    if a.visual_mode_keyframes:
        kf_data = export_camera_keyframes_for_mode(a.visual_mode_keyframes, frames=a.frames, fps=a.fps, intensity=a.intensity)
        if a.output:
            Path(a.output).expanduser().resolve().write_text(json.dumps(kf_data, indent=2), encoding="utf-8")
        print(json.dumps({"ok": True, **kf_data}, indent=2))
        return

    if not a.input:
        p.error("--input image path or --visual-mode-keyframes is required")
    inp = Path(a.input).expanduser().resolve()
    if not inp.is_file():
        p.error(f"Input image not found: {inp}")

    img_bgr = cv2.imread(str(inp), cv2.IMREAD_COLOR)
    if img_bgr is None:
        p.error(f"Could not decode image: {inp}")

    depth01 = estimate_depth_heuristic(img_bgr)
    res = {"ok": True, "input": str(inp), "preset": a.preset}

    if a.export_layers:
        layers_dir = Path(a.export_layers).expanduser().resolve()
        res["layers"] = export_rgba_layers(img_bgr, depth01, layers_dir)

    if a.output:
        out_mp4 = Path(a.output).expanduser().resolve()
        res["render"] = render_warped_mp4(
            img_bgr,
            depth01,
            out_mp4,
            a.preset,
            a.frames,
            a.fps,
            a.intensity,
            depth_text=a.depth_text,
            depth_text_z=a.depth_text_z,
            realtime_lighting=not a.no_lighting,
        )

    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
