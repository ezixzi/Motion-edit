---
name: reels-sfx-studio
description: Local procedural SFX & beat-locked BGM synthesizer and audio mixer across all 16 video-shotcraft categories (transition, impact, riser, camera, ui, text, paper, film, light, data, scifi, mech, glass, fluid, crowd, counter) plus 4 BGM stems. Generates 48kHz WAV files offline and mixes frame-accurate audio cues.
---

# Procedural SFX, Beat-Locked BGM & Audio Cue Studio (`reels-sfx-studio` v5.0)

Inspired by the procedural Python sound design workflow in `awesome-opus5-5-videos` (`@Dheepanratnam`, `@LeowenAI`, `@humzaakhalid`, `@DengenT`) and compatible with all 16 `video-shotcraft` SFX categories.

## Features

1. **Zero-Dependency 48kHz Stereo WAV Library (`scripts/sfx_engine.py --init-library`)**:
   - Automatically generates and populates 32 crisp stereo WAV SFX across all 16 categories:
     - `transition/whoosh-soft.wav`, `transition/whip-fast.wav`
     - `impact/sub-hit.wav`, `impact/cinematic-slam.wav`
     - `riser/tension-sweep.wav`, `riser/shimmer-lift.wav`
     - `camera/shutter-clean.wav`, `camera/flash-charge.wav`
     - `ui/tactile-click.wav`, `ui/toggle-pop.wav`
     - `text/type-key.wav`, `text/caption-pop.wav`
     - `paper/page-slide.wav`, `paper/card-deal.wav`
     - `film/projector-tick.wav`, `film/tape-stop.wav`
     - `light/sparkle-chime.wav`, `light/laser-sweep.wav`
     - `data/telemetry-beep.wav`, `data/chart-lock.wav`
     - `scifi/hud-scan.wav`, `scifi/neural-pulse.wav`
     - `mech/gear-ratchet.wav`, `mech/servo-lock.wav`
     - `glass/crystal-ping.wav`, `glass/refract-shimmer.wav`
     - `fluid/droplet-plop.wav`, `fluid/flow-surge.wav`
     - `crowd/warm-applause-swell.wav`, `crowd/studio-murmur.wav`
     - `counter/digit-tick.wav`, `counter/metric-land.wav`
   - Plus 4 procedural beat-locked BGM loops:
     - `bgm/kinetic-120bpm.wav` (120 BPM crisp tech-minimal pulse)
     - `bgm/cyber-pulse-128bpm.wav` (128 BPM futuristic synth drive)
     - `bgm/warm-editorial-96bpm.wav` (96 BPM warm acoustic-electric chord groove)
     - `bgm/suspense-tech-110bpm.wav` (110 BPM deep cinematic explainer pulse)
2. **Frame-Accurate Timeline Cue Mixer (`scripts/sfx_engine.py --mix-timeline`)**:
   - Reads `timeline.json` or `audio-cues.json`, places each SFX at its exact `frame / fps` timestamp, mixes optional narration (`--narration`) and auto-ducked BGM (`--bgm`), and outputs `soundtrack_master.wav` normalized to `-14 LUFS` headroom.
