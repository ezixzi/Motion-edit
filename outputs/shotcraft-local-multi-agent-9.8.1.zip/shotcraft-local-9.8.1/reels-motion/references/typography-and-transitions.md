# Typography Styles, Transitions & 3D Camera Presets Reference (v4.0)

Load this reference when choosing typography styles, transition bridges, or 3D depth camera trajectories for a video brief. All styles below have ready-to-use implementations in sibling `reels-templates/components/` and `reels-depth-motion/scripts/depth_engine.py`.

## 1. Curated Typography Styles (`KineticTypographyStage.tsx`)

| Style ID | Visual Character | Best Used For | Mobile Safe Sizing (1080×1920) |
|---|---|---|---|
| `karaoke-pill` | Dark translucent rounded pill (`borderRadius: 28px`) with active spoken word highlighted in high-contrast accent pill | Narrated explainers, educational Reels, technical cutaways | Word size `44–50px` bold (`800`), max 2–3 lines per pill |
| `brutalist-stagger` | High-impact grotesque display (`72–84px`), per-word spring y-offset stagger, optional `*accent*` word highlight | SaaS hooks, bold problem statements, energetic openings | Headline `72–84px` (`800`), eyebrow `26–28px` uppercase |
| `editorial-serif` | Contrast pairing of serif display (`Georgia / Instrument Serif`) with italic accent words and clean sans subcopy | Ink Press vertical, luxury brand stories, cultural/historical topics | Headline `64–76px` (`600`), subcopy `34–38px` sans |
| `glass-callout` | Frosted card (`backdropFilter: blur(18px)`), subtle rim border, eyebrow badge + structured assertion | Feature callouts over busy footage or 3D parallax backgrounds | Card width within `x: 90..870`, headline `52–60px` |
| `counter-shock` | Giant tabular number (`tabular-nums`, `128–144px`) with spring scale impact, unit badge, and qualification note | Verified metrics, speed/cost comparisons, scientific scale shocks | Number `128–144px` (`900`), label `42–46px`, source note `24px` |
| `asymmetric-ragged` | Deliberate alternating left/right editorial rag anchored to a consistent vertical grid column | Multi-fact listicles ("3 Fakta..."), rhythmic chapter contrast | Primary `56–68px`, secondary `36–44px` |
| `kinetic-slam` | Fast damped spring (`damping: 12, stiffness: 180`) locked to musical downbeats or SFX impacts | Action hooks, fast montage chapters, rhythm cuts | Max 3–5 words per slam, hold ≥1.2s after settle |
| `leader-callout` | Animated SVG dashed leader line + target dot tracking a component coordinate `(x, y)` to a clean callout card | Cutaway diagrams, UI element pointers, hardware anatomy | Card at top safe zone, leader dot `r=9px` on target |

## 2. Motivated Scene Transitions (`TransitionBridge.tsx`)

Avoid repeating the same generic fade across scenes. Pick 2–3 complementary transitions motivated by the scene's geometry:

| Transition ID | Mechanism | Ideal Scene Handoff | Default Duration |
|---|---|---|---|
| `iris-aperture` | Circular or 6-blade iris expanding from an interactive click/focal point `(originX, originY)` using exact `coverRadius` | Button click → full-bleed footage/3D scene, or loop closure | 16–22 frames |
| `palette-ripple` | Radial theme wave with accent ring inverting dark/light surface palette | Problem (dark) → Solution (light) or chapter shift | 18–24 frames |
| `shape-morph-relay` | Shared rounded rectangle carrier morphing bounds, corner radius, and surface color (`matchCutRect`) | Continuity UI relay, card → player → chart handoff | 15–20 frames |
| `whip-pan-blur` | Directional horizontal/vertical camera whip with proportional sine-bell motion blur (`blur(0→22px→0)`) | Fast spatial shifts between sibling facts or carousel items | 12–16 frames |
| `depth-z-pass` | Outgoing scene scales past the lens (`1.0 → 2.35x`) while incoming scene emerges from depth (`0.72 → 1.0x`) | Macro layer zoom, exterior → interior subsystem dive | 18–24 frames |
| `glyph-mask-takeover` | Giant headline letter silhouette zooms through until the masked world fills the entire viewport | Opening brand hook → first product/visual scene (`text-as-mask`) | 24–30 frames |
| `cutaway-shell-peel` | Directional inset clip peel sliding away the exterior shell over an aligned interior diagram | Technical cutaway reveal (`CutawayRigStage`) | 20–28 frames |
| `split-shutter` | Symmetrical architectural shutters opening/closing from center or diagonal axis | Editorial luxury look, before/after comparison | 16–20 frames |
| `flash-frame-cut` | 3-beat rhythmic scale/crop stepping synced to camera shutter SFX (`paparazzi-flash`) | Highlighting 3 rapid details before a big number | 9–15 frames |
| `match-cut-rect` | Measured source bounding box projects directly into incoming hero frame | Thumbnail/card selection → full-screen hero preview | 16–22 frames |

## 3. 3D Depth Camera Presets (`depth_engine.py` & `DepthParallaxStage.tsx`)

| Preset ID | Camera Trajectory | Focal & DoF Behavior |
|---|---|---|
| `cinematic-orbit` | Smooth elliptical X/Y orbit with gentle sine zoom (`1.06 → 1.12`) | Pivot at `focal_depth=0.45`, sharp foreground (`focus_depth=0.78`) |
| `dolly-push` | Quintic ease-out push during first 75% of shot, settling into a calm reading hold | Rack focus shifts from midground (`0.55`) to foreground (`0.80`) |
| `vertigo-contra-zoom` | Hitchcock dolly-zoom: foreground locked at `focal_depth=0.80` while background warps | Dramatic psychological/hook tension; keep foreground sharp |
| `crane-rise` | Vertical crane elevation (`y_shift` sweep) with subtle forward push | Great for architecture, full-page landing strips, or tall objects |
| `parallax-drift` | Horizontal tracking shot across multi-plane layers | Ideal for wide scenes recomposed into 9:16 vertical frames |
| `breathing-float` | Low-amplitude organic suspension (`intensity * 0.3`) | Best background motion during dense text or long reading holds |
| `cutaway-peel` | Spring-driven parallax shift paired with foreground layer opacity peel (`1.0 → 0.12`) | Designed for mechanism/cutaway reveals |
| `hero-pullback` | Starts tight (`zoom=1.18`) on focal detail and pulls back to full context | Great for "mystery detail → whole object" hooks |
