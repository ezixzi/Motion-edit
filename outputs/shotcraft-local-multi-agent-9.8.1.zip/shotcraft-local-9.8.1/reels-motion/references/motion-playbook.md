# Motion and transition director

Read local shotcraft-local config and current catalog. Read each selected recipe/demo/helpers/reference before implementation. Use the production playbook and upstream aesthetic rules. Do not invent available shot names or claim a generic animation is a faithful library shot.

## Motion plan

Create a shot table with meaning, focal object, entry, primary motion, settle, readable hold, exit and audio landmark. Budget every phase in integer frames. For explicit shot lists preserve order and identity; use creativity within allowed content/framing. If open-ended, mix three or four compatible families rather than exhausting the catalog:

- Typography: masks, assembled type, word tunnels; for questions, concepts and hooks.
- Spatial: card dealing,3D layers, carousel; for relationships, multiple facts and structure.
- Diagram/data: scale shocks, reveals; only real supported data or clearly labeled illustration.
- Light/material: spotlight, palette ripple; for focus and chapter changes.

These are routing ideas, not fixed topic stereotypes. One primary event per beat. Motion should reveal meaning, not merely add activity. Stronger animation does not mean faster or more simultaneous effects.

## Transitions

Choose a motivated connection: shape match, shared object, depth/camera continuation, direction carry, palette handoff, or intentional hard cut. Do not default to every scene fading or flashing. Keep camera/motion direction coherent across a handoff unless reversal has a purpose. Avoid back-to-back dominant transition motifs unless requested. Library single-use preferences yield to explicit user repeats.

Use transitions as short bridges, not substitutes for reading time. Maintain contrast before/during/after palette changes. Inspect safe-stage transforms and backgrounds independently: backgrounds full-bleed, critical text inside safe bounds. Check mask content coverage at maximum zoom, ripple radius at farthest corner,3D projections and clipping. Never fix a seam by cutting abruptly without inspecting the resulting handoff.

For speech, use finalized audio landmarks. For SFX-only, create a cue grid from visual events; deliberate quiet holds are allowed. BGM beat grids apply only if music is authorized. Avoid mechanical beat changes unrelated to content.

## Typography choreography

Use semantic line breaks; one or two emphasized words at a time. Alternate left/right alignment only when requested or conceptually useful, with consistent safe geometry. Keep dynamic motion away from final reading holds. Honor user textScale once in final coordinates. Long CTAs must have a fully readable period; shorten only with authorization. Parent textAlign is not sufficient if nested components override it.

## Evidence and revision

Render anticipation, peak action, settled hold, and both sides of every transition. Inspect at phone preview size. Compare named shots to source/reference grammar, not only a poster frame. Mark adapted timing and missing reference previews in shot-map.md. After final encoding recheck the same boundaries; do not approve using stale native stills. When quality fails, identify the cause (hierarchy, timing, geometry, lighting, sound) and fix that cause instead of stacking more effects.

## Companion continuity recipes

The installed sibling `reels-continuity-lab` contains seven opt-in recipes: six from supplied Prompt Motion texts and one technical cutaway from an inspected user video. Read its catalog.json and selected card when relevant. Names are local recipe IDs, not upstream shot IDs. Prefer actual upstream demos for shared primitives; record missing previews. Its style bans/audio/aspect defaults never override the current user brief.
