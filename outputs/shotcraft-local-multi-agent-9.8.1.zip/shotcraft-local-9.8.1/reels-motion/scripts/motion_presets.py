#!/usr/bin/env python3
"""
Shotcraft Pro v9.6.0 — Motion, Typography & Transition Routing Engine (`reels-motion/scripts/motion_presets.py`).

Provides programmatic and CLI access to the 8 Typography Styles, 7 Caption Styles,
10 Motivated Scene Transitions, and 8 3D Depth Camera Trajectories documented in `reels-motion/SKILL.md`.
"""
import argparse
import json
import sys
from pathlib import Path

TYPOGRAPHY_STYLES = {
    "karaoke-pill": {"family": "Inter", "weight": 800, "use_case": "Conversational explainers & high-retention Reels"},
    "brutalist-stagger": {"family": "Inter", "weight": 900, "use_case": "Bold tech announcements & rapid listicles"},
    "editorial-serif": {"family": "Georgia", "weight": 700, "use_case": "Coffee, culinary, history & literary essays"},
    "glass-callout": {"family": "Inter", "weight": 700, "use_case": "Floating HUD & frosted glass talking-head overlays"},
    "counter-shock": {"family": "Inter", "weight": 900, "use_case": "Data-driven hero metrics & benchmark comparisons"},
    "asymmetric-ragged": {"family": "Inter", "weight": 800, "use_case": "Editorial commentary & opinion pieces"},
    "kinetic-slam": {"family": "Inter", "weight": 900, "use_case": "Urgent myth-busting hooks & warnings"},
    "leader-callout": {"family": "Inter", "weight": 800, "use_case": "3D technical cutaway pointer labels"},
}

CAPTION_STYLES = [
    "karaoke-pill",
    "typewriter",
    "slide-up",
    "glitch",
    "handwritten",
    "neon",
    "minimal",
]

SCENE_TRANSITIONS = {
    "iris-aperture": {"frames": 14, "style": "Circular iris reveal centered on hero subject"},
    "palette-ripple": {"frames": 12, "style": "Color-matched radial wave wipe"},
    "shape-morph-relay": {"frames": 16, "style": "Continuous carrier shape morphing between UI cards"},
    "whip-pan-blur": {"frames": 12, "style": "High-velocity directional whip pan"},
    "depth-z-pass": {"frames": 16, "style": "3D camera push through foreground plane"},
    "glyph-mask-takeover": {"frames": 14, "style": "Hero metric counter expands to fill viewport"},
    "cutaway-shell-peel": {"frames": 16, "style": "Outer casing peels back into 3D interior cutaway"},
    "split-shutter": {"frames": 12, "style": "Opposing vertical/horizontal shutter slice"},
    "flash-frame-cut": {"frames": 6, "style": "2-frame high-contrast editorial luminance pop"},
    "match-cut-rect": {"frames": 14, "style": "Bounding-box geometry match cut across scenes"},
}

DEPTH_CAMERA_PRESETS = [
    "cinematic-orbit",
    "dolly-push",
    "vertigo-contra-zoom",
    "crane-rise",
    "parallax-drift",
    "breathing-float",
    "cutaway-peel",
    "hero-pullback",
]


def select_motion_plan(intent: str, fps: int = 30, duration_sec: float = 12.0) -> dict:
    q = (intent or "").lower()
    if any(k in q for k in ("kopi", "coffee", "kuliner", "sejarah", "editorial", "clean", "minimal")):
        typo = "editorial-serif"
        cap = "karaoke-pill" if "minimal" not in q else "minimal"
        trans = "palette-ripple"
        depth = "breathing-float"
    elif any(k in q for k in ("mesin", "motor", "cutaway", "bedah", "cara kerja", "otak", "sains")):
        typo = "leader-callout"
        cap = "karaoke-pill"
        trans = "cutaway-shell-peel"
        depth = "cutaway-peel"
    elif any(k in q for k in ("kode", "coding", "terminal", "tech", "glitch", "cyber")):
        typo = "brutalist-stagger"
        cap = "typewriter" if "glitch" not in q else "glitch"
        trans = "match-cut-rect"
        depth = "dolly-push"
    else:
        typo = "counter-shock"
        cap = "karaoke-pill"
        trans = "whip-pan-blur"
        depth = "cinematic-orbit"

    total_frames = max(60, int(round(duration_sec * fps)))
    return {
        "ok": True,
        "version": "9.6.0",
        "intent": intent,
        "typography_variant": typo,
        "caption_style": cap,
        "transition_bridge": trans,
        "depth_preset": depth,
        "fps": fps,
        "total_frames": total_frames,
        "safe_zone": {"x_min": 84, "x_max": 876, "y_min": 220, "y_max": 1490},
    }


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.6.0 Motion, Typography & Transition Selector")
    p.add_argument("--intent", default="clean editorial cutaway", help="Natural language motion intent or topic")
    p.add_argument("--list", action="store_true", help="List all typography, caption, transition, and 3D depth presets")
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--duration", type=float, default=12.0)
    p.add_argument("--out-shot-map", help="Optional path to write shot-map.md")
    a = p.parse_args()

    if a.list:
        print(
            json.dumps(
                {
                    "ok": True,
                    "version": "9.6.0",
                    "typography_styles": TYPOGRAPHY_STYLES,
                    "caption_styles": CAPTION_STYLES,
                    "scene_transitions": SCENE_TRANSITIONS,
                    "depth_camera_presets": DEPTH_CAMERA_PRESETS,
                },
                indent=2,
            )
        )
        return 0

    plan = select_motion_plan(a.intent, fps=a.fps, duration_sec=a.duration)
    if a.out_shot_map:
        out_p = Path(a.out_shot_map).expanduser().resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        md = (
            f"# Shotcraft Pro v9.6.0 — Motion & Typography Shot Map\n\n"
            f"- **Intent**: {plan['intent']}\n"
            f"- **Typography Variant**: `{plan['typography_variant']}`\n"
            f"- **Caption Style**: `{plan['caption_style']}`\n"
            f"- **Transition Bridge**: `{plan['transition_bridge']}`\n"
            f"- **3D Depth Camera Preset**: `{plan['depth_preset']}`\n"
            f"- **Safe Zone (1080x1920)**: `x: 84..876, y: 220..1490`\n"
        )
        out_p.write_text(md, encoding="utf-8")
        plan["shot_map_path"] = str(out_p)

    print(json.dumps(plan, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
