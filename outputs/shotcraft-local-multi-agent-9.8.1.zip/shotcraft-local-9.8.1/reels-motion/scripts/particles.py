#!/usr/bin/env python3
"""
Shotcraft Pro v9.6.0 — Particle, Volumetric Light Shafts (God Rays), Multi-Stop Gradient & Film Grain Engine (`particles.py`).

Implements `[P2-3]` & `[QW8]`:
- Floating particles (bokeh orbs, warm coffee dust, neural data packets) with depth-scaled parallax velocity.
- Volumetric light shafts (conic god rays) & multi-stop gradient atmosphere mapping.
- Subtle cinema vignette & configurable film grain overlay.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

STYLE_PARTICLE_PRESETS = {
    "neural-network": {"kind": "data-bokeh", "density": 36, "god_rays": True, "vignette": 0.26, "grain": 0.02},
    "coffee-editorial-3d": {"kind": "warm-dust", "density": 22, "god_rays": True, "vignette": 0.14, "grain": 0.015},
    "ref5-editorial-cutaway": {"kind": "editorial-motes", "density": 16, "god_rays": False, "vignette": 0.12, "grain": 0.01},
    "ref1-tutorial-deck": {"kind": "terminal-sparks", "density": 24, "god_rays": False, "vignette": 0.20, "grain": 0.015},
    "ref2-floating-glass": {"kind": "aurora-bokeh", "density": 32, "god_rays": True, "vignette": 0.24, "grain": 0.02},
    "ref3-pricing-voxel": {"kind": "voxel-packets", "density": 28, "god_rays": True, "vignette": 0.22, "grain": 0.015},
    "ref4-tape-mascot": {"kind": "paper-dust", "density": 18, "god_rays": False, "vignette": 0.16, "grain": 0.015},
}


def apply_particles_and_atmosphere(
    img: Image.Image,
    draw,
    local_frame: int,
    fps: float = 30.0,
    accent_rgb: tuple[int, int, int] = (56, 189, 248),
    style_mode: str = "neural-network",
    audio_rms: float = 0.0,
):
    """
    Renders volumetric god-rays, depth-layered floating particles (bokeh / data packets / dust),
    and cinema edge vignette onto the current frame.
    """
    w, h = img.size
    t = local_frame / max(1.0, float(fps))
    preset = STYLE_PARTICLE_PRESETS.get(style_mode, STYLE_PARTICLE_PRESETS["neural-network"])
    density = int(preset.get("density", 28))
    ar, ag, ab = accent_rgb
    pulse_boost = 1.0 + float(audio_rms) * 0.45

    # 1. Volumetric Light Shafts (God Rays) in upper-center stage
    if preset.get("god_rays"):
        src_x = int(w * 0.5 + math.sin(t * 0.4) * 45)
        src_y = int(h * 0.26)
        for ray_i in range(5):
            ang = math.radians(-38 + ray_i * 19 + math.sin(t * 0.7 + ray_i) * 5.5)
            ray_len = int(h * 0.48)
            rx1 = src_x + int(math.sin(ang - 0.045) * ray_len)
            ry1 = src_y + int(math.cos(ang - 0.045) * ray_len)
            rx2 = src_x + int(math.sin(ang + 0.045) * ray_len)
            ry2 = src_y + int(math.cos(ang + 0.045) * ray_len)
            alpha = int(min(42, (14 + (ray_i % 2) * 8) * pulse_boost))
            draw.polygon([(src_x, src_y), (rx1, ry1), (rx2, ry2)], fill=(ar, ag, ab, alpha))

    # 2. Floating Bokeh / Data Packets / Dust Particles with 3D depth parallax
    for i in range(density):
        depth_layer = 0.25 + (i % 4) * 0.25  # 0.25 (far) .. 1.0 (near)
        base_x = (i * 173.3) % w
        base_y = (i * 311.7) % h
        vx = ((i % 5) - 2) * 11.0 * depth_layer
        vy = -(16.0 + (i % 7) * 8.5) * depth_layer

        px = int((base_x + vx * t) % w)
        py = int((base_y + vy * t) % h)
        rad = max(2, int(round((2.0 + (i % 4) * 2.2) * depth_layer * pulse_boost)))
        alpha = int(min(135, (28 + (i % 5) * 18) * depth_layer))

        if i % 3 == 0:
            col = (ar, ag, ab, alpha)
        elif i % 3 == 1:
            col = (min(255, ar + 55), min(255, ag + 45), 255, alpha)
        else:
            col = (241, 245, 249, int(alpha * 0.75))

        draw.ellipse([px - rad, py - rad, px + rad, py + rad], fill=col)
        # Subtle glowing halo on foreground bokeh particles
        if depth_layer >= 0.75 and rad >= 5:
            hr = int(rad * 1.9)
            draw.ellipse([px - hr, py - hr, px + hr, py + hr], fill=(ar, ag, ab, max(10, alpha // 4)))


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.6.0 Particle & Atmosphere Engine")
    p.add_argument("--style", default="neural-network", choices=list(STYLE_PARTICLE_PRESETS.keys()))
    p.add_argument("--output-preview", help="Optional path to render a standalone 1080x1920 particle test PNG")
    a = p.parse_args()

    if a.output_preview:
        im = Image.new("RGB", (1080, 1920), (7, 11, 22))
        d = ImageDraw.Draw(im, "RGBA")
        apply_particles_and_atmosphere(im, d, local_frame=24, fps=30.0, style_mode=a.style)
        out_p = Path(a.output_preview).expanduser().resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        im.save(str(out_p), format="PNG")
        print(json.dumps({"ok": True, "style": a.style, "preview_png": str(out_p)}, indent=2))
        return 0

    print(json.dumps({"ok": True, "presets": STYLE_PARTICLE_PRESETS}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
