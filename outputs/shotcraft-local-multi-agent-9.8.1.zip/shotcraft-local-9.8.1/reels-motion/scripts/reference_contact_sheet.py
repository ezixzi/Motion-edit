#!/usr/bin/env python3
"""Sample a reference for visual study. No transcription or factual validation."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw


def main():
    p=argparse.ArgumentParser();p.add_argument('video');p.add_argument('--out',required=True);p.add_argument('--samples',type=int,default=12)
    a=p.parse_args()
    if not 4<=a.samples<=48:p.error('samples must be between 4 and 48')
    source=Path(a.video).expanduser().resolve();out=Path(a.out).expanduser().resolve()
    if not source.is_file():p.error('Video file missing')
    if out.exists():p.error('Use a new output directory')
    q=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(source)],capture_output=True,text=True,check=True)
    meta=json.loads(q.stdout);video=next(x for x in meta['streams'] if x['codec_type']=='video');duration=float(video.get('duration') or meta['format']['duration'])
    out.mkdir(parents=True)
    cell_w=240;thumb_h=round(cell_w*video['height']/video['width']);cell_h=thumb_h+26;columns=4
    sheet=Image.new('RGB',(columns*cell_w,((a.samples+columns-1)//columns)*cell_h),'#161616');draw=ImageDraw.Draw(sheet);frames=[]
    for i in range(a.samples):
        t=duration*(i+.5)/a.samples;path=out/f'frame-{i:02d}.png'
        subprocess.run(['ffmpeg','-v','error','-nostdin','-ss',str(t),'-i',str(source),'-frames:v','1','-vf',f'scale={cell_w}:-1',str(path)],capture_output=True,check=True)
        with Image.open(path) as image:sheet.paste(image,(i%columns*cell_w,i//columns*cell_h))
        draw.text((i%columns*cell_w+8,i//columns*cell_h+thumb_h+5),f'~{t:.2f}s',fill='white');frames.append({'approx_seconds':t,'file':path.name})
    sheet.save(out/'contact-sheet.jpg',quality=90)
    digest=hashlib.sha256()
    with source.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
    report={'source_name':source.name,'sha256':digest.hexdigest(),'duration':duration,'width':video['width'],'height':video['height'],'frames':frames,'audio_review':'not performed','facts':'not validated','purpose':'reference study; not training or automatic visual approval'}
    (out/'reference.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'ok':True,'contact_sheet':str(out/'contact-sheet.jpg'),'report':str(out/'reference.json')}))
if __name__=='__main__':main()
