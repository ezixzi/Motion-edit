---
name: reels-motion
description: Choose content-led Reels motion, 8 typography styles, 10 motivated transitions, and 3D depth camera trajectories from video-shotcraft and Shotcraft Pro v9.6.0. Works with simple requests such as "lebih dinamis", "clean", "efek 3D", "satu objek berubah terus" or named shots.
---

# Motion, Typography & Transition Routing (v9.6.0)

Read the current brief and sibling `shotcraft-local/config.json`. Search the on-disk inventory (`find_motion.py`) for 3–5 relevant candidates; read exact selected cards, demos, and helpers. Do not load the entire library.
- Read `references/motion-playbook.md` for choreography and validation.
- Read `references/typography-and-transitions.md` for the **8 Typography Styles** (`karaoke-pill`, `brutalist-stagger`, `editorial-serif`, `glass-callout`, `counter-shock`, `asymmetric-ragged`, `kinetic-slam`, `leader-callout`), **10 Scene Transitions** (`iris-aperture`, `palette-ripple`, `shape-morph-relay`, `whip-pan-blur`, `depth-z-pass`, `glyph-mask-takeover`, `cutaway-shell-peel`, `split-shutter`, `flash-frame-cut`, `match-cut-rect`), and **8 3D Depth Presets**.

## Intent Mapping

- **"Lebih dinamis"**: Stronger rhythm, focal scale contrast, and purposeful transition variety (`whip-pan-blur`, `iris-aperture`, `depth-z-pass`)—not random shaking or shorter reading holds.
- **"Clean / minimal / editorial"**: Clear typographic hierarchy (`editorial-serif` or `glass-callout`), restrained damped springs, generous negative space, and `palette-ripple` or `split-shutter` bridges.
- **"Efek 3D / foto hidup / parallax / dolly zoom"**: Route to sibling `reels-depth-motion` (`scripts/depth_engine.py`) and `reels-templates/components/DepthParallaxStage.tsx`.
- **"Satu objek berubah terus / tanpa cut"**: Route to a selected `reels-continuity-lab` recipe + `TransitionBridge.tsx` (`shape-morph-relay`).
- **"Bedah objek / cara kerja mesin / cutaway"**: Read sibling `reels-continuity-lab/references/technical-cutaway-explainer.md`, `references/visual-asset-playbook.md`, and use `reels-templates/components/CutawayRigStage.tsx`.

## Output Contract

Output a compact `shot-map.md`: source recipe/template, content purpose, typography variant, transition bridge, 3D depth preset (if used), entry/action/settle/hold/exit frames, safe geometry (`x: 90..870, y: 250..1500` at 1080×1920), and sound/speech landmark. Before final encode, inspect mask takeover, ripple coverage, 3D extrema, scene handoffs, and CTA reading hold (≥2s).

## CLI Entry Point (`scripts/motion_presets.py`)

Run `python3 reels-motion/scripts/motion_presets.py --intent "..." --out-shot-map shot-map.md` or `--list` to inspect all 8 typography styles, 7 caption styles, 10 transitions, and 8 3D camera presets.
