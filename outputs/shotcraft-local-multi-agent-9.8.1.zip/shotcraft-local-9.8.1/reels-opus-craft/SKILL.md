---
name: reels-opus-craft
description: Local gallery & procedural Remotion animation engine powered by yihui-dev/awesome-opus5-5-videos. Provides 24 curated Opus 5.5 creative-coding recipes, offline HTML/JSON gallery, prompt search CLI, and OpusProceduralStage.tsx for zero-screenshot explainers, 3D cutaways, and motion graphics.
---

# Opus 5.5 Creative-Coding & Local Gallery (`reels-opus-craft` v5.0)

This skill bundles the curated local gallery and procedural Remotion patterns from **[yihui-dev/awesome-opus5-5-videos](https://github.com/yihui-dev/awesome-opus5-5-videos)** directly on disk so you never need internet access or external screenshots to build rich animations.

## Local Assets & Scripts

1. **Local Catalog & Offline Gallery**:
   - `catalog.json` & `gallery/data/videos.json`: 24 structured recipes across **Motion graphics**, **Explainers**, **3D scenes**, and **Games & interactive**.
   - `gallery/prompts/*.md`: Full prompt cards with creator attribution, visual grammar, and procedural mode mapping.
   - `gallery/index.html`: Self-contained offline browser gallery (open directly or run `python scripts/opus_gallery.py --serve`).
2. **Search & Remake CLI (`scripts/search_opus_prompts.py`)**:
   ```sh
   python "<this-skill>/scripts/search_opus_prompts.py" --query "turbofan cutaway 3d" --limit 5
   ```
3. **Reusable Remotion Component (`reels-templates/components/OpusProceduralStage.tsx`)**:
   - Supports 8 deterministic procedural modes:
     - `node-network` (AI/neural node graph & packet routing)
     - `wave-interference` (Multi-harmonic physics & audio waves)
     - `3d-isometric-growth` (Layered architectural 3D slab growth)
     - `stress-heatmap` (Mechanical FEA thermal/stress mesh)
     - `audio-reactive-rings` (Concentric frequency rings & sub-bass pulse)
     - `deconstructed-ui` (Floating SaaS vector widgets with spring choreography)
     - `dual-device-showreel` (Paired desktop browser + mobile frame with dark-mode flip & Q&A chat)
     - `cutaway-turbofan` (Multi-stage technical cutaway with airflow streamlines & leader callouts)
