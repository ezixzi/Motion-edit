# AI In Public 60fps HUD, Terminal & Neural Launch Reel (@humzaakhalid)

- **Creator**: @humzaakhalid
- **Category**: Motion graphics
- **Tech Stack**: Remotion, Canvas, Python Audio
- **Procedural Mode in `OpusProceduralStage.tsx`**: `hud-terminal-neural`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
High-tempo electric-blue (#3D40FE) and ice HUD reel combining live terminal typing, neural particle graphs, camera hits, and Python-synthesized suspense SFX.

## Prompt
```text
A 24-second AI In Public motion reel in Remotion at 1920x1080, 60fps. Use our blue #3D40FE, white, navy, and ice palette with the AI In Public logo and sparkle. Keep it fast, premium, and smooth with motion blur, glow, camera hits, HUD details, seamless transitions, kinetic type, terminal UI, neural visuals, particles, and a cinematic logo finale. Generate all suspenseful music and sound effects in code and sync every hit perfectly.
```
