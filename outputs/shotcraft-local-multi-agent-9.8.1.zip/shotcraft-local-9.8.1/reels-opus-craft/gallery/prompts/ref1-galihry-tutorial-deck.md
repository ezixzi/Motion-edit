# Step-by-Step Dark Dot-Grid UI & Terminal Tutorial Deck (@galihry Reference #1)

- **Creator**: @galihry
- **Category**: Explainers
- **Procedural Mode**: `ref1-tutorial-deck`

## Visual Grammar
Dark dot-grid canvas (#121210) with ambient radial glow, top [✳ REMOTION × CLAUDE] & creator pills, numbered step pill [1 LANGKAH], 2-tone uppercase headline, center macOS terminal/UI window with live typing, progress bars & tilted stickers ([WAJIB!]), and bottom dim-to-lit uppercase karaoke subtitles.

## Prompt
```text
Buatkan video tutorial vertikal 9:16 ala @galihry (REMOTION × CLAUDE): background gelap dot-grid #121210 dengan radial glow hangat, badge atas [✳ REMOTION × CLAUDE], pill langkah bernomor [1 LANGKAH], judul besar 2 warna, jendela macOS/terminal di tengah dengan animasi ketikan perintah CLI, progress bar, stiker miring [WAJIB!], serta subtitle bawah uppercase yang menyala kata demi kata mengikuti narasi.
```
