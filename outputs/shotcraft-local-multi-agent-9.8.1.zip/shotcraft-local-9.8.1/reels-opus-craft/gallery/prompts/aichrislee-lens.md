# Interactive 3D Camera Lens Optical Cutaway (@aichrislee)

- **Creator**: @aichrislee
- **Category**: Explainers
- **Tech Stack**: Three.js, GLSL, SVG, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `optical-ray-cutaway`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Cross-section cutaway of a multi-group optical zoom lens showing aperture blades opening/closing and colored light rays refracting through glass elements onto the sensor.

## Prompt
```text
Build a camera lens in interactive 3D with Three.js/SVG cutaway: a pro zoom lens with its glass front, rubber focus and zoom rings, red stripe, and inside it the stack of glass elements in their groups, aperture blades that open and close, focus motor, image stabilizer, and gold mount contacts. Cut it open down the side so light passes through as colored beams that bend and meet on the camera sensor behind it.
```
