# Split-Screen Web Pricing Inspector + 3D Voxel Presenter (@classai_id Reference #3)

- **Creator**: @classai_id
- **Category**: Explainers
- **Procedural Mode**: `ref3-pricing-voxel`

## Visual Grammar
Deep navy grid canvas (#060A12) with giant outlined chapter numbers (01..05), service icon & category tags, zooming dark browser pricing table with animated cursor & blue highlight callout badges ([∞ gratis], [500 BUILD / BULAN]), diagonal blue wipe transitions, electric-blue pop captions, and an expressive 3D voxel presenter at the bottom.

## Prompt
```text
Buatkan video listicle edukasi tech 9:16 ala @classai_id: background grid biru gelap, nomor bab besar 01-05 dengan ikon layanan, jendela browser dokumentasi/harga di tengah yang otomatis zoom ke baris penting dengan kotak highlight biru dan badge angka melayang, teks kata kunci biru elektrik di tengah, transisi diagonal wipe, serta karakter 3D voxel di bagian bawah yang menunjuk ke layar dan memberi jempol saat CTA.
```
