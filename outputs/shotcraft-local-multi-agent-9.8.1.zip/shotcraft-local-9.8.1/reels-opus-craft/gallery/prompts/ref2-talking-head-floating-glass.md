# Talking-Head Floating Frosted Glass UI & Gradient Kinetic Overlay (Reference #2)

- **Creator**: @creator_ai_id
- **Category**: Motion graphics
- **Procedural Mode**: `ref2-floating-glass`

## Visual Grammar
Full-bleed talking-head video with floating frosted glass cards (backdrop-filter: blur(22px)), numbered glass pills ([1 Claude], [2 Guidebook]), glass tag clouds, radial starburst progress ring, purple-pink gradient headlines in the upper headroom (y: 150..560px), and clean karaoke subtitles at the bottom.

## Prompt
```text
Edit video talking-head 9:16 dengan komponen kaca buram (frosted glass) melayang di area atas kepala pembicara: kartu prompt dengan tombol gradien [Editkan], daftar bernomor kaca [1 Claude] [2 Guidebook], tag cloud [Style] [Desain] [Animasi], teks gradien ungu-pink untuk kata kunci utama, glow pelangi di tepi layar saat klimaks, dan subtitle bersih di bagian bawah.
```
