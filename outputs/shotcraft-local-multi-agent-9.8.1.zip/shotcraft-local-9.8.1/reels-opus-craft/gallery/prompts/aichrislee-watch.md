# 3D Mechanical Watch Escapement & Gear Train Cutaway (@aichrislee)

- **Creator**: @aichrislee
- **Category**: 3D scenes
- **Tech Stack**: Three.js, Canvas, Web Audio, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `gear-train-cutaway`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Precision horology cutaway showing mainspring barrel,meshed gear train, breathing hairspring, oscillating balance wheel, pallet fork ticking at 4Hz, and ruby pivot jewels.

## Prompt
```text
Build a mechanical watch in 3D cutaway: gold case and glass on top, dial and hands, and behind it the movement: mainspring in its barrel, gear train, balance wheel swinging back and forth with its hairspring breathing, escape wheel and pallet fork ticking, and red jewels the gears turn on, with an exploded layer view.
```
