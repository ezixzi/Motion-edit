# 3D Mechanical Stress & Thermal Heatmap Simulation (@chang_)

- **Creator**: @chang_
- **Category**: 3D scenes
- **Tech Stack**: Three.js, GLSL, Canvas, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `stress-heatmap`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Finite-element-style (FEA) mesh visualization where applied load warps the grid and shifts color smoothly from cool blue (low stress) through green/yellow to critical red concentration zones.

## Prompt
```text
Create a 3D brake pedal mechanical stress simulation animation showing applied force vectors, finite-element mesh deformation, and a dynamic blue-green-yellow-red Von Mises stress heatmap.
```
