# Algorithm & System Architecture Step-by-Step Visualizer (@sudo_kiran)

- **Creator**: @sudo_kiran
- **Category**: Explainers
- **Tech Stack**: Canvas, SVG, GSAP, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `algorithm-stepper`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Step-locked state machine visualization showing request tokens moving through load balancer, cache, queue, and worker pools with live latency counters.

## Prompt
```text
Create a step-by-step system architecture and algorithm explainer in Canvas/SVG + GSAP showing requests flowing through API gateway, cache hit/miss paths, message queues, and database shards with real-time throughput metrics.
```
