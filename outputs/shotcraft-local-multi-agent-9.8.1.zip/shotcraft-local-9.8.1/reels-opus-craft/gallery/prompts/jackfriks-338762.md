# Vertical 9:16 Character & Mascot Story Reel (@jackfriks)

- **Creator**: @jackfriks
- **Category**: Motion graphics
- **Tech Stack**: Canvas, SVG, GSAP, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `mascot-story`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos/blob/main/prompts/jackfriks-338762.md

## Visual Grammar
Expressive SVG character/mascot in a 9:16 vertical stage reacting to user milestones, notifications, and emotional story beats with squash-and-stretch springs.

## Prompt
```text
Build a vertical 9:16 social video featuring an expressive vector mascot character that reacts to app milestones, streak notifications, and user wins with lively SVG squash-and-stretch animation and punchy caption cards.
```
