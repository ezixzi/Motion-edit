# How QR Codes Hold & Repair Messages Explainer (@eyadnour)

- **Creator**: @eyadnour
- **Category**: Explainers
- **Tech Stack**: Three.js, Canvas, Web Audio, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `matrix-bit-decoder`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Deconstructs a QR matrix into finder patterns, timing strips, zig-zag byte placement, mask XOR overlays, and Reed-Solomon parity recovery when modules are damaged.

## Prompt
```text
Build an interactive explainer on how QR codes hold and repair a message. Show finder patterns, timing modules, zig-zag bit reading order, XOR masking, and Reed-Solomon error correction restoring damaged cells with synchronized visuals and sound design.
```
