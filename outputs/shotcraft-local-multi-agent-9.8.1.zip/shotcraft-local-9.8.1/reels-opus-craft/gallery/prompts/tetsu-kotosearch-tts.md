# Automated Screenshot + 32-Phrase TTS Sync & Auto-Ducked BGM (@tetsu_tetsu333)

- **Creator**: @tetsu_tetsu333
- **Category**: Explainers
- **Tech Stack**: Remotion, SVG, GSAP, TTS, Python Audio
- **Procedural Mode in `OpusProceduralStage.tsx`**: `narrated-phrase-sync`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Splits TTS voiceover into phrase-level and word-level timestamps so every UI card, callout, and caption appears at the exact millisecond it is spoken, while Python-composed BGM automatically ducks under the voice.

## Prompt
```text
Create a 52-second SaaS release video in Remotion: capture desktop, mobile, and component cutouts; generate natural TTS narration; split the voiceover into phrase segments so screen transitions and telop captions fire on the exact spoken syllable; compose BGM in code that automatically ducks its volume whenever the narrator speaks; and self-inspect rendered still frames to eliminate any text clipping or overlap.
```
