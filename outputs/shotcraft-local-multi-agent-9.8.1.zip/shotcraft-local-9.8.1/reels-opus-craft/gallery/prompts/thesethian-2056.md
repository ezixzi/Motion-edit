# Continuous 30-Year Future Space Camera Flight (@theSethian)

- **Creator**: @theSethian
- **Category**: Motion graphics
- **Tech Stack**: Three.js, GLSL, Canvas, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `timeline-camera-flight`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Single unbroken camera flight across 5 chronological stops (2026 Earth satellites -> 2032 orbital ring -> 2040 Moon base -> 2048 Mars cities -> 2056 Dyson swarm) with continuous Z-depth travel.

## Prompt
```text
Show me the next 30 years. One shot, no cuts. Five stops: 2026, Earth at night under a cloud of satellites; 2032, a ring around the planet with space elevators; 2040, a base on the Moon; 2048, cities on Mars; 2056, a swarm of mirrors circling the Sun. Continuous camera flight from Earth out to Mars, then back past Earth to the Sun.
```
