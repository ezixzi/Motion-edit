# 3D Turbofan Jet Engine Exploded Cutaway (@0xSpikez)

- **Creator**: @0xSpikez
- **Category**: Explainers
- **Tech Stack**: Three.js, GLSL, SVG, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `cutaway-turbofan`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Annotated 4-stage engine cutaway (Intake Fan -> Compressor -> Combustor -> Turbine) with particle airflow streamlines transitioning from cold cyan intake to high-temp orange exhaust and exploded stage separation.

## Prompt
```text
An interactive 3D turbofan you can take apart, built with Three.js / SVG. Suck, squeeze, bang, blow, every stage labelled: the fan pulls in a huge mass of air; compressor stages squeeze the air about 40 times, heating it; fuel burns hotter than the turbine metal's melting point; two shafts spinning at different speeds; then it explodes into every stage.
```
