# Halftone Xerox & Beat-Synced Eyes Anchor Launch Film (@LeowenAI)

- **Creator**: @LeowenAI
- **Category**: Motion graphics
- **Tech Stack**: Remotion, GLSL, Canvas, SVG, Python Audio
- **Procedural Mode in `OpusProceduralStage.tsx`**: `halftone-eye-anchor`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Uses a persistent visual anchor (expressive eyes/logo core) that watches the typing cursor, blinks on the beat, glances at incoming UI cards, and lands on the final brand mark over a tactile halftone texture.

## Prompt
```text
Create a product launch film in Remotion with a halftone xerox aesthetic, dynamic camera moves, seamless transitions, and a Python-synthesized beat. Use expressive eyes as the visual anchor of the whole film—they watch you type, blink on the beat, squint, glance at features, and land on the final logo.
```
