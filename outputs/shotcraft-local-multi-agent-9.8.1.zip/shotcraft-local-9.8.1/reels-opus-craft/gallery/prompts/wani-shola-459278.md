# Dual-Device Browser & Phone Showreel (@wani_shola)

- **Creator**: @wani_shola
- **Category**: Motion graphics
- **Tech Stack**: Remotion, SVG, GSAP
- **Procedural Mode in `OpusProceduralStage.tsx`**: `dual-device-showreel`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos/blob/main/prompts/wani-shola-459278.md

## Visual Grammar
Animates real website captures inside paired desktop browser and mobile phone frames, flips seamlessly to dark mode, and displays bold Q&A chat exchanges cut on a 120 BPM beat with zero extra clutter.

## Prompt
```text
Make a showreel-style motion graphics video for my portfolio website, http://sholajegede.com, using Remotion. Capture the pages and sections in a browser (home, Ask, package pages, Hire, mobile view, dark mode) and animate them inside browser and phone frames. Show the site's chat answering real questions about my work, with the questions and answers large and bold. Follow premium brand rules: three colours and the site's own fonts, one idea per shot, key objects centred, space to breathe, eased motion only, smooth transitions instead of hard cuts. Add music at about 120 BPM and cut every scene on the beat.
```
