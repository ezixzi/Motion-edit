# Retro-Futuristic Film Grain & CRT Launch Video (@johnsavage_ai)

- **Creator**: @johnsavage_ai
- **Category**: Motion graphics
- **Tech Stack**: Three.js, GLSL, Canvas, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `retro-crt-shader`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos/blob/main/prompts/johnsavage-ai-427263.md

## Visual Grammar
Combines procedural GLSL CRT scanlines, subtle chromatic aberration at frame edges, organic film grain, and bold retro-futuristic kinetic typography.

## Prompt
```text
Use this image only as a style/vibe reference image and create an Opus 5.5 launch video (20 sec long). Add film grain and CRT effect, make it mesmerizing, and show off your skills as a motion designer for a retro/futuristic style launch video 16:9.
```
