# Audio-Reactive Radial Spectrum & Beat Rings (@BuildFastWithAI)

- **Creator**: @BuildFastWithAI
- **Category**: Motion graphics
- **Tech Stack**: Canvas, Web Audio, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `audio-reactive-rings`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Concentric frequency rings, harmonic bars, and sub-bass pulse waves driven deterministically by the audio envelope and BPM beat grid.

## Prompt
```text
Generate an audio-reactive motion video with concentric frequency spectrum rings, sub-bass camera pulse, and beat-locked typography bursts synchronized to the soundtrack.
```
