# 3D Beating Heart Chambers & Blood Flow Explainer (@aichrislee)

- **Creator**: @aichrislee
- **Category**: Explainers
- **Tech Stack**: Three.js, Canvas, Web Audio, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `bio-pulse-flow`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
Rhythmic 60 BPM anatomical cutaway showing four chambers, valves opening in phase, deoxygenated blue venous inflow, oxygenated red arterial outflow, and electrical conduction pathways.

## Prompt
```text
Build a human heart in 3D cutaway: deep red muscle with red arteries and blue veins on top, and inside it the four chambers, four valves, aorta, pulmonary artery, and electrical wiring that sets the beat. The heart beats once a second, valves open and close in time, and blood flows through it, blue going in and red going out, with an exploded layer reveal.
```
