# Nobel Prize Science & Wave Harmonics Simulation (@KeWai386772)

- **Creator**: @KeWai386772
- **Category**: Explainers
- **Tech Stack**: Canvas, SVG, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `wave-interference`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Multi-harmonic sine/cosine wave superposition and radial energy spectrum demonstrating constructive/destructive interference, phase locking, and energy transfer.

## Prompt
```text
Build a Nobel Prize science explainer showing wave superposition, harmonic resonance, and quantum phase alignment using crisp mathematical curves, phase indicators, and clear scientific annotations.
```
