# 2D/3D Rigid-Body Feature Pills Gravity Drop (@froessell)

- **Creator**: @froessell
- **Category**: Games & interactive
- **Tech Stack**: Three.js, Canvas, Physics, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `physics-pill-drop`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Feature badges and metric pills drop under deterministic gravity, collide, rotate, and settle into a balanced stack at the bottom of the frame.

## Prompt
```text
Build a deterministic physics animation where bold feature pills and icon badges drop from above, bounce off each other with realistic restitution, and settle into a readable stack.
```
