# 3D Avatar & Blocky Claude Mascot + Masking-Tape Banner & Torn-Paper Stickers (Reference #4)

- **Creator**: @motionmaxxing_id
- **Category**: 3D scenes
- **Procedural Mode**: `ref4-tape-mascot`

## Visual Grammar
Alternates 3D studio creator avatar and 3D blocky orange Claude mascot at a computer desk, paired with a top masking-tape cream paper banner (CLAUDE BUKAN CUMA BUAT NGODING), middle hole-punch skill card with orange number badge (1)(2)(3), and bottom tilted terracotta/cream torn-paper word stickers.

## Prompt
```text
Buatkan video Reels 3D bergaya maskot & stiker kertas: kombinasikan adegan karakter 3D di depan mikrofon dan maskot 3D kotak oranye Claude di meja komputer, pita kertas selotip (masking-tape banner) di bagian atas untuk judul bab, kartu skill berlubang dengan badge nomor oranye (1)(2)(3), serta subtitle bawah berbentuk potongan kertas robek (torn-paper stickers) warna terakota dan krem yang miring bergantian.
```
