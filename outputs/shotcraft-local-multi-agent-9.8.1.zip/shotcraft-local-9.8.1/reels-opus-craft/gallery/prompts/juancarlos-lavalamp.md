# GLSL Metaball Liquid & Lava Lamp Shader Stage (@juancarlos17626)

- **Creator**: @juancarlos17626
- **Category**: 3D scenes
- **Tech Stack**: GLSL, WebGL, Canvas, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `liquid-metaballs`
- **Source**: https://github.com/yihui-dev/awesome-opus5-5-videos

## Visual Grammar
Smooth signed-distance-field (SDF) metaball blobs rising, merging, and splitting with Fresnel rim lighting as an atmospheric backdrop for luxury or tech typography.

## Prompt
```text
Create a realistic lava lamp and liquid metaball animation using smooth SDF blending, warm internal subsurface glow, and specular rim highlights.
```
