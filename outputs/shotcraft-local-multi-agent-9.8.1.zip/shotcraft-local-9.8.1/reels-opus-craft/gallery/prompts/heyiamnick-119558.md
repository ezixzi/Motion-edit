# One Pencil Line Promoted Three Times Showreel (@heyiamnick)

- **Creator**: @heyiamnick
- **Category**: Motion graphics
- **Tech Stack**: Canvas, SVG, Remotion
- **Procedural Mode in `OpusProceduralStage.tsx`**: `single-line-relay`
- **Source**: https://skillry.dev/ai-videos/opus-5-5

## Visual Grammar
One continuous line gets promoted three times (graphite on paper #EDE6D5 -> wire on blueprint #1B3ED2 -> hologram cyan #45F0DD on black #07080A) and never leaves the screen; every shot transforms out of the previous one with zero cuts.

## Prompt
```text
Build a 30-second looping motion design showreel that introduces CLAUDE, a motion designer. Concept, in one line: one pencil line gets promoted three times (graphite on paper, wire on a blueprint, light on black) and never leaves the screen. Every shot is made out of the previous one: shapes, type and colour transform into the next scene. No cuts, no fades. Typeface: Geist only. Weight 900 for big words, 600 to 800 for small labels. Palette: paper cream #EDE6D5, blueprint blue #1B3ED2, hologram cyan #45F0DD, plus black #07080A.
```
