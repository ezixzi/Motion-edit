#!/usr/bin/env python3
"""Search local awesome-opus5-5-videos catalog, companion continuity recipes, and blueprint templates (v5.0)."""
import argparse
import json
import re
from pathlib import Path


def norm(s: str) -> str:
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", s)
    return re.sub(r"[^\w]+", " ", s.lower()).strip()


def main():
    p = argparse.ArgumentParser(description="Search local Opus 5.5 gallery and Shotcraft companion catalogs")
    p.add_argument("--query", required=True, help="Search keywords (Indonesian or English)")
    p.add_argument("--category", default="", help="Optional category filter")
    p.add_argument("--limit", type=int, default=6)
    a = p.parse_args()

    here = Path(__file__).resolve().parent
    opus_dir = here.parent
    skills_root = opus_dir.parent

    aliases = {
        "otak": "brain neural network",
        "jaringan": "network neural nodes",
        "gelombang": "wave science harmonics",
        "mesin": "engine turbofan cutaway",
        "bedah": "cutaway exploded lens heart",
        "jantung": "heart anatomy bio",
        "lensa": "lens camera optical",
        "jam": "watch mechanical gears",
        "produk": "showreel saas launch ui",
        "website": "showreel browser phone",
        "suara": "audio reactive tts",
        "narasi": "tts narration sync",
        "panas": "heatmap stress thermal",
        "bangunan": "3d isometric growth architecture",
        "fisika": "physics gravity wave",
    }

    q_norm = norm(a.query)
    words = []
    for w in q_norm.split():
        words.extend(aliases.get(w, w).split())
    phrase = " ".join(words)

    results = []

    # 1. Search reels-opus-craft/catalog.json
    cat_path = opus_dir / "catalog.json"
    if cat_path.is_file():
        cat = json.loads(cat_path.read_text(encoding="utf-8"))
        for r in cat.get("recipes", []):
            if a.category and a.category.lower() not in r.get("category", "").lower():
                continue
            hay = norm(
                " ".join(
                    [
                        r.get("id", ""),
                        r.get("title", ""),
                        r.get("creator", ""),
                        r.get("category", ""),
                        r.get("procedural_mode", ""),
                        r.get("grammar", ""),
                        r.get("prompt", ""),
                        " ".join(r.get("search_terms", [])),
                        " ".join(r.get("tech_stack", [])),
                    ]
                )
            )
            score = (90 if norm(r["id"]) == q_norm else 25 if q_norm in hay else 0) + sum(
                6 for w in set(words) if w in hay.split()
            )
            if score > 0:
                results.append(
                    {
                        "score": score,
                        "source": "reels-opus-craft",
                        "id": r["id"],
                        "title": r["title"],
                        "creator": r.get("creator"),
                        "category": r.get("category"),
                        "procedural_mode": r.get("procedural_mode"),
                        "grammar": r.get("grammar"),
                        "prompt_file": str(opus_dir / r["prompt_file"]),
                        "prompt_preview": r.get("prompt", "")[:240],
                    }
                )

    # 2. Search reels-continuity-lab/catalog.json
    cont_path = skills_root / "reels-continuity-lab" / "catalog.json"
    if cont_path.is_file():
        cont = json.loads(cont_path.read_text(encoding="utf-8"))
        for r in cont.get("recipes", []):
            hay = norm(
                r.get("id", "")
                + " "
                + r.get("title", "")
                + " "
                + " ".join(r.get("upstream_search_hints", []) + r.get("search_terms", []))
            )
            score = (80 if norm(r["id"]) == q_norm else 20 if q_norm in hay else 0) + sum(
                5 for w in set(words) if w in hay.split()
            )
            if score > 0:
                results.append(
                    {
                        "score": score,
                        "source": "reels-continuity-lab",
                        "id": r["id"],
                        "title": r["title"],
                        "recipe_path": str(cont_path.parent / r["recipe"]),
                    }
                )

    # 3. Search reels-templates/blueprints/templates_catalog.json
    tpl_path = skills_root / "reels-templates" / "blueprints" / "templates_catalog.json"
    if tpl_path.is_file():
        tpl = json.loads(tpl_path.read_text(encoding="utf-8"))
        for r in tpl.get("templates", []):
            hay = norm(
                r.get("id", "")
                + " "
                + r.get("title", "")
                + " "
                + r.get("description", "")
                + " "
                + " ".join(r.get("best_for", []))
            )
            score = (80 if norm(r["id"]) == q_norm else 20 if q_norm in hay else 0) + sum(
                5 for w in set(words) if w in hay.split()
            )
            if score > 0:
                results.append(
                    {
                        "score": score,
                        "source": "reels-templates",
                        "id": r["id"],
                        "title": r["title"],
                        "typography_style": r.get("typography_style"),
                        "default_visual_mode": r.get("default_visual_mode"),
                    }
                )

    # If no keyword matched, return top general recipes
    if not results and cat_path.is_file():
        cat = json.loads(cat_path.read_text(encoding="utf-8"))
        for r in cat.get("recipes", [])[: a.limit]:
            results.append(
                {
                    "score": 1,
                    "source": "reels-opus-craft (fallback)",
                    "id": r["id"],
                    "title": r["title"],
                    "procedural_mode": r.get("procedural_mode"),
                    "grammar": r.get("grammar"),
                }
            )

    results.sort(key=lambda x: (-x["score"], x["id"]))
    print(
        json.dumps(
            {
                "ok": True,
                "query": a.query,
                "count": len(results[: a.limit]),
                "results": results[: a.limit],
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
