#!/usr/bin/env python3
"""Local Awesome Opus 5.5 Gallery CLI — list, inspect prompt, export Remotion scene spec, or serve HTML gallery."""
import argparse
import http.server
import json
import socketserver
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description="Manage local Awesome Opus 5.5 Gallery")
    p.add_argument("--list", action="store_true", help="List all bundled Opus 5.5 recipes")
    p.add_argument("--get", help="Get full details and prompt for a recipe ID")
    p.add_argument("--serve", type=int, metavar="PORT", help="Serve offline HTML gallery on localhost:PORT")
    a = p.parse_args()

    opus_dir = Path(__file__).resolve().parent.parent
    cat = json.loads((opus_dir / "catalog.json").read_text(encoding="utf-8"))
    recipes = cat.get("recipes", [])

    if a.get:
        matches = [r for r in recipes if r["id"] == a.get]
        if not matches:
            print(json.dumps({"ok": False, "error": f"Recipe not found: {a.get}"}))
            return
        print(json.dumps({"ok": True, "recipe": matches[0]}, indent=2, ensure_ascii=False))
        return

    if a.serve:
        gallery_dir = opus_dir / "gallery"
        handler = lambda *args, **kwargs: http.server.SimpleHTTPRequestHandler(*args, directory=str(gallery_dir), **kwargs)
        with socketserver.TCPServer(("127.0.0.1", a.serve), handler) as httpd:
            print(f"Serving Local Opus 5.5 Gallery at http://127.0.0.1:{a.serve}/index.html")
            httpd.serve_forever()
        return

    summary = [
        {
            "id": r["id"],
            "title": r["title"],
            "creator": r["creator"],
            "category": r["category"],
            "procedural_mode": r["procedural_mode"],
        }
        for r in recipes
    ]
    print(json.dumps({"ok": True, "total": len(summary), "recipes": summary}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
