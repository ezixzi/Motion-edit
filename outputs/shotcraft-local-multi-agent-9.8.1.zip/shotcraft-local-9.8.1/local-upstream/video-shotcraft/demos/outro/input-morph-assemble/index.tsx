// Demo reference for input-morph-assemble
export const shotId = 'input-morph-assemble';
