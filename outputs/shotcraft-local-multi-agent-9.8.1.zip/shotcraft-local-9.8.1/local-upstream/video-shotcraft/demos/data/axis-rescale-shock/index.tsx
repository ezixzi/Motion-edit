// Demo reference for axis-rescale-shock
export const shotId = 'axis-rescale-shock';
