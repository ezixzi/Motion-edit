// Demo reference for basic-3d-scene
export const shotId = 'basic-3d-scene';
