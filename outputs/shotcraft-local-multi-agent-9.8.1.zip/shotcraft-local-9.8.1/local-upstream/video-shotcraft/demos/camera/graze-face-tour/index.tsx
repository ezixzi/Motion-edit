// Demo reference for graze-face-tour
export const shotId = 'graze-face-tour';
