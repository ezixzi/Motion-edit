// Demo reference for exploded-view
export const shotId = 'exploded-view';
