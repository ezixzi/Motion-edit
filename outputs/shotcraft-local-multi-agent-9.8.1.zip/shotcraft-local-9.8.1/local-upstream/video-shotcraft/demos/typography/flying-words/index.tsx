// Demo reference for flying-words
export const shotId = 'flying-words';
