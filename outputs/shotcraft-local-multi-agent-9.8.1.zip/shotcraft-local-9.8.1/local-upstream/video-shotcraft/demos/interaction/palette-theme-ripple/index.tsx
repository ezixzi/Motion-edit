// Demo reference for palette-theme-ripple
export const shotId = 'palette-theme-ripple';
