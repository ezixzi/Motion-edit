// Demo reference for pill-chip-slot-cycle-handled
export const shotId = 'pill-chip-slot-cycle-handled';
