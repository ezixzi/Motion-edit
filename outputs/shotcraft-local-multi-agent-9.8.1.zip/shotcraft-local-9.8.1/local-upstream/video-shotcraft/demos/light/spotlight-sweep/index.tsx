// Demo reference for spotlight-sweep
export const shotId = 'spotlight-sweep';
