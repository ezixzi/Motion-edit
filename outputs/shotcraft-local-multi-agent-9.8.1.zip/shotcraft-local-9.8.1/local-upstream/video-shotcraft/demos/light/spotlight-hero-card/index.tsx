// Demo reference for spotlight-hero-card
export const shotId = 'spotlight-hero-card';
