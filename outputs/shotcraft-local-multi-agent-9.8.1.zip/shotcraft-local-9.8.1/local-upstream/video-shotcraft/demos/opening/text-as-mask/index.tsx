// Demo reference for text-as-mask
export const shotId = 'text-as-mask';
