// Demo reference for paparazzi-flash
export const shotId = 'paparazzi-flash';
