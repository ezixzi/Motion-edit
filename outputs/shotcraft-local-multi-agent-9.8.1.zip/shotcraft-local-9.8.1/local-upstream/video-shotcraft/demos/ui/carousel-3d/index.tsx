// Demo reference for carousel-3d
export const shotId = 'carousel-3d';
