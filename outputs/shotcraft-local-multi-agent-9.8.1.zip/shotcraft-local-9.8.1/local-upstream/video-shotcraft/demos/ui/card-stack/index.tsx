// Demo reference for card-stack
export const shotId = 'card-stack';
