---
name: video-shotcraft
description: Local bundled video-shotcraft v9.6.0 core repository with Remotion 4.x template, 16-category procedural SFX/BGM library, 150+ shot catalog, 3D Blinn-Phong & depth parallax stages, and multi-stage QA workflow.
---

# Video Shotcraft — Bundled Local Core (v9.6.0)

This directory contains the self-contained local upstream seed of `video-shotcraft` required by the Shotcraft Pro v9.6.0 suite. It enables 100% offline workspace scaffolding, Remotion 4.x composition generation, 16-category audio design, and deterministic visual/technical QA without external git clones or network calls.

## Directory Layout

- `template/` — Canonical Remotion 4.x TypeScript project template (`package.json`, `tsconfig.json`, `src/Root.tsx`, `src/MainReel.tsx`).
- `gallery/api/library.json` — Curated shot & motion metadata catalog for fast local discovery via `shotcraft-local/scripts/discover.py` and `find_motion.py`.
- `assets/audio/sfx/` — 32 studio-grade WAV sound effects across 16 semantic categories (`transition`, `impact`, `riser`, `camera`, `ui`, `text`, `paper`, `film`, `light`, `data`, `scifi`, `mech`, `glass`, `fluid`, `crowd`, `counter`).
- `assets/audio/bgm/` — 7 beat-synced plucked explainer & lo-fi BGM loops (`explainer-groove-104bpm.wav`, `warm-editorial-96bpm.wav`, `lofi-study-chill-84bpm.wav`, `ambient-dreamscape-72bpm.wav`, `kinetic-120bpm.wav`, `cyber-pulse-128bpm.wav`, `suspense-tech-110bpm.wav`).
- `references/` — Core production guidelines:
  - `references/pipeline.md` — End-to-end 7-stage production, rendering, and verification pipeline.
  - `references/aesthetic-rules.md` — Typography hierarchy, WCAG contrast, safe-zone geometry, and color palette rules.
  - `references/sound-design.md` — Multi-band sidechain ducking, LUFS targets, and frame-accurate foley sync.
  - `references/final-review.md` — Pre-delivery visual, safe-zone, and technical QA checklist.

## Integration with Shotcraft Pro v9.6.0 Skills

1. **Workspace Scaffolding (`reels-templates/scripts/scaffold_project.py`)**:
   Copies `template/package.json`, injects all 10 reusable TSX stage components (`EditorialCutawayStage.tsx`, `ReferenceShowreelStage.tsx`, `KineticTypographyStage.tsx`, `DepthParallaxStage.tsx`, `CutawayRigStage.tsx`, `OpusProceduralStage.tsx`, `SmartFootageStage.tsx`, `SoundtrackStage.tsx`, `TransitionBridge.tsx`, `ReelsSafeZoneGuide.tsx`), and links local audio assets into `public/audio/`.
2. **Smart Rendering (`reels-templates/scripts/smart_render.py`)**:
   Renders 30fps True 3D Blinn-Phong volumetric scenes and semantic animated captions across 5 aspect ratios (`9:16`, `16:9`, `1:1`, `4:5`, `2:3`), streaming directly into `ffmpeg` H.264 `yuv420p` or delegating to Remotion CLI when `node_modules/@remotion/cli` is installed.
3. **Zero-Token-Waste One-Shot Producer (`reels-production/scripts/one_shot_produce.py`)**:
   Executes semantic content analysis, script-to-visual storyboard generation, A/B retention scoring, SSML Indonesian TTS synthesis, 3-band BGM sidechain mixing, MP4 encoding, and technical/safe-zone QA in a single deterministic run.
