export const mulberry32 = (seed: number) => () => ((seed = (seed + 0x6D2B79F5) | 0), ((seed ^ (seed >>> 15)) >>> 0) / 4294967296);
