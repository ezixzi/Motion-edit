# Shotcraft Pro v9.6.0 — End-to-End Video Production Pipeline

This document defines the canonical 7-stage production pipeline validated by `install.py` and executed by `reels-production/scripts/one_shot_produce.py` and the `shotcraft-director` MCP server.

---

## Stage 1: Semantic Content Analysis & Script-to-Visual Storyboarding
- **Entry Point**: `reels-production/scripts/one_shot_produce.py` (`analyze_content_semantically`, `generate_scenes_from_script`).
- **Process**:
  1. Classifies the input Indonesian prompt or script into content archetypes (`tutorial`, `data`, `story`, `opinion`, `science-explainer`, `culinary`, `mechanical`).
  2. Selects the optimal visual world (`cream-editorial`, `coffee-editorial`, `charcoal-terminal`, `cosmic-glass`, `tape-mascot`, `dark-science`), evidence card layout (`bars`, `quote`, `checklist`), caption style (`karaoke-pill`, `typewriter`, `slide-up`, `glitch`, `handwritten`, `neon`, `minimal`), emotional tone, and BGM/SFX pack.
  3. If `--ab-variants N` is enabled, generates candidate storyboards, scores each by predicted viewer retention (hook strength in first 3s, visual pacing every 2–4s, caption readability, and visual variety), and selects the highest-scoring variant.

## Stage 2: Conversational Indonesian Narration & Acoustic Word Alignment
- **Entry Point**: `reels-narration/scripts/narrate.py`.
- **Process**:
  1. Parses SSML & prosody tags (`<emphasis level="strong">`, `<break time="300ms"/>`, `<prosody>`, `<emotion type="excited|urgent|warm|skeptical">`, `[breath]`).
  2. Normalizes Indonesian numbers (`terbilang_id`), currency (`Rp`), units (`°C`, `km/jam`), colloquial Jakartan slang (`gue`→`saya`, `gak`→`tidak`, `udah`→`sudah`), and context-dependent acronyms (`KPI`→`ka pe i` vs `kopi`).
  3. Applies the unified Voice Profile (`--voice-profile`, matching $F_0$ pitch, formant warp, and EQ warmth across all TTS providers) and multi-speaker dialogue voices (`narrator`, `expert`, `user`, `host`, `guest`).
  4. Computes sub-word acoustic RMS energy envelopes (`build_acoustic_word_timings`) and exports `narration.wav`, `timing-report.json`, `remotion-subtitles.json`, `subtitles.srt`, and `subtitles.vtt`.

## Stage 3: Isolated Workspace Scaffolding, Brand Kit & Versioning
- **Entry Point**: `reels-templates/scripts/scaffold_project.py`.
- **Process**:
  1. Automatically snapshots any existing project files (`timeline.json`, `brand_kit.json`, `src/MainReel.tsx`) into `.shotcraft-versions/` before modification (`--list-versions`, `--rollback`).
  2. Injects all 10 Remotion TSX components into `src/components/` and copies the 16-category SFX & BGM WAV assets into `public/audio/`.
  3. Applies `brand_kit.json` (custom brand colors, typography family, watermark placement) and configures target aspect ratio (`9:16`, `16:9`, `1:1`, `4:5`, `2:3`).

## Stage 4: Automatic Visual-to-Audio Pacing & Instant Styleframe Preview
- **Entry Point**: `reels-templates/scripts/smart_render.py` (`auto_fit_visuals_to_audio`, `--preview-frame N`).
- **Process**:
  1. Synchronizes each scene's `durationInFrames` and transition boundaries to the actual synthesized TTS speech duration from `timing-report.json`.
  2. Renders styleframe stills (`--stills` or `--preview-frame N` in `<0.4s`) to verify 3-zone vertical composition, 3D cutaway callout placement, and caption collision avoidance.

## Stage 5: True 3D Volumetric & Semantic Caption Rendering
- **Entry Point**: `reels-templates/scripts/smart_render.py` & `reels-depth-motion/scripts/depth_engine.py`.
- **Process**:
  1. Renders 30fps Blinn-Phong 3D volumetric objects (orbiting 3D neuron networks, animated piston engine cutaways, 3D ceramic coffee extraction stages, and depth-mapped parallax layers with real-time normal lighting and depth-occluded 3D text).
  2. Renders phrase-grouped semantic subtitles (`group_words_semantically`) with per-word `scale-bounce` emphasis, inline vector emoji icons (`🎯`, `💡`, `🔥`, `📊`, `⚡`, `✅`), speaker badges, and automatic 3D collision shifting.

## Stage 6: Procedural Event SFX & 3-Band Smart Sidechain Audio Mastering
- **Entry Point**: `reels-sfx-studio/scripts/sfx_engine.py`.
- **Process**:
  1. Synthesizes procedural event SFX (`scale-bounce`, `glitch-burst`, `typewriter-key`, `orbit-whoosh`) aligned to the BGM 16th-note musical grid and word emphasis timestamps.
  2. Applies 3-band frequency-selective dynamic sidechain ducking (carving 180–4200 Hz during speech with 25ms attack / 240ms release while preserving sub-bass groove < 180 Hz) and soft-limits peaks to `-0.7 dBFS`.

## Stage 7: Multi-Layer Technical, Safe-Zone & Retention QA
- **Entry Points**: `reels-qa/scripts/check_video.py`, `reels-safezone/scripts/safezone_audit.py`, and `qa/telemetry.json`.
- **Process**:
  1. Verifies container duration, exact decoded frame count, H.264 `yuv420p` stream compliance, zero audio clipping, and zero black/dead-air frames.
  2. Exports `qa/safezone_overlay_proof.png` verifying all primary UI and captions sit inside the Reels/TikTok safe zone (`x: 84..876, y: 220..1490`).
  3. Writes `qa/telemetry.json` with per-scene render latency, TTS provider telemetry, bitrate, and predicted viewer retention score.
