# exploded-view

Category: camera

3D tilted view where component layers separate in Z-depth with callout labels.
