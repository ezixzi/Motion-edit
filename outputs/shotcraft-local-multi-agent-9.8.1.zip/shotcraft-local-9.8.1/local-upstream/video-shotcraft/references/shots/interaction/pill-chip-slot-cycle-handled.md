# pill-chip-slot-cycle-handled

Category: interaction

Interactive pill chips cycling states with tactile click timing.
