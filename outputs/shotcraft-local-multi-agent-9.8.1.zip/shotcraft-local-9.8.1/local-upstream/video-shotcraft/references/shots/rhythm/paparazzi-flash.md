# paparazzi-flash

Category: rhythm

Three rhythmic shutter flashes cutting between detail crops before a big number.
