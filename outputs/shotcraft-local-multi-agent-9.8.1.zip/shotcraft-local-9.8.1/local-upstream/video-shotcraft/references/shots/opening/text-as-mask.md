# text-as-mask

Category: opening

Giant headline letters reveal the product or visual scene inside the glyph silhouette.
