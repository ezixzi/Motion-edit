# flying-words

Category: typography

High-energy kinetic typography words flying into a locked assertion.
