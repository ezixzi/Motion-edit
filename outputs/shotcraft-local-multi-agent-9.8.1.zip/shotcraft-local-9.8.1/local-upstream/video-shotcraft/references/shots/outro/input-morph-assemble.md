# input-morph-assemble

Category: outro

Interactive input bar or pill morphing into the final brand CTA.
