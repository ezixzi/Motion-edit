# axis-rescale-shock

Category: data

Metric counter and chart spike that dynamically rescales the axis.
