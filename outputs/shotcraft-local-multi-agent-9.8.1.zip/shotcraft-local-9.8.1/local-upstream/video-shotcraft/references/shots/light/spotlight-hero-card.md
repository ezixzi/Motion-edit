# spotlight-hero-card

Category: light

Hero card illuminated with rim lighting and subtle elevation.
