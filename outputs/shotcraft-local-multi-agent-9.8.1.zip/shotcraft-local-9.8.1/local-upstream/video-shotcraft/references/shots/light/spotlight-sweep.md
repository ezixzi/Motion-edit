# spotlight-sweep

Category: light

Focused stage spotlight sweeping across the hero card and title.
