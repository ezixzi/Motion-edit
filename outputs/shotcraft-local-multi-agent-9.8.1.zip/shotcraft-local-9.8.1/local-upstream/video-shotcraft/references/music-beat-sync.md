# Music Beat Sync
- Default 120 BPM (0.5s per beat, 2.0s per bar).
- Lock major cuts to downbeats.
