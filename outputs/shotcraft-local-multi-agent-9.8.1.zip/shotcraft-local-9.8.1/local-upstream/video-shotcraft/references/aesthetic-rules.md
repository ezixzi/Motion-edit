# Aesthetic Rules
- One focal idea per shot.
- Strict 3-Zone layout on 9:16 Reels: Top Header (220..380px), Center Visual Stage (400..1140px), Bottom Fact Card (1160..1620px).
- Never overlap duplicate ghost numbers.
- Hold every caption at opacity=1 until sequence end (zero black dead-air frames).
