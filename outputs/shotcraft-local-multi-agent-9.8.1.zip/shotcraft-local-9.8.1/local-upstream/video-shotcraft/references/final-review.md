# Independent Final Review Checklist
- Check resolution, frame count, strict decode, audio peak/LUFS, and zero black dead-air frames (`shotcraft_audit_video`).
