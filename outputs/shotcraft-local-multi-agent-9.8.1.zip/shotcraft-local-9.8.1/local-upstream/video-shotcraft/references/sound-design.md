# Sound Design Rules
- 16 SFX categories under `assets/audio/sfx/`.
- Align transitions, text pops, and metric landings within <=2 frames.
- Duck BGM by -10dB during active speech.
