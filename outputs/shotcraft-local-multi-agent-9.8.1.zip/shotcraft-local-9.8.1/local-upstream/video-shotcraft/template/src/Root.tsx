import React from 'react';
import {Composition} from 'remotion';
import {MainReel} from './MainReel';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="MainReel"
      component={MainReel}
      durationInFrames={450}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
