# Themes: Dark Science (#070B14), Ink Press (#F7F3EA), Cyber Blue (#050816)
