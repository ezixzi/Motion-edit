import assert from 'node:assert/strict';
import {
  springState,
  targetSequence,
  coverRadius,
  subframeTimes,
  beatMap,
  integratedSpeed,
  bezierEasing,
  parallaxLayerTransform,
  dollyZoomProjection,
  matchCutRect,
  karaokeActiveWord,
} from './motion-math.mjs';

const near = (a, b, e = 1e-7) => assert.ok(Math.abs(a - b) < e, `${a} != ${b}`);

for (const damping of [0.8, 1, 1.3]) {
  const cfg = {from: 14, to: 90, velocity: 25, frequency: 12, damping};
  assert.deepEqual(springState(0, cfg), {position: 14, velocity: 25});
  near(springState(5, cfg).position, 90, 1e-6);
  const t = 0.2,
    h = 1e-6;
  near(
    (springState(t + h, cfg).position - springState(t - h, cfg).position) / (2 * h),
    springState(t, cfg).velocity,
    1e-4
  );
}

const changes = [
  {time: 0, target: 1},
  {time: 0.25, target: 3},
  {time: 0.6, target: -1},
];
const first = targetSequence(0.4, 0, changes);
targetSequence(4, 0, changes);
assert.deepEqual(targetSequence(0.4, 0, changes), first);
near(targetSequence(0.25 - 1e-8, 0, changes).position, targetSequence(0.25 + 1e-8, 0, changes).position, 1e-6);
assert.throws(() => targetSequence(1, 0, [{time: 1, target: 1}, {time: 0, target: 2}]));

const ts = subframeTimes(60, 60, 3, 0.5);
near(ts[0], 1 - 1 / 240);
near(ts[1], 1);
near(ts[2], 1 + 1 / 240);
assert.equal(subframeTimes(0, 60, 3, 0.5)[0], 0);
assert.ok(subframeTimes(0, 60, 3, 0.5, {duration: 2, loop: true})[0] > 1.9);

near(coverRadius(1080, 1920, 540, 960), Math.hypot(540, 960));

const b = beatMap({duration: 15});
assert.equal(b.events.length, 30);
assert.equal(b.bars, 7.5);
assert.equal(b.events[4].downbeat, true);
assert.equal(beatMap({duration: 20}).bars, 10);
assert.equal(beatMap({duration: 14}).events.length, 28);

const knots = [
  {time: 0, speed: 0},
  {time: 1, speed: 2},
  {time: 3, speed: 2},
];
near(integratedSpeed(0.5, knots), 0.25);
near(integratedSpeed(2, knots), 3);
near(integratedSpeed(4, knots), 7);

// v4.0 tests
near(bezierEasing(0.25, 0.25, 0.75, 0.75, 0.5), 0.5, 1e-5);
assert.equal(bezierEasing(0.42, 0, 0.58, 1, 0), 0);
assert.equal(bezierEasing(0.42, 0, 0.58, 1, 1), 1);

const pl = parallaxLayerTransform(0.9, {camX: 20, camY: -10, zoom: 1.05, focalDepth: 0.5, focusDepth: 0.9, maxBlurPx: 10});
near(pl.translateX, -8, 1e-6);
near(pl.translateY, 4, 1e-6);
near(pl.blurPx, 0, 1e-6);

const dz = dollyZoomProjection(0.5, {fovStartDeg: 30, fovEndDeg: 60, baseWidth: 1080});
assert.equal(dz.fovDeg, 45);
assert.ok(dz.backgroundScale < 1 && dz.backgroundScale > 0.4);

const mc = matchCutRect(
  {x: 100, y: 200, width: 300, height: 100, radius: 24},
  {x: 0, y: 0, width: 1080, height: 1920, radius: 0},
  3.0
);
near(mc.width, 1080, 1e-2);
near(mc.height, 1920, 1e-2);

const kw = karaokeActiveWord(1.2, [
  {word: 'Cara', start: 0.2, end: 0.8},
  {word: 'kerja', start: 0.8, end: 1.5},
  {word: 'mesin', start: 1.5, end: 2.2},
]);
assert.equal(kw.activeIndex, 1);
assert.equal(kw.activeWord, 'kerja');

console.log(
  'PASS: spring boundaries/velocity, random-access targets, shutter groups, aperture, beats, speed integral, bezier, 3D parallax, dolly-zoom, match-cut rect, and karaoke word sync'
);
