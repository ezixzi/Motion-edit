// Deterministic state-free motion, camera, easing, match-cut, and karaoke math helpers (v4.0).
const finite = (...v) => {
  if (!v.every(Number.isFinite)) throw new Error('Finite numeric arguments required');
};

export const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

export function springState(t, {from = 0, to = 1, velocity = 0, frequency = 12, damping = 1} = {}) {
  finite(t, from, to, velocity, frequency, damping);
  if (frequency <= 0 || damping <= 0) throw new Error('Positive frequency/damping required');
  if (t <= 0) return {position: from, velocity};
  const w = frequency,
    z = damping,
    d = from - to;
  if (Math.abs(z - 1) < 1e-7) {
    const b = velocity + w * d,
      e = Math.exp(-w * t);
    return {position: to + e * (d + b * t), velocity: e * (b - w * (d + b * t))};
  }
  if (z < 1) {
    const wd = w * Math.sqrt(1 - z * z),
      a = z * w,
      b = (velocity + a * d) / wd,
      e = Math.exp(-a * t),
      c = Math.cos(wd * t),
      s = Math.sin(wd * t);
    return {
      position: to + e * (d * c + b * s),
      velocity: e * ((-a * d + b * wd) * c + (-a * b - d * wd) * s),
    };
  }
  const q = Math.sqrt(z * z - 1),
    r1 = -w / (z + q),
    r2 = -w * (z + q),
    a = (velocity - r2 * d) / (r1 - r2),
    b = d - a;
  return {
    position: to + a * Math.exp(r1 * t) + b * Math.exp(r2 * t),
    velocity: a * r1 * Math.exp(r1 * t) + b * r2 * Math.exp(r2 * t),
  };
}

export function targetSequence(t, initial, changes, config = {}) {
  finite(t, initial);
  let lastTime = -Infinity,
    lastTarget = initial,
    position = initial,
    velocity = 0;
  for (const event of changes) {
    finite(event.time, event.target);
    if (event.time < lastTime) throw new Error('Changes must be ordered');
    const delta = event.target - lastTarget;
    if (t >= event.time) {
      const s = springState(t - event.time, {...config, from: 0, to: delta, velocity: 0});
      position += s.position;
      velocity += s.velocity;
    }
    lastTime = event.time;
    lastTarget = event.target;
  }
  return {position, velocity};
}

export function coverRadius(width, height, cx, cy) {
  finite(width, height, cx, cy);
  if (width <= 0 || height <= 0) throw new Error('Positive dimensions required');
  return Math.max(
    ...[[0, 0], [width, 0], [0, height], [width, height]].map(([x, y]) => Math.hypot(x - cx, y - cy))
  );
}

export function subframeTimes(frame, fps, samples = 3, shutter = 0.5, {duration, loop = false} = {}) {
  finite(frame, fps, samples, shutter);
  if (
    !Number.isInteger(frame) ||
    frame < 0 ||
    fps <= 0 ||
    !Number.isInteger(samples) ||
    samples < 1 ||
    shutter < 0 ||
    shutter > 1
  )
    throw new Error('Invalid sampling parameters');
  if (duration !== undefined && (!Number.isFinite(duration) || duration <= 0))
    throw new Error('Invalid duration');
  if (loop && duration === undefined) throw new Error('Loops require duration');
  return Array.from({length: samples}, (_, i) => {
    let t = frame / fps + (samples === 1 ? 0 : (i / (samples - 1) - 0.5) * shutter / fps);
    if (loop) t = ((t % duration) + duration) % duration;
    else t = Math.max(0, duration === undefined ? t : Math.min(duration, t));
    return t;
  });
}

export function beatMap({bpm = 120, beatsPerBar = 4, duration, fps = 60, offset = 0}) {
  finite(bpm, beatsPerBar, duration, fps, offset);
  if (bpm <= 0 || !Number.isInteger(beatsPerBar) || beatsPerBar < 1 || duration <= 0 || fps <= 0)
    throw new Error('Invalid beat map');
  const step = 60 / bpm,
    events = [];
  const first = Math.ceil(-offset / step);
  for (let i = first; offset + i * step < duration - 1e-10; i++) {
    const time = offset + i * step;
    events.push({
      beat: i,
      time,
      frame: Math.round(time * fps),
      downbeat: ((i % beatsPerBar) + beatsPerBar) % beatsPerBar === 0,
    });
  }
  return {
    beatSeconds: step,
    barSeconds: step * beatsPerBar,
    bars: duration / (step * beatsPerBar),
    events,
  };
}

export function integratedSpeed(t, knots) {
  finite(t);
  if (knots.length < 2) throw new Error('At least two speed knots required');
  for (let i = 0; i < knots.length; i++) {
    finite(knots[i].time, knots[i].speed);
    if (i && knots[i].time <= knots[i - 1].time)
      throw new Error('Strictly increasing knot times required');
  }
  if (t <= knots[0].time) return 0;
  let distance = 0;
  for (let i = 1; i < knots.length; i++) {
    const a = knots[i - 1],
      b = knots[i],
      dt = Math.min(t, b.time) - a.time;
    if (dt > 0) distance += a.speed * dt + 0.5 * ((b.speed - a.speed) / (b.time - a.time)) * dt * dt;
    if (t <= b.time) return distance;
  }
  const end = knots.at(-1);
  return distance + (t - end.time) * end.speed;
}

// --- New in v4.0: Cubic Bezier Easing, 3D Parallax Math, Match-Cut Rect & Karaoke Sync ---

export function bezierEasing(x1, y1, x2, y2, t) {
  finite(x1, y1, x2, y2, t);
  if (x1 < 0 || x1 > 1 || x2 < 0 || x2 > 1) throw new Error('Bezier control X must be in [0, 1]');
  const x = clamp(t, 0, 1);
  if (x === 0 || x === 1) return x;
  const sampleX = (u) => 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
  const sampleDX = (u) =>
    3 * (1 - u) * (1 - u) * x1 + 6 * (1 - u) * u * (x2 - x1) + 3 * u * u * (1 - x2);
  const sampleY = (u) => 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
  let u = x;
  for (let i = 0; i < 8; i++) {
    const dx = sampleDX(u);
    if (Math.abs(dx) < 1e-6) break;
    u = clamp(u - (sampleX(u) - x) / dx, 0, 1);
  }
  return sampleY(u);
}

export function parallaxLayerTransform(
  depth01,
  {camX = 0, camY = 0, zoom = 1.06, focalDepth = 0.5, focusDepth = 0.75, maxBlurPx = 8} = {}
) {
  finite(depth01, camX, camY, zoom, focalDepth, focusDepth, maxBlurPx);
  const d = clamp(depth01, 0, 1);
  const rel = d - focalDepth;
  return {
    translateX: -camX * rel,
    translateY: -camY * rel,
    scale: zoom + rel * 0.04,
    blurPx: Math.max(0, Math.abs(d - focusDepth) * maxBlurPx),
  };
}

export function dollyZoomProjection(progress, {fovStartDeg = 35, fovEndDeg = 65, baseWidth = 1000} = {}) {
  finite(progress, fovStartDeg, fovEndDeg, baseWidth);
  if (fovStartDeg <= 1 || fovStartDeg >= 170 || fovEndDeg <= 1 || fovEndDeg >= 170)
    throw new Error('FOV must be in (1, 170) degrees');
  const p = clamp(progress, 0, 1);
  const fovDeg = fovStartDeg + (fovEndDeg - fovStartDeg) * p;
  const tanStart = Math.tan((fovStartDeg * Math.PI) / 360);
  const tanCur = Math.tan((fovDeg * Math.PI) / 360);
  const cameraDistance = baseWidth / (2 * tanCur);
  const backgroundScale = tanStart / tanCur;
  return {fovDeg, cameraDistance, backgroundScale};
}

export function matchCutRect(fromRect, toRect, t, springCfg = {frequency: 12, damping: 0.95}) {
  finite(fromRect.x, fromRect.y, fromRect.width, fromRect.height);
  finite(toRect.x, toRect.y, toRect.width, toRect.height, t);
  const s = springState(t, {...springCfg, from: 0, to: 1}).position;
  return {
    x: fromRect.x + (toRect.x - fromRect.x) * s,
    y: fromRect.y + (toRect.y - fromRect.y) * s,
    width: fromRect.width + (toRect.width - fromRect.width) * s,
    height: fromRect.height + (toRect.height - fromRect.height) * s,
    radius: (fromRect.radius ?? 0) + ((toRect.radius ?? 0) - (fromRect.radius ?? 0)) * s,
    progress: s,
  };
}

export function karaokeActiveWord(t, words) {
  finite(t);
  if (!Array.isArray(words) || words.length === 0) return {activeIndex: -1, activeWord: null, progress: 0};
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    finite(w.start, w.end);
    if (t >= w.start && t <= w.end) {
      const p = w.end > w.start ? (t - w.start) / (w.end - w.start) : 1;
      return {activeIndex: i, activeWord: w.word, progress: clamp(p, 0, 1)};
    }
  }
  if (t > words.at(-1).end) {
    return {activeIndex: words.length - 1, activeWord: words.at(-1).word, progress: 1};
  }
  return {activeIndex: -1, activeWord: null, progress: 0};
}


// [P2-1]: Beat-Synced & Narration-Envelope Visual Pulse Helpers
export function audioEnvelopePulse(frame, frameRmsArray = [], baseScale = 1.0, intensity = 0.28) {
  if (!Array.isArray(frameRmsArray) || frameRmsArray.length === 0) {
    return baseScale;
  }
  const idx = Math.max(0, Math.min(frameRmsArray.length - 1, Math.floor(frame)));
  const rms = Number(frameRmsArray[idx]) || 0;
  return Number((baseScale + rms * intensity).toFixed(4));
}

export function detectAudioTransients(frameRmsArray = [], diffThreshold = 0.22, minRms = 0.32, minGapFrames = 10) {
  const transients = [];
  let lastFrame = -minGapFrames;
  for (let i = 1; i < frameRmsArray.length; i++) {
    const diff = (Number(frameRmsArray[i]) || 0) - (Number(frameRmsArray[i - 1]) || 0);
    if (diff >= diffThreshold && frameRmsArray[i] >= minRms && i - lastFrame >= minGapFrames) {
      transients.push(i);
      lastFrame = i;
    }
  }
  return transients;
}
