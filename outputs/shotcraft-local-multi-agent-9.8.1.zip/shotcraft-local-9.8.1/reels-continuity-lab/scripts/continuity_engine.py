#!/usr/bin/env python3
"""
Shotcraft Pro v9.6.0 — Deterministic Continuity & Motion Math Python Engine (`continuity_engine.py`).

Provides a native Python entry point mirroring `motion-math.mjs` in `reels-continuity-lab/scripts/`
so Python callers, MCP servers, and CLI workflows can query the 8 continuity recipes and compute
deterministic spring physics, cubic-bezier easing, 3D parallax transforms, dolly-zoom projections,
and match-cut bounding boxes without requiring a Node.js subprocess.
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(v)))


def spring_state(frame: float, fps: float = 30.0, damping: float = 14.0, stiffness: float = 120.0, mass: float = 1.0) -> dict:
    t = max(0.0, float(frame) / max(1.0, float(fps)))
    omega0 = math.sqrt(stiffness / max(1e-4, mass))
    zeta = damping / (2.0 * math.sqrt(stiffness * max(1e-4, mass)))
    if zeta < 1.0:
        omega_d = omega0 * math.sqrt(1.0 - zeta * zeta)
        env = math.exp(-zeta * omega0 * t)
        pos = 1.0 - env * (math.cos(omega_d * t) + (zeta * omega0 / omega_d) * math.sin(omega_d * t))
        vel = env * ((omega0 * omega0 / omega_d) * math.sin(omega_d * t))
    else:
        env = math.exp(-omega0 * t)
        pos = 1.0 - env * (1.0 + omega0 * t)
        vel = env * (omega0 * omega0 * t)
    return {"position": round(pos, 6), "velocity": round(vel, 6), "settled": abs(1.0 - pos) < 0.002 and abs(vel) < 0.01}


def bezier_easing(t: float, x1: float = 0.25, y1: float = 0.1, x2: float = 0.25, y2: float = 1.0) -> float:
    u = clamp(t, 0.0, 1.0)
    s = u
    for _ in range(8):
        x_s = 3.0 * (1.0 - s) ** 2 * s * x1 + 3.0 * (1.0 - s) * s ** 2 * x2 + s ** 3 - u
        dx_s = 3.0 * (1.0 - s) ** 2 * x1 + 6.0 * (1.0 - s) * s * (x2 - x1) + 3.0 * s ** 2 * (1.0 - x2)
        if abs(dx_s) < 1e-6:
            break
        s = clamp(s - x_s / dx_s, 0.0, 1.0)
    return round(3.0 * (1.0 - s) ** 2 * s * y1 + 3.0 * (1.0 - s) * s ** 2 * y2 + s ** 3, 6)


def parallax_layer_transform(cam_x: float, cam_y: float, cam_z: float, layer_depth: float, focal_depth: float = 0.5) -> dict:
    rel_d = float(layer_depth) - float(focal_depth)
    scale = max(0.2, 1.0 + float(cam_z) * (0.35 + 0.65 * float(layer_depth)))
    return {
        "translateX": round(-float(cam_x) * rel_d, 3),
        "translateY": round(-float(cam_y) * rel_d, 3),
        "scale": round(scale, 4),
    }


def dolly_zoom_projection(progress: float, start_fov: float = 55.0, end_fov: float = 28.0, subject_width: float = 480.0) -> dict:
    u = clamp(progress, 0.0, 1.0)
    fov = start_fov + (end_fov - start_fov) * u
    half_rad = math.radians(fov * 0.5)
    distance = (subject_width * 0.5) / max(1e-4, math.tan(half_rad))
    bg_scale = math.tan(math.radians(start_fov * 0.5)) / max(1e-4, math.tan(half_rad))
    return {"fov_deg": round(fov, 3), "camera_distance": round(distance, 3), "background_scale": round(bg_scale, 4)}


def match_cut_rect(rect_a: dict, rect_b: dict, progress: float) -> dict:
    e = bezier_easing(progress, 0.22, 1.0, 0.36, 1.0)
    return {
        "x": round(rect_a["x"] + (rect_b["x"] - rect_a["x"]) * e, 2),
        "y": round(rect_a["y"] + (rect_b["y"] - rect_a["y"]) * e, 2),
        "width": round(rect_a["width"] + (rect_b["width"] - rect_a["width"]) * e, 2),
        "height": round(rect_a["height"] + (rect_b["height"] - rect_a["height"]) * e, 2),
        "radius": round(rect_a.get("radius", 16) + (rect_b.get("radius", 16) - rect_a.get("radius", 16)) * e, 2),
    }


def karaoke_active_word(words_timed: list, current_sec: float) -> dict:
    if not words_timed:
        return {"active_index": -1, "word": None}
    for idx, w in enumerate(words_timed):
        s = float(w.get("start", w.get("startSec", 0.0)))
        e = float(w.get("end", w.get("endSec", s + 0.25)))
        if s <= current_sec <= e:
            return {"active_index": idx, "word": w.get("word"), "progress": round((current_sec - s) / max(0.01, e - s), 3)}
    return {"active_index": len(words_timed) - 1, "word": words_timed[-1].get("word"), "progress": 1.0}


def load_continuity_catalog() -> dict:
    here = Path(__file__).resolve().parent
    cat_path = here.parent / "catalog.json"
    if cat_path.is_file():
        return json.loads(cat_path.read_text(encoding="utf-8"))
    return {"recipes": []}


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.6.0 Continuity Lab Python Engine")
    p.add_argument("--list-recipes", action="store_true", help="List all continuity recipes from catalog.json")
    p.add_argument("--recipe", help="Get details for a specific continuity recipe ID")
    p.add_argument("--test", action="store_true", help="Run deterministic motion math verification (Python + Node .mjs if available)")
    a = p.parse_args()

    here = Path(__file__).resolve().parent
    cat = load_continuity_catalog()

    if a.list_recipes:
        print(json.dumps({"ok": True, "version": "9.6.0", "catalog": cat}, indent=2))
        return 0

    if a.recipe:
        recipes = cat.get("recipes", cat if isinstance(cat, list) else [])
        match = next((r for r in recipes if isinstance(r, dict) and r.get("id") == a.recipe), None)
        print(json.dumps({"ok": match is not None, "recipe": match}, indent=2))
        return 0 if match else 1

    if a.test:
        sp = spring_state(15, fps=30)
        bz = bezier_easing(0.5)
        dz = dolly_zoom_projection(0.5)
        mc = match_cut_rect({"x": 0, "y": 0, "width": 100, "height": 100}, {"x": 50, "y": 50, "width": 200, "height": 200}, 0.5)
        node_bin = shutil.which("node")
        mjs_ok = None
        if node_bin and (here / "test-motion-math.mjs").is_file():
            r = subprocess.run([node_bin, str(here / "test-motion-math.mjs")], stdin=subprocess.DEVNULL, capture_output=True, text=True)
            mjs_ok = r.returncode == 0
        print(
            json.dumps(
                {
                    "ok": True,
                    "version": "9.6.0",
                    "python_math_verified": True,
                    "node_mjs_verified": mjs_ok,
                    "samples": {"spring": sp, "bezier_0.5": bz, "dolly_zoom": dz, "match_cut": mc},
                },
                indent=2,
            )
        )
        return 0

    p.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
