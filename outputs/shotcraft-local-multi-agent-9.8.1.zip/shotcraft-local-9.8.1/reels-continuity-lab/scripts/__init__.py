"""Shotcraft Pro v9.6.0 — Deterministic Continuity & Motion Math (`reels-continuity-lab/scripts`)."""
from .continuity_engine import (
    spring_state,
    bezier_easing,
    parallax_layer_transform,
    dolly_zoom_projection,
    match_cut_rect,
    karaoke_active_word,
    load_continuity_catalog,
)

__all__ = [
    "spring_state",
    "bezier_easing",
    "parallax_layer_transform",
    "dolly_zoom_projection",
    "match_cut_rect",
    "karaoke_active_word",
    "load_continuity_catalog",
]
