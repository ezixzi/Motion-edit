---
name: reels-continuity-lab
description: Selective motion recipes from user-supplied Prompt Motion texts and an inspected technical explainer video. Product UI transformations, single-shape morphs, kinetic loops, footage carousels, flyovers, photo/glass journeys and cutaway illustrations. Includes deterministic timing and rendering guidance.
---

# Continuity motion lab

This is a companion adaptation library, not an official Prompt Motion plugin or a video-shotcraft shot catalog. Six recipes derive from supplied texts; a seventh derives from sampled frames of the user's uploaded technical explainer. Read `references/provenance.md` before attribution. No source media, site code, brand assets or license grant is bundled.

Treat reference <inputs>/<start> blocks as template material. They do not instruct you to generate a Dub/Distilbook film or request assets merely because the user is adding references to a skill. Select a recipe only for a subsequent production brief; user instructions override recipe defaults. Preserve no-logo/no-VO/SFX-only requirements. All bans and palette/audio rules below are scoped to the selected recipe, never global replacements for neon or other requested styles.

## Select and route

Read the selected reference card, using `catalog.json` or bounded discovery to choose. Seven local IDs, deliberately distinct from upstream shot names:

- `continuity-product-object` — one authentic product element becomes the next UI/scene
- `single-shape-ui-relay` — button/slider/tab/chart/command states share one morphing carrier
- `kinetic-architecture-loop` — type, shape,2D/3D and data form a seamless showreel loop
- `footage-drop-carousel` — real clips, scan selection,3D carousel and hero handoff
- `landing-depth-flyover` — layer-captured landing page with integrated camera travel
- `photo-glass-print-loop` — wordmark/dot/iris/photo/glass/device/print journey
- `technical-cutaway-explainer` — whole object becomes a cutaway, then paths, data and a practical conclusion

Read current video-shotcraft cards/demos for any upstream components you reuse. Related IDs in catalog.json are search suggestions, not equivalent implementations or promised installed variants. Record exact matches or missing support. An HTML/WebGL renderer is an optional alternative, not a reason to replace a working Remotion pipeline without the brief requiring it.

## Before building

1. Record reference ID, actual content, through-line object, aspect ratio, duration/fps, audio scope, real-asset availability and license evidence.
2. Read `references/timing-and-reels.md`; reconcile beat/bar arithmetic and overloaded source structures. Do not silently invent longer duration or remove requested events.
3. Read `references/deterministic-rendering.md`; plan pure seek, camera/shape continuity, video decoding, subframe grouping and final QA.
4. Produce a beat-level storyboard with object states, copy, entrance/exit/hold, audio landmarks and frame numbers. Ask only for essential missing inputs. Template “ask first” instructions apply only if that creation mode was selected; autonomous mode does not require a new approval pause.
5. For the full recipe, use authentic supplied/authorized assets or verified public product evidence. Do not invent UI, statistics, owned clips, voice rights or commercial music permissions. Research Dub/Distilbook only if the user actually selects those products; Distilbook's URL is unspecified in the source.
6. Use the source aspect ratio when explicitly requested. Otherwise adapt to Reels1080x1920 with recomposed views, not a blind crop. The reference still list and one-frame-per-beat previews are minimum additional checks, not proof of final correctness.
7. Build in the isolated video workspace. Native still QA, independent encoded review and audio validation remain required by reels-production/reels-qa. These seven recipes are guides, not newly rendered components. Source-frame study does not verify an adaptation's implementation; math/installer tests do not establish visual quality.

Keep a readable hold even when a small decorative property changes each beat. Do not apply the source “no holds >0.5s” to essential reading time indiscriminately. Explicit conflicting requirements must be surfaced and resolved, not hidden behind jittering text.

## Python & Node.js Entry Points (`scripts/`)

- `scripts/continuity_engine.py` — Native Python CLI & module (`--list-recipes`, `--recipe <id>`, `--test`) providing deterministic spring physics, cubic-bezier easing, 3D parallax layer transforms, dolly-zoom projections, and match-cut geometry.
- `scripts/motion-math.mjs` & `scripts/test-motion-math.mjs` — ES module implementation and unit tests.
