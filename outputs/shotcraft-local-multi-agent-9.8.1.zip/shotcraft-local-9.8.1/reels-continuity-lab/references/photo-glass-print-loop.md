# Photo Glass to Print Loop

Source: user-uploaded photo/wordmark reference text. Reference54beats at120BPM =27s; square1440×1440. **Inputs:** permitted brand wordmark,9–12cleared high-resphotos, optional licensed song withdrop/breakdown, and a cleared wall-footage clip. No hardcoded site-name license assumptions.

**Continuous2Dgrammar:** compress wordmark letters proportionally toward a dot; dot→pill; cursorclick→sixbladeiris→photo; circle→square→unfoldedgrid→bento; click selectedtile into the drop. Glassletters become a droplet and toolbar. Adjustmentcontrol becomes a slider/lens; dragging changes aligned before/afterlighting only with real matching source images. Orb expands into lockscreen; homebar stretches into player. Bezel grows fromscreen; island detaches into a desktopwindow; wallpaperdrag becomes a pagehero; scrolling transforms thatphoto into a framedprint. Controls update frame/size. One black carrier conveys ordered→printing→route→delivered, then floods the canvas and contracts into a framed print on realwallfootage. Iris/shape returns to pill→dot→wordmark for the loop.

**Scope:** this is a long multistage recipe, not one template to cram into every15s reel. Map every beat/action to actual assets. If no logos, choose a permitted title/carrier instead of inventing a mark. Order status UI may be a clearly fictional concept; do not claim an existing product supports it without evidence.

**Look:** warm off-white, blackUI, one coherent glass material; Archivo-style variable-width wordmark andGeist-likeUI only when fonts are available/licensed.2Dlayer morphs, no3Dflips. Near-critical springs. No crossfades, blur-in entrances, arbitrary brightness development, particles or glow. Physical optical glass/refraction and goo-underlay blur are localized material effects, not exceptions for generic blurtransitions.

**Mechanics:** each glass element samples an aligned clone of its background with displacement/rimlight; keep text/photo interiors crisp. Goo uses a thresholded blurred silhouette with sharp foreground composited above. Irisblade geometry must choose short arcs. Wordmark letter centers and width compression move together; inspect kerning. Cursorcontact/longpress/drag drive actions, not disembodied statechanges. Use masks for outgoing/incomingcopy.

**Media/audio:** all-intra/blob seeking is one option, verified image sequences another. Use real alignedlightingpairs, not an unverified magical lightingclaim. Reference profile prefers downloaded licensed eventSFX and optionalmusic; this does not prohibit synthesized audio globally. Measure peaks and musical drop/breakdown, and apply requested loudness only after actual analysis.

**Reels:** reduce photo-gridcount, enlargecontrols and stack device/page views. Keep wallart as the hero and leave UI-safe negative space. Maintain objectcontinuity rather than showing tiny full desktopwindows.

**QA:** per-beat previews plus open/glass/device/wall styleframes; no one-frame flood, gap at irisblade joins, floatingcursor, unmasked contentoverlap or incorrect photoalignment. Review frame-difference spikes without treating intentional events as bugs; verify periodic position/velocity and media-frame behavior at loopseam.
