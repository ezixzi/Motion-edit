# Real Footage Drop Carousel

Source: user's inline minimal product/clip-wall prompt. **Use:** editor, creator tool or reel showcasing authentic owned clips. **Inputs:** product/promise,3–5UI moments, one accent,10–20owned/clearedvertical clips, and authorized track if music is desired. Asset ownership is not inferred from presence in a folder.

**Grammar:** masked hook words hit beats; one hook word matches into real productUI; cursor types/clicks; a button-centered circular aperture introduces the darker footage scene. A real-clip wall scans/selects3winners; key output gets a single bold type moment. Real videos occupy a3Dcarousel with restrained floor reflections; a direction-consistent whip selects one hero. Hero becomes a phone preview; a panel turns into verified results, then one-metric push cuts, a3word ticker and optionalbrand/CTA.

**Timing:** source10bars implies20s but describes more moves than bars. Use the documented20s grouping in timing-and-reels.md or negotiate a longer duration. Calibrate the actual downbeat/drop from the supplied song rather than assuming0s and a generic4sdrop. Do not fabricate beat analysis without audio.

**Look:** minimal, one sans and accent, spacious frames, no sentence-ending full stops in on-screen copy if this profile is selected. Real footage only for media surfaces; no fake generic cards standing in for owned clips. Structural containers can exist but must carry the real asset.

**Exclusions:** shockwave rings, particle bursts, globalRGBsplit, shake, flares, neon, grid floors, flashing backgrounds or bouncy easing. A filled button aperture is distinct from a decorative shockwave ring.

**Reels:** few large vertical videos, not an unreadable desktop wall. Keep carousel hero and all primary text in the UI-safe region. Reflections remain decorative and may extend beyond it. Phone/results can stack rather than compete side-by-side.

**QA:** every source/media license tracked, decoded footage matches timestamp, hero match cut uses measured coordinates, carousel has correct depth/backfaces, no stray previous-topic copy, drop/SFX align to actual transients, big stats are supported. Do not render the full recipe until real clips are available.
