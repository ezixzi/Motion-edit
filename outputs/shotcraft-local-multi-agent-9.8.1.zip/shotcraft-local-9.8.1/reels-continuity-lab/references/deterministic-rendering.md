# Deterministic renderer and technical corrections

The pasted prompts describe an HTML/Playwright or WebGL production method. It is optional for new briefs, not a mandatory replacement of Remotion. Files in this skill are math helpers and recipe guidance, NOT a complete renderer. Verify the chosen local dependencies, browser, GPU and playback support.

## Pure seek

Implement `async window.seek(t)` as a pure projection of time after a one-time layout/asset initialization. No elapsed timers, CSS transitions/animations or mutation accumulating between calls. Recompute every dynamic value including cursor/hover, camera, mask, text and media frame. `document.fonts.ready`, image.decode and actual video seek completion must finish before capture. Initialize immutable geometry after fonts/images load; remeasure on viewport/layout changes, not from the previous animated frame.

Validate seek order independence by rendering tA,tB,tA and comparing both tA images, then random frame order. Layout-dependent match cuts must transform measured source/target rectangles into the same coordinate system. Never read an already transformed previous-frame rectangle as the new baseline. Fix scrollbar, device scale, font loading, random seeds and input data. `scripts/motion-math.mjs` supplies state-free spring, timed target, aperture and sampling helpers with tests.

Springs: use closed-form under/critical/overdamped responses, including initial velocity for drag release. For discrete target changes, sum each target delta's zero-initial-state response. During drag, geometry comes directly from the prescribed cursor trajectory; at release carry position AND velocity. Use near-critical damping for tiny overshoot, not high bounce. Split-edge springs for tabs/toggles retain positive width and bounded stretch.

## Media and blur

For real clips, extract known-fps image sequences with an explicit ffmpeg fps filter and retained start/end/trim metadata. Map timeline time to clip frame index deterministically, clamp to available frames, and await img.decode before screenshots. A30fpssource rendered at60 repeats frames; it does not become true60fps footage. True subframe footage blur needs higher-rate decoding/interpolation or accepting that only scene transforms get smooth blur.

All-intra video improves seeking but is not inherently frame-accurate. Blob URLs may help simple servers; HTTP Range support is server/version-dependent. Await seeked only when time actually changes (otherwise it may never fire), ensure readyState/decoded frame availability, and use image sequences where exact seeking cannot be established. Blob URLs can consume significant memory.

For N subframes per output frame, render them as one explicit group at known shutter offsets; average within that group only. Do not apply a sliding tmix filter and retain all N blended subframes or run a second fps conversion: that smears across output-frame boundaries. For a linear input image sequence grouped3peroutput at60fps, a valid pipeline is input framerate180, then `tmix=frames=3:weights='1 1 1',select='eq(mod(n,3),2)',setpts=N/(60*TB)`, output60fps. Frames0–2 make output0,3–5 output1. Verify exactly K output frames from K×3 inputs. The helper samples t−1/240,t,t+1/240 for3samples/shutter0.5 at60fps. Clamp non-loop boundaries or wrap loop times deliberately.

For4or16 samples use matching weights/group size, not the3-sample filter unchanged. Equal-weight blending in gamma-encoded PNG is an approximation; linear-light blending reduces dark fringes. Motion blur is a quality/performance tradeoff, not evidence of a rendered film. Inspect fine type and audio timing after final mux.

##3D, glass and flyover

Opacity/filter on a preserve-3d subtree can flatten it; place fades on a wrapper outside the3D context. Check both faces and clip/backface visibility. Avoid blanket will-change on camera-scaled text; inspect Chromium rasterization. Light clipping/glow/shadows need actual rendered evidence.

Glass: if backdrop-filter displacement is unsupported, clone the relevant background at identical world coordinates into each glass element, displace it and mask it. This is expensive and must not duplicate user interactions. Chromatic refraction confined to glass edges is not permission for global RGB-split effects. Goo threshold affects a silhouette underlay; keep foreground text/photo sharp. Six-blade iris geometry must use the intended short arcs and extend beyond corners when closing.

For WebGL, detect WebGL2, anisotropy extension and maximum filtering; request min(16,maxSupported) rather than assuming16x. `--use-angle=d3d11` is Windows-specific; do not hardcode it on macOS/Linux or force-ignore GPU blocklists by default. Inspect capabilities, then choose supported backend or a truthful lower-quality fallback. Lowest-to-highest painter ordering with no depth buffer works only for non-intersecting layers in a known camera range; general geometry needs depth testing/sorting. Mipmap/DOF sampling support must be checked.

## Audio and QA

License is per asset and use, not per stock-site name. “Mixkit/Pexels” alone is not proof every track/SFX/clip permits every commercial use. Record source URL, license, retrieval date and restrictions. Synthesized soundtrack via OfflineAudioContext is opt-in for the selected brief; never add music to SFX-only. Physical-stock-SFX-only applies only to the selected photo/glass recipe.

Place measured sound peaks at event times; validate after encoding instead of copying a previous2048sample compensation. If requested, use measured two-pass ffmpeg loudnorm for−14LUFS with suitable true-peak ceiling, then check actual output. Do not blindly boost a sparse SFX-only mix to a music target. Negative-time peaks need lead-in/trim handling without deleting attacks.

Preview at least one frame per beat and extra transition extrema; for non-beat flyover inspect the reference key seconds and camera trajectory. Frame-difference spikes above3×neighbors are review candidates, not automatic defects (cuts/whips can be intentional). Optical flow is content-sensitive: also test the numeric speed curve and camera direction. Verify final encoded duration, frame count, safe bounds, audio and visual continuity with reels-qa/reels-reviewer.
