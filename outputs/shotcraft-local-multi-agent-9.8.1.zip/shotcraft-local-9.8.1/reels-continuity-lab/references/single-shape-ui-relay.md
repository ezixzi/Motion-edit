# Single Shape UI Relay

Source: user's inline square UI morph prompt. **Use:** interaction craftsmanship, component system or UI demo. **Inputs:** actual8–12states, color choice, desired duration and authorized audio. The source's longer example state chain is optional, not a requirement that fits automatically.

**Carrier:** one rounded rectangle preserves identity throughout. Button→loader→check→island/player→progress→volume→toggle→tabs→chart→command→toast→button is a menu; choose/merge states to fit the requested7bars(14s at120BPM). Each state's content gets separate exit/entry timing while the carrier morphs size/radius/color. Do not overlap old/new text at full opacity.

**Direct manipulation:** cursor visibly contacts controls. While held, slider/knob position is computed directly from cursor coordinates; overscroll stretch stays bounded. Release uses the final position and velocity in a closed-form spring. No delayed spring between the held cursor and the dragged control. The leading/trailing edges of a tab indicator use different springs, yielding a stretched ribbon before settling. Keep width positive and clamp pathological overshoot.

**Appearance:** warm gray canvas, black/white or one accent, consistent Geist-style UI type and icon strokes. Tiny spring overshoot only. No particles/glows, arbitrary chrome gradients or unmatched assets. Icon morph uses compatible contours/cross-shape masks rather than an opacity-only swap when continuity is required.

**Timeline:** each beat has a purposeful interaction or geometry event; allow sub-beats for click feedback. Last state reconnects to first with cursor and velocity continuity. Choose mathematical periodicity vs literal identical exported endpoints explicitly; see timing guide.

**Reels:** retain one large central component; magnify labels, reduce simultaneous states and reflow command/chart details. Do not stretch squareUI into a phone or crop slider handles outside safe bounds.

**QA:** seek-order independence, exact click/drag mapping, release continuity, tab-edge bounds, text mask timing, loop seam, no single-frame pops. Generic UI can be illustrative; product-specificUI must be verified.
