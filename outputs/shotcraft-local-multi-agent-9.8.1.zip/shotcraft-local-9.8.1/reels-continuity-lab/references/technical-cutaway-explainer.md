# Technical Cutaway Explainer

Local adaptation from the user's uploaded scooter explainer. Read `uploaded-video-study.md` only when source observations matter; read sibling `reels-motion/references/visual-asset-playbook.md` when creating assets. This is a production recipe, not an installed upstream shot or finished animation component.

## When to select

Simple prompts: “jelaskan cara kerja mesin seperti video referensi”, “bedah objeknya”, “edukasi teknis dengan ilustrasi”, “gambar alatnya lalu tunjukkan alirannya”. Suitable for mechanisms, anatomy with verified references, electronics, household objects or scientific processes. Adapt to subject and requested palette; do not force a scooter, cream background, fixed duration or narration onto every brief.

## Visual grammar

- One persistent hero object, first in a recognizable environment, then exposed from outside to inside. Use the same camera, materials and proportions across states.
- Warm neutral canvas, dark bold heading, small status label, one large illustration, short captions and limited callouts. Reserve visible negative space. Accent colors encode states rather than arbitrary decoration.
- The information sequence is question → mechanism → evidence → practical conclusion. One visible cause and response per shot.
- Keep headings/captions as vector text. Add labels after the relevant part is in focus. Anchor leader lines to the actual moving part or its projected 3D anchor.

## Suggested sequence (scale to the brief)

| Portion | Action | Continuity mechanism |
|---|---|---|
| 0–12% | Establish object, pose question | Gentle push with stable typography |
| 12–20% | Approach relevant part, remove shell | Aligned intact/cutaway states; shell moves out or mask reveals interior |
| 20–45% | Explain one process at a time | Moving parts, path-following flow, labels appear at arrival |
| 45–62% | Present sourced comparison | Reframe object to make room for a readable data panel |
| 62–78% | Show control/feedback or another process | Traced paths and a purposeful pulse; no random sparks |
| 78–90% | Return to real-world consequence | Reverse reframe, sourced quantity visual or clearly marked simulation |
| 90–100% | Give takeaway and CTA | Short checklist or return to hero framing |

Percentages are planning suggestions, not measured source timings. Preserve requested exact frame ranges. For short videos, remove secondary explanations rather than shrinking every label. A callback is not automatically a seamless loop.

## Motion implementation

Search installed `basic-3d-scene`, `exploded-view`, `spotlight-sweep`, `axis-rescale-shock` and `input-morph-assemble` sources for useful primitives. Inspect actual code/previews before reuse; none is assumed to implement a cutaway engine or accurate fluid simulation. Explain remaining bespoke work in the shot map.

Use a stable hero rig with shell/interior groups. Capture projected bounds at a known reference time for match cuts; compute subsequent movement from absolute frame time. With flat assets use registered views and clipping, not an impossible camera orbit through a PNG. Real parallax needs depth layers or geometry.

Advance paths by normalized arc length; derive component motion from a coherent mechanism or label it illustrative. Stage camera move → part reveal → process → annotation → reading hold. Vary transition logic among shell removal, focus reframe, traced connection and return to context. Do not add a random transition at every sentence.

## Audio and captions

Follow the current brief: narration, SFX, music or silence. If narration is selected, captions can use short black pills with an accent on the currently spoken word, driven by actual word timestamps/alignment. Segment-only TTS timestamps are insufficient for accurate karaoke. Without word alignment, use phrase captions; without narration, use deliberate reading holds. SFX follow meaningful actions, not every letter; never infer the uploaded soundtrack from screenshots.

## QA

Verify mechanical/scientific assertions independently. Source cards must cite inspected evidence, not decorative fake references. Counters must come from sourced data or say “simulasi/ilustrasi”; show “dipercepat” for accelerated time. Do not reuse numerical claims from the reference automatically.

Inspect intact/cutaway identity, anchor tracking, occlusion, flow direction, text collision, safe zones and final-phone-size readability. Keep captions out of the mechanism's active area. A new mechanism with unverifiable details should be presented as a simplified diagram, not a precise engineering model. Preview handoffs densely and inspect the encoded video, not just a contact sheet.
