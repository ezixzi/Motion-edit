# 3D Depth Parallax & Dolly-Zoom Hero Journey (`depth-parallax-hero-journey`)

Source: Upgraded from the user's `MotionDepthSkill` (`gemini-code-1792649781745.py`) into `reels-depth-motion/scripts/depth_engine.py` and `reels-templates/components/DepthParallaxStage.tsx`.

## When to select

Select this recipe when the user wants static 2D photos, product heroes, architectural renders, historical/educational stills, or technical illustrations to feel alive with **true 3D depth parallax**, **camera orbit**, **Vertigo dolly-zoom**, **rack-focus bokeh**, or **multi-plane 2.5D separation**.

## Two Execution Modes

1. **Pre-rendered Pixel-Warped MP4 (`depth_engine.py --output`)**:
   - Best when you want dense per-pixel 3D warping (`cv2.remap`) and smooth Depth-of-Field blur on a complex single photo (e.g., nature, fish/wildlife, street photography, macro hardware).
   - Output is an H.264 `yuv420p` MP4 ready to drop into Remotion via `<OffthreadVideo>` or upstream `ClipCard`.
2. **Multi-Plane RGBA Layer Slicing (`depth_engine.py --export-layers` + `<DepthParallaxStage>`)**:
   - Best when you need interactive callout pins (`ParallaxPin`), text behind the foreground subject (sandwich depth), or cutaway peeling directly synchronized with Remotion's `useCurrentFrame()`.

## Recommended Choreography

| Phase | Frame Share | Camera Preset | Typography & Sound |
|---|---|---|---|
| Hook Impact | 0–18% | `vertigo-contra-zoom` or `dolly-push` | Bold hook question (`kinetic-slam` or `brutalist-stagger`) + low sub riser |
| Exploration | 18–55% | `cinematic-orbit` or `parallax-drift` | 2–3 anchored `ParallaxPin` callouts appearing on speech landmarks |
| Deep Focus | 55–82% | `crane-rise` or `cutaway-peel` | Rack focus shifts (`focusDepth: 0.45 → 0.85`) + `glass-callout` or `karaoke-pill` |
| Settle & CTA | 82–100% | `breathing-float` (intensity 8) | Calm micro-float so final takeaway & CTA hold cleanly for ≥2s |

## Quality Checks

- Check foreground silhouette edges at peak horizontal displacement (`x_shift` extremum) to confirm bilateral filtering prevented background halo tearing.
- Ensure any text placed between midground and foreground layers remains 100% legible during reading holds.
- Never combine `vertigo-contra-zoom` with rapid flashing or violent camera shake in the same beat.
