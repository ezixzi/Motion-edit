# Kinetic Type to Architecture Loop

Source: user's inline15s showreel prompt. **Use:** motion portfolio or an abstract concept, not a substitute for explaining a real product.

**Concept first:** name one concrete chain, e.g. stroke→letter→wall→data column→word. The next scene is made from the previous scene's geometry/color rather than a cut/crossfade. Include kinetic type, shape morph,2D→3D, data/UI and end title. This is an original adaptation concept, not an observed site demo.

**Timing modes:**15s at120BPM is30beats. Equal-technique mode assigns five3schapters; bar mode assigns2schapters and extra hook/payoff time. Document the selected resolution of the conflicting source constraints. Strongest moment goes near the final full phrase; end-title reconnects to the initial object. A short reading hold is compatible with a small nontext beat event.

**Design:** one font, ≤3colors plusblack/white, one camera language. Type is shape, not just overlay copy. Anchor a vertex, edge or baseline through handoffs; outgoing and incoming glyphs receive separate masks. A flat plane can acquire depth without rotating unpredictably; a column can become a plotted value only when its fictional/illustrative status is clear.

**Profile exclusions:** particles, glow/flares, camera shake, RGBsplit, crossfades, unmotivated generic gradients, bouncy easing. Fast movement may use measured directional blur; settle to crisp type. Never make the entire film illegible just to satisfy “no stillness”.

**Audio:** source proposes an original OfflineAudioContext kick/riser/hit composition. Generate it only when music is authorized; otherwise time SFX to a virtual grid. Keep a reusable source score and renderWAV before final mux.

**QA:** every transition has a visible geometric cause, consistent camera/lighting, equal emphasis if that mode was selected, and loop position/velocity continuity. One frame per beat plus peak3D/mask frames and final encoded seam. Do not assert a seamless loop from only matching poster frames.
