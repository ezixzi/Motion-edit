# Product Object Continuity

Source: user's inline Dub15s and Distilbook30/40s prompts, consolidated because they share the same grammar. The sites/products and UI were not researched during this packaging task.

**Use:** SaaS launch/explainer with verified interface states. **Inputs:** real product URL, authorized screenshots/UI, brand assets, a verified promise and3–4actual features. No invented dashboard metrics or actions. Research the selected product before creating screens; do not hardcode Dub or an unspecified Distilbook URL.

**Grammar:** select one authentic through-line object (cursor, button, data point or brand mark). It interrupts a3–5word problem hook, deforms into the first actionable UI, then becomes each next scene's key element. A visible cursor types/clicks/drags with contact timing. Each transformation reveals one real feature; the strongest feature becomes the payoff. The object returns as brand/CTA only if branding is allowed.

**Timing:** plan at actual beat times; default reference120BPM. Hook first bar;3–4feature chapters; final payoff/CTA.15s,30s and40s are variants. Allocate readable copy windows before mapping micro-actions. No newly appearing object without a geometric/mask/reveal origin.

**Camera/type:** one verified brand font and accent; gentle1.0→1.04 pushes may continue at the next scene's starting zoom, with a bounded overall framing plan. Never accumulate scale indefinitely. Rebuild visible UI as independently movable vector/DOM layers based on actual reference. This is a visual reconstruction, not a live product simulation; don't claim clicks trigger backend services. Cursor scale follows camera intentionally. Lots of empty space.

**Profile-only exclusions:** particles, glow/flares, camera shake, global RGBsplit, generic gradient fills and unrelated crossfades. Near-critical springs with small overshoot. Decorative movement can continue on beats while primary copy remains stable/readable.

**Reels:** use section-sizedUI views and focused camera targets; convert broad dashboards into selected real subpanels, retain context labels. Limit each text block to the safe column. Use measured rectangle mappings for UI/object match cuts.

**QA:** evidence for every feature/number, exact object identity through each transformation, cursor contact before state change, no text overlap, matching camera boundary, readable final CTA. Review no-logo variant independently.
