# Uploaded reference: scooter / engine educational reel

## Evidence and scope

User supplied the MP4 for studying images, composition and motion. Inspected on 2026-10-22: 62 roughly one-second sampled frames, selected native-resolution stills, and 16 frames at roughly 0.2-second intervals across the exterior-to-engine transition. Contact-sheet labels are approximate sampling positions, not frame-accurate edit marks. This is visual inspection, not a listening review or inspection of the creator's project.

- Source filename begins `ClipDown.com_AQN0etwLiXqc4-futbIB9IhnfcFe6eVnF0j90iR28jQvX16t1W-hvAhqtUUepktGYATR4KKUmLkYR9tHA-fMObhAf-2AvP4hOpjL39w.mp4`
- SHA-256: `1fbee9ce0c90443bb90ce7d69e7b93045612777e2c03dccc3a2a17315a5a971e`
- 720×1280, H.264, 30 fps; video stream 61.866667s; AAC/container approximately 61.972s
- No original footage, extracted stills, soundtrack, brand assets or third-party scene code redistributed in this kit
- Source renderer, AI use, CAD model, rig and asset licenses are unknown

## Observed visual construction

Ivory background and lightly sketched porch isolate a red scooter with shaded, outlined surfaces and soft shadows. The top heading and small metadata eyebrow remain organized while the illustration changes below. Black rounded caption pills sit under the visual; an active word is yellow, surrounding text white/gray. Yellow also labels parts, blue denotes operating state, rust/orange marks heat/waste and green marks the conclusion. These are inferred visual roles, not documented brand tokens.

| Approximate range | What is visible | Adaptable principle |
|---|---|---|
| 0–7s | Scooter in context; question and short changing caption phrases | Establish one recognizable object before explaining it |
| 7–10s | Push toward rear/engine; red body clears away, chassis exposed; surrounding parts move/blur out while isolated cutaway stays | Nested reveal: whole → subsystem → mechanism, maintaining spatial association |
| 10–22s | Cutaway, oil reservoir, moving internal parts, routes and small anchored labels; comparison panel around 13–16s | Reuse a single diagram; reveal one cause and response at a time |
| 22–34s | Flow and friction highlights; manual/source cards occupy the upper area | Reframe the subject to reserve space for evidence |
| 35–41s | Engine linked to ECU/ECM box by paths and yellow pulse | Show the relationship between parts through a moving signal |
| 42–49s | Accelerated counter, fuel/distance panel, return toward scooter context, estimate/source card | Translate internal process into a real-world consequence |
| 50–59s | Bottle/container quantity metaphor and green-tick takeaway card | Convert abstract quantities into visible scale and action |
| 60–62s | Return to opening scooter/question composition | Visual callback; seamless looping is unverified |

The dense transition frames support a shell/chassis/engine reveal with a moving camera. They do not establish whether this used geometry, composited layers or generated footage. Reproduce the perceptual grammar with original assets, not a claim about the creator's tooling.

## What to improve in our adaptation

Keep the large object, stable heading and stepwise explanation. Enlarge tiny component labels, reduce concurrent arrows, and separate comparison panels from active mechanism regions. Recompose to the chosen Reels UI exclusions rather than inheriting the source's exact pixel positions. Make one fact understandable without pausing; use less copy before making it smaller.

Do not copy scooter branding, technical figures, manual quotations, fuel estimates or mechanical conclusions as verified information. Research the new topic independently. We have not reviewed this video's audio or validated its claims. The supplied video demonstrates a visual direction; the new recipe remains an implementation guide, not a newly rendered demonstration.
