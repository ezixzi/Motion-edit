# Technical Study & Visual Grammar of the 4 Uploaded Reference Videos (v5.5)

Inspected frame-by-frame and via `ffprobe` on 2026-10-22. All 4 videos are 9:16 vertical (`720×1280` / `1080×1920` at `30fps`) code-driven motion graphics / hybrid Reels.

---

## 1. Reference Video 1: `ref1-tutorial-deck` (`snapgram.io_2i7acf0oifhk.mp4`)
- **Duration / Format**: `124.53s`, `720×1280`, `30fps`, stereo AAC.
- **Visual Style**: Dark Dot-Grid Step-by-Step UI & Terminal Tutorial Deck (`REMOTION × CLAUDE` / `Galihry` style).
- **Canvas & Zones (at 1080×1920)**:
  1. **Background**: Deep charcoal `#121210` with a `36px × 36px` subtle dot matrix (`rgba(255,255,255,0.07)`) and a large soft radial ambient glow (`r = 520px`) whose hue shifts per chapter (`#D97757` coral, `#6BCB77` node green, `#5B9BD5` folder blue, `#A855F7` studio purple).
  2. **Top Brand Header (`y = 68..124px`)**:
     - Left pill: `[✳ REMOTION × CLAUDE]` (`#1E1E1A`, border `rgba(217,119,87,0.45)`).
     - Right pill: `[✳ Galihry]` creator handle pill.
  3. **Step Badge & 2-Tone Headline (`y = 220..460px`, left-aligned at `x = 84px`)**:
     - Step pill: `[ ① LANGKAH ]` or `[ ✳ CONTOH ]` / `[ ✳ REVISI ]` / `[ ✳ SELESAI ]`.
     - 2-line heavy grotesque uppercase headline (`76px`, weight `900`): Line 1 in cream white `#F5F2EB`, Line 2 in the chapter accent color (e.g. `INSTALL` / `NODE.JS`, `BUKA` / `CLAUDE CODE`, `JALANIN` / `STUDIO`).
  4. **Center Interactive UI / Terminal Window (`y = 520..1280px`)**:
     - macOS dark window (`#1C1C19`, traffic light dots `#FF5F56`, `#FFBD2E`, `#27C93F`) or 3D perspective phone/tablet mockup.
     - Supports 5 sub-modes:
       - `browser-download`: App logo + title + animated cursor clicking `[DOWNLOAD LTS]` + progress bar `MENGINSTAL... 100%` + tilted sticker `[WAJIB!]` (`rotate(-6deg)`) + stacked architecture blocks (`[REMOTION]` over `[NODE.JS]`).
       - `terminal-command`: Typing `$ npx create-video@latest` & `$ npm install`, interactive CLI prompts (`? NAMA PROJECT? › remotion-video`), progress bar, and tilted sticker `[JAWAB SESUAI SELERA]`.
       - `prompt-composer`: Claude Code prompt box typing uppercase prompt while token pills (`[1080×1920] [30 FPS] [10 DETIK] [SPRING] [NAVY]`) pop in below the box.
       - `chat-revision`: User revision bubbles right-aligned (`[GANTI JUDULNYA JADI ...]`, `[DURASINYA DIPERPANJANG]`) + Claude response pill left-aligned (`[✓ UDAH! CEK LAGI DI STUDIO]`) + tilted sticker `[TANPA NYENTUH KODE]`.
       - `checklist-outro`: Animated checkbox card ticking off all 5 steps (`☑ NODE.JS`, `☑ CLAUDE CODE`, etc.) + creator starburst sign-off.
  5. **Bottom Word-by-Word Dim-to-Lit Karaoke Subtitle (`y = 1580..1680px`)**:
     - 3–4 uppercase words centered horizontally; active spoken word is `#FFFFFF` or `#D97757`, while unspoken words in the same phrase remain dimmed at `rgba(255,255,255,0.28)`.

---

## 2. Reference Video 2: `ref2-floating-glass` (`snapgram.io_emctocdrhal8.mp4`)
- **Duration / Format**: `55.66s`, `720×1280`, `30fps`, stereo AAC.
- **Visual Style**: Talking-Head Video with Floating Frosted Glass UI & Gradient Kinetic Typography in Upper Headroom.
- **Canvas & Zones (at 1080×1920)**:
  1. **Background (`0..1920px`)**: Real talking-head vertical footage (`SmartFootageStage`) or studio speaker silhouette with subtle vignette and optional rainbow border glow on climax beats.
  2. **Upper Headroom Floating Glass Stage (`y = 150..580px`)**:
     - Never blocks the speaker's face (`y > 600px`).
     - Supports modular floating widgets:
       - `glass-prompt-card`: Frosted glass card (`backdropFilter: blur(22px)`, `rgba(30,32,38,0.74)`) with file attachment chip `[content AI & Tech.mp4 | MP4]` and glowing gradient button `[Editkan]`.
       - `numbered-glass-pills`: Stacked translucent pills `[ ① Claude  editor kita  ✳ ]` and `[ ② Guidebook  📖 ]`.
       - `glass-tag-cloud`: Icon header `📖 Guidebook` + staggered glass pills `[Style] [Desain] [Animasi] [Motion kit]`.
       - `radial-ai-loader`: Circular gradient progress ring around the Claude starburst icon (`Suruh Claude`).
       - `gradient-kinetic-headline`: Small white eyebrow (`Kalian harus tahu`) above giant bold headline with purple-pink-blue gradient text (`cara AI bekerja.`, `promptnya apa.`) + dark pill sub-badge (`[pakai AI semaksimal mungkin]`).
  3. **Bottom Clean Karaoke Subtitle (`y = 1480..1580px`)**:
     - Clean sans-serif (`42px`, weight `700`), active words `#FFFFFF` with soft drop shadow, inactive words `rgba(255,255,255,0.42)`.

---

## 3. Reference Video 3: `ref3-pricing-voxel` (`snapgram.io_o0bpx04sdtdo.mp4`)
- **Duration / Format**: `49.33s`, `720×1280`, `30fps`, stereo AAC (`@classai_id` style).
- **Visual Style**: Split-Screen Web Pricing/Docs Inspector + Diagonal Wipe + 3D Voxel Character Presenter.
- **Canvas & Zones (at 1080×1920)**:
  1. **Background**: Deep navy `#060A12` with `40px × 40px` technical grid (`rgba(56,189,248,0.06)`).
  2. **Top Brand Bar (`y = 64..115px`)**: Left `[C classai.id]` logo, Right `@classai_id`.
  3. **Chapter Number & Service Header (`y = 150..275px`)**:
     - Giant outlined tabular number (`01`..`05`, `88px` bold) + colored service icon tile (`Pages`, `Neon`, `Clerk`, `Resend`, `R2`) + service name (`56px` bold white) + category tags (`[CLOUDFLARE] [TAMPILAN WEB]`).
  4. **Browser Pricing/Docs Inspector Window (`y = 290..820px`)**:
     - Dark browser card with URL bar (`neon.com/pricing`, `clerk.com/pricing`, `resend.com/pricing`).
     - Inside: pricing tiers/tables that pan & zoom smoothly while an animated pointer cursor moves to key limits (`50,000 MRU limit per app`, `100 emails a day`, `10 GB-month`), drawing a glowing blue/amber highlight box (`#2563EB` or `#F59E0B`) and popping a floating counter badge (`[∞ gratis]`, `[500 BUILD / BULAN]`, `[50rb USER AKTIF / BULAN]`, `[Jatah harian yang habis duluan]`).
  5. **Middle Kinetic Speech Caption (`y = 850..1040px`)**:
     - 2–3 large words (`64px`, weight `900`) popping on speech beats with key terms in electric blue `#3B82F6` or white highlight box `[Coba lihat]`.
  6. **Bottom 3D Voxel Presenter Character (`y = 1060..1920px`)**:
     - Stylized 3D blocky/voxel character (blue knit beanie + striped tee) with 4 expressive poses: `pointing-up` (pointing at the browser card), `explaining`, `thinking-warning` (hand on chin when pointing out a caveat), and `thumbs-up-cta` (for the final `Komen [DEPLOY]` screen).
  7. **Scene Transition**: Crisp diagonal blue wipe (`#2563EB`) sweeping across the frame between numbered items.

---

## 4. Reference Video 4: `ref4-tape-mascot` (`snapgram.io_ipv2bjl9o94a.mp4`)
- **Duration / Format**: `28.07s`, `720×1280`, `30fps`, stereo AAC.
- **Visual Style**: 3D Studio Character & Blocky Claude Mascot A/B Cut + Top Masking-Tape Banner + Torn-Paper Word Stickers.
- **Canvas & Zones (at 1080×1920)**:
  1. **Alternating 3D Scene Stage (`0..1920px`)**:
     - Alternates between **Shot A (`studio-avatar`)**: 3D stylized creator with sunglasses, bandana, and podcast mic in a warm lit studio, and **Shot B (`claude-mascot-desk`)**: 3D blocky terracotta/orange Claude mascot sitting at a desk in front of a dark computer monitor showing code lines, timeline bars (`PRO`), a rotating 3D Blender cube, or a live video editor preview + terminal bar (`> tambahin teks, subtitle sama transisi|`).
  2. **Top Masking-Tape Paper Banner (`y = 165..265px`)**:
     - Cream textured paper strip (`#EDE8DC`) with angled masking-tape tabs on left and right edges (`rotate(-4deg)` / `rotate(+4deg)`) and bold black uppercase headline (`CLAUDE BUKAN CUMA BUAT NGODING`, `PASANG 3 SKILL INI`, `SKILL PERTAMA: MOTIONMAXXING`, `KOMEN "EDIT"`).
  3. **Middle Hole-Punch Skill Index Card (`y = 1020..1210px`, on Shot A)**:
     - Cream card (`#F3EFE6`, `borderRadius: 18px`) with left punch-hole circle, bold skill title (`MotionMaxxing`, `Blender Skills`, `Remotion`), subtitle (`motion graphic`, `animator 3D`, `editor video`), and an orange circular number badge `(1)`, `(2)`, `(3)` overlapping the top-right corner.
  4. **Bottom Torn-Paper Ransom Word Stickers (`y = 1360..1540px`)**:
     - 1–3 spoken words at a time inside tilted (`-2.5deg` to `+2.5deg`) terracotta orange (`#C85A3A`, cream text) and cream (`#F4EFE6`, orange/dark text) torn-paper sticker badges!
