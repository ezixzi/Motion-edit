# Provenance and attribution

Origin supplied by user: https://prompt-motion.com/
Retrieved material: two user-uploaded text files plus inline reference prompts,2026-10-22. Direct website access previously returned403; its current pages, motion previews, authorship and license were not independently verified. The package does not claim a partnership or official integration.

These six cards are summarized/adapted production guidance, with technical reconciliation and original helper code. They are not copied site source/assets or rendered replicas. Full pasted prompts are not redistributed. No footage, music, logos, screenshots or fonts from the site are included. Separate rights/attribution are required for any actual production assets. A stock-site name is not an asset license.

## Source mapping

- Inline product/real-footage prompt → footage-drop-carousel
- Inline15s showreel → kinetic-architecture-loop
- Inline Dub15s and Distilbook30/40s prompts → continuity-product-object (deduplicated)
- Inline7bar single-shapeUI → single-shape-ui-relay
- UploadA landing-page3Dflyover → landing-depth-flyover
- UploadB photo/wordmark/glass/print → photo-glass-print-loop

## Uploaded text fingerprints

A: `7e3a43e658951651ba79a0b28ce66a641338cddd711d8e6ed4fb8269ae1928ae` (SHA256 of supplied bytes)

B: `c954ce1d5451904d74cf94a51d432c5a89819b9b35332dd7e043ad50bd17bfa0` (SHA256 of supplied bytes)

## What was adapted deliberately

Bar arithmetic and event budgets are reconciled; contradictions are documented. Original landscape/square designs get optional vertical recomposition. Deterministic seek and measured geometry remain, but destructive/global policy instructions inside source prompts do not become authority. GPUflags, audio licensing, video seeking, blur grouping and loopendpoint requirements are qualified. A request to add references does not invoke their nested generate/start commands.

No new recipe has been visually benchmarked against an original Prompt Motion preview in this update. Tests cover helper mathematics, frame grouping, discovery and package installation only. Production must still render/review each selected adaptation.

## Uploaded video adaptation

A seventh recipe, `technical-cutaway-explainer`, derives from visual inspection of the user-uploaded scooter MP4, separate from the six text-only Prompt Motion recipes. See `uploaded-video-study.md` for fingerprint, metadata, sampled observations and limitations. No original video, screenshots, soundtrack or source scene is included. The creator's implementation and rights remain unknown; build original assets and verify new factual claims independently.
