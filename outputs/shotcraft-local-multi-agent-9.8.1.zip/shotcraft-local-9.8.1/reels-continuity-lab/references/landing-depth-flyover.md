# Landing Page Depth Flyover

Source: user-uploaded landing-page reference text. Reference14.5s,1440×1152,60fps. **Use:** an owned/authorized real landing page with meaningful sections. **Inputs:** URL, brand/mark, closing statement + short italic tail, optional authorized track. Keep the capture deterministic and free of sensitive account content.

**Capture:** fix viewport and font state, scroll once to load lazy content, stabilize sticky/animated sections. Select liftable elements and record immutable page rectangles. Capture a clean base with those elements hidden without reflow, then isolated transparent pieces with padding and recorded anchors. Verify no missing text, double images or shifts caused by isolation. The page must be locked before camera timing.

**Motion:** single continuous backward/down-page glide, no sideways swing/cuts. Page sits on a bright studio floor, rounded edges, broad soft shadow. Pieces near focus lift and tilt gently toward the lens; larger feature lifts are deliberate exceptions. Logo tiles persist only when logos are permitted. Camera rises to a whole-page strip, dives back to the hero, and hero becomes a card below closing typography.

**Phase reference:**flight0–8.2s;rise7.75–9.25;overhead9.25–9.47;dive9.47–9.97;title9.97–14.5. Overlap is deliberate. Establish camera near56°off-down and a consistent view distance. A continuous speed curve handles acceleration0–1.6s, near-constant cruise through7.3s, deceleration toward8.3s. Integrate velocity; don't independently keyframe positions every half-second. “No surges” describes cruise, not the source's explicit entry acceleration.

**Rise/dive:** log-scale ramp with smooth acceleration/constant/deceleration, solve look-at from a pinned edge. Show bottom edge before dive; keep hero edge anchored through takeover, then land with a rounded-card mask. Measure screen positions after projection; source pixel constants are references for1440×1152, not portableReels coordinates. End uses one sans + a deliberate italic accent face if the user permits two fonts.

**Depth:** asymmetric foreground/background blur, sharper subject and restrained rear blur. If usingWebGL, verify GPU/anisotropy/texture limits; cap taps/mipmap bias to hardware. Painter ordering is only valid for suitable non-intersecting layers. Soft shadows depend on actual height; avoid letting translucent pieces show unwanted back surfaces while fading.

**Reels:** use section-focused narrow travel or a shorter hero-to-feature path; fullpage strip is context only, never expected to be legible. Do not promise this effect can run at full16subframeGPUquality on every laptop. Offer a tested lower-cost preview before finalrender.

**QA frames:**0,1.6,2.5,5,6.5,9.3,11s plus boundary pairs. Verify numeric camera speed stays smooth in cruise and zoom direction stays consistent duringflight; optical flow is a supporting, content-dependent test. Confirm no capture holes, wrong layer anchors or frame-edge collisions. MP4 output depends on available runtime, not on whether the agent is local/cloud by definition.
