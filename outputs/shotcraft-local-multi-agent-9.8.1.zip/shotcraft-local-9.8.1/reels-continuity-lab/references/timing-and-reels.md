# Timing reconciliation and vertical composition

A beat is60/BPM seconds. In4/4 a bar is4beats. At120BPM: beat0.5s,bar2s. The source uses these assumptions but mixes event count, technique count and bar count.

| Reference | Duration implied by meter | Resolve before production |
|---|---|---|
| Footage10bars |20s/40beats | Intro + drop + all listed moves exceed10distinct bars if each gets a whole bar; combine related sub-events into a shared bar or ask to extend, never silently claim literal one-event-per-bar |
| Kinetic15s |7.5bars/30beats | Equal shares across five techniques conflict with strict one-technique-per2sbar plus hook/payoff; prioritize the explicit latest constraint and document allocation |
| UI7bars |14s/28beats |8–12requested states vs a longer example chain; select/merge actual states with the user, place multiple interactions within a bar |
| Photo/glass54beats |27s/13.5bars | Align return/payoff to the actual track; stock song tempo/drop may require a revised map |
| Dub15s |7.5bars/30beats | Brand facts/UI need research; timings are a reference mode, not default all videos |
| Distilbook30/40s |15/20bars | Two variants of one recipe, not separate confirmed products or mandatory tasks |
| Landing flyover |14.5s/870frames at60 | Seconds-driven camera curve with overlapping lift/rise phases; do not force into4/4 bars |

A possible20s footage allocation (an adaptation, not a reproduction claim):0–2hook;2–4word→UI/type/click;4–6button aperture→clip wall/scan;6–8three selections→key output;8–10carousel→hero whip;10–12phone→results panel;12–14verified stats push;14–16three-word ticker;16–18brand/CTA;18–20finish. For no-logo briefs use a final content object/CTA instead of inventing a brand. Keep only real results; replace unsupported stats with qualitative verified copy.

For15s kinetic equal-technique mode: five3s chapters,6beats each, with the last beat of each performing the next transformation. For strict bar mode: use2s chapters and allocate remaining bars to hook, payoff and loop closure. Label which mode was chosen. Do not claim both contradictory allocations simultaneously.

Music analysis: onset strength/autocorrelation or tempogram yields tempo candidates, not guaranteed kick/downbeat/drop truth. Validate half/double-time candidates, transient timing and phrase downbeats against waveform/listening. “Highest-energy bar” is not automatically the musical drop. Keep detected vs manually confirmed landmarks separate. With SFX-only, use a virtual grid and motion events; do not download a song to satisfy the template.

Vertical adaptation: start essential copy within x90..870,y250..1500 at1080x1920, then validate current platform overlays. This is a working guide, not a universal platform guarantee. Convert a horizontal wall into fewer larger tiles; carousel to tall clips with shallow travel; flyover to section-focused travel; beside-phone results to a stacked panel; data to one legible metric at a time. Keep exact user aspect ratio when given. Primary copy must survive phone preview size and all transforms.

Loops require position, scale, color, opacity, cursor and velocity continuity at t=T and t=0. A correctly sampled exported last frame is normally at T−1/fps, not T: it need not equal the first pixel-for-pixel if motion is continuous. If literal identical first/last frames is demanded, design a short seam hold or an explicit duplicate end frame, and validate the resulting cadence. Never satisfy it by adding an accidental stutter.
