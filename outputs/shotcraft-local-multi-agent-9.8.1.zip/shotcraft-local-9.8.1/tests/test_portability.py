"""Offline regression tests. Run: python -m unittest discover -s tests -v"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import tomllib
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import install


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def run(*args,env=None):
    return subprocess.run([sys.executable,*map(str,args)],capture_output=True,text=True,encoding='utf-8',timeout=60,env=env)


class InstallTests(unittest.TestCase):
    def test_all_clients_and_preservation(self):
        with tempfile.TemporaryDirectory(prefix='shotcraft test ') as td:
            base=Path(td);dirs={c:base/(c+' space & name') for c in ['claude','codex','opencode']}
            for d in dirs.values():d.mkdir()
            (dirs['claude']/'.claude.json').write_text('{"unrelated":123,"mcpServers":{"other":{"command":"other"}}}')
            (dirs['codex']/'config.toml').write_text('model = "my-model"\n# user comment\n')
            (dirs['opencode']/'opencode.jsonc').write_text('{ // existing settings\n"theme":"system", "mcp":{},}')
            args=[ROOT/'install.py','--client','all']
            for c,d in dirs.items():args += ['--'+c+'-dir',d]
            q=run(*args);self.assertEqual(q.returncode,0,q.stderr)
            for c,d in dirs.items():
                cfg=json.loads((d/'skills/shotcraft-local/config.json').read_text())
                self.assertEqual(cfg['skills_dir'],str(d/'skills'))
                self.assertTrue((d/'mcp/core/rpc.py').is_file())
                self.assertEqual(len(list((d/'skills').glob('*/SKILL.md'))),13) # twelve skills plus seed
                self.assertEqual(run(d/'shotcraft.py','--help').returncode,0)
                listed=run(d/'shotcraft.py','template','list');self.assertEqual(listed.returncode,0,listed.stderr)
            doc=json.loads((dirs['claude']/'.claude.json').read_text());self.assertEqual(doc['unrelated'],123);self.assertIn('other',doc['mcpServers']);self.assertNotIn('shotcraft-pro',doc['mcpServers'])
            codex=tomllib.loads((dirs['codex']/'config.toml').read_text());self.assertEqual(codex['model'],'my-model');self.assertEqual(len(codex['agents']),12)
            self.assertTrue(all(Path(a['config_file']).exists() for a in codex['agents'].values()))
            op=json.loads((dirs['opencode']/'opencode.jsonc').read_text());self.assertEqual(op['theme'],'system');self.assertEqual(len(op['mcp']),5)
            agent=(dirs['opencode']/'agents/reels-director.md').read_text();self.assertIn('mode: subagent',agent);self.assertNotIn('model: inherit',agent)
            marker=dirs['claude']/'skills/reels-motion/custom.txt';marker.write_text('keep')
            self.assertNotEqual(run(*args).returncode,0)
            self.assertEqual(marker.read_text(),'keep')
            q=run(*args,'--upgrade');self.assertEqual(q.returncode,0,q.stderr)
            self.assertTrue(list(dirs['claude'].glob('.shotcraft-backups/**/custom.txt')))

    def test_invalid_configuration_leaves_no_install(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);cfg=d/'opencode.json';cfg.write_text('{broken')
            q=run(ROOT/'install.py','--client','opencode','--opencode-dir',d)
            self.assertNotEqual(q.returncode,0);self.assertEqual(cfg.read_text(),'{broken');self.assertFalse((d/'skills').exists())

    def test_jsonc_preserves_comment_like_strings(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'config.jsonc';p.write_text('{"url":"https://example.test/a//b",/* comment */"text":"comma,}",}')
            self.assertEqual(install.read_json_config(p),{'url':'https://example.test/a//b','text':'comma,}'})

    def test_backup_failure_restores_existing_files(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);a=d/'one';b=d/'two';a.write_text('old one');b.write_text('old two')
            original=install.shutil.move
            def fail_second(src,dst):
                if src==str(b):raise OSError('simulated backup failure')
                return original(src,dst)
            with patch.object(install.shutil,'move',side_effect=fail_second):
                with self.assertRaises(OSError):install.transaction([(a,'new one'),(b,'new two')],d/'backup')
            self.assertEqual(a.read_text(),'old one');self.assertEqual(b.read_text(),'old two')

    def test_external_repo_untouched(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);repo=d/'upstream';repo.mkdir()
            for f in ['SKILL.md','references/pipeline.md','template/package.json']:
                p=repo/f;p.parent.mkdir(exist_ok=True);p.write_text('{}')
            before={str(p.relative_to(repo)):p.read_bytes() for p in repo.rglob('*') if p.is_file()}
            q=run(ROOT/'install.py','--repo',repo,'--claude-dir',d/'client');self.assertEqual(q.returncode,0,q.stderr)
            self.assertEqual(before,{str(p.relative_to(repo)):p.read_bytes() for p in repo.rglob('*') if p.is_file()})

    @unittest.skipIf(os.name=='nt','Symlink creation requires Windows privileges')
    def test_symlink_destination_refused(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);(d/'real').mkdir();(d/'link').symlink_to(d/'real',target_is_directory=True)
            self.assertNotEqual(run(ROOT/'install.py','--claude-dir',d/'link').returncode,0)
            self.assertEqual(list((d/'real').iterdir()),[])


class MCPTests(unittest.TestCase):
    def test_protocol_survives_bad_requests_on_every_server(self):
        for name,relative in install.MCP_SERVERS.items():
            with self.subTest(server=name):
                requests=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-06-18'}},{'jsonrpc':'2.0','id':2,'method':'tools/list'},[],{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'unknown','arguments':{}}},{'jsonrpc':'2.0','id':4,'method':'ping'}]
                q=subprocess.run([sys.executable,str(ROOT/relative)],input='not json\n'+'\n'.join(map(json.dumps,requests))+'\n',capture_output=True,text=True,timeout=15)
                self.assertEqual(q.returncode,0,q.stderr);rows=list(map(json.loads,q.stdout.splitlines()))
                self.assertEqual(rows[0]['error']['code'],-32700);self.assertEqual(rows[-1]['id'],4);self.assertEqual(rows[1]['result']['protocolVersion'],'2025-06-18')
                first=rows[2]['result']['tools'][0]
                invalid=[{'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':first['name'],'arguments':[]}},{'jsonrpc':'2.0','id':6,'method':'ping'}]
                q=subprocess.run([sys.executable,str(ROOT/relative)],input='\n'.join(map(json.dumps,invalid))+'\n',capture_output=True,text=True,timeout=15)
                self.assertEqual(q.returncode,0,q.stderr);rows=list(map(json.loads,q.stdout.splitlines()));self.assertEqual(rows[0]['error']['code'],-32602);self.assertEqual(rows[1]['id'],6)

    def test_library_search_returns_real_paths(self):
        sys.path.insert(0,str(ROOT/'mcp'))
        import shotcraft_library_mcp as lib
        result=lib.handle_tool_call('library_search_all',{'query':'card-stack','limit':3})
        self.assertTrue(result['ok'],result)
        self.assertGreater(len(result['shotcraft_upstream_matches']),0)
        self.assertTrue(all(Path(x['path']).is_file() for x in result['shotcraft_upstream_matches']))

    def test_nonzero_subprocess_cannot_report_success(self):
        sys.path.insert(0,str(ROOT/'mcp'))
        from core.utils import run_quiet
        result=run_quiet([sys.executable,'-c','print(\'{"ok":true}\');raise SystemExit(3)'])
        self.assertFalse(result['ok']);self.assertEqual(result['exit_code'],3)

    def test_recommendation_does_not_match_ai_inside_air(self):
        mod=load('token_saver_test','mcp/shotcraft_token_saver_mcp.py')
        self.assertNotEqual(mod.recommend_for_topic('air mendidih')['recommended_style'],'neural-network')
        self.assertEqual(mod.recommend_for_topic('otak dan saraf')['recommended_style'],'neural-network')


class RenderAndSpeechTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pipeline=load('pipeline_test','reels-production/scripts/one_shot_produce.py')
        cls.narrator=load('narrator_test','reels-narration/scripts/narrate.py')

    def test_frame_budget_exact(self):
        for total in [4,90,1200,1800]:
            scenes=[{'durationInFrames':30},{'durationInFrames':80},{'durationInFrames':150}]
            self.pipeline.fit_scene_frames(scenes,total)
            self.assertEqual(sum(s['durationInFrames'] for s in scenes),total)
            self.assertTrue(all(s['durationInFrames']>0 for s in scenes))
            self.assertEqual(scenes[-1]['startFrame']+scenes[-1]['durationInFrames'],total)

    def test_bad_duration_fails_before_workspace(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'never-created'
            q=run(ROOT/'reels-production/scripts/one_shot_produce.py','--workspace',d,'--duration','nan','--no-narration')
            self.assertNotEqual(q.returncode,0);self.assertFalse(d.exists())

    def test_offline_prevents_cloud_even_if_cached_online(self):
        with patch.dict(os.environ,{'SHOTCRAFT_OFFLINE':'1'}),patch.object(self.narrator,'_NET_ONLINE',True):
            self.assertFalse(self.narrator.is_online(timeout=0.1))

    def test_cloud_opt_in_is_enforced(self):
        with patch.object(self.narrator,'synth_edge_online') as synth:
            with self.assertRaisesRegex(RuntimeError,'allow-cloud'):
                self.narrator.synthesize_segment(provider='edge',spoken_text='uji',voice='',model_path='',api_key='',out_raw=Path('/tmp/unused.wav'),window_sec=1,allow_cloud=False)
            synth.assert_not_called()

    def test_missing_baseline_is_not_created_or_passed(self):
        import visual_regression as vr
        with tempfile.TemporaryDirectory() as td,patch.object(vr,'_golden_root',return_value=Path(td)/'golden'):
            result=vr.run_visual_regression(Path(td)/'out')
            self.assertFalse(result['visual_pass']);self.assertEqual(result['status'],'missing_baseline');self.assertFalse((Path(td)/'golden').exists())

    def test_renderer_failure_returns_nonzero(self):
        with tempfile.TemporaryDirectory() as td:
            q=run(ROOT/'reels-templates/scripts/smart_render.py', '--workspace', td, '--engine', 'remotion', '--mode', 'final', '--output', Path(td)/'never.mp4')
            self.assertNotEqual(q.returncode,0)
            self.assertFalse((Path(td)/'never.mp4').exists())

    def test_custom_fonts_are_context_local(self):
        import smart_render as sr
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier
        barrier=Barrier(2)
        def task(font):
            sr._ACTIVE_SCENE_CUSTOM_FONT.set(font);barrier.wait();return sr._ACTIVE_SCENE_CUSTOM_FONT.get()
        with ThreadPoolExecutor(max_workers=2) as pool:
            self.assertEqual(list(pool.map(task,['serif','mono'])),['serif','mono'])

if __name__=='__main__':unittest.main()
