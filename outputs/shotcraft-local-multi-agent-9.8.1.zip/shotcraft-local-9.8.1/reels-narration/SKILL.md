---
name: reels-narration
description: Produce Indonesian narration for Reels with Edge TTS, ElevenLabs, or offline Piper; normalize Indonesian numbers/units, generate SRT/VTT and Remotion word-level karaoke JSON, auto-duck BGM underneath speech, and sync animations to actual speech landmarks.
---

# Indonesian Narration, Karaoke Sync & Audio Ducking (v4.0)

Use the upstream `video-shotcraft` sound-design workflow together with `scripts/narrate.py`. Do not activate narration for explicit SFX-only or no-VO briefs.

Cloud speech requires --allow-cloud; --tts-mode offline excludes it even when a cloud provider is selected. An explicit failed provider is reported instead of silently becoming a different voice. Voice samples do not include a neural synthesis model.

## Voice Providers

- **Edge TTS (`--provider edge --allow-cloud`)**: Fast Indonesian synthesis (`id-ID-GadisNeural` or `id-ID-ArdiNeural`). Requires `edge-tts` package and network consent.
- **ElevenLabs (`--provider elevenlabs --allow-cloud`)**: Expressive multilingual synthesis (`eleven_multilingual_v2`). Requires `ELEVENLABS_API_KEY` and `ELEVENLABS_VOICE_ID` in local environment variables (never in chat).
- **Piper (`--provider piper --model /path/to/id_ID.onnx`)**: 100% offline local synthesis.

## What's New in v4.0 (`scripts/narrate.py`)

1. **Indonesian Text & Number Normalization (`--normalize-id`)**:
   - Automatically expands `Rp 150.000`, `3,5%`, `°C`, `km/jam`, `24/7`, `vs`, `dll` into natural spoken Indonesian while preserving concise `display_text` for on-screen captions.
2. **Automatic Subtitle & Karaoke JSON Export**:
   - Every run automatically generates:
     - `subtitles.srt` & `subtitles.vtt`
     - `remotion-subtitles.json` containing deterministic `words: [{word, startSec, endSec}]` mapped to the fitted audio window; inspect alignment_method because some providers use estimated word timings rather than measured alignment—ready to pass directly into `<KineticTypographyStage variant="karaoke-pill" words={...} />`!
3. **Automatic BGM Sidechain-Style Ducking (`--bgm <file> --duck-db -10`)**:
   - Loops/trims background music to match total video duration, smoothly attenuates BGM volume by `--duck-db` (default `-10dB`) during active speech windows `[start - 0.12s .. end + 0.20s]`, and outputs a stereo `master_mix.wav` ready for final video muxing.

## CLI Example

```sh
python "<this-skill>/scripts/narrate.py" \
  --manifest "./workspace/narration_manifest.json" \
  --provider edge \
  --voice id-ID-GadisNeural \
  --allow-cloud \
  --normalize-id \
  --bgm "./workspace/public/audio/bgm.mp3" \
  --duck-db -10 \
  --out-dir "./workspace/audio-render-01"
```
