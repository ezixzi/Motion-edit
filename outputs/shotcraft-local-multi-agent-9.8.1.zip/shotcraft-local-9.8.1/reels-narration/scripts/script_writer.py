#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Context-Grounded Bilingual Script & Storyboard Planner (`script_writer.py`).

Implements Audit & Benchmark Fixes:
- F01: Separates motorcycle warm-up fixture (`panasin motor`) from general mechanical topics (`mesin potong rumput`, `mesin cuci`, etc.).
  Provides the exact 6-shot Lawnmower Rotary Cutaway specification (Section 9) with explicit editorial assumption.
- F02: Token-based, word-boundary-aware semantic classification (`rantai makanan` -> `ecology`, `air mendidih` -> `physics-science`,
  `api kompor` -> `household-safety`, `API developer` -> `software-engineering`).
- F03: Zero fabricated statistics/percentages/RPM when user supplies topic-only prompt. Only step numbers or qualitative process states
  are used unless user data is provided.
- F08 & RQ01: Maintains single coherent style family across a video (`ref3-cutaway-mechanism` for mechanism explainers,
  `ref1-voxel-evidence` for tools/tutorials, `ref2-cinematic-character` for character stories, `ref4-minimal-ui` for UI workflows)
  without overwriting subject identity.
- F12: Separates Ollama connection probe timeout (0.8s) from generation timeout (15s), validates schema, and reports provider status.
- RQ05: Explicit `language` / `locale` (`id-ID` and `en-US`) support.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import socket
import sys
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
if str(SKILLS_ROOT / "mcp" / "core") not in sys.path:
    sys.path.insert(0, str(SKILLS_ROOT / "mcp" / "core"))

import style_map as sm_mod

# Fact-free, non-deceptive educational & narrative hooks (F03: zero ungrounded percentages or research claims)
CLEAN_HOOK_TEMPLATES_ID = {
    "how-it-works": [
        "Pernah perhatikan bagaimana {topic} bekerja dari awal sampai akhir?",
        "Di balik {topic}, ada urutan mekanisme yang saling terhubung.",
        "Mari kita lihat proses kerja di dalam {topic} tahap demi tahap.",
        "Begini alur kerja {topic} jika dilihat dari potongan bagian dalamnya.",
    ],
    "tools-list": [
        "Ini daftar fitur dan bukti tampilan langsung dari {topic}.",
        "Mari kita bedah fungsi utama {topic} langsung dari layarnya.",
    ],
    "storytelling": [
        "Semua berawal dari satu ide sederhana di balik {topic}.",
        "Begini cerita dan alur kreatif bagaimana {topic} membantu pekerjaanmu.",
    ],
    "workflow": [
        "Alur kerja {topic} dari langkah pertama hingga selesai.",
        "Ringkasan tahapan {topic} yang terstruktur dan rapi.",
    ],
}

CLEAN_HOOK_TEMPLATES_EN = {
    "how-it-works": [
        "Ever wondered how {topic} actually works from the inside?",
        "Inside {topic}, each component drives the next stage of the mechanism.",
    ],
    "tools-list": [
        "Here is a direct look at {topic} with real interface evidence.",
    ],
    "storytelling": [
        "Every great workflow behind {topic} starts with one clear idea.",
    ],
    "workflow": [
        "How the {topic} workflow progresses from input to final output.",
    ],
}


def detect_language(text: str, explicit_lang: str = "") -> str:
    if explicit_lang:
        low = explicit_lang.strip().lower()
        return "en-US" if low.startswith("en") else "id-ID"
    t = (text or "").lower()
    tokens = set(re.findall(r"[a-z]+", t))
    en_markers = {"how", "works", "work", "the", "inside", "engine", "lawnmower", "mower", "solar", "workflow", "guide", "what", "why"}
    id_markers = {"cara", "kerja", "mesin", "rumput", "potong", "panel", "surya", "rantai", "makanan", "air", "mendidih", "apa", "kenapa", "bagaimana"}
    en_hits = len(tokens & en_markers)
    id_hits = len(tokens & id_markers)
    return "en-US" if (en_hits > id_hits and en_hits >= 1) else "id-ID"


def classify_topic_and_subject(text: str, requested_style: str = "auto-context") -> dict:
    """
    F01, F02 & F08:
    Tokenizes input text with strict word boundaries, separates user intent (`how-it-works`, `tools-list`,
    `storytelling`, `workflow`, `myth-busting`) from subject domain (`lawnmower-rotary`, `ecology`,
    `physics-thermodynamics`, `solar-energy`, `household-safety`, `software-engineering`, `ai-science`,
    `motorcycle-warmup`, `culinary-coffee`), and records classification reasoning.
    """
    raw = (text or "").strip()
    t_low = raw.lower()
    tokens = re.findall(r"[a-z0-9_]+", t_low)
    token_set = set(tokens)
    reasons = []

    # 1. Determine Intent separately from Subject Domain
    if any(p in t_low for p in ("cara kerja", "how it works", "how does", "mekanisme", "proses", "siklus", "rantai")):
        intent = "how-it-works"
        reasons.append("Matched mechanism/process phrase ('cara kerja' / 'proses' / 'how it works').")
    elif any(w in token_set for w in ("daftar", "rekomendasi", "tools", "website", "aplikasi", "hosting", "cloudflare", "gratis")):
        intent = "tools-list"
        reasons.append("Matched tool/service curation keywords.")
    elif any(w in token_set for w in ("cerita", "kisah", "sejarah", "story", "animator", "karakter")):
        intent = "storytelling"
        reasons.append("Matched narrative/character storytelling keywords.")
    elif any(w in token_set for w in ("workflow", "otomasi", "automation", "pipeline", "dashboard", "ui")):
        intent = "workflow"
        reasons.append("Matched UI/software workflow keywords.")
    elif any(w in token_set for w in ("cara", "langkah", "tutorial", "panduan", "setup", "install")):
        intent = "tutorial"
        reasons.append("Matched step-by-step tutorial keywords.")
    else:
        intent = "how-it-works"
        reasons.append("Defaulted intent to explanatory mechanism ('how-it-works').")

    # 2. Disambiguate "API" (software) vs "api" (fire/flame) — F02 / T03
    has_fire_context = bool(token_set & {"kompor", "gas", "kebakaran", "bakar", "panas", "unggun", "oksigen", "memasak", "dapur", "padam"})
    has_software_context = bool(token_set & {"developer", "endpoint", "rest", "json", "http", "backend", "server", "coding", "kode", "python", "javascript", "sdk", "auth", "webhook"})
    has_uppercase_api = bool(re.search(r"\bAPI\b", raw))

    # 3. Determine Specific Subject & Domain (Order matters: specific entities first!)
    if ("lawnmower" in token_set or "mower" in token_set) or (
        "rumput" in token_set and ("potong" in token_set or "mesin" in token_set)
    ):
        domain = "mechanical-explainer"
        subject_id = "lawnmower-rotary"
        asset_id = "lawnmower-rotary-rig"
        assumption = "Mesin pemotong rumput dorong (walk-behind rotary lawnmower) dengan bilah putar horizontal, rumah dek pelindung, dan kantong penampung belakang."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched rotary lawnmower entity ('mesin potong rumput' / 'lawnmower').")
    elif "rantai" in token_set and "makanan" in token_set:
        domain = "ecology"
        subject_id = "food-chain-ecology"
        asset_id = "ecology-trophic-cycle"
        assumption = "Ekosistem darat: Produsen (tumbuhan hijau) -> Konsumen I (herbivora) -> Konsumen II (karnivora) -> Dekomposer (pengurai)."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched ecology phrase 'rantai makanan' (prevented false 'ai' substring match).")
    elif ("air" in token_set and ("mendidih" in token_set or "uap" in token_set or "panas" in token_set or "boil" in token_set)) or "termal" in token_set:
        domain = "physics-thermodynamics"
        subject_id = "water-thermodynamics"
        asset_id = "thermal-convection-vessel"
        assumption = "Pemanasan air pada tekanan atmosfer standar: hantaran panas dasar wadah, arus konveksi, hingga perubahan fase cair ke uap."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched thermodynamics/boiling water ('air mendidih', prevented false 'ai' substring match).")
    elif ("panel" in token_set and "surya" in token_set) or ("solar" in token_set and ("panel" in token_set or "cell" in token_set)) or "fotovoltaik" in token_set:
        domain = "renewable-energy"
        subject_id = "solar-panel"
        asset_id = "photovoltaic-cell-cutaway"
        assumption = "Panel surya silikon fotovoltaik dengan inverter arus searah (DC) ke arus bolak-balik (AC)."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched photovoltaic solar panel ('panel surya').")
    elif "api" in token_set and (has_fire_context or (not has_software_context and not has_uppercase_api)):
        domain = "household-safety"
        subject_id = "combustion-fire-triangle"
        asset_id = "stove-burner-cutaway"
        assumption = "Pembakaran gas LPG pada tungku kompor rumah tangga (segitiga api: bahan bakar, oksigen, dan sumber panas)."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Disambiguated 'api' as physical fire/flame based on context.")
    elif ("api" in token_set and (has_software_context or has_uppercase_api)) or bool(
        token_set & {"coding", "python", "react", "remotion", "terminal", "developer", "git", "cloudflare", "hosting", "database"}
    ):
        domain = "software-engineering"
        subject_id = "software-api-system" if "api" in token_set else "ui-workflow-cards"
        asset_id = "voxel-evidence-stage" if intent == "tools-list" else "software-architecture-flow"
        assumption = "Antarmuka Pemrograman Aplikasi (Application Programming Interface / REST HTTP)." if "api" in token_set else "Alur perangkat lunak modern."
        default_family = "ref1-voxel-evidence" if intent in ("tools-list", "tutorial") else "ref4-minimal-ui"
        reasons.append("Disambiguated software/API/developer topic.")
    elif bool(token_set & {"panasin", "memanaskan"}) and bool(token_set & {"motor", "oli", "injeksi", "karburator"}):
        domain = "automotive-maintenance"
        subject_id = "motorcycle-warmup"
        asset_id = "combustion-engine"
        assumption = "Mesin sepeda motor 4-tak berpendingin udara/cairan dengan sistem pelumasan pompa oli."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched specific motorcycle warm-up topic ('panasin motor').")
    elif bool(token_set & {"diesel", "solar"}) and bool(token_set & {"mesin", "mobil", "truk", "bus", "kendaraan", "otomotif", "automotive", "truck"}):
        domain = "automotive-diesel"
        subject_id = "diesel-engine-vehicle"
        asset_id = "diesel-engine-cutaway"
        assumption = "Mesin pembakaran dalam jenis diesel (mesin solar) untuk kendaraan bermotor, sistem injeksi, borang piston, dan turbin pengendap."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched automotive diesel engine topic ('mesin solar' / 'mesin diesel').")
    elif bool(token_set & {"piston", "silinder", "knalpot", "karburator", "injeksi", "crankshaft", "poros"}):
        domain = "mechanical-explainer"
        subject_id = "combustion-engine"
        asset_id = "combustion-engine"
        assumption = "Mekanisme mesin pembakaran dalam 4-langkah (hisap, kompresi, usaha, buang)."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched internal combustion engine components.")
    elif bool(token_set & {"kopi", "coffee", "espresso", "kafein", "seduh", "arabika", "robusta", "barista"}):
        domain = "culinary"
        subject_id = "coffee-extraction"
        asset_id = "coffee-extraction-stage"
        assumption = "Ekstraksi seduh kopi manual (pour-over / espresso) dari biji kopi giling."
        default_family = "coffee-editorial-3d"
        reasons.append("Matched coffee/culinary keywords.")
    elif bool(token_set & {"ai", "llm", "chatgpt", "gpt", "transformer", "neural", "neuron", "otak", "sinapsis"}) or any(
        p in t_low for p in ("artificial intelligence", "kecerdasan buatan", "machine learning", "deep learning", "model machine learning")
    ):
        # Note: 'model' alone (e.g. 'model baju') does NOT trigger AI!
        domain = "ai-science"
        subject_id = "neural-network-ai"
        asset_id = "neural-network-stage"
        assumption = "Arsitektur jaringan saraf tiruan / pemrosesan sinyal sinaptik."
        default_family = "neural-network"
        reasons.append("Matched whole-word AI / neuroscience terms.")
    elif "model" in token_set and bool(token_set & {"baju", "pakaian", "fashion", "jahit", "kain", "desain"}):
        domain = "fashion-design"
        subject_id = "system-mechanism"
        asset_id = "system-flowchart"
        assumption = "Desain pola dan konstruksi pakaian (fashion apparel)."
        default_family = "ref2-cinematic-character"
        reasons.append("Disambiguated 'model baju' as fashion design, not ML model.")
    elif bool(token_set & {"arsitek", "bangunan", "gedung", "struktur", "tata ruang", "blueprint", "fondasi", "kolom", "balok", "atap"}) or bool(
        token_set & {"architecture", "building", "architectural", "construction", "floor plan"}
    ):
        domain = "architectural"
        subject_id = "building-structure"
        asset_id = "architectural-cutaway"
        assumption = "Struktur bangunan arsitektur dengan fondasi, kolom, balok, atap, dan tata ruang interior."
        default_family = "ref3-cutaway-mechanism"
        reasons.append("Matched architectural/building design topic.")
    elif ("talking head" in t_low) or bool(token_set & {"pidato", "ucapan", "pembicara", "presenter", "vlog", "wawancara", "presentasi", "narator", "spokesperson"}):
        domain = "talking-head"
        subject_id = "talking-head-presenter"
        asset_id = "talking-head-face-aware"
        assumption = "Pembicara atau presenter berbicara langsung ke kamera dengan framing face-aware, caption per segmen, dan gaya visual konsisten per beat."
        default_family = "ref2-cinematic-character"
        reasons.append("Matched talking-head / presenter topic.")
    else:
        domain = "general-explainer"
        subject_id = "system-mechanism"
        asset_id = "system-flowchart"
        assumption = f"Penjelasan terstruktur mengenai mekanisme dan alur kerja {raw}."
        if intent == "tools-list":
            default_family = "ref1-voxel-evidence"
        elif intent == "storytelling":
            default_family = "ref2-cinematic-character"
        elif intent == "workflow":
            default_family = "ref4-minimal-ui"
        else:
            default_family = "ref3-cutaway-mechanism"
        reasons.append("Classified as general topic using intent-driven style family.")

    resolved_style = sm_mod.resolve_style_id(
        requested_style, default_style=default_family, strict=False
    )
    style_spec = sm_mod.get_style_spec(resolved_style)

    return {
        "intent": intent,
        "domain": domain,
        "subject_id": subject_id,
        "asset_id": asset_id,
        "assumption": assumption,
        "default_style_family": default_family,
        "resolved_style": resolved_style,
        "bgm_track": style_spec.get("bgm_track", "explainer-groove-104bpm.wav"),
        "sfx_pack": style_spec.get("sfx_pack", "organic"),
        "caption_style": style_spec.get("caption_style", ""),
        "classification_reasons": reasons,
    }


def check_ollama_status(host_url: str, connect_timeout: float = 0.8) -> dict:
    """F12: Separates fast TCP connection probe from LLM generation timeout and reports status."""
    if os.environ.get("SHOTCRAFT_DISABLE_OLLAMA") == "1":
        return {"available": False, "status": "disabled_by_env", "host": host_url}
    try:
        req = urllib.request.Request(f"{host_url.rstrip('/')}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=connect_timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
            models = [m.get("name") for m in data.get("models", []) if isinstance(m, dict)]
            return {"available": True, "status": "online", "host": host_url, "models": models}
    except Exception as exc:
        return {"available": False, "status": f"unreachable ({type(exc).__name__})", "host": host_url}


def try_local_ollama_generation(
    topic: str,
    duration_sec: float,
    style: str,
    classification: dict,
    audience: str = "umum",
) -> tuple[list | None, dict]:
    """
    F12: Queries local Ollama with separate connection probe (0.8s) and generation timeout (15.0s),
    validates response schema, and returns `(scenes, provider_status)`.
    """
    ollama_base = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
    probe = check_ollama_status(ollama_base, connect_timeout=0.8)
    if not probe["available"]:
        return None, probe

    model = os.environ.get("SHOTCRAFT_LLM_MODEL", "qwen2.5:7b-instruct")
    gen_timeout = float(os.environ.get("SHOTCRAFT_OLLAMA_TIMEOUT", "15.0"))
    prompt = (
        f"Buatkan JSON object dengan key 'scenes' berisi array 4-6 scene video penjelasan tentang '{topic}' "
        f"(subjek: {classification['subject_id']}, asumsi: {classification['assumption']}) untuk audiens {audience}. "
        "PENTING: Jangan mengarang statistik, persentase, atau angka riset yang tidak diberikan pengguna. "
        "Setiap scene wajib memiliki: id, eyebrow, headline, subcopy, narration, mechanismStep, windowContentLines (array 3 string)."
    )
    try:
        payload = json.dumps({"model": model, "prompt": prompt, "stream": False, "format": "json"}).encode("utf-8")
        req = urllib.request.Request(f"{ollama_base}/api/generate", data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=gen_timeout) as resp:
            body = json.loads(resp.read().decode("utf-8", errors="replace"))
            parsed = json.loads(body.get("response", "{}"))
            scenes = parsed.get("scenes", parsed) if isinstance(parsed, dict) else parsed
            if isinstance(scenes, list) and len(scenes) >= 3 and all(isinstance(x, dict) and x.get("headline") and x.get("narration") for x in scenes):
                probe["status"] = "generated_valid_schema"
                probe["model_used"] = model
                return scenes, probe
            probe["status"] = "invalid_schema_returned"
    except Exception as exc:
        probe["status"] = f"generation_error ({type(exc).__name__}: {exc})"
    return None, probe


def _build_lawnmower_6shot_scenes(topic: str, style_id: str, fps: int, duration_sec: float, lang: str = "id-ID") -> list[dict]:
    """
    Section 9 & RQ02:
    Builds the exact 6-shot specification for 'Cara kerja mesin potong rumput':
    - Editorial assumption: walk-behind rotary lawnmower with electric/combustion motor, vertical shaft,
      horizontal rotary blade, protective deck housing, and rear collection chute/bag.
    - Zero fabricated RPM or fake efficiency percentages!
    - Coherent visual style across all 6 shots (defaulting to `ref3-cutaway-mechanism` unless user overrides style).
    """
    n_shots = 6
    total_frames = max(180, int(round(max(24.0, duration_sec) * fps)))
    base_f = total_frames // n_shots
    rem_f = total_frames - base_f * (n_shots - 1)
    assumption = "Mesin pemotong rumput dorong (walk-behind rotary lawnmower) dengan bilah putar horizontal, rumah dek pelindung, dan kantong penampung belakang."

    if lang.startswith("en"):
        raw_shots = [
            {
                "id": "scene-01",
                "eyebrow": "STAGE 01 · OVERVIEW & DECK",
                "stateBadge": "WALK-BEHIND ROTARY MOWER",
                "mechanismStep": "overview-deck",
                "action": "camera_push_to_deck",
                "camera": {"preset": "dolly-push", "target_component": "mower_deck", "zoom": 1.08},
                "transitionIn": "cut",
                "transitionOut": "crossfade",
                "headline": "How does a walk-behind rotary lawnmower cut grass cleanly?",
                "subcopy": "Beneath the protective deck sits a coordinated system of motor, vertical shaft, airfoil blade, and airflow chute.",
                "narration": "Ever wondered how a rotary lawnmower cuts grass so evenly? Beneath the deck, four connected mechanisms work in sequence.",
                "windowTitle": "ROTARY LAWNMOWER — SYSTEM ASSUMPTION",
                "windowContentLines": [
                    "Tool Type: Walk-behind rotary mower",
                    "Core Parts: Motor, shaft, blade & deck",
                    "Collector: Rear discharge chute & bag",
                ],
                "callouts": [
                    {"label": "HANDLE & FRAME", "tx": 280, "ty": 760, "px": 220, "py": 1120},
                    {"label": "MOTOR HOUSING", "tx": 480, "ty": 790, "px": 480, "py": 1120},
                    {"label": "CUTTING DECK", "tx": 640, "ty": 910, "px": 740, "py": 1120},
                ],
                "emphasisWords": ["ROTARY", "DECK", "SEQUENCE"],
                "accent": "#1D7A46",
            },
            {
                "id": "scene-02",
                "eyebrow": "STAGE 02 · POWER SOURCE",
                "stateBadge": "MOTOR ENERGY TO VERTICAL SHAFT",
                "mechanismStep": "power-source-to-shaft",
                "action": "energy_flow_to_shaft",
                "camera": {"preset": "focus-pull", "target_component": "motor_unit", "zoom": 1.15},
                "transitionIn": "crossfade",
                "transitionOut": "cutaway-peel",
                "headline": "The upper drive motor converts energy into rotational torque",
                "subcopy": "When activated, the motor spins the central drive shaft downward into the cutting chamber.",
                "narration": "First, the upper motor converts energy into steady rotational torque and drives the central shaft downward.",
                "windowTitle": "STAGE 2 — POWER TRANSMISSION",
                "windowContentLines": [
                    "Input: Top drive motor unit",
                    "Transmission: Vertical drive shaft",
                    "Direction: Downward into deck chamber",
                ],
                "callouts": [
                    {"label": "DRIVE MOTOR", "tx": 480, "ty": 760, "px": 240, "py": 1120},
                    {"label": "ENERGY FLOW", "tx": 480, "ty": 845, "px": 480, "py": 1120},
                    {"label": "DRIVE SHAFT", "tx": 480, "ty": 920, "px": 720, "py": 1120},
                ],
                "emphasisWords": ["MOTOR", "TORQUE", "SHAFT"],
                "accent": "#2563EB",
            },
            {
                "id": "scene-03",
                "eyebrow": "STAGE 03 · SHAFT & BLADE COUPLING",
                "stateBadge": "RIGID MECHANICAL LINKAGE",
                "mechanismStep": "shaft-to-blade-coupling",
                "action": "coupled_shaft_blade_rotation",
                "camera": {"preset": "cinematic-orbit", "target_component": "blade_hub", "zoom": 1.20},
                "transitionIn": "cutaway-peel",
                "transitionOut": "object-match",
                "headline": "The vertical shaft locks directly into the horizontal cutting blade",
                "subcopy": "As the shaft turns, the balanced steel blade rotates in the same plane inside the deck.",
                "narration": "Second, the vertical shaft connects to the center hub, spinning the horizontal blade inside the protective housing.",
                "windowTitle": "STAGE 3 — SHAFT TO BLADE LINK",
                "windowContentLines": [
                    "Drive Shaft: Vertical central axis",
                    "Center Hub: Bolts blade to shaft",
                    "Rotary Blade: Spins horizontally",
                ],
                "callouts": [
                    {"label": "VERTICAL SHAFT", "tx": 480, "ty": 835, "px": 230, "py": 1120},
                    {"label": "CENTER HUB", "tx": 480, "ty": 925, "px": 480, "py": 1120},
                    {"label": "ROTARY BLADE", "tx": 635, "ty": 925, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["SHAFT", "HUB", "HORIZONTAL"],
                "accent": "#D97706",
            },
            {
                "id": "scene-04",
                "eyebrow": "STAGE 04 · LIFT & SHEAR CONTACT",
                "stateBadge": "UPWARD AIRFLOW & CLEAN CUT",
                "mechanismStep": "blade-grass-contact",
                "action": "blade_lift_and_shear_grass",
                "camera": {"preset": "dolly-push", "target_component": "blade_edge", "zoom": 1.28},
                "transitionIn": "object-match",
                "transitionOut": "slide",
                "headline": "Curved blade wings lift the grass upright as the sharp edge slices",
                "subcopy": "Upward airflow raises each grass blade so the leading cutting edge shears it cleanly at uniform height.",
                "narration": "Third, the curved rear edge creates upward airflow that lifts the grass upright, while the sharp leading edge slices it cleanly.",
                "windowTitle": "STAGE 4 — LIFT & CUT CONTACT",
                "windowContentLines": [
                    "Airfoil Wing: Lifts grass blades upright",
                    "Leading Edge: Shears at contact point",
                    "Result: Even cut across the lawn",
                ],
                "callouts": [
                    {"label": "UPWARD LIFT", "tx": 340, "ty": 945, "px": 230, "py": 1120},
                    {"label": "CUTTING EDGE", "tx": 520, "ty": 935, "px": 480, "py": 1120},
                    {"label": "GRASS CONTACT", "tx": 640, "ty": 965, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["AIRFLOW", "UPRIGHT", "SLICES"],
                "accent": "#16A34A",
            },
            {
                "id": "scene-05",
                "eyebrow": "STAGE 05 · CLIPPING DISCHARGE PATH",
                "stateBadge": "DECK CHANNEL TO COLLECTION BAG",
                "mechanismStep": "clippings-airflow-to-bag",
                "action": "particle_flow_to_collector",
                "camera": {"preset": "focus-pull", "target_component": "discharge_chute", "zoom": 1.12},
                "transitionIn": "slide",
                "transitionOut": "crossfade",
                "headline": "Circulating airflow carries grass clippings through the chute into the bag",
                "subcopy": "The curved deck interior guides cut grass along a spiral path straight into the rear collector.",
                "narration": "Fourth, circulating air inside the curved deck pushes the cut clippings through the rear chute into the collection bag.",
                "windowTitle": "STAGE 5 — CLIPPING PATHWAY",
                "windowContentLines": [
                    "Deck Chamber: Guides circulating air",
                    "Rear Chute: Channels cut clippings",
                    "Collector Bag: Traps clippings cleanly",
                ],
                "callouts": [
                    {"label": "DECK AIRFLOW", "tx": 380, "ty": 900, "px": 230, "py": 1120},
                    {"label": "REAR CHUTE", "tx": 610, "ty": 875, "px": 480, "py": 1120},
                    {"label": "COLLECTOR BAG", "tx": 760, "ty": 835, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["CURVED", "CHUTE", "BAG"],
                "accent": "#0284C7",
            },
            {
                "id": "scene-06",
                "eyebrow": "STAGE 06 · COMPLETE CYCLE SUMMARY",
                "stateBadge": "POWER -> LIFT & CUT -> COLLECT",
                "mechanismStep": "full-cycle-summary",
                "action": "camera_return_to_overview",
                "camera": {"preset": "crane-rise", "target_component": "full_mower", "zoom": 1.0},
                "transitionIn": "crossfade",
                "transitionOut": "cut",
                "headline": "Three linked stages: transmit power, lift and slice, then channel into the bag",
                "subcopy": "From motor shaft to airfoil blade and rear collector, every part works together as one continuous mechanism.",
                "narration": "In summary: the motor spins the shaft, the blade lifts and slices the grass, and airflow carries the clippings into the bag.",
                "windowTitle": "SUMMARY — ROTARY MOWER MECHANISM",
                "windowContentLines": [
                    "1. Power: Motor spins vertical shaft",
                    "2. Cut: Blade lifts & slices grass",
                    "3. Collect: Airflow channels to bag",
                ],
                "callouts": [
                    {"label": "1. POWER SHAFT", "tx": 460, "ty": 790, "px": 230, "py": 1120},
                    {"label": "2. LIFT & CUT", "tx": 480, "ty": 935, "px": 480, "py": 1120},
                    {"label": "3. BAG COLLECT", "tx": 740, "ty": 845, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["SPINS", "SLICES", "COLLECT"],
                "accent": "#1D7A46",
            },
        ]
    else:
        raw_shots = [
            {
                "id": "scene-01",
                "eyebrow": "TAHAP 01 · PENGENALAN ALAT",
                "stateBadge": "MESIN DORONG BILAH ROTARY",
                "mechanismStep": "overview-deck",
                "action": "camera_push_to_deck",
                "camera": {"preset": "dolly-push", "target_component": "mower_deck", "zoom": 1.08},
                "transitionIn": "cut",
                "transitionOut": "crossfade",
                "headline": "Bagaimana cara kerja mesin potong rumput dorong memotong dengan rata?",
                "subcopy": "Di balik rumah dek pelindung, sumber tenaga, poros vertikal, bilah putar, dan saluran kantong bekerja berurutan.",
                "narration": "Pernah kepikiran nggak, gimana mesin potong rumput dorong bisa motong serapi ini? Di balik dek pelindungnya, ada mekanisme yang saling terhubung.",
                "windowTitle": "ASUMSI ALAT — MESIN DORONG ROTARY",
                "windowContentLines": [
                    "Jenis Alat: Mesin dorong bilah rotary",
                    "Bagian Inti: Motor, poros, bilah & dek",
                    "Penampung: Saluran & kantong belakang",
                ],
                "callouts": [
                    {"label": "RANGKA DORONG", "tx": 280, "ty": 760, "px": 220, "py": 1120},
                    {"label": "SUMBER TENAGA", "tx": 480, "ty": 790, "px": 480, "py": 1120},
                    {"label": "RUMAH DEK", "tx": 640, "ty": 910, "px": 740, "py": 1120},
                ],
                "emphasisWords": ["DORONG", "DEK", "MEKANISME"],
                "accent": "#1D7A46",
            },
            {
                "id": "scene-02",
                "eyebrow": "TAHAP 02 · ASAL TENAGA PENGGERAK",
                "stateBadge": "ALIRAN TENAGA MENUJU POROS",
                "mechanismStep": "power-source-to-shaft",
                "action": "energy_flow_to_shaft",
                "camera": {"preset": "focus-pull", "target_component": "motor_unit", "zoom": 1.15},
                "transitionIn": "crossfade",
                "transitionOut": "cutaway-peel",
                "headline": "Motor penggerak di atas dek mengubah energi menjadi putaran poros vertikal",
                "subcopy": "Saat dinyalakan, sumber tenaga memutar poros tengah secara langsung ke arah ruang pemotongan di bawah dek.",
                "narration": "Pertama, begitu mesin nyala, motor penggerak di bagian atas langsung memutar poros vertikal menuju ruang bawah dek.",
                "windowTitle": "TAHAP 2 — TRANSMISI TENAGA KE POROS",
                "windowContentLines": [
                    "Sumber Tenaga: Unit motor penggerak atas",
                    "Penerus Daya: Poros vertikal tengah",
                    "Arah Aliran: Menuju ruang bawah dek",
                ],
                "callouts": [
                    {"label": "MOTOR PENGGERAK", "tx": 480, "ty": 760, "px": 240, "py": 1120},
                    {"label": "ALIRAN TENAGA", "tx": 480, "ty": 845, "px": 480, "py": 1120},
                    {"label": "POROS VERTIKAL", "tx": 480, "ty": 920, "px": 720, "py": 1120},
                ],
                "emphasisWords": ["TENAGA", "PUTAR", "POROS"],
                "accent": "#2563EB",
            },
            {
                "id": "scene-03",
                "eyebrow": "TAHAP 03 · HUBUNGAN POROS & BILAH",
                "stateBadge": "ROTASI MEKANIS TERHUBUNG",
                "mechanismStep": "shaft-to-blade-coupling",
                "action": "coupled_shaft_blade_rotation",
                "camera": {"preset": "cinematic-orbit", "target_component": "blade_hub", "zoom": 1.20},
                "transitionIn": "cutaway-peel",
                "transitionOut": "object-match",
                "headline": "Poros vertikal mengunci dudukan tengah untuk memutar bilah secara horizontal",
                "subcopy": "Poros dan bilah terhubung pada satu sumbu putar sehingga putaran poros langsung memutar kedua ujung bilah.",
                "narration": "Kedua, ujung poros tengah ini mengunci dudukan bilah, sehingga bilah baja di bawahnya ikut berputar mendatar.",
                "windowTitle": "TAHAP 3 — POROS MEMUTAR BILAH",
                "windowContentLines": [
                    "Poros Tengah: Sumbu putar vertikal",
                    "Dudukan Inti: Mengikat bilah ke poros",
                    "Bilah Rotary: Berputar pada bidang datar",
                ],
                "callouts": [
                    {"label": "POROS TENGAH", "tx": 480, "ty": 835, "px": 230, "py": 1120},
                    {"label": "DUDUKAN BILAH", "tx": 480, "ty": 925, "px": 480, "py": 1120},
                    {"label": "BILAH PUTAR", "tx": 635, "ty": 925, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["POROS", "DUDUKAN", "BILAH"],
                "accent": "#D97706",
            },
            {
                "id": "scene-04",
                "eyebrow": "TAHAP 04 · PROSES PEMOTONGAN RUMPUT",
                "stateBadge": "ANGKAT TEGAK & POTONG DI TITIK KONTAK",
                "mechanismStep": "blade-grass-contact",
                "action": "blade_lift_and_shear_grass",
                "camera": {"preset": "dolly-push", "target_component": "blade_edge", "zoom": 1.28},
                "transitionIn": "object-match",
                "transitionOut": "slide",
                "headline": "Sirip lengkung bilah mengangkat rumput tegak sebelum sisi tajam memotongnya",
                "subcopy": "Aliran udara ke atas menahan helai rumput tetap tegak saat sisi depan bilah menebas pada ketinggian yang rata.",
                "narration": "Ketiga, sirip lengkung di belakang bilah mengangkat helai rumput berdiri tegak, tepat sebelum sisi tajamnya menebas dengan rata.",
                "windowTitle": "TAHAP 4 — KONTAK BILAH & RUMPUT",
                "windowContentLines": [
                    "Sirip Belakang: Mengangkat helai rumput",
                    "Sisi Tajam Depan: Memotong di titik kontak",
                    "Hasil Potong: Tinggi rumput seragam",
                ],
                "callouts": [
                    {"label": "ANGKATAN UDARA", "tx": 340, "ty": 945, "px": 230, "py": 1120},
                    {"label": "SISI POTONG", "tx": 520, "ty": 935, "px": 480, "py": 1120},
                    {"label": "KONTAK RUMPUT", "tx": 640, "ty": 965, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["UDARA", "TEGAK", "MEMOTONG"],
                "accent": "#16A34A",
            },
            {
                "id": "scene-05",
                "eyebrow": "TAHAP 05 · JALUR POTONGAN RUMPUT",
                "stateBadge": "DEK -> SALURAN -> KANTONG PENAMPUNG",
                "mechanismStep": "clippings-airflow-to-bag",
                "action": "particle_flow_to_collector",
                "camera": {"preset": "focus-pull", "target_component": "discharge_chute", "zoom": 1.12},
                "transitionIn": "slide",
                "transitionOut": "crossfade",
                "headline": "Putaran udara di dalam dek mendorong potongan rumput masuk ke kantong",
                "subcopy": "Dinding dalam dek yang melengkung mengarahkan partikel potongan rumput melewati saluran belakang menuju kantong.",
                "narration": "Keempat, putaran udara di dalam dek mendorong potongan rumput tadi masuk melewati saluran belakang ke kantong penampung.",
                "windowTitle": "TAHAP 5 — JALUR ALIRAN POTONGAN",
                "windowContentLines": [
                    "Ruang Dek: Mengarahkan putaran udara",
                    "Saluran Buang: Jalur menuju belakang",
                    "Kantong: Menampung potongan rumput",
                ],
                "callouts": [
                    {"label": "ALIRAN DEK", "tx": 380, "ty": 900, "px": 230, "py": 1120},
                    {"label": "SALURAN BUANG", "tx": 610, "ty": 875, "px": 480, "py": 1120},
                    {"label": "KANTONG PENAMPUNG", "tx": 760, "ty": 835, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["ALIRAN", "SALURAN", "KANTONG"],
                "accent": "#0284C7",
            },
            {
                "id": "scene-06",
                "eyebrow": "TAHAP 06 · RANGKUMAN MEKANISME",
                "stateBadge": "TENAGA -> PUTAR & POTONG -> TAMPUNG",
                "mechanismStep": "full-cycle-summary",
                "action": "camera_return_to_overview",
                "camera": {"preset": "crane-rise", "target_component": "full_mower", "zoom": 1.0},
                "transitionIn": "crossfade",
                "transitionOut": "cut",
                "headline": "Rangkuman: motor memutar poros, bilah mengangkat dan memotong, udara membawa ke kantong",
                "subcopy": "Ketiga tahap bekerja berkesinambungan dari sumber tenaga hingga rumput terpotong rapi dan tertampung bersih.",
                "narration": "Jadi alurnya simpel: motor memutar poros, bilah mengangkat lalu memotong rumput, dan udara membawanya bersih ke kantong.",
                "windowTitle": "RANGKUMAN — 3 TAHAP INTI",
                "windowContentLines": [
                    "Tahap 1: Motor memutar poros vertikal",
                    "Tahap 2: Bilah mengangkat & memotong",
                    "Tahap 3: Udara mendorong ke kantong",
                ],
                "callouts": [
                    {"label": "1. TENAGA POROS", "tx": 460, "ty": 790, "px": 230, "py": 1120},
                    {"label": "2. POTONG RUMPUT", "tx": 480, "ty": 935, "px": 480, "py": 1120},
                    {"label": "3. MASUK KANTONG", "tx": 740, "ty": 845, "px": 730, "py": 1120},
                ],
                "emphasisWords": ["MOTOR", "MEMOTONG", "KANTONG"],
                "accent": "#1D7A46",
            },
        ]

    scenes = []
    cur_f = 0
    for idx, s_raw in enumerate(raw_shots):
        dur_f = rem_f if idx == len(raw_shots) - 1 else base_f
        s_raw["durationInFrames"] = dur_f
        s_raw["startFrame"] = cur_f
        s_raw["subjectId"] = "lawnmower-rotary"
        s_raw["assetId"] = "lawnmower-rotary-rig"
        s_raw["cutawayKind"] = "lawnmower"
        s_raw["assumption"] = assumption
        s_raw["language"] = lang
        s_raw["visualMode"] = style_id
        s_raw["evidenceCardKind"] = ["bars", "quote", "checklist"][idx % 3]
        s_raw["metric"] = ""
        s_raw["unit"] = ""
        s_raw["stickerText"] = f"TAHAP 0{idx + 1}" if not lang.startswith("en") else f"STAGE 0{idx + 1}"
        norm_sc = sm_mod.normalize_and_validate_scene_contract(
            s_raw, idx=idx, default_subject_id="lawnmower-rotary", default_style_id=style_id, fps=fps
        )
        scenes.append(norm_sc)
        cur_f += dur_f
    return scenes


def _build_domain_specific_4shot_scenes(
    topic: str,
    classification: dict,
    fps: int,
    duration_sec: float,
    lang: str = "id-ID",
) -> list[dict]:
    """
    F01, F02, F03 & F08:
    Generates 4-scene storyboards for specific domains (`food-chain-ecology`, `solar-panel`,
    `water-thermodynamics`, `combustion-fire-triangle`, `software-api-system`, `motorcycle-warmup`,
    `coffee-extraction`, `neural-network-ai`, or general topics) WITHOUT fabricated percentages/claims,
    keeping a coherent style family throughout the video.
    """
    subj = classification["subject_id"]
    style_id = classification["resolved_style"]
    assumption = classification["assumption"]
    n_scenes = 4
    total_frames = max(120, int(round(duration_sec * fps)))
    base_f = total_frames // n_scenes
    rem_f = total_frames - base_f * (n_scenes - 1)

    if subj == "food-chain-ecology":
        raw_list = [
            {
                "eyebrow": "EKOLOGI · TAHAP 01",
                "stateBadge": "PRODUSEN — FOTOSINTESIS TUMBUHAN",
                "mechanismStep": "producer-photosynthesis",
                "headline": "Rantai makanan dimulai dari tumbuhan hijau sebagai produsen utama",
                "subcopy": "Tumbuhan menyerap cahaya matahari, air, dan karbon dioksida untuk membentuk energi kimia melalui fotosintesis.",
                "narration": "Dalam ekosistem, rantai makanan selalu dimulai dari tumbuhan hijau sebagai produsen yang mengolah cahaya matahari menjadi cadangan makanan.",
                "windowTitle": "TINGKAT TROFIK 1 — PRODUSEN",
                "windowContentLines": [
                    "Peran: Produsen autotrof ekosistem",
                    "Proses: Fotosintesis daun hijau",
                    "Hasil: Energi organik bagi organisme lain",
                ],
                "emphasisWords": ["PRODUSEN", "MATAHARI", "TUMBUHAN"],
                "accent": "#16A34A",
                "transitionIn": "cut",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "EKOLOGI · TAHAP 02",
                "stateBadge": "KONSUMEN PRIMER — HERBIVORA",
                "mechanismStep": "primary-consumer-herbivore",
                "headline": "Energi berpindah ketika hewan pemakan tumbuhan mengonsumsi produsen",
                "subcopy": "Serangga, burung pemakan biji, atau mamalia herbivora menyerap nutrisi dari daun dan batang tanaman.",
                "narration": "Kedua, energi berpindah ke konsumen tingkat pertama, yaitu hewan herbivora yang memakan bagian tumbuhan secara langsung.",
                "windowTitle": "TINGKAT TROFIK 2 — HERBIVORA",
                "windowContentLines": [
                    "Peran: Konsumen tingkat pertama",
                    "Sumber Pangan: Daun, biji, atau rumput",
                    "Aliran: Energi berpindah dari tumbuhan",
                ],
                "emphasisWords": ["ENERGI", "HERBIVORA", "PERTAMA"],
                "accent": "#D97706",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "EKOLOGI · TAHAP 03",
                "stateBadge": "KONSUMEN SEKUNDER & PREDATOR",
                "mechanismStep": "secondary-consumer-predator",
                "headline": "Karnivora menjaga keseimbangan populasi dengan memangsa herbivora",
                "subcopy": "Perpindahan energi berlanjut ke konsumen tingkat lanjut dalam jaring-jaring makanan alami.",
                "narration": "Ketiga, konsumen tingkat kedua dan predator memangsa herbivora sehingga populasi tetap seimbang di dalam habitatnya.",
                "windowTitle": "TINGKAT TROFIK 3 — KARNIVORA",
                "windowContentLines": [
                    "Peran: Konsumen sekunder & predator",
                    "Fungsi: Mengendalikan populasi herbivora",
                    "Jejaring: Menghubungkan rantai trofik",
                ],
                "emphasisWords": ["PREDATOR", "SEIMBANG", "HABITAT"],
                "accent": "#DC2626",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "EKOLOGI · TAHAP 04",
                "stateBadge": "DEKOMPOSER — SIKLUS NUTRISI TANAH",
                "mechanismStep": "decomposer-nutrient-return",
                "headline": "Pengurai mengembalikan unsur hara ke tanah untuk memulai siklus baru",
                "subcopy": "Jamur dan bakteri menguraikan sisa organisme menjadi mineral yang kembali diserap akar tumbuhan.",
                "narration": "Terakhir, organisme pengurai mengembalikan nutrisi ke dalam tanah agar dapat diserap kembali oleh tumbuhan baru.",
                "windowTitle": "TAHAP 4 — PENGURAI (DEKOMPOSER)",
                "windowContentLines": [
                    "Organisme: Jamur & mikroorganisme tanah",
                    "Proses: Menguraikan sisa bahan organik",
                    "Siklus: Mengembalikan unsur hara ke akar",
                ],
                "emphasisWords": ["PENGURAI", "NUTRISI", "TANAH"],
                "accent": "#0284C7",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]
    elif subj == "solar-panel":
        raw_list = [
            {
                "eyebrow": "ENERGI SURYA · TAHAP 01",
                "stateBadge": "PENANGKAPAN FOTON CAHAYA",
                "mechanismStep": "photon-absorption",
                "headline": "Bagaimana panel surya mengubah sinar matahari menjadi aliran listrik?",
                "subcopy": "Permukaan panel tersusun atas sel fotovoltaik berbahan semikonduktor silikon yang peka terhadap foton cahaya.",
                "narration": "Pernah terpikir bagaimana panel surya menghasilkan listrik dari sinar matahari? Prosesnya berlangsung di dalam lapisan sel silikon fotovoltaik.",
                "windowTitle": "STRUKTUR SEL FOTOVOLTAIK",
                "windowContentLines": [
                    "Material Inti: Lapisan semikonduktor silikon",
                    "Pemicu: Foton dari cahaya matahari",
                    "Pelindung: Kaca anti-reflektif transparan",
                ],
                "emphasisWords": ["SURYA", "SILIKON", "CAHAYA"],
                "accent": "#0284C7",
                "transitionIn": "cut",
                "transitionOut": "cutaway-peel",
            },
            {
                "eyebrow": "ENERGI SURYA · TAHAP 02",
                "stateBadge": "EFEK FOTOVOLTAIK & ELEKTRON",
                "mechanismStep": "electron-excitation-pn-junction",
                "headline": "Energi foton melepaskan elektron bebas pada pertemuan lapisan silikon",
                "subcopy": "Medan listrik pada batas silikon tipe-N dan tipe-P mendorong elektron bergerak ke satu arah yang teratur.",
                "narration": "Saat cahaya mengenai sel silikon, energi foton mendorong elektron lepas dan bergerak searah melewati medan sambungan semikonduktor.",
                "windowTitle": "TAHAP 2 — EFEK FOTOVOLTAIK",
                "windowContentLines": [
                    "Lapisan Atas: Silikon bermuatan negatif (N)",
                    "Lapisan Bawah: Silikon bermuatan positif (P)",
                    "Reaksi: Elektron mengalir pada jalur konduktor",
                ],
                "emphasisWords": ["FOTON", "ELEKTRON", "SEARAH"],
                "accent": "#D97706",
                "transitionIn": "cutaway-peel",
                "transitionOut": "object-match",
            },
            {
                "eyebrow": "ENERGI SURYA · TAHAP 03",
                "stateBadge": "KONVERSI ARUS DC KE AC (INVERTER)",
                "mechanismStep": "dc-to-ac-inverter",
                "headline": "Aliran elektron membentuk arus searah lalu diubah oleh inverter",
                "subcopy": "Listrik arus searah dari panel dialirkan menuju inverter agar menjadi arus bolak-balik yang sesuai untuk peralatan rumah.",
                "narration": "Ketiga, aliran elektron tersebut menghasilkan listrik arus searah, lalu komponen inverter mengubahnya menjadi arus bolak-balik.",
                "windowTitle": "TAHAP 3 — PERAN INVERTER",
                "windowContentLines": [
                    "Keluaran Panel: Arus searah (DC)",
                    "Komponen Konversi: Unit Inverter",
                    "Keluaran Akhir: Arus bolak-balik (AC)",
                ],
                "emphasisWords": ["SEARAH", "INVERTER", "BOLAK-BALIK"],
                "accent": "#16A34A",
                "transitionIn": "object-match",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "ENERGI SURYA · TAHAP 04",
                "stateBadge": "DISTRIBUSI KE BEBAN LISTRIK",
                "mechanismStep": "power-distribution",
                "headline": "Listrik siap menyuplai perangkat rumah atau disimpan ke baterai",
                "subcopy": "Dari panel, sambungan sel, hingga inverter, cahaya matahari berubah menjadi energi listrik tanpa bagian mesin yang berputar.",
                "narration": "Terakhir, arus listrik dari inverter langsung mengalir ke panel distribusi rumah atau disimpan di dalam baterai cadangan.",
                "windowTitle": "RANGKUMAN — ALUR PANEL SURYA",
                "windowContentLines": [
                    "1. Cahaya mengenai sel silikon",
                    "2. Elektron membentuk arus DC",
                    "3. Inverter menyuplai arus AC ke rumah",
                ],
                "emphasisWords": ["DISTRIBUSI", "BATERAI", "LISTRIK"],
                "accent": "#2563EB",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]
    elif subj == "water-thermodynamics":
        raw_list = [
            {
                "eyebrow": "TERMODINAMIKA · TAHAP 01",
                "stateBadge": "HANTARAN PANAS KE DASAR WADAH",
                "mechanismStep": "conduction-base-heating",
                "headline": "Bagaimana proses air mendidih dari suhu ruang hingga menjadi uap?",
                "subcopy": "Sumber panas memanaskan dinding bawah wadah secara konduksi, lalu menyalurkan energi termal ke lapisan air paling bawah.",
                "narration": "Saat air dipanaskan di dalam wadah, energi panas merambat secara konduksi melalui dasar wadah menuju lapisan air paling bawah.",
                "windowTitle": "TAHAP 1 — HANTARAN KONDUKSI",
                "windowContentLines": [
                    "Sumber Energi: Pemanas di bawah wadah",
                    "Perpindahan Awal: Konduksi dasar logam",
                    "Dampak: Molekul air bawah bergerak lebih cepat",
                ],
                "emphasisWords": ["PANAS", "KONDUKSI", "DASAR"],
                "accent": "#DC2626",
                "transitionIn": "cut",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "TERMODINAMIKA · TAHAP 02",
                "stateBadge": "SIRKULASI ARUS KONVEKSI",
                "mechanismStep": "convection-circulation",
                "headline": "Air hangat yang memuai bergerak naik dan digantikan air yang lebih dingin",
                "subcopy": "Perbedaan massa jenis memicu arus konveksi memutar sehingga suhu air di seluruh wadah meningkat merata.",
                "narration": "Kedua, lapisan air bawah yang memanas menjadi lebih ringan lalu bergerak naik, sementara air dingin di atas turun menggantikannya.",
                "windowTitle": "TAHAP 2 — ARUS KONVEKSI",
                "windowContentLines": [
                    "Air Panas: Memuai dan bergerak ke atas",
                    "Air Dingin: Turun ke dasar wadah",
                    "Hasil: Sirkulasi konveksi meratakan suhu",
                ],
                "emphasisWords": ["MEMUAI", "NAIK", "KONVEKSI"],
                "accent": "#EA580C",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "TERMODINAMIKA · TAHAP 03",
                "stateBadge": "PEMBENTUKAN GELEMBUNG UAP",
                "mechanismStep": "nucleation-vapor-bubbles",
                "headline": "Gelembung uap terbentuk di dasar wadah dan naik ke permukaan",
                "subcopy": "Ketika energi kinetik molekul melampaui ikatan cair, kantong uap air terbentuk dan terdorong ke atas.",
                "narration": "Ketiga, saat suhu mencapai titik didih, molekul air berubah menjadi gelembung gas uap di dasar wadah lalu naik ke permukaan.",
                "windowTitle": "TAHAP 3 — PERUBAHAN FASE",
                "windowContentLines": [
                    "Fase Cair ke Gas: Terbentuk gelembung uap",
                    "Gerak Gelembung: Naik menuju permukaan",
                    "Pelepasan: Gelembung pecah melepas uap air",
                ],
                "emphasisWords": ["TITIK", "GELEMBUNG", "UAP"],
                "accent": "#0284C7",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "TERMODINAMIKA · TAHAP 04",
                "stateBadge": "KESETIMBANGAN DIDIH & PENGUAPAN",
                "mechanismStep": "boiling-equilibrium",
                "headline": "Energi panas berikutnya dipakai untuk mengubah wujud cair menjadi uap",
                "subcopy": "Selama mendidih pada tekanan tetap, tambahan kalor digunakan sebagai kalor laten penguapan.",
                "narration": "Jadi dari konduksi di dasar, putaran konveksi, hingga lepasnya gelembung uap, begitulah urutan fisika saat air mendidih.",
                "windowTitle": "RANGKUMAN — PROSES AIR MENDIDIH",
                "windowContentLines": [
                    "1. Konduksi: Dasar wadah memanaskan air",
                    "2. Konveksi: Putaran arus meratakan panas",
                    "3. Penguapan: Gelembung uap lepas ke udara",
                ],
                "emphasisWords": ["KONDUKSI", "KONVEKSI", "PENGUAPAN"],
                "accent": "#2563EB",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]
    elif subj == "combustion-fire-triangle":
        raw_list = [
            {
                "eyebrow": "KESELAMATAN · TAHAP 01",
                "stateBadge": "SEGITIGA API PADA KOMPOR GAS",
                "mechanismStep": "fire-triangle-elements",
                "headline": "Bagaimana api kompor menyala dan kapan bisa menjadi bahaya?",
                "subcopy": "Api terbentuk ketika bahan bakar gas, oksigen udara, dan percikan pemantik bertemu dalam rasio yang tepat.",
                "narration": "Api pada kompor gas bekerja karena tiga unsur segitiga api bertemu: aliran gas bahan bakar, oksigen di udara, dan pemantik panas.",
                "windowTitle": "UNSUR PEMBENTUK API KOMPOR",
                "windowContentLines": [
                    "Unsur 1: Bahan bakar gas LPG",
                    "Unsur 2: Oksigen dari sirkulasi udara",
                    "Unsur 3: Percikan api pemantik",
                ],
                "emphasisWords": ["API", "GAS", "OKSIGEN"],
                "accent": "#EA580C",
                "transitionIn": "cut",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "KESELAMATAN · TAHAP 02",
                "stateBadge": "PENCAMPURAN UDARA DI TUNGKU",
                "mechanismStep": "burner-venturi-mixing",
                "headline": "Saluran tungku mencampur gas dengan oksigen agar nyala api biru stabil",
                "subcopy": "Campuran oksigen yang cukup menghasilkan pembakaran sempurna berwarna biru, sedangkan kekurangan udara memicu api merah dan jelaga.",
                "narration": "Di bawah tungku, saluran pencampur menarik udara sekitar agar gas terbakar sempurna menghasilkan nyala api biru yang stabil.",
                "windowTitle": "PEMBAKARAN SEMPURNA VS TIDAK SEMPURNA",
                "windowContentLines": [
                    "Api Biru: Campuran gas dan udara seimbang",
                    "Api Merah/Kuning: Saluran udara kotor/kurang",
                    "Tindakan: Bersihkan lubang tungku berkala",
                ],
                "emphasisWords": ["TUNGKU", "BIRU", "STABIL"],
                "accent": "#2563EB",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "KESELAMATAN · TAHAP 03",
                "stateBadge": "DETEKSI KEBOCORAN SELANG & REGULATOR",
                "mechanismStep": "leak-hazard-prevention",
                "headline": "Gas yang bocor di ruang tertutup berbahaya jika bertemu percikan listrik",
                "subcopy": "Karena gas LPG lebih berat dari udara, gas yang bocor mengendap di bagian bawah lantai dapur.",
                "narration": "Bahaya muncul saat regulator atau selang bocor di ruang tertutup, karena gas mengendap di bawah dan mudah tersulut percikan.",
                "windowTitle": "TITIK RAWAN KEBOCORAN GAS",
                "windowContentLines": [
                    "Karet Sil: Pastikan terpasang rapat tanpa retak",
                    "Selang Gas: Cek dari gigitan atau getas",
                    "Sirkulasi: Pastikan dapur memiliki ventilasi",
                ],
                "emphasisWords": ["REGULATOR", "BOCOR", "VENTILASI"],
                "accent": "#DC2626",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "KESELAMATAN · TAHAP 04",
                "stateBadge": "LANGKAH AMAN SAAT TERCIUM BAU GAS",
                "mechanismStep": "emergency-ventilation-response",
                "headline": "Lepas regulator, buka jendela lebar-lebar, dan jangan nyalakan sakelar!",
                "subcopy": "Memutus aliran bahan bakar dan membuka ventilasi menghilangkan unsur segitiga api secara aman.",
                "narration": "Jika tercium bau gas, segera lepas regulator, buka pintu dan jendela, serta jangan menyalakan sakelar listrik apa pun.",
                "windowTitle": "PROSEDUR AMAN PENANGANAN GAS",
                "windowContentLines": [
                    "1. Lepaskan regulator dari tabung gas",
                    "2. Buka pintu dan jendela agar udara mengalir",
                    "3. Hindari menyalakan sakelar atau korek",
                ],
                "emphasisWords": ["LEPAS", "JENDELA", "SAKELAR"],
                "accent": "#16A34A",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]
    elif subj == "software-api-system":
        raw_list = [
            {
                "eyebrow": "SOFTWARE · TAHAP 01",
                "stateBadge": "REQUEST CLIENT KE ENDPOINT API",
                "mechanismStep": "client-http-request",
                "headline": "Bagaimana API menghubungkan aplikasi di ponselmu dengan server?",
                "subcopy": "API (Application Programming Interface) bertindak sebagai kontrak komunikasi terstruktur antara aplikasi klien dan server.",
                "narration": "Dalam pemrograman, API bekerja sebagai penghubung resmi yang meneruskan permintaan dari aplikasi klien menuju server.",
                "windowTitle": "ARSITEKTUR REQUEST API",
                "windowContentLines": [
                    "Client App: Mengirim HTTP Request (GET/POST)",
                    "Endpoint URL: Alamat rute layanan tujuan",
                    "Headers: Token autentikasi & format konten",
                ],
                "emphasisWords": ["API", "REQUEST", "SERVER"],
                "accent": "#2563EB",
                "transitionIn": "cut",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "SOFTWARE · TAHAP 02",
                "stateBadge": "VALIDASI & AUTENTIKASI GATEWAY",
                "mechanismStep": "api-gateway-validation",
                "headline": "API Gateway memeriksa izin akses dan kelengkapan parameter permintaan",
                "subcopy": "Sebelum menyentuh database, server memverifikasi kunci akses dan skema data yang dikirim aplikasi.",
                "narration": "Kedua, lapisan gateway memeriksa kunci autentikasi dan memastikan format parameter yang dikirim sudah sesuai kontrak.",
                "windowTitle": "VALIDASI KEAMANAN & SKEMA",
                "windowContentLines": [
                    "Auth Check: Verifikasi API Key / Bearer Token",
                    "Rate Limit: Mengatur batas kuota permintaan",
                    "Schema Check: Validasi parameter input",
                ],
                "emphasisWords": ["GATEWAY", "AUTENTIKASI", "PARAMETER"],
                "accent": "#D97706",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "SOFTWARE · TAHAP 03",
                "stateBadge": "EKSEKUSI LOGIKA & DATABASE",
                "mechanismStep": "backend-service-execution",
                "headline": "Layanan backend memproses logika bisnis dan mengambil data yang diminta",
                "subcopy": "Server menjalankan fungsi yang diminta tanpa mengekspos struktur internal database ke pengguna luar.",
                "narration": "Ketiga, layanan backend mengolah permintaan tersebut dan mengambil data dari penyimpanan internal secara aman.",
                "windowTitle": "PEMROSESAN LAYANAN BACKEND",
                "windowContentLines": [
                    "Controller: Menjalankan fungsi layanan",
                    "Database Query: Mengambil atau menyimpan data",
                    "Enkapsulasi: Struktur internal tetap terlindungi",
                ],
                "emphasisWords": ["BACKEND", "DATA", "AMAN"],
                "accent": "#9333EA",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "SOFTWARE · TAHAP 04",
                "stateBadge": "RESPONSE JSON KEMBALI KE APLIKASI",
                "mechanismStep": "json-response-render",
                "headline": "Server mengirimkan respons JSON terstruktur untuk ditampilkan di layar",
                "subcopy": "Aplikasi klien menerima kode status dan payload JSON, lalu memperbarui tampilan antarmuka pengguna.",
                "narration": "Terakhir, server mengembalikan paket data berformat JSON beserta kode status agar antarmuka aplikasi langsung diperbarui.",
                "windowTitle": "STRUKTUR HTTP RESPONSE",
                "windowContentLines": [
                    "Status Code: Indikator keberhasilan permintaan",
                    "Payload: Data terstruktur berformat JSON",
                    "UI Update: Tampilan aplikasi diperbarui",
                ],
                "emphasisWords": ["JSON", "STATUS", "APLIKASI"],
                "accent": "#16A34A",
                "transitionIn": "slide",
                "transitionOut": "cut",
            },
        ]
    elif subj == "building-structure":
        raw_list = [
            {
                "eyebrow": "TAHAP 01 · PONDASI & STRUKTUR BAWAH",
                "stateBadge": "TIANG PANCANG & DISTRIBUSI BEBAN",
                "mechanismStep": "stage-1-foundation",
                "headline": f"Bagaimana pondasi dalam menopang struktur {topic.strip()} agar kokoh?",
                "subcopy": "Pondasi menyalurkan beban gravitasi dan getaran dari bangunan atas langsung ke lapisan tanah keras.",
                "narration": "Pertama, seluruh beban bangunan ditopang oleh pondasi dalam yang menancap hingga ke lapisan tanah keras di bawah permukaan.",
                "windowTitle": "STRUKTUR BAWAH — PONDASI & TANAH KERAS",
                "windowContentLines": [
                    "Pondasi Dalam: Menyalurkan beban ke tanah keras",
                    "Sloof Pengikat: Meratakan gaya antar titik kolom",
                    "Redaman: Menahan pergeseran tanah saat gempa",
                ],
                "callouts": [
                    {"label": "KOLOM UTAMA", "tx": 305, "ty": 945, "px": 225, "py": 1140},
                    {"label": "BALOK SLOOF", "tx": 480, "ty": 1005, "px": 480, "py": 1140},
                    {"label": "PONDASI TAPAK", "tx": 655, "ty": 1035, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["PONDASI", "TANAH", "BEBAN"],
                "accent": "#D97706",
                "transitionIn": "cut",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "TAHAP 02 · RANGKA KOLOM & BALOK",
                "stateBadge": "PORTAL STRUKTURAL & GAYA GESER",
                "mechanismStep": "stage-2-columns-beams",
                "headline": "Kolom vertikal dan balok horizontal membentuk rangka portal yang saling mengunci",
                "subcopy": "Sambungan kolom dan balok membagi beban lantai serta menahan gaya dorong angin maupun guncangan.",
                "narration": "Kedua, kolom vertikal dan balok induk saling mengunci membentuk portal kaku sehingga beban setiap lantai terdistribusi merata.",
                "windowTitle": "RANGKA PORTAL — KOLOM & BALOK INDUK",
                "windowContentLines": [
                    "Kolom Vertikal: Menahan gaya tekan dari lantai atas",
                    "Balok Induk: Menopang bentang pelat lantai",
                    "Sambungan Kaku: Menjaga gedung tetap tegak stabil",
                ],
                "callouts": [
                    {"label": "KOLOM TEKAN", "tx": 305, "ty": 935, "px": 225, "py": 1140},
                    {"label": "PELAT LANTAI", "tx": 480, "ty": 965, "px": 480, "py": 1140},
                    {"label": "BALOK INDUK", "tx": 655, "ty": 965, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["KOLOM", "BALOK", "MERATA"],
                "accent": "#0284C7",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "TAHAP 03 · INTI GESER & ATAP",
                "stateBadge": "STABILITAS LATERAL & PENUTUP ATAP",
                "mechanismStep": "stage-3-roof-truss",
                "headline": "Rangka atap dan dinding geser menjaga keseimbangan bangunan di bagian puncak",
                "subcopy": "Struktur atap melindungi ruang dalam sekaligus mengikat ujung kolom bagian atas agar tidak melentur.",
                "narration": "Ketiga, rangka atap di bagian puncak mengikat ujung-ujung kolom sehingga struktur bangunan tetap kaku dan terlindung dari cuaca.",
                "windowTitle": "STRUKTUR ATAS — RANGKA ATAP & PENGAKU",
                "windowContentLines": [
                    "Rangka Atap: Mengikat puncak kolom struktural",
                    "Beban Angin: Diteruskan kembali menuju kolom",
                    "Perlindungan: Menutup seluruh selubung bangunan",
                ],
                "callouts": [
                    {"label": "KUDA-KUDA ATAP", "tx": 480, "ty": 895, "px": 230, "py": 1140},
                    {"label": "IKATAN ANGIN", "tx": 420, "ty": 910, "px": 480, "py": 1140},
                    {"label": "KOLOM ATAS", "tx": 655, "ty": 925, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["ATAP", "PUNCAK", "KAKU"],
                "accent": "#16A34A",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "TAHAP 04 · RANGKUMAN ALUR BEBAN",
                "stateBadge": "ATAP -> KOLOM -> PONDASI -> TANAH",
                "mechanismStep": "stage-4-load-path",
                "headline": "Alur penyaluran beban utuh dari atap, pelat lantai, kolom, hingga ke pondasi",
                "subcopy": "Keamanan struktur bergantung pada kesinambungan jalur beban dari puncak bangunan sampai ke tanah.",
                "narration": "Jadi rangkumannya: kekuatan bangunan ditentukan oleh jalur beban yang menyambung utuh dari atap, balok, kolom, hingga ke pondasi.",
                "windowTitle": "RANGKUMAN — JALUR BEBAN STRUKTUR",
                "windowContentLines": [
                    "1. Beban Atas: Atap & pelat lantai menerima beban",
                    "2. Jalur Tengah: Balok & kolom menyalurkan gaya",
                    "3. Tumpuan Bawah: Pondasi meneruskan ke tanah",
                ],
                "callouts": [
                    {"label": "BEBAN LANTAI", "tx": 480, "ty": 905, "px": 225, "py": 1140},
                    {"label": "JALUR KOLOM", "tx": 480, "ty": 965, "px": 480, "py": 1140},
                    {"label": "TUMPUAN TANAH", "tx": 480, "ty": 1035, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["RANGKUMANNYA", "KOLOM", "PONDASI"],
                "accent": "#2563EB",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]
    else:
        clean_t = re.sub(r"^(cara kerja|bagaimana cara kerja|bagaimana|mengapa|kenapa|apa itu|proses|mekanisme)\s+", "", topic.strip(), flags=re.IGNORECASE).strip() or topic.strip()
        stop_w = {"cara", "kerja", "bagaimana", "mengapa", "kenapa", "pada", "dalam", "yang", "untuk", "dari", "dengan", "saat", "bisa", "dan", "atau", "sistem", "proses"}
        toks = [w.upper() for w in re.findall(r"[A-Za-z0-9]+", clean_t) if len(w) >= 3 and w.lower() not in stop_w]
        k1 = toks[0][:14] if len(toks) > 0 else "PEMICU AWAL"
        k2 = toks[1][:14] if len(toks) > 1 else f"INTI {k1[:8]}"
        k3 = toks[2][:14] if len(toks) > 2 else "HASIL AKHIR"

        hook_bank = CLEAN_HOOK_TEMPLATES_EN if lang.startswith("en") else CLEAN_HOOK_TEMPLATES_ID
        intent_hooks = hook_bank.get(classification["intent"], hook_bank["how-it-works"])
        hook_line = intent_hooks[sum(ord(c) for c in clean_t) % len(intent_hooks)].format(topic=clean_t)
        raw_list = [
            {
                "eyebrow": f"TAHAP 01 · PEMICU & MASUKAN ({k1})",
                "stateBadge": f"INPUT UTAMA: {k1}",
                "mechanismStep": "stage-1-input",
                "headline": hook_line,
                "subcopy": f"Tahap awal {clean_t} dimulai saat pemicu masukan mengaktifkan komponen {k1.lower()}.",
                "narration": f"{hook_line} Pertama, alur {clean_t} dimulai ketika pemicu awal mengaktifkan bagian masukan utama.",
                "windowTitle": f"KOMPONEN MASUKAN — {clean_t[:22].upper()}",
                "windowContentLines": [
                    f"Pemicu Awal: Aktivasi komponen {clean_t[:24]}",
                    f"Bagian Aktif: Modul masukan ({k1.title()})",
                    "Fungsi Tahap: Menyiapkan aliran menuju inti",
                ],
                "callouts": [
                    {"label": f"INPUT {k1[:8]}", "tx": 280, "ty": 960, "px": 225, "py": 1140},
                    {"label": k2[:14], "tx": 480, "ty": 950, "px": 480, "py": 1140},
                    {"label": k3[:14], "tx": 680, "ty": 960, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["PERTAMA", k1, "MASUKAN"],
                "accent": "#2563EB",
                "transitionIn": "cut",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": f"TAHAP 02 · KONVERSI & PROSES INTI",
                "stateBadge": f"PROSES INTI: {k2}",
                "mechanismStep": "stage-2-process",
                "headline": f"Bagaimana bagian inti {clean_t} mengolah masukan secara berurutan?",
                "subcopy": f"Di dalam ruang inti, masukan diubah melalui interaksi langsung antar komponen {clean_t}.",
                "narration": f"Kedua, masukan tadi diteruskan ke bagian inti sehingga mekanisme pengolahan {clean_t} bekerja secara sinkron.",
                "windowTitle": f"MEKANISME INTI — {clean_t[:20].upper()}",
                "windowContentLines": [
                    f"Penyaluran: Masukan masuk ke inti {clean_t[:18]}",
                    f"Proses Utama: Konversi terukur pada {k2.title()}",
                    "Sinkronisasi: Antar bagian bekerja berurutan",
                ],
                "callouts": [
                    {"label": "ALIRAN MASUK", "tx": 255, "ty": 965, "px": 225, "py": 1140},
                    {"label": f"INTI {k1[:9]}", "tx": 480, "ty": 945, "px": 480, "py": 1140},
                    {"label": "JALUR KELUAR", "tx": 705, "ty": 965, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["KEDUA", "INTI", "SINKRON"],
                "accent": "#16A34A",
                "transitionIn": "crossfade",
                "transitionOut": "slide",
            },
            {
                "eyebrow": "TAHAP 03 · KELUARAN & EFEK KERJA",
                "stateBadge": f"OUTPUT TERUKUR: {k3}",
                "mechanismStep": "stage-3-output",
                "headline": f"Perubahan di bagian inti menghasilkan keluaran nyata pada {clean_t}",
                "subcopy": f"Hasil olahan dari tahap inti disalurkan ke bagian akhir sehingga fungsi {clean_t} langsung bekerja.",
                "narration": f"Ketiga, hasil pemrosesan dari bagian inti disalurkan menuju keluaran sehingga fungsi utama {clean_t} tercapai.",
                "windowTitle": f"HASIL KELUARAN — {clean_t[:20].upper()}",
                "windowContentLines": [
                    "Tahap Akhir: Penyaluran dari inti ke keluaran",
                    f"Hasil Kerja: Fungsi {clean_t[:22]} aktif",
                    "Kestabilan: Aliran terjaga tanpa hambatan",
                ],
                "callouts": [
                    {"label": "TAHAP AWAL", "tx": 270, "ty": 985, "px": 225, "py": 1140},
                    {"label": "KONVERSI", "tx": 480, "ty": 960, "px": 480, "py": 1140},
                    {"label": f"HASIL {k1[:8]}", "tx": 690, "ty": 935, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["KETIGA", "KELUARAN", "UTAMA"],
                "accent": "#D97706",
                "transitionIn": "slide",
                "transitionOut": "crossfade",
            },
            {
                "eyebrow": "TAHAP 04 · RANGKUMAN SIKLUS UTUH",
                "stateBadge": f"{k1[:8]} -> PROSES -> HASIL",
                "mechanismStep": "stage-4-summary",
                "headline": f"Rangkuman utuh cara kerja {clean_t} dari pemicu awal hingga hasil akhir",
                "subcopy": f"Seluruh rangkaian {clean_t} menghubungkan komponen pemicu, pemrosesan inti, dan keluaran secara utuh.",
                "narration": f"Jadi rangkumannya: {clean_t} bekerja melalui tiga tahap berurutan mulai dari pemicu masukan, pemrosesan inti, hingga menghasilkan keluaran akhir.",
                "windowTitle": f"RANGKUMAN ALUR — {clean_t[:20].upper()}",
                "windowContentLines": [
                    f"1. Pemicu: Komponen masukan {clean_t[:16]} aktif",
                    "2. Inti: Pemrosesan & konversi mekanisme",
                    "3. Hasil: Keluaran akhir bekerja penuh",
                ],
                "callouts": [
                    {"label": f"1. {k1[:10]}", "tx": 280, "ty": 960, "px": 225, "py": 1140},
                    {"label": "2. PROSES INTI", "tx": 480, "ty": 945, "px": 480, "py": 1140},
                    {"label": "3. KELUARAN", "tx": 680, "ty": 960, "px": 735, "py": 1140},
                ],
                "emphasisWords": ["RANGKUMANNYA", "BERURUTAN", "AKHIR"],
                "accent": "#0284C7",
                "transitionIn": "crossfade",
                "transitionOut": "cut",
            },
        ]

    scenes = []
    cur_f = 0
    for idx, item in enumerate(raw_list):
        dur_f = rem_f if idx == len(raw_list) - 1 else base_f
        item["id"] = f"scene-{idx + 1:02d}"
        item["durationInFrames"] = dur_f
        item["startFrame"] = cur_f
        item["subjectId"] = subj
        item["assetId"] = classification["asset_id"]
        item["assumption"] = assumption
        item["language"] = lang
        item["visualMode"] = style_id
        item["evidenceCardKind"] = ["bars", "quote", "checklist"][idx % 3]
        item["metric"] = ""
        item["unit"] = ""
        item["stickerText"] = f"TAHAP 0{idx + 1}"
        norm_sc = sm_mod.normalize_and_validate_scene_contract(
            item, idx=idx, default_subject_id=subj, default_style_id=style_id, fps=fps
        )
        scenes.append(norm_sc)
        cur_f += dur_f
    return scenes


def _build_talking_head_scenes(
    topic: str,
    style_id: str,
    fps: int,
    duration_sec: float,
    lang: str = "id-ID",
) -> list[dict]:
    """
    Talking-head scenes with face-aware framing, transcript-led EDL,
    caption per segment, and style plan per beat.
    """
    n_scenes = 4
    total_frames = max(120, int(round(duration_sec * fps)))
    base_f = total_frames // n_scenes
    rem_f = total_frames - base_f * (n_scenes - 1)
    assumption = "Pembicara atau presenter berbicara langsung ke kamera dengan framing face-aware, caption per segmen, dan gaya visual konsisten per beat."

    clean_t = topic.strip()
    hook_bank = CLEAN_HOOK_TEMPLATES_EN if lang.startswith("en") else CLEAN_HOOK_TEMPLATES_ID
    intent_hooks = hook_bank["storytelling"]
    hook_line = intent_hooks[sum(ord(c) for c in clean_t) % len(intent_hooks)].format(topic=clean_t)

    raw_list = [
        {
            "eyebrow": "TALKING HEAD · BEAT 01",
            "stateBadge": "FACE-AWARE CLOSE-UP",
            "mechanismStep": "intro-hook",
            "headline": hook_line,
            "subcopy": f"Kenalkan pembicara dan topik utama: {clean_t}.",
            "narration": f"{hook_line} Pada bagian ini, kita perkenalkan pembicara dan inti topik {clean_t}.",
            "windowTitle": "BEAT 1 — PENGENALAN PEMBERICARA",
            "windowContentLines": [
                f"Subjek: {clean_t[:28]}",
                "Framing: Face-aware close-up",
                "Caption: Per-kalimat di bawah",
            ],
            "emphasisWords": ["PEMBICARA", "TOPIK"],
            "accent": "#38BDF8",
            "transitionIn": "cut",
            "transitionOut": "crossfade",
            "framing": "face-aware-closeup",
            "caption_per_segment": True,
            "style_plan_beat": "intro",
        },
        {
            "eyebrow": "TALKING HEAD · BEAT 02",
            "stateBadge": "MEDIUM SHOT & GESTURE",
            "mechanismStep": "core-message",
            "headline": f"Ini inti pesan dari {clean_t}",
            "subcopy": f"Pembicara menyampaikan materi inti dengan gerakan tangan dan ekspresi wajah yang natural.",
            "narration": f"Ini adalah inti pesan dari {clean_t}. Pembicara menyampaikan materi secara langsung dan natural.",
            "windowTitle": "BEAT 2 — INTI PESAN",
            "windowContentLines": [
                "Framing: Medium shot",
                "Gesture: Tangan terbuka",
                "Caption: Sinkron dengan ucapan",
            ],
            "emphasisWords": ["INTI", "PESAN"],
            "accent": "#10B981",
            "transitionIn": "crossfade",
            "transitionOut": "slide",
            "framing": "face-aware-medium",
            "caption_per_segment": True,
            "style_plan_beat": "core",
        },
        {
            "eyebrow": "TALKING HEAD · BEAT 03",
            "stateBadge": "EVIDENCE & EXAMPLE",
            "mechanismStep": "evidence-demo",
            "headline": f"Bukti dan contoh nyata dari {clean_t}",
            "subcopy": f"Contoh konkret yang memperkuat pesan utama {clean_t}.",
            "narration": f"Berikut adalah bukti dan contoh nyata yang memperkuat pesan {clean_t}.",
            "windowTitle": "BEAT 3 — BUKTI & CONTOH",
            "windowContentLines": [
                "Framing: Face-aware medium",
                "Overlay: Kartu bukti di samping",
                "Caption: Highlight kata kunci",
            ],
            "emphasisWords": ["BUKTI", "CONTOH"],
            "accent": "#F59E0B",
            "transitionIn": "slide",
            "transitionOut": "crossfade",
            "framing": "face-aware-medium",
            "caption_per_segment": True,
            "style_plan_beat": "evidence",
        },
        {
            "eyebrow": "TALKING HEAD · BEAT 04",
            "stateBadge": "CALL TO ACTION & CLOSE",
            "mechanismStep": "cta-close",
            "headline": f"Kesimpulan dan langkah selanjutnya untuk {clean_t}",
            "subcopy": "Pembicara memberikan rangkuman dan ajakan untuk tindakan lanjutan.",
            "narration": f"Untuk menutup, pembicara merangkum poin-poin penting dan mengajak tindakan lanjutan tentang {clean_t}.",
            "windowTitle": "BEAT 4 — KESIMPULAN & CTA",
            "windowContentLines": [
                "Framing: Face-aware close-up",
                "Action: Call to action",
                "Caption: Pesan penutup",
            ],
            "emphasisWords": ["KESIMPULAN", "TINDAKAN"],
            "accent": "#EC4899",
            "transitionIn": "crossfade",
            "transitionOut": "cut",
            "framing": "face-aware-closeup",
            "caption_per_segment": True,
            "style_plan_beat": "outro",
            "is_last_scene": True,
        },
    ]

    scenes = []
    cur_f = 0
    for idx, item in enumerate(raw_list):
        dur_f = rem_f if idx == len(raw_list) - 1 else base_f
        item["id"] = f"scene-{idx + 1:02d}"
        item["durationInFrames"] = dur_f
        item["startFrame"] = cur_f
        item["subjectId"] = "talking-head-presenter"
        item["assetId"] = "talking-head-face-aware"
        item["assumption"] = assumption
        item["language"] = lang
        item["visualMode"] = style_id
        item["evidenceCardKind"] = ["quote", "checklist", "bars", "quote"][idx % 4]
        item["metric"] = ""
        item["unit"] = ""
        item["stickerText"] = f"BEAT 0{idx + 1}"
        norm_sc = sm_mod.normalize_and_validate_scene_contract(
            item, idx=idx, default_subject_id="talking-head-presenter", default_style_id=style_id, fps=fps
        )
        scenes.append(norm_sc)
        cur_f += dur_f
    return scenes


def generate_indonesian_scenes(
    topic: str,
    style: str = "auto-context",
    duration_sec: float = 24.0,
    fps: int = 30,
    target_audience: str = "umum",
    language: str = "",
) -> dict:
    """
    Main entry point for storyboard generation.
    Returns structured brief, classification reasoning, provider status, and validated scenes.
    """
    lang = detect_language(topic, explicit_lang=language)
    classification = classify_topic_and_subject(topic, requested_style=style)
    style_id = classification["resolved_style"]

    # Check if local Ollama is available for non-fixture custom topics
    llm_scenes, ollama_status = try_local_ollama_generation(topic, duration_sec, style_id, classification, target_audience)
    if llm_scenes and classification["subject_id"] == "system-mechanism":
        total_frames = max(120, int(round(duration_sec * fps)))
        base_f = total_frames // len(llm_scenes)
        rem_f = total_frames - base_f * (len(llm_scenes) - 1)
        cur_f = 0
        norm_list = []
        for i, sc in enumerate(llm_scenes):
            dur_f = rem_f if i == len(llm_scenes) - 1 else base_f
            sc["id"] = f"scene-{i + 1:02d}"
            sc["durationInFrames"] = dur_f
            sc["startFrame"] = cur_f
            sc["visualMode"] = style_id
            sc["language"] = lang
            norm_list.append(
                sm_mod.normalize_and_validate_scene_contract(
                    sc, idx=i, default_subject_id=classification["subject_id"], default_style_id=style_id, fps=fps
                )
            )
            cur_f += dur_f
        return {
            "ok": True,
            "source": "local-llm-ollama",
            "ollama_status": ollama_status,
            "topic": topic,
            "language": lang,
            "classification": classification,
            "scenes": norm_list,
        }

    if classification["subject_id"] == "lawnmower-rotary":
        scenes = _build_lawnmower_6shot_scenes(topic, style_id=style_id, fps=fps, duration_sec=max(24.0, duration_sec), lang=lang)
        source_tag = "spec-lawnmower-rotary-6shot-v97"
    elif classification["subject_id"] == "talking-head-presenter":
        scenes = _build_talking_head_scenes(topic, style_id=style_id, fps=fps, duration_sec=duration_sec, lang=lang)
        source_tag = f"deterministic-{classification['subject_id']}-v98"
    else:
        scenes = _build_domain_specific_4shot_scenes(topic, classification=classification, fps=fps, duration_sec=duration_sec, lang=lang)
        source_tag = f"deterministic-{classification['subject_id']}-v97"

    return {
        "ok": True,
        "source": source_tag,
        "ollama_status": ollama_status,
        "topic": topic,
        "language": lang,
        "classification": classification,
        "scenes": scenes,
    }


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7.0 Context-Grounded Bilingual Script & Storyboard Planner")
    p.add_argument("--topic", required=True, help="Video topic (Indonesian or English)")
    p.add_argument("--duration", type=float, default=24.0)
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--style", default="auto-context")
    p.add_argument("--language", default="", help="Optional language code: id-ID or en-US")
    p.add_argument("--audience", default="umum")
    p.add_argument("--list-hooks", action="store_true", help="List clean non-fabricated hook templates")
    p.add_argument("--output", help="Optional path to write scenes JSON")
    a = p.parse_args()

    if a.list_hooks:
        print(json.dumps({"ok": True, "id": CLEAN_HOOK_TEMPLATES_ID, "en": CLEAN_HOOK_TEMPLATES_EN}, indent=2, ensure_ascii=False))
        return 0

    res = generate_indonesian_scenes(
        a.topic,
        style=a.style,
        duration_sec=a.duration,
        fps=a.fps,
        target_audience=a.audience,
        language=a.language,
    )
    if a.output:
        out_p = Path(a.output).expanduser().resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
        res["output_file"] = str(out_p)
    print(json.dumps(res, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
