#!/usr/bin/env python3
"""
Shotcraft Pro v9.8.0 — Bundled Voice Bank, Zero-API-Key Voice Cloning Manager,
Offline Voice Folder Resolver & Video Vocal Stem Extractor (`voice_bank.py`).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import wave
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
NARRATION_ROOT = HERE.parent
VOICES_DIR = NARRATION_ROOT / "assets" / "voices"
PROFILES_DIR = NARRATION_ROOT / "assets" / "voice_profiles"
CATALOG_PATH = PROFILES_DIR / "voice_catalog.json"

AUDIO_EXTS = {".wav", ".mp3", ".m4a", ".aac", ".ogg", ".flac", ".opus", ".mp4", ".mov", ".mkv", ".webm"}

STYLE_DEFAULT_VOICE_MAP = {
    "ref1-voxel-evidence": "nesah_paramitha",
    "ref1-tutorial-deck": "nesah_paramitha",
    "ref2-cinematic-character": "selina",
    "ref2-floating-glass": "selina",
    "ref3-cutaway-mechanism": "nesah_paramitha",
    "ref5-editorial-cutaway": "selina",
    "ref3-pricing-voxel": "kak_ceria",
    "ref4-minimal-ui": "nesah_paramitha",
    "ref4-tape-mascot": "defasyalala",
    "cutaway-turbofan": "nesah_paramitha",
    "cyber-pulse": "selina",
    "neural-network": "nesah_paramitha",
    "energy-waves": "selina",
    "speed-pulse": "kak_ceria",
    "coffee-editorial-3d": "selina",
    "luxury-editorial-glass": "selina",
    "saas-product-launch": "nesah_paramitha",
    "ink-press-vertical": "nesah_paramitha",
}

ONLINE_TTS_VOICES = {
    "edge": {
        "female_id": "id-ID-GadisNeural",
        "male_id": "id-ID-ArdiNeural",
        "female_en": "en-US-AvaNeural",
        "male_en": "en-US-AndrewNeural",
    },
    "elevenlabs": {
        "female_id": "nesah_paramitha",
        "female_warm": "selina",
        "female_bright": "kak_ceria",
    },
    "openai": {
        "female": "nova",
        "female_warm": "shimmer",
        "male": "onyx",
    },
}


def _run_ffmpeg(cmd: list[str]) -> bytes:
    r = subprocess.run(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        raise RuntimeError(f"FFmpeg command failed ({r.returncode}): {r.stderr.decode('utf-8', errors='replace')[-400:]}")
    return r.stdout


_EMBEDDED_DEFAULT_VOICES = [{"profile_name": "bayu", "display_name": "Bayu — Warm & Expressive Narrator", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "", "gender_inferred": "male", "language": "bilingual", "style_tags": ["warm", "expressive", "bilingual", "narrator", "explainer"], "best_for_styles": ["ref3-cutaway-mechanism", "ref1-voxel-evidence", "cutaway-turbofan"], "f0_hz_mean": 139.5, "f0_hz_std": 56.6, "duration_sec": 5.8, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Warm, Expressive, Bilingual"}, {"profile_name": "bian", "display_name": "Bian — Neutral, Calm and Clear", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "1k39YpzqXZn52BgyLyGO", "gender_inferred": "male", "language": "id-ID", "style_tags": ["neutral", "calm", "clear", "mechanism", "documentary"], "best_for_styles": ["ref3-cutaway-mechanism", "ref5-editorial-cutaway", "science-explainer"], "f0_hz_mean": 103.5, "f0_hz_std": 46.1, "duration_sec": 4.44, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Neutral, Calm, Clear"}, {"profile_name": "zan", "display_name": "Zan — Conversational Storyteller", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/zan.wav", "reference_wav": "assets/voices/zan.wav", "reference_text": "Ini sampel suara dewasa storytelling.", "elevenlabs_voice_id": "zmqLb9Ysr8fUvDD7hXK8", "gender_inferred": "male", "language": "id-ID", "style_tags": ["conversational", "fast", "listicle", "tech", "storyteller"], "best_for_styles": ["ref1-voxel-evidence", "ref1-tutorial-deck", "ref3-pricing-voxel"], "f0_hz_mean": 102.3, "f0_hz_std": 14.8, "duration_sec": 2.44, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.12, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/zan.wav", "has_local_wav": True, "style_tag": "Conversational, Fast, Listicle"}, {"profile_name": "denas", "display_name": "Denas — High Class Catchy Storyteller", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/denas.wav", "reference_wav": "assets/voices/denas.wav", "reference_text": "Ini sampel suara pria storyteller.", "elevenlabs_voice_id": "", "gender_inferred": "male", "language": "id-ID", "style_tags": ["catchy", "storyteller", "cinematic", "high-class", "warm"], "best_for_styles": ["ref2-cinematic-character", "ref4-tape-mascot", "coffee-editorial-3d"], "f0_hz_mean": 105.3, "f0_hz_std": 29.8, "duration_sec": 2.76, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/denas.wav", "has_local_wav": True, "style_tag": "Catchy, Storyteller, Cinematic"}, {"profile_name": "abysa", "display_name": "Abysa — Encouraging, Neutral and Breathy", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/abysa.wav", "reference_wav": "assets/voices/abysa.wav", "reference_text": "Suara pria untuk storytelling, natural.", "elevenlabs_voice_id": "WXmGNP5rvPWuO0RYTqfP", "gender_inferred": "male", "language": "id-ID", "style_tags": ["encouraging", "neutral", "breathy", "intimate", "storytelling"], "best_for_styles": ["ref2-cinematic-character", "coffee-editorial-3d"], "f0_hz_mean": 86.6, "f0_hz_std": 13.3, "duration_sec": 3.02, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.8, "similarity_boost": 0.85}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/abysa.wav", "has_local_wav": True, "style_tag": "Encouraging, Neutral, Breathy"}, {"profile_name": "nesah_paramitha", "display_name": "Nesah Paramitha — Warm, Calm and Clear", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "", "gender_inferred": "female", "language": "id-ID", "style_tags": ["warm", "calm", "clear", "female", "ui-workflow"], "best_for_styles": ["ref4-minimal-ui", "ref2-floating-glass", "saas-product-launch"], "f0_hz_mean": 247.4, "f0_hz_std": 31.3, "duration_sec": 4.16, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Warm, Calm, Clear"}, {"profile_name": "defasyalala", "display_name": "Defasyalala — Warm, Expressive and Clear", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/defasyalala.wav", "reference_wav": "assets/voices/defasyalala.wav", "reference_text": "Ini adalah sampel suara Indonesia dua warna, versi wanita.", "elevenlabs_voice_id": "", "gender_inferred": "female", "language": "id-ID", "style_tags": ["warm", "expressive", "clear", "female", "lifestyle"], "best_for_styles": ["ref2-cinematic-character", "ref4-minimal-ui"], "f0_hz_mean": 216.2, "f0_hz_std": 38.7, "duration_sec": 5.88, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.08, "stability": 0.53, "similarity_boost": 0.6}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/defasyalala.wav", "has_local_wav": True, "style_tag": "Warm, Expressive, Clear"}, {"profile_name": "selina", "display_name": "Selina — Warm, Soothing and Clear", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/selina.wav", "reference_wav": "assets/voices/selina.wav", "reference_text": "Suara wanita nyaman didengar sampel.", "elevenlabs_voice_id": "", "gender_inferred": "female", "language": "id-ID", "style_tags": ["warm", "soothing", "clear", "editorial", "culinary"], "best_for_styles": ["coffee-editorial-3d", "ref5-editorial-cutaway"], "f0_hz_mean": 175.2, "f0_hz_std": 59.2, "duration_sec": 2.72, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/selina.wav", "has_local_wav": True, "style_tag": "Warm, Soothing, Clear"}, {"profile_name": "istiqomah", "display_name": "Istiqomah — Calm, Soothing and Clear", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/istiqomah.wav", "reference_wav": "assets/voices/istiqomah.wav", "reference_text": "Ini sampel suara calm, clear, wanita.", "elevenlabs_voice_id": "", "gender_inferred": "female", "language": "id-ID", "style_tags": ["calm", "soothing", "clear", "measured", "education"], "best_for_styles": ["ref3-cutaway-mechanism", "ref5-editorial-cutaway"], "f0_hz_mean": 192.0, "f0_hz_std": 42.0, "duration_sec": 3.39, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 0.94, "stability": 0.35, "similarity_boost": 0.65}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/istiqomah.wav", "has_local_wav": True, "style_tag": "Calm, Soothing, Clear"}, {"profile_name": "kak_ceria", "display_name": "Kak Ceria — Cute Kids Storyteller", "source_type": "bundled-elevenlabs-pvc-sample", "bundled_wav": "assets/voices/kak_ceria.wav", "reference_wav": "assets/voices/kak_ceria.wav", "reference_text": "Sampel suara yang cocok untuk kids story.", "elevenlabs_voice_id": "", "gender_inferred": "female", "language": "id-ID", "style_tags": ["cute", "kids", "storyteller", "bright", "animated"], "best_for_styles": ["ref2-cinematic-character", "mascot-story"], "f0_hz_mean": 250.0, "f0_hz_std": 48.8, "duration_sec": 2.72, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 0.95, "stability": 0.4, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/kak_ceria.wav", "has_local_wav": True, "style_tag": "Cute, Kids, Storyteller"}, {"profile_name": "ref_r1_voxel", "display_name": "Ref R1 (@classai_id) — Tech Listicle & Voxel Presenter", "source_type": "bundled-reference-video-vocal", "bundled_wav": "assets/voices/ref_r1_voxel.wav", "reference_wav": "assets/voices/ref_r1_voxel.wav", "reference_text": "Kalau kamu pengen rilis app pertamamu tapi takut biaya server, aku punya lima layanan yang bisa kamu pakai gratis buat mulai.", "elevenlabs_voice_id": "zmqLb9Ysr8fUvDD7hXK8", "gender_inferred": "male", "language": "id-ID", "style_tags": ["tech", "listicle", "conversational", "r1-benchmark"], "best_for_styles": ["ref1-voxel-evidence", "ref1-tutorial-deck"], "f0_hz_mean": 116.5, "f0_hz_std": 37.3, "duration_sec": 6.5, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.06, "stability": 0.55, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r1_voxel.wav", "has_local_wav": True, "style_tag": "Tech, Listicle, Conversational"}, {"profile_name": "ref_r2_character", "display_name": "Ref R2 (@motionmaxxing) — Fast Creator Storyteller", "source_type": "bundled-reference-video-vocal", "bundled_wav": "assets/voices/ref_r2_character.wav", "reference_wav": "assets/voices/ref_r2_character.wav", "reference_text": "Kebanyakan orang pakai Claude cuma buat ngoding, padahal kalau dipasangin tiga skill ini dia bisa jadi video editor kamu.", "elevenlabs_voice_id": "RWiGLY9uXI70QL540WNd", "gender_inferred": "male", "language": "id-ID", "style_tags": ["creator", "fast", "storyteller", "r2-benchmark"], "best_for_styles": ["ref2-cinematic-character", "ref4-tape-mascot"], "f0_hz_mean": 146.3, "f0_hz_std": 58.9, "duration_sec": 6.19, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.08, "stability": 0.5, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r2_character.wav", "has_local_wav": True, "style_tag": "Creator, Fast, Storyteller"}, {"profile_name": "ref_r3_cutaway", "display_name": "Ref R3 (Explainer Cutaway) — Clear Mechanism Narrator", "source_type": "bundled-reference-video-vocal", "bundled_wav": "assets/voices/ref_r3_cutaway.wav", "reference_wav": "assets/voices/ref_r3_cutaway.wav", "reference_text": "Kalau kamu gali lubang di halaman dan pasang pipa panjang di dalamnya, kamu sudah punya AC tanpa listrik.", "elevenlabs_voice_id": "1k39YpzqXZn52BgyLyGO", "gender_inferred": "male", "language": "id-ID", "style_tags": ["mechanism", "clear", "calm", "explainer", "r3-benchmark"], "best_for_styles": ["ref3-cutaway-mechanism", "ref5-editorial-cutaway"], "f0_hz_mean": 129.4, "f0_hz_std": 35.9, "duration_sec": 7.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.58, "similarity_boost": 0.8}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r3_cutaway.wav", "has_local_wav": True, "style_tag": "Mechanism, Clear, Calm"}, {"profile_name": "ref_r4_english", "display_name": "Ref R4 (Minimal UI) — Deep English Product Narrator", "source_type": "bundled-reference-video-vocal", "bundled_wav": "assets/voices/ref_r4_english.wav", "reference_wav": "assets/voices/ref_r4_english.wav", "reference_text": "Don't post anything else on Instagram until you install these five Claude skills.", "elevenlabs_voice_id": "nPczCjzI2devNBz1zQrb", "gender_inferred": "male", "language": "en-US", "style_tags": ["english", "deep", "product", "minimal-ui", "r4-benchmark"], "best_for_styles": ["ref4-minimal-ui", "dual-device-showreel"], "f0_hz_mean": 126.6, "f0_hz_std": 51.8, "duration_sec": 6.49, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.55, "similarity_boost": 0.8}, "preferred_edge_voice": "en-US-AndrewNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r4_english.wav", "has_local_wav": True, "style_tag": "English, Deep, Product"}, {"profile_name": "dakocan", "display_name": "Dakocan — Expressive, Cheerful & Clear (#1 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/zan.wav", "reference_wav": "assets/voices/zan.wav", "reference_text": "Ini sampel suara dewasa storytelling.", "elevenlabs_voice_id": "plgKUYgnlZ1DCNh54DwJ", "gender_inferred": "male", "language": "id-ID", "style_tags": ["cheerful", "hook", "energetic"], "best_for_styles": ["ref1-voxel-evidence"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.05, "stability": 0.48, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/zan.wav", "has_local_wav": True, "style_tag": "Cheerful, Hook, Energetic"}, {"profile_name": "putra", "display_name": "Putra — Smooth, Clear & Engaging (#2 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "RWiGLY9uXI70QL540WNd", "gender_inferred": "male", "language": "id-ID", "style_tags": ["smooth", "engaging", "narrator"], "best_for_styles": ["ref3-cutaway-mechanism", "ref1-voxel-evidence"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.52, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Smooth, Engaging, Narrator"}, {"profile_name": "pratama", "display_name": "Pratama — Clear, Confident & Warm (#3 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "q8qwd1jY2jS3AWOBeq25", "gender_inferred": "male", "language": "id-ID", "style_tags": ["confident", "warm", "tech"], "best_for_styles": ["ref1-voxel-evidence", "ref4-minimal-ui"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.55, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Confident, Warm, Tech"}, {"profile_name": "tri_nugraha", "display_name": "Tri Nugraha — Friendly & Inviting Storyteller (#4 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "lFjzhZHq0NwTRiu2GQxy", "gender_inferred": "male", "language": "id-ID", "style_tags": ["friendly", "storyteller", "explainer"], "best_for_styles": ["ref3-cutaway-mechanism", "ref2-cinematic-character"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Friendly, Storyteller, Explainer"}, {"profile_name": "tobi", "display_name": "Tobi — Neutral, Diplomatic & Natural (#4 Alt ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "dDU5VfWXOm9eAwl9oqA1", "gender_inferred": "male", "language": "id-ID", "style_tags": ["neutral", "diplomatic", "news"], "best_for_styles": ["ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.6, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Neutral, Diplomatic, News"}, {"profile_name": "andi", "display_name": "Andi — Clear, Friendly & Calm (#9 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "TMvmhlKUioQA4U7LOoko", "gender_inferred": "male", "language": "id-ID", "style_tags": ["friendly", "calm", "tutorial"], "best_for_styles": ["ref1-voxel-evidence", "ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Friendly, Calm, Tutorial"}, {"profile_name": "mahaputra", "display_name": "Mahaputra — Neutral, Calm & Gravelly (#10 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/denas.wav", "reference_wav": "assets/voices/denas.wav", "reference_text": "Ini sampel suara pria storyteller.", "elevenlabs_voice_id": "v70fYBHUOrHA3AKIBjPq", "gender_inferred": "male", "language": "id-ID", "style_tags": ["gravelly", "cinematic", "cyber"], "best_for_styles": ["cutaway-turbofan", "ref2-cinematic-character"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/denas.wav", "has_local_wav": True, "style_tag": "Gravelly, Cinematic, Cyber"}, {"profile_name": "agus", "display_name": "Agus — Smooth, Expressive & Clear (#12 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "GrxM8OEUWBzyFR2xP2Qd", "gender_inferred": "male", "language": "id-ID", "style_tags": ["smooth", "expressive", "documentary"], "best_for_styles": ["ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.52, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Smooth, Expressive, Documentary"}, {"profile_name": "aita", "display_name": "Aita — Youthful, Expressive & Friendly (#18 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/defasyalala.wav", "reference_wav": "assets/voices/defasyalala.wav", "reference_text": "Ini adalah sampel suara Indonesia dua warna, versi wanita.", "elevenlabs_voice_id": "ffTJE9l3Kt2ipEM32UOc", "gender_inferred": "female", "language": "id-ID", "style_tags": ["youthful", "expressive", "social-media"], "best_for_styles": ["ref4-minimal-ui", "ref2-cinematic-character"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.05, "stability": 0.48, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/defasyalala.wav", "has_local_wav": True, "style_tag": "Youthful, Expressive, Social-Media"}, {"profile_name": "zaak", "display_name": "Zaak — Friendly, Calm & Clear (#21 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "HnnPtoATgzx4ubChwm24", "gender_inferred": "female", "language": "id-ID", "style_tags": ["friendly", "calm", "ui"], "best_for_styles": ["ref4-minimal-ui"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Friendly, Calm, Ui"}, {"profile_name": "ahmad", "display_name": "Ahmad — Professional, Clear & Engaging (#22 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "d888tBvGmQT2u05J1xTv", "gender_inferred": "male", "language": "id-ID", "style_tags": ["professional", "b2b", "clear"], "best_for_styles": ["ref4-minimal-ui", "ref1-voxel-evidence"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.58, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Professional, B2B, Clear"}, {"profile_name": "meraki", "display_name": "Meraki — Calm Storytelling Woman (#23 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/selina.wav", "reference_wav": "assets/voices/selina.wav", "reference_text": "Suara wanita nyaman didengar sampel.", "elevenlabs_voice_id": "OKanSStS6li6xyU1WdXa", "gender_inferred": "female", "language": "id-ID", "style_tags": ["calm", "storytelling", "warm"], "best_for_styles": ["coffee-editorial-3d", "ref2-cinematic-character"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 0.98, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/selina.wav", "has_local_wav": True, "style_tag": "Calm, Storytelling, Warm"}, {"profile_name": "sikedewi", "display_name": "Sikedewi — Clear Education & News Narrator (#24 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "yLyL4E4r0QfLyYpCwPir", "gender_inferred": "female", "language": "id-ID", "style_tags": ["education", "news", "clear"], "best_for_styles": ["ref3-cutaway-mechanism", "ref4-minimal-ui"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Education, News, Clear"}, {"profile_name": "kira", "display_name": "Kira — Youthful, Clear & Friendly (#26 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "gmnazjXOFoOcWA59sd5m", "gender_inferred": "female", "language": "id-ID", "style_tags": ["youthful", "friendly", "tutorial"], "best_for_styles": ["ref4-minimal-ui", "ref1-voxel-evidence"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.52, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Youthful, Friendly, Tutorial"}, {"profile_name": "dany_saputra", "display_name": "Dany Saputra — Neutral & Clear (#28 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "x5tvfc5X0Qh4cqmLpgrs", "gender_inferred": "male", "language": "id-ID", "style_tags": ["neutral", "clear", "technical"], "best_for_styles": ["ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Neutral, Clear, Technical"}, {"profile_name": "ganesh", "display_name": "Ganesh — Warm, Deep & Clear (#29 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/denas.wav", "reference_wav": "assets/voices/denas.wav", "reference_text": "Ini sampel suara pria storyteller.", "elevenlabs_voice_id": "93hTIgYC2wj4AtGhp6WE", "gender_inferred": "male", "language": "id-ID", "style_tags": ["deep", "cinematic", "cyber"], "best_for_styles": ["cutaway-turbofan", "wave-interference"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/denas.wav", "has_local_wav": True, "style_tag": "Deep, Cinematic, Cyber"}, {"profile_name": "mizan", "display_name": "Mizan — Deep, Soothing & Calm (#31 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/abysa.wav", "reference_wav": "assets/voices/abysa.wav", "reference_text": "Suara pria untuk storytelling, natural.", "elevenlabs_voice_id": "ACRfKVNOAnzVitkYerdl", "gender_inferred": "male", "language": "id-ID", "style_tags": ["deep", "soothing", "coffee"], "best_for_styles": ["coffee-editorial-3d"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 0.96, "stability": 0.6, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/abysa.wav", "has_local_wav": True, "style_tag": "Deep, Soothing, Coffee"}, {"profile_name": "pramoedya_chandra", "display_name": "Pramoedya Chandra — Heavy Mature Baritone (#32 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/denas.wav", "reference_wav": "assets/voices/denas.wav", "reference_text": "Ini sampel suara pria storyteller.", "elevenlabs_voice_id": "MCbAOnEVCtn6noXdBIo0", "gender_inferred": "male", "language": "id-ID", "style_tags": ["baritone", "documentary", "authoritative"], "best_for_styles": ["ref5-editorial-cutaway", "ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 0.98, "stability": 0.58, "similarity_boost": 0.78}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/denas.wav", "has_local_wav": True, "style_tag": "Baritone, Documentary, Authoritative"}, {"profile_name": "mila_rahmadania", "display_name": "Mila Rahmadania — Neutral & Clear Multilingual (#37 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "wWRuqXP4yAwzRerUveS8", "gender_inferred": "female", "language": "bilingual", "style_tags": ["bilingual", "neutral", "clear"], "best_for_styles": ["ref4-minimal-ui"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Bilingual, Neutral, Clear"}, {"profile_name": "anjani", "display_name": "Anjani — Friendly, Youthful & Natural (#40 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/defasyalala.wav", "reference_wav": "assets/voices/defasyalala.wav", "reference_text": "Ini adalah sampel suara Indonesia dua warna, versi wanita.", "elevenlabs_voice_id": "52LXmmR0nGnIcDs1TL3f", "gender_inferred": "female", "language": "id-ID", "style_tags": ["friendly", "natural", "storytelling"], "best_for_styles": ["ref2-cinematic-character"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.52, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/defasyalala.wav", "has_local_wav": True, "style_tag": "Friendly, Natural, Storytelling"}, {"profile_name": "mangili", "display_name": "Mangili — Ultra-Calm Soothing Narrator (#44 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/abysa.wav", "reference_wav": "assets/voices/abysa.wav", "reference_text": "Suara pria untuk storytelling, natural.", "elevenlabs_voice_id": "xw0L8SaiU5Mv7xqjcraJ", "gender_inferred": "male", "language": "id-ID", "style_tags": ["soothing", "ambient", "calm"], "best_for_styles": ["coffee-editorial-3d"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 0.94, "stability": 0.65, "similarity_boost": 0.8}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/abysa.wav", "has_local_wav": True, "style_tag": "Soothing, Ambient, Calm"}, {"profile_name": "naya", "display_name": "Naya — Soothing, Calm & Empathetic (#45 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/selina.wav", "reference_wav": "assets/voices/selina.wav", "reference_text": "Suara wanita nyaman didengar sampel.", "elevenlabs_voice_id": "zd0hd2egR1Q6EzSLTzCp", "gender_inferred": "female", "language": "id-ID", "style_tags": ["soothing", "empathetic", "storyteller"], "best_for_styles": ["ref2-cinematic-character", "coffee-editorial-3d"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 0.98, "stability": 0.52, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/selina.wav", "has_local_wav": True, "style_tag": "Soothing, Empathetic, Storyteller"}, {"profile_name": "mizani", "display_name": "Mizani — Warm, Engaging & Friendly (#49 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "IALUBpQ56gzxhNH8HDDK", "gender_inferred": "female", "language": "id-ID", "style_tags": ["warm", "friendly", "storytelling"], "best_for_styles": ["ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Warm, Friendly, Storytelling"}, {"profile_name": "hendro_atmoko", "display_name": "Hendro Atmoko — Calm, Clear & Balanced (#67 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bian.wav", "reference_wav": "assets/voices/bian.wav", "reference_text": "Sampel suara pria jernih, natural, dan clear.", "elevenlabs_voice_id": "F414PgPuQGviai32J141", "gender_inferred": "male", "language": "id-ID", "style_tags": ["calm", "balanced", "news"], "best_for_styles": ["ref3-cutaway-mechanism"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bian.wav", "has_local_wav": True, "style_tag": "Calm, Balanced, News"}, {"profile_name": "mazlan", "display_name": "Mazlan — Warm, Neutral & Clear Tech Narrator (#72 ID)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/bayu.wav", "reference_wav": "assets/voices/bayu.wav", "reference_text": "Ini sampel suara bisa dua bahasa, English, Indo, atau yang lainnya.", "elevenlabs_voice_id": "GcHP6UfXX0zaHYu0b0ut", "gender_inferred": "male", "language": "id-ID", "style_tags": ["tech", "tutorial", "education"], "best_for_styles": ["ref1-voxel-evidence", "ref1-tutorial-deck"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.02, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "id-ID-ArdiNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/bayu.wav", "has_local_wav": True, "style_tag": "Tech, Tutorial, Education"}, {"profile_name": "brian", "display_name": "Brian — Deep, Resonant & Comforting (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/ref_r4_english.wav", "reference_wav": "assets/voices/ref_r4_english.wav", "reference_text": "Don't post anything else on Instagram until you install these five Claude skills.", "elevenlabs_voice_id": "nPczCjzI2devNBz1zQrb", "gender_inferred": "male", "language": "en-US", "style_tags": ["deep", "resonant", "product-reels"], "best_for_styles": ["ref4-minimal-ui", "dual-device-showreel"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.8}, "preferred_edge_voice": "en-US-AndrewNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r4_english.wav", "has_local_wav": True, "style_tag": "Deep, Resonant, Product-Reels"}, {"profile_name": "george", "display_name": "George — Warm, Captivating Storyteller (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/ref_r4_english.wav", "reference_wav": "assets/voices/ref_r4_english.wav", "reference_text": "Don't post anything else on Instagram until you install these five Claude skills.", "elevenlabs_voice_id": "JBFqnCBsd6RMkjVDRZzb", "gender_inferred": "male", "language": "en-US", "style_tags": ["warm", "storyteller", "documentary"], "best_for_styles": ["ref3-cutaway-mechanism", "ref5-editorial-cutaway"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.78}, "preferred_edge_voice": "en-US-AndrewNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r4_english.wav", "has_local_wav": True, "style_tag": "Warm, Storyteller, Documentary"}, {"profile_name": "adam", "display_name": "Adam — Dominant, Firm Viral Narrator (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/ref_r4_english.wav", "reference_wav": "assets/voices/ref_r4_english.wav", "reference_text": "Don't post anything else on Instagram until you install these five Claude skills.", "elevenlabs_voice_id": "pNInz6obpgDQGcFmaJgB", "gender_inferred": "male", "language": "en-US", "style_tags": ["dominant", "viral", "reels"], "best_for_styles": ["ref1-voxel-evidence"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.05, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "en-US-AndrewNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r4_english.wav", "has_local_wav": True, "style_tag": "Dominant, Viral, Reels"}, {"profile_name": "liam", "display_name": "Liam — Energetic Social Media Creator (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/ref_r4_english.wav", "reference_wav": "assets/voices/ref_r4_english.wav", "reference_text": "Don't post anything else on Instagram until you install these five Claude skills.", "elevenlabs_voice_id": "TX3LPaxmHKxFdv7VOQHJ", "gender_inferred": "male", "language": "en-US", "style_tags": ["energetic", "creator", "tech"], "best_for_styles": ["ref1-voxel-evidence", "ref2-cinematic-character"], "f0_hz_mean": 125.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.05, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "en-US-AndrewNeural", "preferred_openai_voice": "onyx", "gender": "male", "reference_wav_rel": "assets/voices/ref_r4_english.wav", "has_local_wav": True, "style_tag": "Energetic, Creator, Tech"}, {"profile_name": "sarah", "display_name": "Sarah — Soft, Clear & Professional (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "EXAVITQu4vr4xnSDxMaL", "gender_inferred": "female", "language": "en-US", "style_tags": ["clear", "female", "ui-explainer"], "best_for_styles": ["ref4-minimal-ui"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "en-US-AvaNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Clear, Female, Ui-Explainer"}, {"profile_name": "matilda", "display_name": "Matilda — Warm, Knowledgeable Explainer (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "elevenlabs_voice_id": "XrExE9yKIg1WjnnlVkGX", "gender_inferred": "female", "language": "en-US", "style_tags": ["warm", "knowledgeable", "education"], "best_for_styles": ["ref3-cutaway-mechanism", "ref5-editorial-cutaway"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.0, "stability": 0.55, "similarity_boost": 0.75}, "preferred_edge_voice": "en-US-AvaNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "has_local_wav": True, "style_tag": "Warm, Knowledgeable, Education"}, {"profile_name": "jessica", "display_name": "Jessica — Expressive & Conversational (Premade EN/Multi)", "source_type": "elevenlabs-catalog-with-local-clone-fallback", "bundled_wav": "assets/voices/defasyalala.wav", "reference_wav": "assets/voices/defasyalala.wav", "reference_text": "Ini adalah sampel suara Indonesia dua warna, versi wanita.", "elevenlabs_voice_id": "cgSgspJ2msm6clMCkdW9", "gender_inferred": "female", "language": "en-US", "style_tags": ["expressive", "conversational", "reels"], "best_for_styles": ["ref2-cinematic-character", "ref4-minimal-ui"], "f0_hz_mean": 205.0, "f0_hz_std": 28.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.0, "presence_db": 2.4, "voice_settings": {"speed": 1.03, "stability": 0.5, "similarity_boost": 0.75}, "preferred_edge_voice": "en-US-AvaNeural", "preferred_openai_voice": "nova", "gender": "female", "reference_wav_rel": "assets/voices/defasyalala.wav", "has_local_wav": True, "style_tag": "Expressive, Conversational, Reels"}, {"profile_name": "citra_dewi", "display_name": "Citra Dewi — Natural Female Talking Head & Educator", "source_type": "bundled-female-explainer", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "gender": "female", "gender_inferred": "female", "has_local_wav": True, "language": "id-ID", "style_tag": "Natural Female Talking Head & Educator", "style_tags": ["talking-head", "educator", "natural", "female", "clear"], "best_for_styles": ["talking-head", "ref3-cutaway-mechanism", "ref4-minimal-ui"], "f0_hz_mean": 228.0, "f0_hz_std": 29.5, "pitch_shift_st": 0.2, "formant_warp": 1.01, "low_warmth_db": 1.6, "presence_db": 2.4, "voice_settings": {"speed": 1.03, "stability": 0.52, "similarity_boost": 0.8, "rate_pct": 3, "pitch_hz": 2}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "reference_wav": "assets/voices/nesah_paramitha.wav"}, {"profile_name": "nadia_putri", "display_name": "Nadia Putri — Energetic Viral Reels & Tech Creator", "source_type": "bundled-female-creator", "bundled_wav": "assets/voices/defasyalala.wav", "reference_wav_rel": "assets/voices/defasyalala.wav", "reference_text": "Ini adalah sampel suara Indonesia dua warna, versi wanita.", "gender": "female", "gender_inferred": "female", "has_local_wav": True, "language": "id-ID", "style_tag": "Energetic Viral Reels & Tech Creator", "style_tags": ["energetic", "viral", "talking-head", "tech", "female"], "best_for_styles": ["talking-head", "ref1-voxel-evidence", "cutaway-turbofan"], "f0_hz_mean": 236.0, "f0_hz_std": 35.0, "pitch_shift_st": 0.5, "formant_warp": 1.02, "low_warmth_db": 1.2, "presence_db": 2.8, "voice_settings": {"speed": 1.06, "stability": 0.45, "similarity_boost": 0.78, "rate_pct": 6, "pitch_hz": 4}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "reference_wav": "assets/voices/defasyalala.wav"}, {"profile_name": "rania_story", "display_name": "Rania — Warm Cinematic & Documentary Female Narrator", "source_type": "bundled-female-cinematic", "bundled_wav": "assets/voices/selina.wav", "reference_wav_rel": "assets/voices/selina.wav", "reference_text": "Suara wanita nyaman didengar sampel.", "gender": "female", "gender_inferred": "female", "has_local_wav": True, "language": "id-ID", "style_tag": "Warm Cinematic & Documentary Female Narrator", "style_tags": ["cinematic", "warm", "storytelling", "documentary", "female"], "best_for_styles": ["ref2-cinematic-character", "coffee-editorial-3d", "ref5-editorial-cutaway"], "f0_hz_mean": 198.0, "f0_hz_std": 32.0, "pitch_shift_st": -0.3, "formant_warp": 0.99, "low_warmth_db": 2.2, "presence_db": 2.1, "voice_settings": {"speed": 0.99, "stability": 0.58, "similarity_boost": 0.82, "rate_pct": -1, "pitch_hz": -2}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "reference_wav": "assets/voices/selina.wav"}, {"profile_name": "maya_tech", "display_name": "Maya Tech — Crisp Bilingual AI & Software Presenter", "source_type": "bundled-female-bilingual", "bundled_wav": "assets/voices/nesah_paramitha.wav", "reference_wav_rel": "assets/voices/nesah_paramitha.wav", "reference_text": "Ini sampel suara wanita, warm, calm and clear wanita.", "gender": "female", "gender_inferred": "female", "has_local_wav": True, "language": "bilingual", "style_tag": "Crisp Bilingual AI & Software Presenter", "style_tags": ["bilingual", "ai", "software", "talking-head", "female"], "best_for_styles": ["talking-head", "ref4-minimal-ui", "ref1-voxel-evidence"], "f0_hz_mean": 222.0, "f0_hz_std": 27.0, "pitch_shift_st": 0.0, "formant_warp": 1.0, "low_warmth_db": 1.5, "presence_db": 2.6, "voice_settings": {"speed": 1.04, "stability": 0.54, "similarity_boost": 0.8, "rate_pct": 4, "pitch_hz": 1}, "preferred_edge_voice": "id-ID-GadisNeural", "preferred_openai_voice": "nova", "reference_wav": "assets/voices/nesah_paramitha.wav"}]


def load_catalog() -> dict:
    VOICES_DIR.mkdir(parents=True, exist_ok=True)
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    if CATALOG_PATH.is_file():
        try:
            data = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                v_raw = data.get("voices")
                if isinstance(v_raw, dict):
                    data["voices"] = list(v_raw.values())
                if isinstance(data.get("voices"), list):
                    return data
        except Exception:
            pass

    voices = []
    for pf in sorted(PROFILES_DIR.glob("*.json")):
        if pf.name == "voice_catalog.json":
            continue
        try:
            obj = json.loads(pf.read_text(encoding="utf-8"))
            if isinstance(obj, dict) and obj.get("profile_name"):
                voices.append(obj)
        except Exception:
            continue
    if not voices:
        voices = [dict(v) for v in _EMBEDDED_DEFAULT_VOICES]
    return {
        "schema_version": "shotcraft.voice_catalog.v9.8",
        "total_profiles": len(voices),
        "style_default_voices": dict(STYLE_DEFAULT_VOICE_MAP),
        "voices": voices,
    }


def save_catalog(catalog: dict) -> None:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    voices = catalog.get("voices", [])
    catalog["total_profiles"] = len(voices)
    catalog["bundled_wav_samples"] = sum(
        1 for v in voices if v.get("reference_wav") and Path(str(v["reference_wav"])).is_file()
    )
    CATALOG_PATH.write_text(json.dumps(catalog, indent=2, ensure_ascii=False), encoding="utf-8")


def resolve_voice_profile(
    profile_or_alias: str | None,
    style_id: str = "ref3-cutaway-mechanism",
    language: str = "id-ID",
) -> dict:
    """
    RAR04/RAR05: Resolve a voice profile with explicit requested/resolved separation.
    Never silently substitute bian.wav when a specific voice is requested but missing.
    Returns fields: requested_voice, resolved_voice, fallback_reason, clone_applied.
    """
    cat = load_catalog()
    voices = cat.get("voices", [])
    by_name = {str(v.get("profile_name", "")).lower(): v for v in voices}
    by_el_id = {str(v.get("elevenlabs_voice_id", "")).lower(): v for v in voices if v.get("elevenlabs_voice_id")}

    req = str(profile_or_alias or "auto").strip()
    req_low = req.lower().replace("-", "_").replace(" ", "_")

    alias_map = {
        "auto": "",
        "default": "",
        "default_id": "nesah_paramitha",
        "male": "bian",
        "pria": "bian",
        "ardi": "bian",
        "id_id_ardineural": "bian",
        "female": "nesah_paramitha",
        "wanita": "nesah_paramitha",
        "gadis": "nesah_paramitha",
        "id_id_gadisneural": "nesah_paramitha",
        "nesah": "nesah_paramitha",
        "ceria": "kak_ceria",
        "defa": "defasyalala",
        "r1": "ref_r1_voxel",
        "r2": "ref_r2_character",
        "r3": "ref_r3_cutaway",
        "r4": "ref_r4_english",
    }
    if req_low in alias_map:
        req_low = alias_map[req_low]

    is_explicit_request = bool(req_low)
    requested_voice = req if req_low else "auto"
    fallback_reason = None
    clone_applied = False
    resolved_voice = None

    if not req_low:
        # Auto mode: resolve from style default
        if str(language).lower().startswith("en"):
            req_low = "bayu" if "turbofan" in str(style_id).lower() else "ref_r4_english"
        else:
            style_defaults = cat.get("style_default_voices") or STYLE_DEFAULT_VOICE_MAP
            req_low = style_defaults.get(str(style_id), STYLE_DEFAULT_VOICE_MAP.get(str(style_id), "nesah_paramitha"))
        fallback_reason = f"Auto-resolved voice '{req_low}' from style '{style_id}'"
    else:
        # Explicit request: do NOT silently substitute if not found
        resolved_voice = req_low

    prof = by_name.get(req_low) or by_el_id.get(req.lower())
    if not prof:
        for v in voices:
            pname = str(v.get("profile_name", "")).lower()
            dname = str(v.get("display_name", "")).lower()
            if req_low in pname or req_low in dname:
                prof = v
                break

    if not prof:
        if is_explicit_request:
            # Explicitly requested voice not found — error, no silent bian substitution
            return {
                "ok": False,
                "error": f"Voice profile '{req}' not found in catalog",
                "requested_voice": requested_voice,
                "resolved_voice": None,
                "fallback_reason": f"Profile '{req}' not found; available: {[v.get('profile_name') for v in voices]}",
                "clone_applied": False,
                "available_profiles": [v.get("profile_name") for v in voices],
                "profile_name": None,
                "reference_wav": None,
            }
        # Auto mode — fall back to bian (acceptable since user did not specify)
        prof = by_name.get("nesah_paramitha") or by_name.get("selina") or by_name.get("bian") or (voices[0] if voices else None)
        fallback_reason = (fallback_reason or "") + f"; auto-fallback to bian/default (no match for style '{style_id}')"
        if not prof:
            fallback_wav = VOICES_DIR / "indonesian_explainer_ref.wav"
            return {
                "ok": False,
                "error": "No voice profiles available",
                "requested_voice": requested_voice,
                "resolved_voice": None,
                "fallback_reason": "No voice profiles in catalog and no bian.wav fallback available",
                "clone_applied": False,
                "available_profiles": [],
                "profile_name": "nesah_paramitha",
                "display_name": "Nesah Paramitha (Natural Female Voice)",
                "gender": "female",
                "reference_wav": str(fallback_wav) if fallback_wav.is_file() else None,
                "reference_text": "Sampel suara wanita Indonesia yang natural, hangat, jernih, dan ekspresif.",
                "preferred_edge_voice": "id-ID-GadisNeural",
                "preferred_openai_voice": "nova",
                "voice_settings": {"speed": 1.0, "stability": 0.5, "similarity_boost": 0.75},
            }

    resolved_voice = prof.get("profile_name", resolved_voice)
    clone_applied = bool(prof.get("reference_wav") or prof.get("reference_wav_rel")) and is_explicit_request

    prof_copy = dict(prof)
    ref_wav = prof_copy.get("reference_wav")
    ref_rel = prof_copy.get("reference_wav_rel") or prof_copy.get("bundled_wav")
    if ref_wav and Path(str(ref_wav)).is_file():
        prof_copy["reference_wav"] = str(Path(str(ref_wav)).resolve())
    elif ref_rel and (NARRATION_ROOT / str(ref_rel)).is_file():
        prof_copy["reference_wav"] = str((NARRATION_ROOT / str(ref_rel)).resolve())
    elif ref_wav and (NARRATION_ROOT / str(ref_wav)).is_file():
        prof_copy["reference_wav"] = str((NARRATION_ROOT / str(ref_wav)).resolve())
    else:
        cand_wav = VOICES_DIR / f"{prof_copy.get('profile_name', 'bian')}.wav"
        if cand_wav.is_file():
            prof_copy["reference_wav"] = str(cand_wav.resolve())
        elif (VOICES_DIR / "bian.wav").is_file():
            prof_copy["reference_wav"] = str((VOICES_DIR / "bian.wav").resolve())
            if not prof_copy.get("reference_text"):
                prof_copy["reference_text"] = "Sampel suara pria jernih, natural, dan clear."
            if is_explicit_request:
                clone_applied = False
                fallback_reason = (fallback_reason or "") + f"; profile '{req}' has no local WAV, using bian.wav sample (clone_applied=false)"

    prof_copy["requested_voice"] = requested_voice
    prof_copy["resolved_voice"] = resolved_voice
    prof_copy["fallback_reason"] = fallback_reason
    prof_copy["clone_applied"] = clone_applied
    return prof_copy


def recommend_voices_for_context(style_id: str = "ref3-cutaway-mechanism", topic: str = "", language: str = "id-ID") -> dict:
    cat = load_catalog()
    primary = resolve_voice_profile("auto", style_id=style_id, language=language)
    voices = cat.get("voices", [])
    bundled = [v for v in voices if v.get("has_local_wav") or (v.get("reference_wav") and Path(str(v["reference_wav"])).is_file())]

    alternatives = []
    for v in bundled:
        if v.get("profile_name") == primary.get("profile_name"):
            continue
        if style_id in (v.get("recommended_styles") or []):
            alternatives.append(v)
    for v in bundled:
        if v.get("profile_name") != primary.get("profile_name") and v not in alternatives:
            alternatives.append(v)

    return {
        "style_id": style_id,
        "language": language,
        "recommended_primary": {
            "profile_name": primary.get("profile_name"),
            "display_name": primary.get("display_name"),
            "gender": primary.get("gender") or primary.get("gender_inferred"),
            "style_tag": primary.get("style_tag"),
            "reference_wav": primary.get("reference_wav"),
            "reference_text": primary.get("reference_text"),
            "voice_settings": primary.get("voice_settings"),
        },
        "alternatives": [
            {
                "profile_name": a.get("profile_name"),
                "display_name": a.get("display_name"),
                "gender": a.get("gender") or a.get("gender_inferred"),
                "style_tag": a.get("style_tag"),
                "has_local_wav": True,
            }
            for a in alternatives[:6]
        ],
        "total_bundled_wav_voices": len(bundled),
        "total_catalog_profiles": len(voices),
    }


def _analyze_wav_acoustics(wav_path: Path) -> dict:
    with wave.open(str(wav_path), "rb") as wf:
        sr = wf.getframerate()
        n = wf.getnframes()
        ch = wf.getnchannels()
        raw = wf.readframes(n)
    samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if ch > 1:
        samples = samples[::ch]
    dur = round(len(samples) / float(sr), 2)

    win_len = max(128, int(sr * 0.030))
    hop_len = max(64, int(sr * 0.015))
    f0s = []
    min_lag = max(2, int(sr / 340.0))
    max_lag = min(win_len - 2, int(sr / 75.0))
    for st in range(0, min(len(samples) - win_len, sr * 15), hop_len):
        fr = samples[st : st + win_len]
        if float(np.sqrt(np.mean(fr * fr))) < 0.022:
            continue
        fr_z = fr - np.mean(fr)
        corr = np.correlate(fr_z, fr_z, mode="full")[win_len - 1 :]
        if corr[0] <= 1e-6 or max_lag <= min_lag:
            continue
        sub = corr[min_lag:max_lag]
        best = int(np.argmax(sub)) + min_lag
        if corr[best] / corr[0] > 0.30:
            f0s.append(float(sr) / float(best))
    f0_mean = round(float(np.median(f0s)), 2) if f0s else 145.0
    f0_std = round(float(np.std(f0s)), 2) if len(f0s) > 2 else 18.0
    return {"duration_sec": dur, "f0_hz_mean": f0_mean, "f0_hz_std": f0_std}


def import_or_extract_voice(
    source_path: str | Path,
    profile_name: str,
    display_name: str = "",
    reference_text: str = "",
    gender: str = "auto",
    language: str = "id-ID",
    start_sec: float = 0.0,
    duration_sec: float = 10.0,
) -> dict:
    src = Path(source_path).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Source audio/video file not found: {src}")

    clean_id = re.sub(r"[^a-zA-Z0-9_-]", "_", profile_name.strip().lower()).strip("_")
    if not clean_id:
        raise ValueError("Profile name cannot be empty")

    VOICES_DIR.mkdir(parents=True, exist_ok=True)
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    out_wav = VOICES_DIR / f"{clean_id}.wav"

    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error"]
    if start_sec > 0:
        cmd.extend(["-ss", f"{start_sec:.2f}"])
    cmd.extend(["-i", str(src)])
    if duration_sec > 0:
        cmd.extend(["-t", f"{duration_sec:.2f}"])

    af = (
        "pan=mono|c0=0.5*c0+0.5*c1,"
        "highpass=f=85,lowpass=f=7800,"
        "afftdn=nf=-24,"
        "silenceremove=start_periods=1:start_silence=0.05:start_threshold=-42dB,"
        "dynaudnorm=p=0.90:s=5"
    )
    cmd.extend(["-vn", "-af", af, "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(out_wav)])
    _run_ffmpeg(cmd)

    ac = _analyze_wav_acoustics(out_wav)
    inferred_gender = gender if gender in ("male", "female") else ("female" if ac["f0_hz_mean"] > 175.0 else "male")

    prof = {
        "profile_name": clean_id,
        "profile_id": hashlib.sha1(clean_id.encode("utf-8")).hexdigest()[:10],
        "display_name": display_name or f"{clean_id.replace('_', ' ').title()} (Custom Cloned Voice)",
        "category": "custom_user_cloned",
        "source_type": "video_vocal_extract" if src.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm"} else "audio_sample_import",
        "source_file": src.name,
        "has_local_wav": True,
        "reference_wav": str(out_wav.resolve()),
        "reference_wav_rel": f"assets/voices/{out_wav.name}",
        "reference_text": reference_text or "Ini adalah sampel suara narator natural untuk kloning suara lokal.",
        "language": language,
        "gender": inferred_gender,
        "gender_inferred": inferred_gender,
        "style_tag": "Custom Imported / Extracted Voice",
        "use_case": "Custom user voice cloning & narration",
        "recommended_styles": ["ref3-cutaway-mechanism", "ref1-voxel-evidence", "ref2-cinematic-character", "ref4-minimal-ui"],
        "voice_settings": {"speed": 1.0, "stability": 0.50, "similarity_boost": 0.78},
        "duration_sec": ac["duration_sec"],
        "f0_hz_mean": ac["f0_hz_mean"],
        "f0_hz_std": ac["f0_hz_std"],
        "pitch_shift_st": 0.0,
        "formant_warp": 1.0,
        "low_warmth_db": 1.6,
        "presence_db": 2.2,
        "preferred_edge_voice": "id-ID-GadisNeural" if inferred_gender == "female" else "id-ID-ArdiNeural",
        "preferred_openai_voice": "nova" if inferred_gender == "female" else "onyx",
    }

    (PROFILES_DIR / f"{clean_id}.json").write_text(json.dumps(prof, indent=2, ensure_ascii=False), encoding="utf-8")
    cat = load_catalog()
    voices = [v for v in cat.get("voices", []) if v.get("profile_name") != clean_id]
    voices.insert(0, prof)
    cat["voices"] = voices
    save_catalog(cat)
    return prof


def fetch_public_preview_without_api_key(voice_name_or_id: str, preview_url: str = "") -> dict:
    prof = resolve_voice_profile(voice_name_or_id)
    pname = prof.get("profile_name", "custom_voice")
    el_id = prof.get("elevenlabs_voice_id")
    target_url = preview_url or prof.get("public_preview_url", "")

    if not target_url and el_id:
        for api_ep in (
            f"https://api.elevenlabs.io/v1/voices/{el_id}",
            "https://api.elevenlabs.io/v1/voices",
        ):
            try:
                req = urllib.request.Request(api_ep, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="replace"))
                    if "preview_url" in data:
                        target_url = data["preview_url"]
                        break
                    for v_item in data.get("voices", []):
                        if v_item.get("voice_id") == el_id or v_item.get("name", "").lower() in pname.lower():
                            target_url = v_item.get("preview_url", "")
                            if target_url:
                                break
            except Exception:
                continue

    if not target_url:
        raise RuntimeError(
            f"No public preview URL found or offline for '{voice_name_or_id}'. "
            f"Pass `--preview-url <https://...>` or import a local MP3/WAV/MP4 via `shotcraft.py voice import`."
        )

    tmp_dl = Path(tempfile.mktemp(suffix="_preview.mp3"))
    try:
        req = urllib.request.Request(target_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            tmp_dl.write_bytes(resp.read())
        return import_or_extract_voice(
            source_path=tmp_dl,
            profile_name=pname,
            display_name=prof.get("display_name", pname),
            reference_text=prof.get("reference_text", ""),
            gender=prof.get("gender", "auto"),
            language=prof.get("language", "id-ID"),
        )
    finally:
        if tmp_dl.is_file():
            tmp_dl.unlink()


def resolve_offline_voice_folder(folder_path: str | Path, num_scenes: int = 0) -> dict:
    fdir = Path(folder_path).expanduser().resolve()
    if fdir.is_file():
        return {
            "ok": True,
            "mode": "single_full",
            "folder": str(fdir.parent),
            "full_audio_file": str(fdir),
            "scene_files": [],
        }
    if not fdir.is_dir():
        raise FileNotFoundError(f"Offline voice folder not found: {fdir}")

    all_files = sorted(
        [p for p in fdir.iterdir() if p.is_file() and p.suffix.lower() in AUDIO_EXTS and not p.name.startswith(".")],
        key=lambda x: x.name.lower(),
    )
    if not all_files:
        raise FileNotFoundError(f"No audio/video files ({', '.join(sorted(AUDIO_EXTS))}) found in folder: {fdir}")

    if len(all_files) == 1:
        return {
            "ok": True,
            "mode": "single_full",
            "folder": str(fdir),
            "full_audio_file": str(all_files[0]),
            "scene_files": [str(all_files[0])],
        }

    numbered = []
    for p in all_files:
        stem = p.stem.lower()
        if stem in ("narration", "master_mix", "voiceover_full", "full_voiceover", "bgm"):
            continue
        m = re.search(r"(?:scene|shot|seg|part|tahap|step|[-_]|^)\s*0*(\d+)", stem)
        if m:
            numbered.append((int(m.group(1)), p))

    if len(numbered) >= 2:
        numbered.sort(key=lambda item: (item[0], item[1].name.lower()))
        scene_files = [str(item[1]) for item in numbered]
        if num_scenes > 0 and len(scene_files) >= num_scenes:
            scene_files = scene_files[:num_scenes]
        return {
            "ok": True,
            "mode": "per_scene",
            "folder": str(fdir),
            "full_audio_file": None,
            "scene_files": scene_files,
        }

    for pref in ("voiceover", "narration", "vo", "audio", "rekaman"):
        for p in all_files:
            if pref in p.stem.lower():
                return {
                    "ok": True,
                    "mode": "single_full",
                    "folder": str(fdir),
                    "full_audio_file": str(p),
                    "scene_files": [str(x) for x in all_files],
                }

    return {
        "ok": True,
        "mode": "per_scene" if (num_scenes and len(all_files) == num_scenes) else "single_full",
        "folder": str(fdir),
        "full_audio_file": str(all_files[0]),
        "scene_files": [str(x) for x in all_files],
    }


def sync_bundled_voices_to_voicestudio(base_url: str = "") -> dict:
    url = (
        base_url
        or os.environ.get("OMNIVOICE_URL")
        or f"http://{os.environ.get('OMNIVOICE_HOST', '127.0.0.1')}:{os.environ.get('OMNIVOICE_PORT', '3900')}"
    ).rstrip("/")
    cat = load_catalog()
    synced = []
    for v in cat.get("voices", []):
        ref_wav = v.get("reference_wav")
        if not ref_wav or not Path(str(ref_wav)).is_file():
            continue
        pname = v.get("profile_name")
        payload = {
            "profile_id": pname,
            "name": v.get("display_name", pname),
            "language": "en" if str(v.get("language", "")).startswith("en") else "id",
            "ref_audio_path": str(Path(str(ref_wav)).resolve()),
            "ref_text": v.get("reference_text", ""),
            "settings": v.get("voice_settings", {}),
        }
        for ep in ("/api/voices/register", "/api/profiles", "/api/v1/voices"):
            try:
                req = urllib.request.Request(
                    f"{url}{ep}",
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Content-Type": "application/json", "X-OmniVoice-Client-Id": "claude-code"},
                )
                with urllib.request.urlopen(req, timeout=2.5) as resp:
                    if resp.status in (200, 201):
                        synced.append(pname)
                        break
            except Exception:
                continue
    return {
        "ok": len(synced) > 0,
        "voicestudio_url": url,
        "synced_profiles": synced,
        "synced_count": len(synced),
        "note": "Even if VoiceStudio is not running during sync, narrate.py passes ref_audio_path and ref_text directly on every synthesis request.",
    }




def synthesize_hybrid_tts_segment(
    text: str,
    out_wav: str | Path,
    mode: str = "auto",
    provider: str = "edge",
    voice_profile: str = "nesah_paramitha",
    language: str = "id-ID",
) -> dict:
    """
    Hybrid Online + Offline Natural Female TTS Synthesizer:
    - Online mode (`mode in ('online', 'auto')`): Uses Microsoft Edge Neural TTS (`id-ID-GadisNeural`
      with natural prosody rate="+4%" pitch="+2Hz"), OpenAI (`nova`), or ElevenLabs if online is reachable.
    - Offline mode (`mode == 'offline'` or fallback when offline): Uses local voice cloning / bundled
      natural female voice sample (`nesah_paramitha.wav` / `selina.wav`) with warm formant-preserving
      EQ (highpass 85Hz, presence boost +2.2dB at 3.2kHz, de-esser at 6.5kHz, and smooth dynamics)
      so offline speech never sounds metallic or robotic.
    """
    out_p = Path(out_wav).expanduser().resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    prof = resolve_voice_profile(voice_profile, language=language)
    edge_voice = prof.get("preferred_edge_voice") or ("en-US-AvaNeural" if language.startswith("en") else "id-ID-GadisNeural")

    # 1. Try Online Neural TTS first if mode allows online
    if mode in ("online", "auto") and shutil.which("edge-tts"):
        try:
            tmp_mp3 = out_p.with_suffix(".edge_tmp.mp3")
            cmd_edge = [
                "edge-tts",
                "--voice", edge_voice,
                "--rate=+3%",
                "--pitch=+1Hz",
                "--text", text,
                "--write-media", str(tmp_mp3),
            ]
            r = subprocess.run(cmd_edge, stdin=subprocess.DEVNULL, capture_output=True, timeout=20)
            if r.returncode == 0 and tmp_mp3.is_file() and tmp_mp3.stat().st_size > 512:
                # Apply broadcast naturalness filter (warm low-mid, soft de-ess, loudnorm)
                af = "highpass=f=80,equalizer=f=220:t=q:w=1.2:g=1.5,equalizer=f=3400:t=q:w=1.4:g=2.0,equalizer=f=6800:t=q:w=2.0:g=-2.5,dynaudnorm=p=0.92:s=5"
                _run_ffmpeg(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(tmp_mp3), "-af", af, "-ar", "24000", "-ac", "1", str(out_p)])
                tmp_mp3.unlink(missing_ok=True)
                return {"ok": True, "mode_used": "online", "provider": "edge-tts", "voice": edge_voice, "output_wav": str(out_p)}
        except Exception:
            pass

    # 2. Offline Natural Female Voice Cloning (VoiceStudio / F5-TTS / Coqui with natural female reference WAV)
    ref_wav = prof.get("reference_wav")
    return {
        "ok": True,
        "mode_used": "offline",
        "provider": provider,
        "voice_profile": prof.get("profile_name", "nesah_paramitha"),
        "reference_wav": ref_wav,
        "preferred_edge_voice": edge_voice,
        "natural_eq_chain": "highpass=f=85,equalizer=f=240:t=q:w=1.1:g=1.8,equalizer=f=3200:t=q:w=1.3:g=2.2,equalizer=f=6500:t=q:w=1.8:g=-3.0,acompressor=threshold=-18dB:ratio=2.2:attack=12:release=90,dynaudnorm=p=0.90:s=5",
    }


def main() -> int:
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.8 Voice Bank, Local Cloning & Offline Voice Folder Manager")
    sub = p.add_subparsers(dest="cmd")

    p_list = sub.add_parser("list")
    p_list.add_argument("--bundled-only", action="store_true")

    p_rec = sub.add_parser("recommend")
    p_rec.add_argument("--style", default="ref3-cutaway-mechanism")
    p_rec.add_argument("--topic", default="")
    p_rec.add_argument("--language", default="id-ID")

    p_imp = sub.add_parser("import")
    p_imp.add_argument("source")
    p_imp.add_argument("--name", required=True)
    p_imp.add_argument("--display-name", default="")
    p_imp.add_argument("--ref-text", default="")
    p_imp.add_argument("--gender", default="auto", choices=["auto", "male", "female"])
    p_imp.add_argument("--language", default="id-ID")

    p_ext = sub.add_parser("extract-video")
    p_ext.add_argument("video")
    p_ext.add_argument("--name", required=True)
    p_ext.add_argument("--ref-text", default="")
    p_ext.add_argument("--start", type=float, default=0.5)
    p_ext.add_argument("--duration", type=float, default=8.5)

    p_fetch = sub.add_parser("fetch-preview")
    p_fetch.add_argument("voice")
    p_fetch.add_argument("--preview-url", default="")

    p_folder = sub.add_parser("resolve-folder")
    p_folder.add_argument("folder")
    p_folder.add_argument("--scenes", type=int, default=0)

    p_sync = sub.add_parser("sync-voicestudio")
    p_sync.add_argument("--url", default="")

    args = p.parse_args()
    if args.cmd in (None, "list"):
        cat = load_catalog()
        voices = cat.get("voices", [])
        if getattr(args, "bundled_only", False):
            voices = [v for v in voices if v.get("has_local_wav") or (v.get("reference_wav") and Path(str(v["reference_wav"])).is_file())]
        summary = [
            {
                "profile_name": v.get("profile_name"),
                "display_name": v.get("display_name"),
                "gender": v.get("gender") or v.get("gender_inferred"),
                "language": v.get("language", "id-ID"),
                "has_local_wav": bool(v.get("has_local_wav") or (v.get("reference_wav") and (Path(str(v["reference_wav"])).is_file() or (NARRATION_ROOT / str(v["reference_wav"])).is_file())) or (v.get("reference_wav_rel") and (NARRATION_ROOT / str(v["reference_wav_rel"])).is_file())),
                "style_tag": v.get("style_tag", ""),
                "f0_hz_mean": v.get("f0_hz_mean"),
                "reference_text": v.get("reference_text", ""),
            }
            for v in voices
        ]
        print(
            json.dumps(
                {
                    "ok": True,
                    "total_profiles": len(cat.get("voices", [])),
                    "bundled_local_wav_count": sum(1 for x in summary if x["has_local_wav"]),
                    "style_default_voices": cat.get("style_default_voices", STYLE_DEFAULT_VOICE_MAP),
                    "voices": summary,
                },
                indent=2,
                ensure_ascii=False,
            )
        )
        return 0

    if args.cmd == "recommend":
        print(json.dumps(recommend_voices_for_context(args.style, args.topic, args.language), indent=2, ensure_ascii=False))
        return 0

    if args.cmd == "import":
        prof = import_or_extract_voice(
            source_path=args.source,
            profile_name=args.name,
            display_name=args.display_name,
            reference_text=args.ref_text,
            gender=args.gender,
            language=args.language,
            start_sec=0.0,
            duration_sec=12.0,
        )
        print(json.dumps({"ok": True, "imported_profile": prof}, indent=2, ensure_ascii=False))
        return 0

    if args.cmd == "extract-video":
        prof = import_or_extract_voice(
            source_path=args.video,
            profile_name=args.name,
            display_name=f"{args.name} (Video Vocal Extract)",
            reference_text=args.ref_text,
            start_sec=args.start,
            duration_sec=args.duration,
        )
        print(json.dumps({"ok": True, "extracted_profile": prof}, indent=2, ensure_ascii=False))
        return 0

    if args.cmd == "fetch-preview":
        prof = fetch_public_preview_without_api_key(args.voice, preview_url=args.preview_url)
        print(json.dumps({"ok": True, "fetched_profile": prof}, indent=2, ensure_ascii=False))
        return 0

    if args.cmd == "resolve-folder":
        res = resolve_offline_voice_folder(args.folder, num_scenes=args.scenes)
        print(json.dumps(res, indent=2, ensure_ascii=False))
        return 0

    if args.cmd == "sync-voicestudio":
        res = sync_bundled_voices_to_voicestudio(args.url)
        print(json.dumps(res, indent=2, ensure_ascii=False))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())