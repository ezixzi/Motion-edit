#!/usr/bin/env python3
"""
Shotcraft Pro v9.7 — Conversational Indonesian Narrator, SSML & Prosody Engine,
Unified Voice Cloning Profiles, Multi-Speaker Dialogue & Smart Sidechain Ducking (`narrate.py`).

Upgrades implementing SHOTCRAFT_PRO_v9.5_IMPROVEMENT_REPORT:
- Section 1.1: Conversational Prosody, SSML support (<emphasis>, <break>, <prosody>, <emotion>),
  natural micro-breaths, hesitations, and emotional tone / speaking style control.
- Section 1.2: Unified Voice Profile & Voice Cloning system across all providers (saves/loads
  acoustic speaker embeddings: F0 pitch, formant EQ tilt, speaking rate, timbre warmth, reference WAV).
- Section 1.3: Context-aware Indonesian normalization: colloquial/Jakartan slang mapping,
  context-dependent acronym pronunciation (e.g. KPI vs kopi, API vs api), emotional markers,
  and automatic natural clause boundary pauses.
- Section 1.4: Per-word prosody & emphasis control in manifest & build_acoustic_word_timings.
- Section 1.5: Multi-speaker dialogue support (narrator, expert, user, host, guest) with distinct voices.
- Section 4.1: Smart frequency-selective BGM sidechain ducking (carves vocal pocket 250-3800Hz while
  preserving sub-bass groove and highs, with attack/release envelope shaping & beat alignment).
- Section 7.1: Per-segment TTS latency & fallback telemetry.
"""
import argparse
import array
import asyncio
import base64
import ctypes
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import wave
from pathlib import Path

import numpy as np

_HERE_DIR = Path(__file__).resolve().parent
if str(_HERE_DIR) not in sys.path:
    sys.path.insert(0, str(_HERE_DIR))

def _load_voice_bank_module():
    import importlib.util
    vb_path = Path(__file__).resolve().parent / "voice_bank.py"
    if not vb_path.is_file():
        vb_path = Path(__file__).resolve().parents[2] / "reels-narration" / "scripts" / "voice_bank.py"
    spec = importlib.util.spec_from_file_location("voice_bank", str(vb_path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
vb_mod = _load_voice_bank_module()


_COQUI_INSTANCE_CACHE = {}
_FLITE_STATE = {"initialized": False, "flite": None, "v_slt": None, "v_rms": None}
_NET_ONLINE = None


VOICE_ALIAS_MAP = {
    "ardi": "id-ID-ArdiNeural",
    "male": "id-ID-ArdiNeural",
    "pria": "id-ID-ArdiNeural",
    "id-id-ardineural": "id-ID-ArdiNeural",
    "bian": "id-ID-ArdiNeural",
    "zan": "id-ID-ArdiNeural",
    "denas": "id-ID-ArdiNeural",
    "abysa": "id-ID-ArdiNeural",
    "bayu": "id-ID-ArdiNeural",
    "ref_r1_voxel": "id-ID-ArdiNeural",
    "ref_r2_character": "id-ID-ArdiNeural",
    "ref_r3_cutaway": "id-ID-ArdiNeural",
    "gadis": "id-ID-GadisNeural",
    "female": "id-ID-GadisNeural",
    "wanita": "id-ID-GadisNeural",
    "id-id-gadisneural": "id-ID-GadisNeural",
    "nesah_paramitha": "id-ID-GadisNeural",
    "nesah": "id-ID-GadisNeural",
    "defasyalala": "id-ID-GadisNeural",
    "selina": "id-ID-GadisNeural",
    "istiqomah": "id-ID-GadisNeural",
    "kak_ceria": "id-ID-GadisNeural",
    "citra_dewi": "id-ID-GadisNeural",
    "nadia_putri": "id-ID-GadisNeural",
    "rania_story": "id-ID-GadisNeural",
    "maya_tech": "id-ID-GadisNeural",
    "aita": "id-ID-GadisNeural",
    "zaak": "id-ID-GadisNeural",
    "meraki": "id-ID-GadisNeural",
    "sikedewi": "id-ID-GadisNeural",
    "kira": "id-ID-GadisNeural",
    "mila_rahmadania": "id-ID-GadisNeural",
    "anjani": "id-ID-GadisNeural",
    "naya": "id-ID-GadisNeural",
    "mizani": "id-ID-GadisNeural",
    "sarah": "en-US-AvaNeural",
    "matilda": "en-US-AvaNeural",
    "jessica": "en-US-AvaNeural",
    "andrew": "en-US-AndrewNeural",
    "en-male": "en-US-AndrewNeural",
    "en-us-andrewneural": "en-US-AndrewNeural",
    "ref_r4_english": "en-US-AndrewNeural",
    "ava": "en-US-AvaNeural",
    "en-female": "en-US-AvaNeural",
    "en-us-avaneural": "en-US-AvaNeural",
}


def resolve_indonesian_voice_name(voice: str = None, default_voice: str = "id-ID-GadisNeural") -> str:
    if not voice:
        return default_voice
    v_clean = str(voice).strip()
    return VOICE_ALIAS_MAP.get(v_clean.lower(), v_clean)

_ID_SCHWA_WORDS = {
    "delapan", "enam", "empat", "sebelas", "belas", "seratus", "seribu", "setiap", "detik",
    "mengirim", "kecepatan", "lebih", "cepat", "cukup", "menyalakan", "menembus", "mencapai",
    "terang", "sepanjang", "henti", "besar", "kecil", "kerja", "penuh", "terus",
    "berat", "cerdas", "benak", "gelombang", "sel", "dengan", "ketika", "sebuah", "melalui",
    "rekor", "mesin", "gerak", "lemah", "tepat", "bebas", "lepas", "dekat", "benar", "bener",
    "menit", "perlu", "semalaman", "kental", "ngedorong", "semprotan", "bergesekan", "sebentar", "kebakar",
    "seduh", "segar", "celcius", "derajat", "ketimbang", "kenapa", "ternyata", "sekitar",
    "penting", "banget", "seperti", "bekerja", "menjaga", "membuat", "menunggu", "berdebar",
}

# Section 1.3 & Quick Win #7: Indonesian colloquial / Jakartan slang normalization dictionary
_ID_COLLOQUIAL_MAP = {
    "gue": "saya",
    "gw": "saya",
    "gua": "saya",
    "lu": "kamu",
    "lo": "kamu",
    "elo": "kamu",
    "gak": "tidak",
    "nggak": "tidak",
    "ngga": "tidak",
    "enggak": "tidak",
    "kagak": "tidak",
    "udah": "sudah",
    "udh": "sudah",
    "blm": "belum",
    "belom": "belum",
    "bgt": "banget",
    "bener": "benar",
    "beneran": "sungguh",
    "gimana": "bagaimana",
    "gmn": "bagaimana",
    "kayak": "seperti",
    "kaya": "seperti",
    "kyk": "seperti",
    "doang": "saja",
    "aja": "saja",
    "aj": "saja",
    "bikin": "membuat",
    "dapet": "dapat",
    "dpt": "dapat",
    "pake": "pakai",
    "pk": "pakai",
    "tau": "tahu",
    "kalo": "kalau",
    "kl": "kalau",
    "krn": "karena",
    "karna": "karena",
    "tp": "tetapi",
    "utk": "untuk",
    "buat": "untuk",
    "jd": "jadi",
    "jgn": "jangan",
    "hrs": "harus",
    "bs": "bisa",
    "dlm": "dalam",
    "pdhl": "padahal",
    "skrg": "sekarang",
    "ntar": "nanti",
    "tar": "nanti",
    "방": "",
}

# Section 1.3: Context-dependent Indonesian & tech acronyms (pronounced letter-by-letter when uppercase)
_ID_ACRONYM_MAP = {
    "KPI": "ka pe i",
    "API": "e pi ai",
    "AI": "e ai",
    "UI": "yu ai",
    "UX": "yu eks",
    "CPU": "si pi yu",
    "GPU": "ji pi yu",
    "SSD": "es es de",
    "USB": "yu es bi",
    "LED": "el e de",
    "RPM": "er pe em",
    "AHM": "a ha em",
    "ECM": "e ce em",
    "BBM": "be be em",
    "UMKM": "u em ka em",
    "BPJS": "be pe je es",
    "BUMN": "be u em en",
    "KTP": "ka te pe",
    "NPWP": "en pe we pe",
    "SDM": "es de em",
    "SOP": "es o pe",
    "ROI": "ar o ai",
    "CTR": "si ti ar",
    "CPM": "si pi em",
    "FPS": "ef pe es",
    "DNA": "de en a",
    "RNA": "er en a",
    "WHO": "we ha o",
    "SCA": "es ce a",
}

# Section 1.1 & 1.5: Emotional tone & speaking style presets
EMOTION_PROSODY_PRESETS = {
    "neutral": {"rate_pct": 0, "pitch_st": 0.0, "volume_db": 0.0, "breath_gain": 0.04, "edge_style": "general"},
    "conversational": {"rate_pct": 1, "pitch_st": 0.0, "volume_db": 0.6, "breath_gain": 0.05, "edge_style": "chat"},
    "calm": {"rate_pct": -1, "pitch_st": -0.5, "volume_db": 0.2, "breath_gain": 0.05, "edge_style": "calm"},
    "energetic": {"rate_pct": 3, "pitch_st": 0.5, "volume_db": 1.2, "breath_gain": 0.07, "edge_style": "cheerful"},
    "serious": {"rate_pct": -2, "pitch_st": -0.3, "volume_db": 0.4, "breath_gain": 0.04, "edge_style": "serious"},
    "friendly": {"rate_pct": 0, "pitch_st": 0.2, "volume_db": 0.5, "breath_gain": 0.05, "edge_style": "friendly"},
    "excited": {"rate_pct": 3, "pitch_st": 0.0, "volume_db": 1.4, "breath_gain": 0.06, "edge_style": "cheerful"},
    "urgent": {"rate_pct": 4, "pitch_st": 0.0, "volume_db": 1.8, "breath_gain": 0.06, "edge_style": "excited"},
    "skeptical": {"rate_pct": -2, "pitch_st": 0.0, "volume_db": 0.2, "breath_gain": 0.05, "edge_style": "serious"},
    "warm": {"rate_pct": -2, "pitch_st": 0.0, "volume_db": 0.6, "breath_gain": 0.05, "edge_style": "friendly"},
    "dramatic": {"rate_pct": -3, "pitch_st": 0.0, "volume_db": 1.2, "breath_gain": 0.06, "edge_style": "newscast-formal"},
}

# Section 1.5: Multi-Speaker default configurations
SPEAKER_PROFILES = {
    "narrator": {
        "label": "NARATOR",
        "edge_voice": "id-ID-GadisNeural",
        "openai_voice": "nova",
        "tiktok_voice": "id_001",
        "flite_voice": "slt",
        "pitch_shift_st": 0.0,
        "formant_warp": 1.0,
        "eq_warmth_db": 1.8,
        "color": "#38BDF8",
    },
    "expert": {
        "label": "EXPERT",
        "edge_voice": "id-ID-GadisNeural",
        "openai_voice": "nova",
        "tiktok_voice": "id_001",
        "flite_voice": "rms",
        "pitch_shift_st": -1.2,
        "formant_warp": 0.96,
        "eq_warmth_db": 2.6,
        "color": "#F59E0B",
    },
    "user": {
        "label": "USER",
        "edge_voice": "id-ID-GadisNeural",
        "openai_voice": "alloy",
        "tiktok_voice": "id_001",
        "flite_voice": "slt",
        "pitch_shift_st": 1.4,
        "formant_warp": 1.04,
        "eq_warmth_db": 0.8,
        "color": "#10B981",
    },
    "host": {
        "label": "HOST",
        "edge_voice": "id-ID-ArdiNeural",
        "openai_voice": "echo",
        "tiktok_voice": "id_001",
        "flite_voice": "slt",
        "pitch_shift_st": 0.5,
        "formant_warp": 1.01,
        "eq_warmth_db": 1.5,
        "color": "#A855F7",
    },
    "guest": {
        "label": "GUEST",
        "edge_voice": "id-ID-GadisNeural",
        "openai_voice": "shimmer",
        "tiktok_voice": "id_001",
        "flite_voice": "rms",
        "pitch_shift_st": -0.6,
        "formant_warp": 0.98,
        "eq_warmth_db": 2.0,
        "color": "#EC4899",
    },
}


def is_online(timeout: float = 1.5) -> bool:
    global _NET_ONLINE
    if os.environ.get("SHOTCRAFT_OFFLINE") == "1":
        _NET_ONLINE = False
        return False
    if _NET_ONLINE is not None:
        return _NET_ONLINE
    for test_url in ("https://translate.googleapis.com", "https://www.microsoft.com"):
        try:
            req = urllib.request.Request(test_url, method="HEAD", headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout):
                _NET_ONLINE = True
                return True
        except Exception:
            continue
    _NET_ONLINE = False
    return False


def run(cmd, **kwargs):
    if "input" not in kwargs and "stdin" not in kwargs:
        kwargs["stdin"] = subprocess.DEVNULL
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)
    if r.returncode:
        raise RuntimeError(f"Command failed ({r.returncode}): {r.stderr.decode('utf-8', errors='replace')[-400:]}")
    return r.stdout


def duration(path):
    return float(
        run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=nw=1:nk=1",
                str(path),
            ]
        )
        .decode()
        .strip()
    )


_SATUAN = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"]


def terbilang_id(n: int) -> str:
    if n < 0:
        return "minus " + terbilang_id(-n)
    if n == 0:
        return "nol"
    if n < 12:
        return _SATUAN[n]
    if n < 20:
        return terbilang_id(n - 10) + " belas"
    if n < 100:
        puluh = _SATUAN[n // 10] + " puluh"
        sisa = n % 10
        return puluh + (" " + terbilang_id(sisa) if sisa else "")
    if n < 200:
        sisa = n - 100
        return "seratus" + (" " + terbilang_id(sisa) if sisa else "")
    if n < 1000:
        ratus = _SATUAN[n // 100] + " ratus"
        sisa = n % 100
        return ratus + (" " + terbilang_id(sisa) if sisa else "")
    if n < 2000:
        sisa = n - 1000
        return "seribu" + (" " + terbilang_id(sisa) if sisa else "")
    if n < 1_000_000:
        ribu = terbilang_id(n // 1000) + " ribu"
        sisa = n % 1000
        return ribu + (" " + terbilang_id(sisa) if sisa else "")
    if n < 1_000_000_000:
        juta = terbilang_id(n // 1000000) + " juta"
        sisa = n % 1000000
        return juta + (" " + terbilang_id(sisa) if sisa else "")
    if n < 1_000_000_000_000:
        miliar = terbilang_id(n // 1_000_000_000) + " miliar"
        sisa = n % 1_000_000_000
        return miliar + (" " + terbilang_id(sisa) if sisa else "")
    return str(n)


def parse_ssml_and_prosody_tags(raw_text: str, explicit_emphasis_words: list = None) -> dict:
    """
    Section 1.1 & 1.4 & Quick Win #1:
    Parses SSML tags (<emphasis level="strong">...</emphasis>, <break time="300ms"/>,
    <prosody rate="..." pitch="...">...</prosody>, <emotion type="excited">...</emotion>)
    and conversational markers ([breath], [pause:300ms], *emphasis*) into:
    - clean_text: text without XML tags
    - emphasis_words: dict mapping lowercase word -> level ("strong" | "moderate" | "reduced")
    - breaks_after_word: dict mapping word_index -> pause_ms
    - emotion_override: detected emotion tag if any
    - prosody_overrides: dict of rate_pct / pitch_st / volume_db
    - has_breaths: list of word indices where a conversational breath occurs
    """
    text = str(raw_text or "").strip()
    emphasis_map = {}
    if explicit_emphasis_words:
        for ew in explicit_emphasis_words:
            for sub_w in str(ew).split():
                clean_ew = re.sub(r"[^\w]", "", sub_w.lower())
                if clean_ew:
                    emphasis_map[clean_ew] = "strong"

    emotion_override = None
    prosody_overrides = {}

    # Detect <emotion type="...">...</emotion>
    em_match = re.search(r'<emotion\s+type=["\']([a-zA-Z_-]+)["\']\s*>(.*?)</emotion>', text, flags=re.DOTALL | re.IGNORECASE)
    if em_match:
        emotion_override = em_match.group(1).lower()
        text = text[:em_match.start()] + em_match.group(2) + text[em_match.end():]

    # Detect <prosody ...>...</prosody>
    for pr_match in re.finditer(r'<prosody([^>]*)>(.*?)</prosody>', text, flags=re.DOTALL | re.IGNORECASE):
        attrs = pr_match.group(1)
        r_m = re.search(r'rate=["\']([+-]?\d+)%?["\']', attrs)
        p_m = re.search(r'pitch=["\']([+-]?\d+(?:\.\d+)?)(?:st|Hz|%)?["\']', attrs)
        v_m = re.search(r'volume=["\']([+-]?\d+(?:\.\d+)?)(?:dB)?["\']', attrs)
        if r_m:
            prosody_overrides["rate_pct"] = int(r_m.group(1))
        if p_m:
            prosody_overrides["pitch_st"] = float(p_m.group(1))
        if v_m:
            prosody_overrides["volume_db"] = float(v_m.group(1))
    text = re.sub(r'</?prosody[^>]*>', '', text, flags=re.IGNORECASE)

    # Extract <emphasis level="...">words</emphasis>
    def _emph_repl(m):
        attrs = m.group(1) or ""
        lvl_m = re.search(r'level=["\']([a-zA-Z]+)["\']', attrs)
        lvl = lvl_m.group(1).lower() if lvl_m else "strong"
        inner = m.group(2)
        for w in inner.split():
            cw = re.sub(r"[^\w]", "", w.lower())
            if cw:
                emphasis_map[cw] = lvl
        return inner

    text = re.sub(r'<emphasis([^>]*)>(.*?)</emphasis>', _emph_repl, text, flags=re.DOTALL | re.IGNORECASE)

    # Also support markdown-style *STRONG* or **STRONG** emphasis
    def _md_emph_repl(m):
        inner = m.group(1)
        for w in inner.split():
            cw = re.sub(r"[^\w]", "", w.lower())
            if cw:
                emphasis_map[cw] = "strong"
        return inner

    text = re.sub(r'\*\*([^*]+)\*\*', _md_emph_repl, text)
    text = re.sub(r'\*([^*]+)\*', _md_emph_repl, text)

    # Convert <break time="300ms"/> or [pause:300ms] into token __BREAK_300__
    def _break_repl(m):
        val_str = m.group(1).strip().lower()
        if val_str.endswith("ms"):
            ms = int(float(val_str[:-2]))
        elif val_str.endswith("s"):
            ms = int(float(val_str[:-1]) * 1000)
        else:
            ms = int(float(val_str))
        return f" __BREAK_{max(40, min(3000, ms))}__ "

    text = re.sub(r'<break\s+time=["\']([0-9.]+m?s?)["\']\s*/?>', _break_repl, text, flags=re.IGNORECASE)
    text = re.sub(r'\[(?:pause|break):([0-9.]+m?s?)\]', _break_repl, text, flags=re.IGNORECASE)
    text = re.sub(r'\[breath\]', ' __BREATH__ ', text, flags=re.IGNORECASE)
    # Strip any remaining XML tags
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+([,.;:!?])', r'\1', text)

    raw_tokens = text.split()
    clean_words = []
    breaks_after_word = {}
    breath_indices = []

    for tok in raw_tokens:
        b_m = re.match(r'^__BREAK_(\d+)__$', tok)
        if b_m:
            ms = int(b_m.group(1))
            target_idx = max(0, len(clean_words) - 1)
            breaks_after_word[target_idx] = breaks_after_word.get(target_idx, 0) + ms
            continue
        if tok == "__BREATH__":
            target_idx = max(0, len(clean_words) - 1)
            breath_indices.append(target_idx)
            breaks_after_word[target_idx] = breaks_after_word.get(target_idx, 0) + 180
            continue
        # Detect ALL-CAPS words (length >= 3, not acronyms) as automatic moderate emphasis
        letters_only = re.sub(r"[^a-zA-Z]", "", tok)
        if len(letters_only) >= 4 and letters_only.isupper() and letters_only not in _ID_ACRONYM_MAP:
            cw = letters_only.lower()
            if cw not in emphasis_map:
                emphasis_map[cw] = "strong"
        clean_words.append(tok)

    return {
        "clean_text": " ".join(clean_words),
        "emphasis_words": emphasis_map,
        "breaks_after_word": breaks_after_word,
        "breath_indices": breath_indices,
        "emotion": emotion_override,
        "prosody": prosody_overrides,
    }


def normalize_en_text(text: str, pronunciation_overrides: dict = None) -> str:
    """
    RQ05: English pronunciation normalizer (`en-US`).
    Never runs Indonesian `terbilang_id` on English scripts!
    Expands common symbols, units, and custom pronunciation overrides cleanly.
    """
    parsed = parse_ssml_and_prosody_tags(text)
    s = parsed["clean_text"].strip()
    if isinstance(pronunciation_overrides, dict):
        for k, v in pronunciation_overrides.items():
            s = re.sub(rf"\b{re.escape(str(k))}\b", str(v), s, flags=re.IGNORECASE)
    replacements = [
        (r"%", " percent"),
        (r"°C\b", " degrees Celsius"),
        (r"\bkm/h\b", "kilometers per hour"),
        (r"\bRPM\b", "R P M"),
        (r"\bAPI\b", "A P I"),
        (r"\bUI\b", "U I"),
        (r"\bUX\b", "U X"),
        (r"\bvs\.?\b", "versus"),
    ]
    for pat, rep in replacements:
        s = re.sub(pat, rep, s)
    return re.sub(r"\s+", " ", s).strip()


def normalize_id_text(text: str, colloquial_mode: str = "preserve", pronunciation_overrides: dict = None) -> str:
    # Support shorthand metrics like 12M -> 12 juta, 175B -> 175 miliar, 45ms -> 45 milidetik, 3.2 -> 3 koma 2
    text = re.sub(r"\b(\d+)\s*M\b", r"\1 juta", str(text))
    text = re.sub(r"\b(\d+)\s*B\b", r"\1 miliar", str(text))
    text = re.sub(r"\b(\d+)\s*ms\b", r"\1 milidetik", str(text), flags=re.IGNORECASE)
    text = re.sub(r"(\d+)\.(\d+)", r"\1 koma \2", str(text))
    text = re.sub(r"#(\d+)\b", r"nomor \1", str(text))
    """
    Section 1.3 & Quick Win #7:
    Context-aware Indonesian text normalization:
    - Strips/preserves SSML tags cleanly before expanding numbers
    - Handles colloquial/Jakartan slang ("gue"->"saya", "gak"->"tidak", "udah"->"sudah", etc.)
    - Context-dependent acronym pronunciation ("KPI"->"ka pe i" vs "kopi", "API"->"e pi ai" vs "api")
    - Currency, decimals, units, and clause spacing
    """
    parsed = parse_ssml_and_prosody_tags(text)
    s = parsed["clean_text"].strip()
    s = s.replace("±", "kira-kira ").replace("+-", "kira-kira ")

    # Context-dependent acronyms: only expand when written in ALL CAPS (or known acronym context)
    def _acronym_repl(m):
        tok = m.group(0)
        if tok in _ID_ACRONYM_MAP:
            return _ID_ACRONYM_MAP[tok]
        return tok

    s = re.sub(r"\b[A-Z]{2,5}\b", _acronym_repl, s)

    if isinstance(pronunciation_overrides, dict):
        for k, v in pronunciation_overrides.items():
            s = re.sub(rf"\b{re.escape(str(k))}\b", str(v), s, flags=re.IGNORECASE)

    # Disambiguate "api" (fire) vs "API" (software interface) even if lowercase "api" is used in developer context (T03)
    t_tokens = set(re.findall(r"[a-z0-9_]+", s.lower()))
    if "api" in t_tokens and bool(t_tokens & {"developer", "endpoint", "rest", "json", "http", "backend", "server", "client", "gateway", "aplikasi", "request", "response"}):
        s = re.sub(r"\bapi\b", "e pi ai", s, flags=re.IGNORECASE)

    # Colloquial / Jakartan slang normalization: ONLY formalize when colloquial_mode == "formalize" (F09 / T11)
    if colloquial_mode == "formalize":
        out_toks = []
        for tok in s.split():
            lead_p = ""
            trail_p = ""
            m_tok = re.match(r"^([^\w]*)(\w+)([^\w]*)$", tok)
            if m_tok:
                lead_p, core, trail_p = m_tok.groups()
                low_c = core.lower()
                if low_c in _ID_COLLOQUIAL_MAP and _ID_COLLOQUIAL_MAP[low_c]:
                    rep = _ID_COLLOQUIAL_MAP[low_c]
                    out_toks.append(f"{lead_p}{rep}{trail_p}")
                    continue
            out_toks.append(tok)
        s = " ".join(out_toks)

    def _rp_repl(m):
        raw_num = m.group(1).replace(".", "")
        try:
            return terbilang_id(int(raw_num)) + " rupiah"
        except Exception:
            return raw_num + " rupiah"

    s = re.sub(r"\bRp\.?\s*(\d+(?:\.\d{3})+)\b", _rp_repl, s)
    s = re.sub(r"\bRp\.?\s*(\d+)\b", _rp_repl, s)

    def _thousands_repl(m):
        raw_num = m.group(0).replace(".", "")
        try:
            val = int(raw_num)
            if val <= 999_999_999_999:
                return terbilang_id(val)
        except Exception:
            pass
        return m.group(0)

    s = re.sub(r"\b\d{1,3}(?:\.\d{3})+\b", _thousands_repl, s)
    s = re.sub(r"(\d+),(\d+)", r"\1 koma \2", s)

    def _int_repl(m):
        try:
            val = int(m.group(0))
            if 0 <= val <= 999999:
                return terbilang_id(val)
        except Exception:
            pass
        return m.group(0)

    s = re.sub(r"\b\d+\b", _int_repl, s)

    replacements = [
        (r"%", " persen"),
        (r"°C\b", " derajat Celcius"),
        (r"\bkm/jam\b", "kilometer per jam"),
        (r"\bkm/h\b", "kilometer per jam"),
        (r"\bm/s\b", "meter per detik"),
        (r"\bmm2/s\b", "milimeter persegi per detik"),
        (r"\bmg\b", "miligram"),
        (r"\bml\b", "mililiter"),
        (r"\bgr\b", "gram"),
        (r"\bvs\.?\b", "dibandingkan"),
        (r"\bs\.d\.?\b", "sampai"),
        (r"\bdll\.?\b", "dan lain-lain"),
        (r"\bdsb\.?\b", "dan sebagainya"),
        (r"\byg\b", "yang"),
        (r"\btdk\b", "tidak"),
        (r"\bdgn\b", "dengan"),
        (r"\bsdh\b", "sudah"),
        (r"\bdr\b", "dari"),
        (r"\bpd\b", "pada"),
    ]
    for pat, rep in replacements:
        s = re.sub(pat, rep, s, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", s).strip()


# ============================================================================
# SECTION 1.2: UNIFIED VOICE PROFILE & VOICE CLONING SYSTEM ACROSS PROVIDERS
# ============================================================================

def extract_voice_embedding_from_wav(wav_path: Path) -> dict:
    """
    Analyzes a reference speaker WAV file and extracts a portable acoustic voice embedding:
    - f0_hz_mean & f0_hz_std (via autocorrelation pitch tracking)
    - spectral_centroid_hz & formant_tilt_db (low/mid/high energy balance)
    - speaking_energy_rms
    - deterministic speaker hash & reference WAV path
    Works 100% offline using numpy + wave!
    """
    p = Path(wav_path).expanduser().resolve()
    if not p.is_file():
        raise FileNotFoundError(f"Reference speaker WAV not found: {p}")

    tmp_mono = None
    try:
        with wave.open(str(p), "rb") as wf:
            sr = wf.getframerate()
            n_frames = wf.getnframes()
            ch = wf.getnchannels()
            raw = wf.readframes(n_frames)
        samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        if ch > 1:
            samples = samples[::ch]
    except Exception:
        # Convert non-PCM WAV/MP3 via ffmpeg first
        tmp_mono = Path(tempfile.mktemp(suffix="_ref48k.wav"))
        run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(p), "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp_mono)])
        with wave.open(str(tmp_mono), "rb") as wf:
            sr = wf.getframerate()
            samples = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        if tmp_mono.is_file():
            tmp_mono.unlink()

    if len(samples) < 512:
        return {
            "f0_hz_mean": 135.0,
            "f0_hz_std": 18.0,
            "pitch_shift_st": 0.0,
            "formant_warp": 1.0,
            "low_warmth_db": 1.8,
            "presence_db": 2.0,
            "reference_wav": str(p),
        }

    # Estimate F0 on voiced frames (30ms windows)
    win_len = max(128, int(sr * 0.030))
    hop_len = max(64, int(sr * 0.015))
    f0_estimates = []
    min_lag = max(2, int(sr / 320.0))
    max_lag = min(win_len - 2, int(sr / 75.0))

    for start in range(0, min(len(samples) - win_len, sr * 12), hop_len):
        frame = samples[start : start + win_len]
        rms = float(np.sqrt(np.mean(frame * frame)))
        if rms < 0.025:
            continue
        frame_z = frame - np.mean(frame)
        corr = np.correlate(frame_z, frame_z, mode="full")[win_len - 1 :]
        if corr[0] <= 1e-6 or max_lag <= min_lag:
            continue
        sub_corr = corr[min_lag:max_lag]
        best_idx = int(np.argmax(sub_corr)) + min_lag
        if corr[best_idx] / corr[0] > 0.32:
            f0_estimates.append(float(sr) / float(best_idx))

    f0_mean = float(np.median(f0_estimates)) if f0_estimates else 138.0
    f0_std = float(np.std(f0_estimates)) if len(f0_estimates) > 2 else 18.0

    # Compute spectral balance (low < 350Hz vs mid 350-2400Hz vs high > 2400Hz)
    spec = np.abs(np.fft.rfft(samples[: min(len(samples), sr * 10)]))
    freqs = np.fft.rfftfreq(min(len(samples), sr * 10), d=1.0 / sr)
    low_e = float(np.mean(spec[(freqs >= 85) & (freqs < 350)] ** 2) + 1e-9)
    mid_e = float(np.mean(spec[(freqs >= 350) & (freqs < 2400)] ** 2) + 1e-9)
    high_e = float(np.mean(spec[(freqs >= 2400) & (freqs <= 6000)] ** 2) + 1e-9)

    warmth_ratio = math.log10(low_e / mid_e)
    presence_ratio = math.log10(high_e / mid_e)
    low_warmth_db = round(max(-3.0, min(4.5, 2.2 + warmth_ratio * 1.8)), 2)
    presence_db = round(max(-2.0, min(4.5, 2.4 + presence_ratio * 1.5)), 2)

    # Calculate semitone shift relative to standard Indonesian male/female baseline (135 Hz / 215 Hz)
    base_f0 = 210.0 if f0_mean > 175.0 else 132.0
    pitch_shift_st = round(max(-4.5, min(4.5, 12.0 * math.log2(f0_mean / base_f0))), 2)
    formant_warp = round(max(0.90, min(1.10, (f0_mean / base_f0) ** 0.25)), 3)

    return {
        "profile_id": hashlib.sha1(str(p).encode("utf-8")).hexdigest()[:10],
        "reference_wav": str(p),
        "gender_inferred": "female" if f0_mean > 175.0 else "male",
        "f0_hz_mean": round(f0_mean, 2),
        "f0_hz_std": round(f0_std, 2),
        "pitch_shift_st": pitch_shift_st,
        "formant_warp": formant_warp,
        "low_warmth_db": low_warmth_db,
        "presence_db": presence_db,
        "preferred_edge_voice": "id-ID-GadisNeural" if f0_mean > 175.0 else "id-ID-ArdiNeural",
        "preferred_openai_voice": "nova" if f0_mean > 175.0 else "onyx",
    }


def save_or_load_voice_profile(
    profile_name: str,
    speaker_wav: str = None,
    profiles_dir: Path = None,
) -> dict:
    """
    Unified Voice Profile loader/saver across all TTS providers.
    Stores JSON + acoustic embedding parameters in `reels-narration/assets/voice_profiles/<name>.json`.
    """
    here = Path(__file__).resolve().parent
    p_dir = profiles_dir or (here.parent / "assets" / "voice_profiles")
    p_dir.mkdir(parents=True, exist_ok=True)

    clean_name = re.sub(r"[^a-zA-Z0-9_-]", "_", (profile_name or "default_id").strip())
    prof_file = p_dir / f"{clean_name}.json"

    if speaker_wav and Path(speaker_wav).is_file():
        emb = extract_voice_embedding_from_wav(Path(speaker_wav))
        emb["profile_name"] = clean_name
        prof_file.write_text(json.dumps(emb, indent=2, ensure_ascii=False), encoding="utf-8")
        return emb

    # Check voice_bank catalog first (supports 'auto', 'bian', 'zan', 'denas', 'nesah_paramitha', etc.)
    try:
        vb_prof = vb_mod.resolve_voice_profile(profile_name)
        if vb_prof and vb_prof.get("profile_name"):
            return vb_prof
    except Exception:
        pass

    if prof_file.is_file():
        try:
            return json.loads(prof_file.read_text(encoding="utf-8"))
        except Exception:
            pass

    # Default consistent voice profile
    default_prof = {
        "profile_name": clean_name,
        "profile_id": "shotcraft_ardi_v97",
        "reference_wav": speaker_wav,
        "gender_inferred": "male",
        "f0_hz_mean": 134.0,
        "f0_hz_std": 19.5,
        "pitch_shift_st": 0.0,
        "formant_warp": 1.0,
        "low_warmth_db": 1.8,
        "presence_db": 2.2,
        "preferred_edge_voice": "id-ID-ArdiNeural",
        "preferred_openai_voice": "onyx",
    }
    prof_file.write_text(json.dumps(default_prof, indent=2, ensure_ascii=False), encoding="utf-8")
    return default_prof


def apply_conversational_prosody_and_voice_profile(
    wav_path: Path,
    parsed_ssml: dict,
    emotion: str = "conversational",
    voice_profile: dict = None,
    speaker_cfg: dict = None,
    provider_handled_rate: bool = False,
    enable_synthetic_breaths: bool = False,
):
    """
    Section 1.1, 1.2 & 1.4:
    Applies unified voice profile timbre/pitch matching AND conversational prosody shaping
    (micro-breaths, clause pauses, emphasis energy boost, emotional pitch/rate contour)
    directly to the synthesized segment WAV so ALL providers sound natural, expressive, and consistent.
    """
    if not wav_path.is_file():
        return

    preset = EMOTION_PROSODY_PRESETS.get(emotion or "conversational", EMOTION_PROSODY_PRESETS["conversational"])
    pros = parsed_ssml.get("prosody", {})

    pitch_st = float(preset["pitch_st"]) + float(pros.get("pitch_st", 0.0))
    if speaker_cfg:
        pitch_st += float(speaker_cfg.get("pitch_shift_st", 0.0))
    if voice_profile:
        pitch_st += float(voice_profile.get("pitch_shift_st", 0.0)) * 0.5

    vol_db = float(preset["volume_db"]) + float(pros.get("volume_db", 0.0))
    warmth_db = float(voice_profile.get("low_warmth_db", 1.8)) if voice_profile else 1.8
    presence_db = float(voice_profile.get("presence_db", 2.2)) if voice_profile else 2.2

    # F09: Keep segment level consistent rather than boosting entire segment volume when emphasis_words exist

    # Inspect actual input sample rate so we NEVER mis-scale 16kHz/22.05kHz/24kHz WAVs as 48kHz (fixes Chipmunk bug!)
    in_sr = 48000
    try:
        with wave.open(str(wav_path), "rb") as _wf_check:
            in_sr = max(8000, int(_wf_check.getframerate()))
    except Exception:
        in_sr = 48000

    # Only shift pitch if explicitly requested via SSML <prosody pitch="...">, clamped gently to [-1.5, +1.5] st
    explicit_pitch_st = float(pros.get("pitch_st", 0.0))
    pitch_ratio = math.pow(2.0, max(-1.5, min(1.5, explicit_pitch_st)) / 12.0)
    tempo_comp = 1.0 / pitch_ratio
    # F09 / T12: Single owner for tempo! If the provider (e.g. Edge TTS) already received rate_str, do not apply preset rate a second time.
    if provider_handled_rate:
        rate_mult = 1.0 + max(-0.12, min(0.12, float(pros.get("rate_pct", 0)) / 100.0))
    else:
        rate_mult = 1.0 + max(-0.12, min(0.12, (float(preset["rate_pct"]) + float(pros.get("rate_pct", 0))) / 100.0))
    final_atempo = max(0.88, min(1.12, tempo_comp * rate_mult))

    af_chain = ["aresample=48000"]
    if abs(pitch_ratio - 1.0) > 0.01:
        af_chain.append(f"asetrate=48000*{pitch_ratio:.4f},aresample=48000")
    if abs(final_atempo - 1.0) > 0.01:
        af_chain.append(f"atempo={final_atempo:.4f}")
    af_chain.extend([
        "highpass=f=85",
        f"equalizer=f=195:width_type=o:width=1.4:g={warmth_db:.2f}",
        f"equalizer=f=2950:width_type=o:width=1.5:g={presence_db:.2f}",
        f"volume={vol_db:.2f}dB",
        "alimiter=limit=0.93",
    ])
    tmp_out = wav_path.parent / (wav_path.stem + "_prosody.wav")
    try:
        run([
            "ffmpeg", "-nostdin", "-y", "-v", "error",
            "-i", str(wav_path),
            "-af", ",".join(af_chain),
            "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le",
            str(tmp_out),
        ])
        if tmp_out.is_file() and tmp_out.stat().st_size > 512:
            shutil.move(str(tmp_out), str(wav_path))
    except Exception:
        if tmp_out.is_file():
            tmp_out.unlink()

    # F09 & T12: Clause-valley-aligned pause insertion (never cuts inside an active phoneme!)
    # Synthetic breath noise is disabled by default (`enable_synthetic_breaths=False`).
    breaks = parsed_ssml.get("breaks_after_word", {})
    breaths = set(parsed_ssml.get("breath_indices", []))
    if breaks and wav_path.is_file():
        try:
            with wave.open(str(wav_path), "rb") as wf:
                sr = wf.getframerate()
                samples = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
            words_clean = parsed_ssml.get("clean_text", "").split()
            n_words = max(1, len(words_clean))
            # Compute character-weighted cumulative fractions rather than uniform word index
            char_weights = [max(2, len(w)) for w in words_clean]
            total_chars = float(sum(char_weights) or 1.0)
            cum_chars = 0.0
            word_fracs = []
            for cw in char_weights:
                cum_chars += cw
                word_fracs.append(cum_chars / total_chars)

            hop = max(1, int(sr * 0.010))
            n_bins = len(samples) // hop
            rms_env = np.sqrt(np.mean(samples[: n_bins * hop].reshape(n_bins, hop) ** 2, axis=1) + 1e-12) if n_bins > 4 else None

            chunks = []
            prev_idx = 0
            rng = np.random.default_rng(42)
            for w_i in sorted(breaks.keys()):
                if w_i >= len(word_fracs):
                    continue
                approx_frac = min(0.92, max(0.08, word_fracs[w_i]))
                approx_pt = int(len(samples) * approx_frac)
                # Search within +/- 180ms for the deepest energy valley (clause boundary) so we NEVER cut a phoneme!
                if rms_env is not None:
                    center_b = approx_pt // hop
                    lo_b = max(2, center_b - 18)
                    hi_b = min(len(rms_env) - 2, center_b + 18)
                    if hi_b > lo_b:
                        valley_b = lo_b + int(np.argmin(rms_env[lo_b:hi_b]))
                        # Further snap to nearest zero-crossing inside that 10ms valley bin
                        v_start = valley_b * hop
                        v_end = min(len(samples) - 1, v_start + hop)
                        zc_idx = v_start + int(np.argmin(np.abs(samples[v_start:v_end])))
                        approx_pt = zc_idx
                if approx_pt > prev_idx + int(sr * 0.06):
                    # Apply 8ms cosine micro-fade out/in around the valley split to guarantee zero clicks
                    seg_slice = samples[prev_idx:approx_pt].copy()
                    fade_n = min(len(seg_slice) // 4, int(sr * 0.008))
                    if fade_n > 2:
                        seg_slice[-fade_n:] *= np.linspace(1.0, 0.0, fade_n, dtype=np.float32)
                    chunks.append(seg_slice)
                    prev_idx = approx_pt
                    pause_samples = int(sr * (min(500, breaks[w_i]) / 1000.0))
                    if pause_samples > 0:
                        pause_buf = np.zeros(pause_samples, dtype=np.float32)
                        if enable_synthetic_breaths and w_i in breaths and pause_samples > int(sr * 0.08):
                            b_len = min(pause_samples, int(sr * 0.12))
                            t_b = np.linspace(0.0, 1.0, b_len, dtype=np.float32)
                            env_b = np.sin(np.pi * t_b) ** 1.8 * 0.025
                            noise_b = rng.normal(0.0, 0.25, b_len).astype(np.float32)
                            noise_b = np.convolve(noise_b, np.ones(9, dtype=np.float32) / 9.0, mode="same")
                            pause_buf[:b_len] = noise_b * env_b
                        chunks.append(pause_buf)
            tail_slice = samples[prev_idx:].copy()
            if chunks and len(tail_slice) > int(sr * 0.016):
                fade_n = int(sr * 0.008)
                tail_slice[:fade_n] *= np.linspace(0.0, 1.0, fade_n, dtype=np.float32)
            chunks.append(tail_slice)
            merged = np.concatenate(chunks)
            pcm = (np.clip(merged, -0.95, 0.95) * 32767.0).astype(np.int16)
            with wave.open(str(wav_path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(pcm.tobytes())
        except Exception:
            pass


def id_word_to_arpabet(word: str) -> list[str]:
    w = re.sub(r"[^a-z]", "", word.lower())
    if not w:
        return ["aa1"]

    tokens = []
    i = 0
    while i < len(w):
        two = w[i : i + 2]
        if two in ("ng", "ny", "sy", "kh", "ai", "au", "oi"):
            tokens.append(two)
            i += 2
        else:
            tokens.append(w[i])
            i += 1

    vowel_set = {"a", "i", "u", "e", "o", "ai", "au", "oi"}
    vowel_indices = [idx for idx, t in enumerate(tokens) if t in vowel_set]
    stress_idx = vowel_indices[-2] if len(vowel_indices) >= 2 else (vowel_indices[0] if vowel_indices else -1)

    if (
        len(vowel_indices) >= 2
        and tokens[stress_idx] == "e"
        and (w in _ID_SCHWA_WORDS or w.startswith(("se", "ke", "pe", "me", "be", "te", "de")))
    ):
        stress_idx = vowel_indices[-1]

    phones = []
    n_tok = len(tokens)
    for idx, t in enumerate(tokens):
        is_stressed = idx == stress_idx
        st = "1" if is_stressed else "0"
        is_closed_final = idx == n_tok - 2 and tokens[-1] not in vowel_set

        if t == "a":
            phones.append("aa" + st)
        elif t == "i":
            phones.append(("ih" if is_closed_final else "iy") + st)
        elif t == "u":
            phones.append(("uh" if is_closed_final else "uw") + st)
        elif t == "o":
            phones.append("ow" + st)
        elif t == "e":
            if not is_stressed and (
                w in _ID_SCHWA_WORDS or (idx <= 2 and w.startswith(("se", "ke", "pe", "me", "be", "te", "de", "ng", "di")))
            ):
                phones.append("ax0")
            else:
                phones.append("eh" + st)
        elif t == "ai":
            phones.append("ay" + st)
        elif t == "au":
            phones.append("aw" + st)
        elif t == "oi":
            phones.append("oy" + st)
        elif t == "ng":
            phones.append("ng")
        elif t == "ny":
            phones.extend(["n", "y"])
        elif t == "sy":
            phones.append("sh")
        elif t == "kh":
            phones.append("hh")
        elif t == "c":
            phones.append("ch")
        elif t == "j":
            phones.append("jh")
        elif t == "g":
            phones.append("g")
        elif t == "h":
            if idx < n_tok - 1:
                phones.append("hh")
        elif t == "r":
            phones.append("r")
        elif t == "y":
            phones.append("y")
        elif t == "x":
            phones.extend(["k", "s"])
        elif t in ("b", "d", "f", "k", "l", "m", "n", "p", "s", "t", "v", "w", "z"):
            phones.append(t)
        elif t == "q":
            phones.append("k")
    return phones or ["aa1"]


def id_text_to_phonetic_respelling(text: str) -> str:
    out_words = []
    for raw_w in text.split():
        punc = "".join(ch for ch in raw_w if ch in ".,!?;:")
        w = re.sub(r"[^a-zA-Z]", "", raw_w).lower()
        if not w:
            continue
        w = w.replace("sy", "sh").replace("ny", "ny").replace("kh", "h")
        w = re.sub(r"c(?=[aiueo])", "ch", w)
        w = w.replace("u", "oo").replace("i", "ee").replace("a", "ah")
        out_words.append(w + punc)
    return " ".join(out_words)


def synth_edge_online(spoken_text: str, voice: str, out_raw: Path, rate_str: str = "+0%", pitch_str: str = "+0Hz") -> str:
    if not is_online(timeout=1.5):
        raise RuntimeError("Offline environment; skipping Edge Neural online WebSocket TTS so pipeline never hangs")
    resolved_v = resolve_indonesian_voice_name(voice, "id-ID-ArdiNeural")
    target_voice = resolved_v if "Neural" in resolved_v else "id-ID-ArdiNeural"
    mp3_tmp = out_raw.parent / (out_raw.stem + "_edge.mp3")

    last_err = None
    for attempt in range(2):
        try:
            import edge_tts

            async def _run_edge():
                comm = edge_tts.Communicate(spoken_text, target_voice, rate=rate_str, pitch=pitch_str)
                await asyncio.wait_for(comm.save(str(mp3_tmp)), timeout=8)

            asyncio.run(_run_edge())
            if mp3_tmp.is_file() and mp3_tmp.stat().st_size >= 512:
                break
        except Exception as exc:
            last_err = exc
            edge_bin = shutil.which("edge-tts")
            if edge_bin and attempt == 0:
                try:
                    run([edge_bin, "--voice", target_voice, f"--rate={rate_str}", f"--pitch={pitch_str}", "--text", spoken_text, "--write-media", str(mp3_tmp)], timeout=8)
                    if mp3_tmp.is_file() and mp3_tmp.stat().st_size >= 512:
                        break
                except Exception as bin_exc:
                    last_err = bin_exc

    if not mp3_tmp.is_file() or mp3_tmp.stat().st_size < 512:
        raise RuntimeError(f"edge-tts failed after 3 attempts: {last_err}")
    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(mp3_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
    mp3_tmp.unlink()
    return f"edge-neural:{target_voice}"


def synth_tiktok_online(spoken_text: str, out_raw: Path, voice_id: str = "id_001") -> str:
    if not is_online():
        raise RuntimeError("Offline environment; skipping TikTok online TTS")

    endpoints = [
        ("https://tiktok-tts.weilnet.workers.dev/api/generation", "data"),
        ("https://gesserit.co/api/tiktok-tts", "base64"),
    ]
    mp3_tmp = out_raw.parent / (out_raw.stem + "_tiktok.mp3")
    for url, key_field in endpoints:
        try:
            payload = json.dumps({"text": spoken_text[:280], "voice": voice_id}).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=payload,
                headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
                b64_str = body.get(key_field) or body.get("data") or ""
                if "," in b64_str:
                    b64_str = b64_str.split(",", 1)[1]
                raw_bytes = base64.b64decode(b64_str)
                if len(raw_bytes) > 512:
                    mp3_tmp.write_bytes(raw_bytes)
                    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(mp3_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
                    mp3_tmp.unlink()
                    return f"tiktok-neural:{voice_id}"
        except Exception:
            continue
    raise RuntimeError("TikTok TTS endpoints unreachable")


def synth_gtts_http(spoken_text: str, out_raw: Path) -> str:
    if not is_online():
        raise RuntimeError("Offline environment; skipping gtts-http")

    words = spoken_text.split()
    chunks = []
    cur = []
    for w in words:
        if sum(len(x) + 1 for x in cur) + len(w) > 155 and cur:
            chunks.append(" ".join(cur))
            cur = [w]
        else:
            cur.append(w)
    if cur:
        chunks.append(" ".join(cur))
    if not chunks:
        chunks = [spoken_text[:155]]

    part_files = []
    try:
        for idx, ch_txt in enumerate(chunks):
            q = urllib.parse.quote(ch_txt)
            url = f"https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=id&client=tw-ob&q={q}"
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36"
                },
            )
            mp3_part = out_raw.parent / f"{out_raw.stem}_gtts_{idx}.mp3"
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = resp.read()
                if len(data) < 256:
                    raise RuntimeError("Empty audio response from gtts-http")
                mp3_part.write_bytes(data)
                part_files.append(mp3_part)

        if len(part_files) == 1:
            run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(part_files[0]), "-ar", "48000", "-ac", "1", str(out_raw)])
        else:
            inputs = []
            for pf in part_files:
                inputs.extend(["-i", str(pf)])
            concat_str = "".join(f"[{i}:a]" for i in range(len(part_files))) + f"concat=n={len(part_files)}:v=0:a=1[out]"
            run(["ffmpeg", "-nostdin", "-y", "-v", "error", *inputs, "-filter_complex", concat_str, "-map", "[out]", "-ar", "48000", "-ac", "1", str(out_raw)])
        return "gtts-http-id"
    finally:
        for pf in part_files:
            if pf.is_file():
                pf.unlink()


def synth_openai_tts(spoken_text: str, out_raw: Path, voice: str = None) -> str:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key or not is_online():
        raise RuntimeError("OPENAI_API_KEY not set or offline")
    oa_voice = voice if voice in ("alloy", "ash", "coral", "echo", "fable", "onyx", "nova", "sage", "shimmer") else "onyx"
    body = json.dumps({"model": "tts-1-hd", "input": spoken_text, "voice": oa_voice, "response_format": "mp3"}).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/audio/speech",
        data=body,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    )
    mp3_tmp = out_raw.parent / (out_raw.stem + "_openai.mp3")
    with urllib.request.urlopen(req, timeout=25) as resp:
        mp3_tmp.write_bytes(resp.read())
    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(mp3_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
    if mp3_tmp.is_file():
        mp3_tmp.unlink()
    return f"openai-tts:{oa_voice}"


def synth_flite_indonesian(spoken_text: str, out_raw: Path, voice_pref: str = "rms") -> str:
    lib_dir = Path("/usr/lib/x86_64-linux-gnu")
    flite_so = lib_dir / "libflite.so.2.2"
    if not flite_so.is_file():
        flite_so = lib_dir / "libflite.so.1"

    if flite_so.is_file():
        try:
            if not _FLITE_STATE["initialized"]:
                flite = ctypes.CDLL(str(flite_so), mode=ctypes.RTLD_GLOBAL)
                ctypes.CDLL(str(lib_dir / "libflite_usenglish.so.2.2"), mode=ctypes.RTLD_GLOBAL)
                ctypes.CDLL(str(lib_dir / "libflite_cmulex.so.2.2"), mode=ctypes.RTLD_GLOBAL)
                slt = ctypes.CDLL(str(lib_dir / "libflite_cmu_us_slt.so.2.2"), mode=ctypes.RTLD_GLOBAL)
                rms = ctypes.CDLL(str(lib_dir / "libflite_cmu_us_rms.so.2.2"), mode=ctypes.RTLD_GLOBAL)

                flite.flite_init()
                slt.register_cmu_us_slt.restype = ctypes.c_void_p
                rms.register_cmu_us_rms.restype = ctypes.c_void_p
                v_slt = slt.register_cmu_us_slt(None)
                v_rms = rms.register_cmu_us_rms(None)
                flite.flite_voice_add_lex_addenda.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
                flite.flite_text_to_speech.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_char_p]
                flite.flite_text_to_speech.restype = ctypes.c_float

                _FLITE_STATE.update({"initialized": True, "flite": flite, "v_slt": v_slt, "v_rms": v_rms})

            flite = _FLITE_STATE["flite"]
            use_rms = (voice_pref or "slt").lower() in ("rms", "male", "pria", "ardi")
            v_ptr = _FLITE_STATE["v_rms"] if use_rms else _FLITE_STATE["v_slt"]

            words = sorted(set(re.findall(r"[a-zA-Z]+", spoken_text.lower())))
            with tempfile.NamedTemporaryFile("w", suffix=".lex", encoding="utf-8", delete=False) as tf:
                for w in words:
                    phones_str = " ".join(id_word_to_arpabet(w))
                    tf.write(f"{w} : {phones_str}\n")
                lex_path = tf.name

            try:
                flite.flite_voice_add_lex_addenda(v_ptr, lex_path.encode("utf-8"))
                tmp_16k = out_raw.parent / (out_raw.stem + "_flite16k.wav")
                flite.flite_text_to_speech(spoken_text.encode("utf-8"), v_ptr, str(tmp_16k).encode("utf-8"))
            finally:
                if os.path.exists(lex_path):
                    os.unlink(lex_path)

            if tmp_16k.is_file() and tmp_16k.stat().st_size > 1024:
                run(
                    [
                        "ffmpeg",
                        "-nostdin",
                        "-y",
                        "-v",
                        "error",
                        "-i",
                        str(tmp_16k),
                        "-af",
                        "aresample=48000,atempo=1.02,highpass=f=95,lowpass=f=7600,equalizer=f=185:width_type=o:width=1.2:g=-1.2,equalizer=f=2650:width_type=o:width=1.5:g=3.2,acompressor=threshold=-16dB:ratio=2.0:attack=12:release=110,alimiter=limit=0.92",
                        "-ar",
                        "48000",
                        "-ac",
                        "1",
                        "-c:a",
                        "pcm_s16le",
                        str(out_raw),
                    ]
                )
                tmp_16k.unlink()
                return f"flite-clustergen-id:{'rms' if use_rms else 'slt'}"
        except Exception:
            pass

    resp = id_text_to_phonetic_respelling(spoken_text).replace("'", "").replace(":", " ")
    run(
        [
            "ffmpeg",
            "-nostdin",
            "-y",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"flite=text='{resp}':voice=slt",
            "-ar",
            "48000",
            "-ac",
            "1",
            "-c:a",
            "pcm_s16le",
            str(out_raw),
        ]
    )
    if out_raw.is_file() and out_raw.stat().st_size > 1024:
        return "ffmpeg-flite-slt"
    raise RuntimeError("Flite synthesis unavailable")


def synth_coqui_tts(spoken_text: str, out_raw: Path, coqui_model: str = None, speaker_wav: str = None) -> str:
    here = Path(__file__).resolve().parent
    bundled_ref = here.parent / "assets" / "voices" / "indonesian_explainer_ref.wav"
    ref_wav = speaker_wav if (speaker_wav and Path(speaker_wav).is_file()) else (str(bundled_ref) if bundled_ref.is_file() else None)
    model_name = coqui_model or "tts_models/ind/fairseq/vits"
    os.environ.setdefault("COQUI_TOS_AGREED", "1")

    try:
        import torch
        from TTS.api import TTS

        device = "cuda" if torch.cuda.is_available() else "cpu"
        cache_key = (model_name, device)
        if cache_key not in _COQUI_INSTANCE_CACHE:
            _COQUI_INSTANCE_CACHE[cache_key] = TTS(model_name=model_name, progress_bar=False).to(device)
        tts_obj = _COQUI_INSTANCE_CACHE[cache_key]

        if ref_wav and Path(ref_wav).is_file():
            if "xtts" in model_name.lower() or "your_tts" in model_name.lower():
                tts_obj.tts_to_file(
                    text=spoken_text,
                    speaker_wav=str(Path(ref_wav).resolve()),
                    language="id" if "id" in getattr(tts_obj, "languages", ["id"]) else "en",
                    file_path=str(out_raw),
                )
                return f"coqui:{model_name}:cloned"
            else:
                tts_obj.tts_with_vc_to_file(
                    text=spoken_text,
                    speaker_wav=str(Path(ref_wav).resolve()),
                    file_path=str(out_raw),
                )
                return f"coqui:{model_name}:vc-cloned"
        else:
            tts_obj.tts_to_file(text=spoken_text, file_path=str(out_raw))
        # Normalize Coqui output to 48kHz mono PCM so downstream filters never pitch-warp
        tmp_48k = out_raw.parent / (out_raw.stem + "_coqui48k.wav")
        run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(out_raw), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp_48k)])
        if tmp_48k.is_file():
            shutil.move(str(tmp_48k), str(out_raw))
        return f"coqui:{model_name}:cloned" if (ref_wav and Path(ref_wav).is_file()) else f"coqui:{model_name}"
    except ImportError:
        tts_bin = shutil.which("tts")
        if tts_bin:
            tmp_c = out_raw.parent / (out_raw.stem + "_coqui_raw.wav")
            cmd = [tts_bin, "--text", spoken_text, "--model_name", model_name, "--out_path", str(tmp_c)]
            if ref_wav and Path(ref_wav).is_file():
                cmd.extend(["--speaker_wav", str(Path(ref_wav).resolve())])
            run(cmd)
            run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(tmp_c), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(out_raw)])
            if tmp_c.is_file():
                tmp_c.unlink()
            return f"coqui-cli:{model_name}"
        raise RuntimeError("Coqui TTS (`pip install coqui-tts`) is not installed")


def synth_voicestudio(spoken_text: str, out_raw: Path, voice: str = None, speaker_wav: str = None, ref_text: str = None, voice_settings: dict = None) -> str:
    """
    Point 4 Upgrade — Native Integration with debpalash/VoiceStudio (OmniVoice Engine, 646 languages):
    Supports BOTH:
    1. Local VoiceStudio Backend / MCP Server (`http://127.0.0.1:3900` or `OMNIVOICE_URL`, works 100% offline on user PC!)
    2. Direct local Python `omnivoice` / `kokoro` package or `voicestudio` CLI if installed.
    """
    base_url = (
        os.environ.get("OMNIVOICE_URL")
        or os.environ.get("OMNIVOICE_API_URL")
        or f"http://{os.environ.get('OMNIVOICE_HOST', '127.0.0.1')}:{os.environ.get('OMNIVOICE_PORT', '3900')}"
    ).rstrip("/")

    # Fast 0.2s TCP socket check so we never stall for 32s when local VoiceStudio server isn't running!
    _vs_reachable = False
    try:
        from urllib.parse import urlparse
        _u = urlparse(base_url)
        _host = _u.hostname or "127.0.0.1"
        _port = _u.port or (443 if _u.scheme == "https" else 3900)
        with socket.create_connection((_host, _port), timeout=0.25):
            _vs_reachable = True
    except Exception:
        _vs_reachable = False

    # Mode A: Local VoiceStudio / OmniVoice HTTP API & MCP Server (localhost:3900)
    for ep in (("/api/tts", "/api/generate", "/api/v1/tts") if _vs_reachable else ()):
        try:
            payload = {
                "text": spoken_text,
                "language": "id",
                "format": "wav",
            }
            if voice:
                payload["profile_id"] = voice
            if speaker_wav and Path(speaker_wav).is_file():
                payload["ref_audio_path"] = str(Path(speaker_wav).resolve())
            if ref_text:
                payload["ref_text"] = str(ref_text)
            if isinstance(voice_settings, dict):
                payload["voice_settings"] = voice_settings
                if "speed" in voice_settings:
                    payload["speed"] = float(voice_settings["speed"])
            req = urllib.request.Request(
                f"{base_url}{ep}",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "X-OmniVoice-Client-Id": os.environ.get("OMNIVOICE_CLIENT_ID", "claude-code"),
                },
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                ctype = resp.headers.get("Content-Type", "")
                raw_data = resp.read()
                tmp_vs = out_raw.parent / (out_raw.stem + "_vs.wav")
                if "application/json" in ctype:
                    j = json.loads(raw_data.decode("utf-8", errors="replace"))
                    if j.get("output_path") and Path(j["output_path"]).is_file():
                        shutil.copy2(j["output_path"], tmp_vs)
                    elif j.get("wav_base64"):
                        tmp_vs.write_bytes(base64.b64decode(j["wav_base64"]))
                    elif j.get("audio_url"):
                        with urllib.request.urlopen(f"{base_url}{j['audio_url']}", timeout=8) as r2:
                            tmp_vs.write_bytes(r2.read())
                elif len(raw_data) > 512:
                    tmp_vs.write_bytes(raw_data)
                if tmp_vs.is_file() and tmp_vs.stat().st_size > 512:
                    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(tmp_vs), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(out_raw)])
                    tmp_vs.unlink()
                    return f"voicestudio-omnivoice:{voice or 'default-id'}"
        except Exception:
            continue

    # Mode B: Local VoiceStudio Streamable HTTP MCP endpoint (`/mcp/`) calling `generate_speech`
    try:
        if not _vs_reachable:
            raise RuntimeError("VoiceStudio port closed")
        mcp_payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "generate_speech",
                "arguments": {
                    "text": spoken_text,
                    "language": "id",
                    "format": "wav",
                    **({"profile_id": voice} if voice else {}),
                    **({"ref_audio_path": str(Path(speaker_wav).resolve())} if (speaker_wav and Path(speaker_wav).is_file()) else {}),
                    **({"ref_text": str(ref_text)} if ref_text else {}),
                },
            },
        }
        req = urllib.request.Request(
            f"{base_url}/mcp/",
            data=json.dumps(mcp_payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
                "X-OmniVoice-Client-Id": "claude-code",
            },
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            body_txt = resp.read().decode("utf-8", errors="replace")
            m_b64 = re.search(r'"wav_base64"\s*:\s*"([^"]+)"', body_txt)
            m_path = re.search(r'"output_path"\s*:\s*"([^"]+)"', body_txt)
            tmp_vs = out_raw.parent / (out_raw.stem + "_vsmcp.wav")
            if m_path and Path(m_path.group(1)).is_file():
                shutil.copy2(m_path.group(1), tmp_vs)
            elif m_b64:
                tmp_vs.write_bytes(base64.b64decode(m_b64.group(1)))
            if tmp_vs.is_file() and tmp_vs.stat().st_size > 512:
                run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(tmp_vs), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(out_raw)])
                tmp_vs.unlink()
                return f"voicestudio-mcp:{voice or 'claude-code'}"
    except Exception:
        pass

    # Mode C: Offline Python `kokoro` or `f5_tts` CLI if installed locally
    f5_bin = shutil.which("f5-tts_infer-cli")
    if f5_bin:
        tmp_f5 = out_raw.parent / (out_raw.stem + "_f5.wav")
        cmd = [f5_bin, "--gen_text", spoken_text, "--output_file", str(tmp_f5)]
        if speaker_wav and Path(speaker_wav).is_file():
            cmd.extend(["--ref_audio", str(Path(speaker_wav).resolve())])
        if ref_text:
            cmd.extend(["--ref_text", str(ref_text)])
        run(cmd, timeout=60)
        if tmp_f5.is_file() and tmp_f5.stat().st_size > 512:
            run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(tmp_f5), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(out_raw)])
            tmp_f5.unlink()
            return "local-f5-tts"

    raise RuntimeError("VoiceStudio (localhost:3900) / OmniVoice not running or unreachable")


def synth_os_native(spoken_text: str, out_raw: Path, voice_pref: str = None) -> str:
    if sys.platform.startswith("win"):
        ps_raw = spoken_text.replace("'", " ").replace('"', " ")
        ps_phonetic = id_text_to_phonetic_respelling(spoken_text).replace("'", " ").replace('"', " ")
        out_win = str(out_raw.resolve()).replace("'", "''")
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$hasId = $false; "
            "foreach ($v in $s.GetInstalledVoices()) { "
            "  if ($v.VoiceInfo.Culture.Name -like 'id*') { $s.SelectVoice($v.VoiceInfo.Name); $hasId = $true; break } "
            "}; "
            "$s.Rate = 0; "
            f"$s.SetOutputToWaveFile('{out_win}'); "
            f"if ($hasId) {{ $s.Speak('{ps_raw}') }} else {{ $s.Speak('{ps_phonetic}') }}; "
            "$s.Dispose();"
        )
        run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd])
        if out_raw.is_file() and out_raw.stat().st_size > 512:
            tmp_w48 = out_raw.parent / (out_raw.stem + "_win48k.wav")
            run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(out_raw), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp_w48)])
            if tmp_w48.is_file():
                shutil.move(str(tmp_w48), str(out_raw))
            return "windows-sapi"
        raise RuntimeError("Windows SAPI synthesis produced no output")

    if sys.platform == "darwin" and shutil.which("say"):
        aiff_tmp = out_raw.parent / (out_raw.stem + ".aiff")
        try:
            run(["say", "-v", "Damayanti", "-o", str(aiff_tmp), spoken_text])
        except Exception:
            run(["say", "-o", str(aiff_tmp), id_text_to_phonetic_respelling(spoken_text)])
        run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(aiff_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
        if aiff_tmp.is_file():
            aiff_tmp.unlink()
        return "macos-say"

    return synth_flite_indonesian(spoken_text, out_raw, voice_pref=voice_pref or "slt")


def synth_elevenlabs(spoken_text: str, voice: str, api_key: str, out_raw: Path, emotion: str = "conversational") -> str:
    """
    ElevenLabs online TTS provider. Returns provider name 'elevenlabs' on success,
    raises RuntimeError on missing credentials/offline or transport failure.
    """
    if not api_key or not voice or not is_online():
        raise RuntimeError("Missing ELEVENLABS_API_KEY, voice ID, or offline")
    stability = 0.38 if emotion in ("excited", "urgent", "conversational") else 0.55
    style_exag = 0.45 if emotion in ("excited", "urgent", "dramatic") else 0.20
    body = json.dumps(
        {
            "text": spoken_text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {
                "stability": stability,
                "similarity_boost": 0.78,
                "style": style_exag,
                "use_speaker_boost": True,
            },
        }
    ).encode()
    req = urllib.request.Request(
        "https://api.elevenlabs.io/v1/text-to-speech/" + voice,
        data=body,
        headers={"xi-api-key": api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"},
    )
    mp3_tmp = out_raw.parent / (out_raw.stem + "_11labs.mp3")
    with urllib.request.urlopen(req, timeout=30) as r:
        mp3_tmp.write_bytes(r.read())
    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(mp3_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
    if mp3_tmp.is_file():
        mp3_tmp.unlink()
    if not out_raw.is_file() or out_raw.stat().st_size < 512:
        raise RuntimeError("ElevenLabs synthesis produced no usable output")
    return "elevenlabs"


def synth_piper(spoken_text: str, model_path: str, out_raw: Path) -> str:
    """
    Piper offline TTS provider. Returns provider name 'piper' on success,
    raises RuntimeError if the binary or model is unavailable.
    """
    if not model_path or not Path(model_path).is_file() or not shutil.which("piper"):
        raise RuntimeError("Piper binary or model not available")
    run(
        ["piper", "--model", str(Path(model_path).resolve()), "--output_file", str(out_raw)],
        input=spoken_text.encode("utf-8"),
    )
    if not out_raw.is_file() or out_raw.stat().st_size < 512:
        raise RuntimeError("Piper synthesis produced no usable output")
    return "piper"


def build_acoustic_word_timings(
    wav_path: Path,
    text: str,
    seg_start: float,
    seg_end: float,
    parsed_ssml: dict = None,
    speaker: str = "narrator",
    word_animations: list = None,
) -> list:
    """
    Section 1.4 & 2.1:
    Builds acoustic word timings with per-word emphasis weights, SSML <break> pause offsets,
    speaker identity, and animation metadata.
    """
    parsed = parsed_ssml or parse_ssml_and_prosody_tags(text)
    words = [w for w in parsed["clean_text"].strip().split() if w]
    if not words:
        return []

    emphasis_map = parsed.get("emphasis_words", {})
    breaks_map = parsed.get("breaks_after_word", {})

    anim_lookup = {}
    if isinstance(word_animations, list):
        for wa in word_animations:
            if isinstance(wa, dict) and wa.get("word"):
                anim_lookup[re.sub(r"[^\w]", "", str(wa["word"]).lower())] = {
                    "animation": wa.get("animation", "scale-bounce"),
                    "intensity": float(wa.get("intensity", 1.3)),
                }

    # Point 4 Upgrade: Try exact acoustic word-level forced alignment via faster-whisper if installed
    if wav_path and wav_path.is_file() and os.environ.get("SHOTCRAFT_DISABLE_WHISPER_ALIGN") != "1":
        try:
            from faster_whisper import WhisperModel
            global _WHISPER_ALIGN_CACHE
            if "_WHISPER_ALIGN_CACHE" not in globals():
                _WHISPER_ALIGN_CACHE = WhisperModel("tiny", device="cpu", compute_type="int8", local_files_only=not is_online(timeout=1.0))
            segs_w, _ = _WHISPER_ALIGN_CACHE.transcribe(str(wav_path), language="id", word_timestamps=True)
            whisper_words = [w_obj for s_obj in segs_w for w_obj in (s_obj.words or [])]
            if len(whisper_words) == len(words):
                aligned_res = []
                for idx, (w_txt, w_obj) in enumerate(zip(words, whisper_words)):
                    clean_w = re.sub(r"[^\w]", "", w_txt.lower())
                    emph_lvl = emphasis_map.get(clean_w, "none")
                    anim_cfg = anim_lookup.get(clean_w) or (
                        {"animation": "scale-bounce", "intensity": 1.32 if emph_lvl == "strong" else 1.16}
                        if emph_lvl in ("strong", "moderate") else None
                    )
                    entry = {
                        "word": w_txt,
                        "alignment_method": "forced_whisper",
                        "start": round(seg_start + float(w_obj.start), 3),
                        "end": round(seg_start + float(w_obj.end), 3),
                        "startSec": round(seg_start + float(w_obj.start), 3),
                        "endSec": round(seg_start + float(w_obj.end), 3),
                        "speaker": speaker,
                        "emphasis": emph_lvl,
                    }
                    if anim_cfg:
                        entry["animation"] = anim_cfg
                    aligned_res.append(entry)
                return aligned_res
        except Exception:
            pass

    speech_onset = 0.0
    speech_offset = max(0.08, seg_end - seg_start)
    frame_rms = None
    hop_sec = 0.010

    if wav_path and wav_path.is_file():
        try:
            with wave.open(str(wav_path), "rb") as wf:
                sr = wf.getframerate()
                n_frames = wf.getnframes()
                raw_bytes = wf.readframes(n_frames)
            samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
            if wf.getnchannels() > 1:
                samples = samples[:: wf.getnchannels()]
            hop = max(1, int(sr * hop_sec))
            n_bins = len(samples) // hop
            if n_bins >= 4:
                trimmed = samples[: n_bins * hop].reshape(n_bins, hop)
                frame_rms = np.sqrt(np.mean(trimmed * trimmed, axis=1) + 1e-12)
                peak = float(np.max(frame_rms))
                if peak > 1e-4:
                    active_idx = np.where(frame_rms > peak * 0.075)[0]
                    if len(active_idx) >= 2:
                        speech_onset = float(active_idx[0]) * hop_sec
                        speech_offset = min(speech_offset, float(active_idx[-1] + 1) * hop_sec)
        except Exception:
            frame_rms = None

    usable_dur = max(0.08, speech_offset - speech_onset)
    weights = []
    for idx, w in enumerate(words):
        clean_w = re.sub(r"[^\w]", "", w.lower())
        syl = len(re.findall(r"[aiueo]+|\d+", clean_w))
        pause_bonus = 0.65 if any(p in w for p in (",", ".", ":", ";", "?", "!")) else 0.0
        # Add SSML <break> time bonus and <emphasis> prosody stretch
        if idx in breaks_map:
            pause_bonus += min(2.5, breaks_map[idx] / 220.0)
        emph_lvl = emphasis_map.get(clean_w, "none")
        emph_mult = 1.28 if emph_lvl == "strong" else (1.14 if emph_lvl == "moderate" else 1.0)
        weights.append(max(1.0, (float(syl or max(1, len(clean_w) // 2)) + pause_bonus) * emph_mult))

    total_w = sum(weights)
    cursor = seg_start + speech_onset
    result = []

    for idx, (w, weight) in enumerate(zip(words, weights)):
        w_dur = usable_dur * (weight / total_w)
        w_start = cursor
        w_end = cursor + w_dur
        if frame_rms is not None and idx < len(words) - 1:
            center_bin = int(round((w_end - seg_start) / hop_sec))
            lo = max(1, center_bin - 3)
            hi = min(len(frame_rms) - 1, center_bin + 4)
            if hi > lo:
                valley_bin = lo + int(np.argmin(frame_rms[lo:hi]))
                snapped_t = seg_start + valley_bin * hop_sec
                if w_start + 0.04 < snapped_t < seg_start + speech_offset - 0.04:
                    w_end = snapped_t

        clean_w = re.sub(r"[^\w]", "", w.lower())
        emph_lvl = emphasis_map.get(clean_w, "none")
        anim_cfg = anim_lookup.get(clean_w)
        if not anim_cfg and emph_lvl in ("strong", "moderate"):
            anim_cfg = {"animation": "scale-bounce", "intensity": 1.32 if emph_lvl == "strong" else 1.16}

        word_entry = {
            "word": w,
            "start": round(w_start, 3),
            "end": round(w_end, 3),
            "startSec": round(w_start, 3),
            "endSec": round(w_end, 3),
            "speaker": speaker,
            "emphasis": emph_lvl,
        }
        if idx in breaks_map:
            word_entry["pauseAfterMs"] = breaks_map[idx]
        if anim_cfg:
            word_entry["animation"] = anim_cfg["animation"]
            word_entry["intensity"] = anim_cfg["intensity"]
        word_entry["alignment_method"] = "estimated"
        result.append(word_entry)
        cursor = w_end

    # F10 & T13: Guarantee strict monotonicity and clamp within [seg_start, seg_end] so the last word is never cut off or overflowing scene bounds
    n_res = len(result)
    for idx_w, w_item in enumerate(result):
        min_s = seg_start if idx_w == 0 else float(result[idx_w - 1]["end"])
        max_e = seg_end - (n_res - 1 - idx_w) * 0.03
        s_clamped = round(max(seg_start, min(min_s, max_e - 0.03)), 3)
        e_clamped = round(max(s_clamped + 0.03, min(seg_end, float(w_item["end"]))), 3)
        if idx_w == n_res - 1:
            e_clamped = round(min(seg_end, max(s_clamped + 0.04, speech_onset + seg_start + usable_dur)), 3)
        w_item["start"] = s_clamped
        w_item["end"] = e_clamped
        w_item["startSec"] = s_clamped
        w_item["endSec"] = e_clamped
    return result


def format_timestamp_srt(sec: float, vtt: bool = False) -> str:
    ms = max(0, round(sec * 1000))
    hrs = ms // 3600000
    ms %= 3600000
    mins = ms // 60000
    ms %= 60000
    secs = ms // 1000
    ms %= 1000
    sep = "." if vtt else ","
    return f"{hrs:02d}:{mins:02d}:{secs:02d}{sep}{ms:03d}"


def write_subtitles(out_dir: Path, segments_report: list):
    srt_lines = []
    vtt_lines = ["WEBVTT", ""]
    all_words = []

    for idx, seg in enumerate(segments_report, start=1):
        t0 = seg["start"]
        t1 = seg["end"]
        speaker = seg.get("speaker", "narrator")
        spk_prefix = f"[{SPEAKER_PROFILES.get(speaker, {}).get('label', speaker.upper())}] " if seg.get("show_speaker_label") else ""
        caption_text = spk_prefix + (seg.get("display_text") or seg["text"])
        srt_lines.append(f"{idx}\n{format_timestamp_srt(t0)} --> {format_timestamp_srt(t1)}\n{caption_text}\n")
        vtt_lines.append(f"{format_timestamp_srt(t0, True)} --> {format_timestamp_srt(t1, True)}\n{caption_text}\n")
        all_words.extend(seg.get("words", []))

    (out_dir / "subtitles.srt").write_text("\n".join(srt_lines), encoding="utf-8")
    (out_dir / "subtitles.vtt").write_text("\n".join(vtt_lines), encoding="utf-8")
    (out_dir / "remotion-subtitles.json").write_text(
        json.dumps({"segments": segments_report, "words": all_words}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def synthesize_segment(
    provider: str,
    spoken_text: str,
    voice: str,
    model_path: str,
    api_key: str,
    out_raw: Path,
    window_sec: float,
    allow_cloud: bool,
    coqui_model: str = None,
    speaker_wav: str = None,
    strict_provider: bool = False,
    emotion: str = "conversational",
    voice_profile: dict = None,
    speaker_cfg: dict = None,
) -> tuple[str, dict, float]:
    t0_synth = time.time()
    tts_mode_env = os.environ.get("SHOTCRAFT_TTS_MODE", "auto").strip().lower()
    if provider == "local-only" or tts_mode_env == "offline":
        _FALLBACK_ORDER = ["voicestudio", "coqui", "piper", "os-native", "local-synth"]
    elif tts_mode_env == "online":
        _FALLBACK_ORDER = ["edge", "tiktok", "gtts-http", "openai", "elevenlabs", "voicestudio", "coqui", "os-native"]
    else:
        _FALLBACK_ORDER = ["edge", "voicestudio", "coqui", "tiktok", "gtts-http", "openai", "elevenlabs", "piper", "os-native", "local-synth"]
    order = (
        _FALLBACK_ORDER
        if provider in ("auto", "local-only")
        else ([provider] + [p for p in _FALLBACK_ORDER if p != provider])
    )
    cloud = {'edge', 'tiktok', 'gtts-http', 'openai', 'elevenlabs'}
    if provider in cloud and (not allow_cloud or tts_mode_env == 'offline'):
        raise RuntimeError('Cloud TTS requires --allow-cloud and a non-offline mode; choose an installed local provider instead')
    order = [item for item in order if (allow_cloud and tts_mode_env != 'offline') or item not in cloud]
    # Explicit provider selection must not silently invoke another paid provider.
    if provider not in ('auto', 'local-only'):
        order = [provider]
    errors = {}

    preset = EMOTION_PROSODY_PRESETS.get(emotion or "conversational", EMOTION_PROSODY_PRESETS["conversational"])
    rate_str = f"{preset['rate_pct']:+d}%"
    pitch_hz = int(round(preset["pitch_st"] * 6))
    pitch_str = f"{pitch_hz:+d}Hz"

    eff_edge_voice = (
        (speaker_cfg or {}).get("edge_voice")
        or (voice_profile or {}).get("preferred_edge_voice")
        or voice
        or "id-ID-ArdiNeural"
    )
    eff_openai_voice = (
        (speaker_cfg or {}).get("openai_voice")
        or (voice_profile or {}).get("preferred_openai_voice")
        or voice
    )
    eff_flite_voice = (speaker_cfg or {}).get("flite_voice") or voice or "slt"
    eff_ref_wav = speaker_wav or (voice_profile or {}).get("reference_wav")

    for cand in order:
        try:
            if cand in ("voicestudio", "omnivoice", "kokoro", "f5-tts"):
                eff_ref_txt = (voice_profile or {}).get("reference_text") or ""
                eff_v_settings = (voice_profile or {}).get("voice_settings") or {}
                eff_prof_id = (voice_profile or {}).get("profile_name") or voice
                used = synth_voicestudio(
                    spoken_text,
                    out_raw,
                    voice=eff_prof_id,
                    speaker_wav=eff_ref_wav,
                    ref_text=eff_ref_txt,
                    voice_settings=eff_v_settings,
                )
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "coqui":
                used = synth_coqui_tts(spoken_text, out_raw, coqui_model=coqui_model, speaker_wav=eff_ref_wav)
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "edge":
                used = synth_edge_online(spoken_text, eff_edge_voice, out_raw, rate_str=rate_str, pitch_str=pitch_str)
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "tiktok":
                used = synth_tiktok_online(spoken_text, out_raw, voice_id="id_001")
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "gtts-http":
                used = synth_gtts_http(spoken_text, out_raw)
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "openai":
                used = synth_openai_tts(spoken_text, out_raw, voice=eff_openai_voice)
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "elevenlabs":
                if not api_key or not voice or not is_online():
                    raise RuntimeError("Missing ELEVENLABS_API_KEY, voice ID, or offline")
                stability = 0.38 if emotion in ("excited", "urgent", "conversational") else 0.55
                style_exag = 0.45 if emotion in ("excited", "urgent", "dramatic") else 0.20
                body = json.dumps(
                    {
                        "text": spoken_text,
                        "model_id": "eleven_multilingual_v2",
                        "voice_settings": {
                            "stability": stability,
                            "similarity_boost": 0.78,
                            "style": style_exag,
                            "use_speaker_boost": True,
                        },
                    }
                ).encode()
                req = urllib.request.Request(
                    "https://api.elevenlabs.io/v1/text-to-speech/" + voice,
                    data=body,
                    headers={"xi-api-key": api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"},
                )
                mp3_tmp = out_raw.parent / (out_raw.stem + "_11labs.mp3")
                with urllib.request.urlopen(req, timeout=30) as r:
                    mp3_tmp.write_bytes(r.read())
                run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(mp3_tmp), "-ar", "48000", "-ac", "1", str(out_raw)])
                if mp3_tmp.is_file():
                    mp3_tmp.unlink()
                return "elevenlabs", errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand == "piper":
                if not model_path or not Path(model_path).is_file() or not shutil.which("piper"):
                    raise RuntimeError("Piper binary or model not available")
                run(
                    ["piper", "--model", str(Path(model_path).resolve()), "--output_file", str(out_raw)],
                    input=spoken_text.encode("utf-8"),
                )
                return "piper", errors, round((time.time() - t0_synth) * 1000.0, 2)
            if cand in ("os-native", "espeak", "local-synth"):
                used = synth_os_native(spoken_text, out_raw, voice_pref=eff_flite_voice)
                return used, errors, round((time.time() - t0_synth) * 1000.0, 2)
        except Exception as exc:
            errors[cand] = f"{type(exc).__name__}: {exc}"
            if provider != "auto" and strict_provider:
                raise RuntimeError(f"Requested TTS provider '{provider}' failed: {errors[cand]}") from exc
            if provider != "auto":
                break

    if strict_provider or provider not in ("auto", "local-only"):
        raise RuntimeError(f"All requested TTS providers failed: {errors}")

    used = synth_flite_indonesian(spoken_text, out_raw, voice_pref=eff_flite_voice)
    return used, errors, round((time.time() - t0_synth) * 1000.0, 2)


def _build_atempo_chain(speed: float) -> str:
    s = max(0.5, min(2.0, float(speed)))
    return f"atempo={s:.6f}"


def build_smart_sidechain_bgm_filter(segments: list, total_dur: float, duck_db: float = -14.0) -> str:
    """
    Section 4.1:
    Smart Frequency-Selective BGM Sidechain Ducking with smooth attack (35ms) and release (260ms) shaping:
    - Instead of a harsh full-spectrum step volume drop, applies:
      1. Continuous sub-bass preservation (< 150 Hz stays warm and punchy)
      2. Dynamic vocal-pocket carving (250 Hz - 3800 Hz attenuates by duck_db during speech)
      3. Smooth cosine attack/release ramps around every speech segment.
    """
    duck_linear = math.pow(10.0, float(duck_db) / 20.0)
    base_bgm_vol = 0.34
    # Smooth envelope expression with 60ms attack lead-in and 220ms release tail
    env_terms = []
    for s in segments:
        t0 = max(0.0, float(s["start"]) - 0.08)
        t1 = min(total_dur, float(s["end"]) + 0.18)
        env_terms.append(
            f"between(t,{t0:.3f},{t1:.3f})*("
            f"if(lt(t,{t0+0.06:.3f}),(t-{t0:.3f})/0.06,"
            f"if(gt(t,{t1-0.16:.3f}),({t1:.3f}-t)/0.16,1.0)))"
        )
    active_expr = f"min(1.0,{'+'.join(env_terms)})" if env_terms else "0.0"
    vol_expr = f"({base_bgm_vol:.4f}-({base_bgm_vol - duck_linear:.4f})*({active_expr}))"

    return (
        f"equalizer=f=95:width_type=o:width=1.2:g=1.8,"
        f"equalizer=f=1450:width_type=o:width=2.1:g=-8.5,"
        f"equalizer=f=2900:width_type=o:width=1.6:g=-5.5,"
        f"volume='{vol_expr}':eval=frame,atrim=0:{total_dur:.4f}"
    )


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7.0 Conversational Indonesian Narrator & Voice Profile Engine")
    p.add_argument("--manifest", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument(
        "--provider",
        choices=["auto", "local-only", "voicestudio", "omnivoice", "kokoro", "f5-tts", "coqui", "edge", "tiktok", "gtts-http", "openai", "elevenlabs", "piper", "os-native", "espeak", "local-synth"],
        default="auto",
    )
    p.add_argument("--tts-mode", choices=["auto", "online", "offline"], default="auto", help="Online/Offline TTS routing mode")
    p.add_argument("--strict-provider", action="store_true")
    p.add_argument("--audio-driven", action="store_true")
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--coqui-model", default="tts_models/ind/fairseq/vits")
    p.add_argument("--speaker-wav")
    p.add_argument("--voice-folder", default=None, help="Option B: Path to offline folder with voiceover audio files (single full file or per-scene 01.wav, 02.mp3, etc.)")
    p.add_argument("--voice-profile", default="auto", help="Unified voice profile name from voice_catalog.json (e.g. auto, bian, zan, denas, nesah_paramitha, bayu, selina)")
    p.add_argument("--emotion", default="conversational", choices=list(EMOTION_PROSODY_PRESETS.keys()))
    p.add_argument("--allow-cloud", action="store_true")
    p.add_argument("--voice", default=None)
    p.add_argument("--model")
    p.add_argument("--max-speed", type=float, default=1.15)
    p.add_argument("--language", default="", help="Language/locale code e.g. id-ID or en-US (RQ05)")
    p.add_argument("--colloquial-mode", choices=["preserve", "formalize"], default="preserve", help="F09: Preserve conversational style ('nggak', 'udah') or formalize")
    p.add_argument("--enable-breaths", action="store_true", help="F09: Opt-in synthetic breath noise on [breath] tags (off by default)")
    p.add_argument("--normalize-id", action="store_true")
    p.add_argument("--bgm")
    p.add_argument("--duck-db", type=float, default=-14.0)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--verbose", action="store_true", help="Enable verbose TTS provider & prosody logging")
    a = p.parse_args()
    if not a.allow_cloud or a.tts_mode == "offline":
        os.environ["SHOTCRAFT_OFFLINE"] = "1"
    if getattr(a, "tts_mode", None):
        os.environ["SHOTCRAFT_TTS_MODE"] = a.tts_mode

    if not all(shutil.which(x) for x in ["ffmpeg", "ffprobe"]):
        p.error("ffmpeg/ffprobe required on PATH")

    m = json.loads(Path(a.manifest).read_text(encoding="utf-8"))
    total = float(m.get("duration", 12.0))
    segments = m["segments"]
    if not math.isfinite(total) or not 0 < total <= 600 or not isinstance(segments, list) or not 1 <= len(segments) <= 100:
        p.error("Use 1–100 segments and duration up to 600 seconds")

    previous = 0.0
    for s in segments:
        start, end = float(s.get("start", previous)), float(s.get("end", previous + 4.0))
        if not all(math.isfinite(v) for v in [start, end]) or start < previous or end <= start:
            p.error("Segments must be ordered, non-overlapping, and finite")
        if not isinstance(s["text"], str) or not s["text"].strip():
            p.error("Every segment needs nonempty text")
        previous = end

    key = os.environ.get("ELEVENLABS_API_KEY")
    voice = (
        a.voice or os.environ.get("ELEVENLABS_VOICE_ID")
        if a.provider == "elevenlabs"
        else a.voice or "id-ID-GadisNeural"
    )

    out = Path(a.out_dir).expanduser().resolve()
    if out.exists():
        if a.overwrite:
            shutil.rmtree(out)
        else:
            p.error("Use a new output directory or pass --overwrite")
    out.mkdir(parents=True, exist_ok=True)

    # Load or create Unified Voice Profile (Section 1.2)
    voice_profile = save_or_load_voice_profile(
        profile_name=m.get("voiceProfile") or a.voice_profile,
        speaker_wav=a.speaker_wav or m.get("speakerWav"),
    )

    report = {
        "requested_provider": a.provider,
        "used_provider": None,
        "fallback_occurred": False,
        "provider_errors": {},
        "audio_driven": bool(a.audio_driven),
        "online_available": is_online(),
        "coqui_model": a.coqui_model,
        "speaker_wav": a.speaker_wav,
        "voice_profile": voice_profile,
        "emotion": m.get("emotion") or a.emotion,
        "language": m.get("language") or a.language or "id-ID",
        "colloquial_mode": m.get("colloquialMode") or a.colloquial_mode,
        "alignment_method": "estimated",
        "word_alignment": "estimated_syllable_energy_valley",
        "duration": total,
        "telemetry": {"total_tts_latency_ms": 0.0, "fallback_count": 0, "MultiSpeaker": False},
        "segments": [],
        "complete": False,
    }

    try:
        cursor_timeline = 0.0
        speakers_seen = set()
        for i, s in enumerate(segments):
            raw_text = s["text"].strip()
            explicit_emph = s.get("emphasisWords") or m.get("emphasisWords") or []
            parsed_ssml = parse_ssml_and_prosody_tags(raw_text, explicit_emphasis_words=explicit_emph)
            seg_emotion = s.get("emotion") or parsed_ssml.get("emotion") or m.get("emotion") or a.emotion
            seg_speaker = str(s.get("speaker") or "narrator").lower()
            speakers_seen.add(seg_speaker)
            speaker_cfg = SPEAKER_PROFILES.get(seg_speaker, SPEAKER_PROFILES["narrator"])

            seg_lang = str(s.get("language") or m.get("language") or a.language or "id-ID").strip()
            colloq_mode = str(s.get("colloquialMode") or m.get("colloquialMode") or a.colloquial_mode or "preserve").strip()
            pron_overrides = s.get("pronunciationOverrides") or m.get("pronunciationOverrides") or {}
            if seg_lang.lower().startswith("en"):
                spoken_text = normalize_en_text(parsed_ssml["clean_text"], pronunciation_overrides=pron_overrides)
            elif a.normalize_id or m.get("normalizeId", True):
                spoken_text = normalize_id_text(parsed_ssml["clean_text"], colloquial_mode=colloq_mode, pronunciation_overrides=pron_overrides)
            else:
                spoken_text = parsed_ssml["clean_text"]
            display_text = s.get("display_text") or parsed_ssml["clean_text"]
            orig_window = float(s["end"]) - float(s["start"])

            raw = out / f"{i:03d}-raw.wav"
            offline_scene_audio = s.get("offlineAudioFile")
            if not offline_scene_audio and a.voice_folder:
                try:
                    vf_res = vb_mod.resolve_offline_voice_folder(a.voice_folder, num_scenes=len(segments))
                    if vf_res.get("mode") == "per_scene" and i < len(vf_res.get("scene_files", [])):
                        offline_scene_audio = vf_res["scene_files"][i]
                    elif vf_res.get("full_audio_file"):
                        full_af = Path(vf_res["full_audio_file"])
                        full_dur = duration(full_af)
                        slice_st = (i / float(max(1, len(segments)))) * full_dur
                        slice_dur = max(0.8, full_dur / float(max(1, len(segments))))
                        tmp_sl = out / f"{i:03d}-folder-slice.wav"
                        run([
                            "ffmpeg", "-nostdin", "-y", "-v", "error",
                            "-ss", f"{slice_st:.3f}", "-t", f"{slice_dur:.3f}",
                            "-i", str(full_af),
                            "-af", "highpass=f=80,lowpass=f=7800,dynaudnorm=p=0.90:s=5",
                            "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(tmp_sl),
                        ])
                        offline_scene_audio = str(tmp_sl)
                except Exception:
                    offline_scene_audio = None

            if offline_scene_audio and Path(str(offline_scene_audio)).is_file():
                t0_off = time.time()
                run([
                    "ffmpeg", "-nostdin", "-y", "-v", "error",
                    "-i", str(offline_scene_audio),
                    "-af", "highpass=f=80,lowpass=f=7800,afftdn=nf=-22,dynaudnorm=p=0.90:s=5",
                    "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(raw),
                ])
                used_prov = f"offline-voice-folder:{Path(str(offline_scene_audio)).name}"
                prov_errs = {}
                tts_lat_ms = round((time.time() - t0_off) * 1000.0, 2)
            else:
                used_prov, prov_errs, tts_lat_ms = synthesize_segment(
                    provider=a.provider,
                    spoken_text=spoken_text,
                    voice=s.get("voice") or voice,
                    model_path=a.model,
                    api_key=key,
                    out_raw=raw,
                    window_sec=orig_window,
                    allow_cloud=a.allow_cloud,
                    coqui_model=a.coqui_model,
                    speaker_wav=s.get("speakerWav") or a.speaker_wav,
                    strict_provider=a.strict_provider,
                    emotion=seg_emotion,
                    voice_profile=voice_profile,
                    speaker_cfg=speaker_cfg,
                )
            # Apply conversational prosody, clause-valley pauses, and unified voice profile timbre (single tempo owner!)
            apply_conversational_prosody_and_voice_profile(
                wav_path=raw,
                parsed_ssml=parsed_ssml,
                emotion=seg_emotion,
                voice_profile=voice_profile,
                speaker_cfg=speaker_cfg,
                provider_handled_rate=used_prov.startswith("edge-neural"),
                enable_synthetic_breaths=bool(a.enable_breaths),
            )

            report["used_provider"] = used_prov
            report["telemetry"]["total_tts_latency_ms"] = round(
                report["telemetry"]["total_tts_latency_ms"] + tts_lat_ms, 2
            )
            if prov_errs:
                report["provider_errors"].update(prov_errs)
                report["telemetry"]["fallback_count"] += len(prov_errs)
                if a.provider != "auto" and not used_prov.startswith(a.provider):
                    report["fallback_occurred"] = True

            seconds = duration(raw)

            if a.audio_driven:
                speed = 1.0
                actual_spoken_dur = seconds
                step_unit = 0.5 if (a.fps % 2 == 0) else 1.0
                steps = max(4, int(math.ceil((actual_spoken_dur + 0.45) / step_unit)))
                scene_slot_sec = steps * step_unit
                rec_frames = int(round(scene_slot_sec * a.fps))
                seg_start = round(cursor_timeline + 0.14, 3)
                seg_end = round(cursor_timeline + scene_slot_sec - 0.12, 3)
                window = round(seg_end - seg_start, 3)
                cursor_timeline += rec_frames / float(a.fps)
            else:
                seg_start = float(s["start"])
                seg_end = float(s["end"])
                window = seg_end - seg_start
                target_win = max(0.4, window * 0.92)
                speed = max(1.0, min(a.max_speed, seconds / target_win))
                actual_spoken_dur = min(window, seconds / speed)
                rec_frames = max(60, int(round(window * a.fps)))

            fitted = out / f"{i:03d}-fitted.wav"
            samples = max(4800, round(window * 48000))
            fade_st = max(0.0, min(window, actual_spoken_dur) - 0.08)
            atempo_chain = _build_atempo_chain(speed)
            run(
                [
                    "ffmpeg",
                    "-nostdin",
                    "-y",
                    "-v",
                    "error",
                    "-i",
                    str(raw),
                    "-af",
                    f"{atempo_chain},afade=t=out:st={fade_st:.3f}:d=0.07,apad=whole_len={samples},atrim=end_sample={samples}",
                    "-ar",
                    "48000",
                    "-ac",
                    "1",
                    "-c:a",
                    "pcm_s16le",
                    str(fitted),
                ]
            )

            words_timed = build_acoustic_word_timings(
                wav_path=fitted,
                text=display_text,
                seg_start=seg_start,
                seg_end=seg_start + actual_spoken_dur,
                parsed_ssml=parsed_ssml,
                speaker=seg_speaker,
                word_animations=s.get("wordAnimations"),
            )

            rec = {
                "index": i,
                "id": s.get("id", str(i)),
                "speaker": seg_speaker,
                "speaker_label": speaker_cfg["label"],
                "speaker_color": speaker_cfg["color"],
                "show_speaker_label": len(speakers_seen) > 1 or seg_speaker != "narrator",
                "emotion": seg_emotion,
                "start": seg_start,
                "end": seg_end,
                "scene_duration_sec": round(rec_frames / float(a.fps), 3),
                "recommended_frames": rec_frames,
                "language": seg_lang,
                "colloquial_mode": colloq_mode,
                "provider_used": used_prov,
                "voice_used": s.get("voice") or voice,
                "fallback_reason": "; ".join(f"{k}: {v}" for k, v in prov_errs.items()) if prov_errs else None,
                "alignment_method": words_timed[0].get("alignment_method", "estimated") if words_timed else "estimated",
                "spoken_text": spoken_text,
                "text": spoken_text,
                "display_text": display_text,
                "emphasis_words": list(parsed_ssml.get("emphasis_words", {}).keys()),
                "raw_seconds": round(seconds, 3),
                "tts_latency_ms": tts_lat_ms,
                "speed": round(speed, 4),
                "raw_file": str(raw),
                "fitted_file": str(fitted),
                "words": words_timed,
            }
            report["segments"].append(rec)

        report["telemetry"]["MultiSpeaker"] = len(speakers_seen) > 1
        if len(speakers_seen) > 1:
            for seg_item in report["segments"]:
                seg_item["show_speaker_label"] = True

        if a.audio_driven and report["segments"]:
            total = round(cursor_timeline, 3)
            report["duration"] = total

        cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error"]
        for s in report["segments"]:
            cmd += ["-i", s["fitted_file"]]
        graph = []
        for i, s in enumerate(report["segments"]):
            delay_ms = round(s["start"] * 1000)
            graph.append(f"[{i}:a]adelay={delay_ms}|{delay_ms}[a{i}]")
        total_samples = max(4800, round(total * 48000))
        graph.append(
            "".join(f"[a{i}]" for i in range(len(segments)))
            + f"amix=inputs={len(segments)}:normalize=0,apad=whole_len={total_samples},atrim=end_sample={total_samples}[out]"
        )
        final = out / "narration.wav"
        cmd += [
            "-filter_complex",
            ";".join(graph),
            "-map",
            "[out]",
            "-ar",
            "48000",
            "-ac",
            "1",
            "-c:a",
            "pcm_s16le",
            str(final),
        ]
        run(cmd)

        write_subtitles(out, report["segments"])
        report["subtitles"] = {
            "srt": str(out / "subtitles.srt"),
            "vtt": str(out / "subtitles.vtt"),
            "remotion_json": str(out / "remotion-subtitles.json"),
        }

        if a.bgm:
            bgm_path = Path(a.bgm).expanduser().resolve()
            if not bgm_path.is_file():
                raise RuntimeError(f"BGM file not found: {bgm_path}")
            master_out = out / "master_mix.wav"
            bgm_filter = build_smart_sidechain_bgm_filter(report["segments"], total, duck_db=float(a.duck_db))
            run(
                [
                    "ffmpeg",
                    "-nostdin",
                    "-y",
                    "-v",
                    "error",
                    "-i",
                    str(final),
                    "-stream_loop",
                    "-1",
                    "-t",
                    f"{total:.4f}",
                    "-i",
                    str(bgm_path),
                    "-filter_complex",
                    f"[0:a]volume=1.10[narr];[1:a]{bgm_filter}[bgm];[narr][bgm]amix=inputs=2:duration=first:weights='1.15 0.68':normalize=0,alimiter=limit=0.92:level=disabled[mix]",
                    "-map",
                    "[mix]",
                    "-ar",
                    "48000",
                    "-ac",
                    "2",
                    "-c:a",
                    "pcm_s16le",
                    str(master_out),
                ]
            )
            report["master_mix"] = str(master_out)

        report.update(complete=True, output=str(final))
        print(
            json.dumps(
                {
                    "ok": True,
                    "narration_wav": str(final),
                    "provider": report["used_provider"],
                    "fallback_occurred": report["fallback_occurred"],
                    "audio_driven_duration": total,
                    "online": report["online_available"],
                    "voice_profile": voice_profile.get("profile_name"),
                    "emotion": report["emotion"],
                    "telemetry": report["telemetry"],
                    "subtitles": report["subtitles"],
                    "master_mix": report.get("master_mix"),
                },
                ensure_ascii=False,
            )
        )
        return 0
    except Exception as e:
        message = str(e)
        report["error"] = message
        print(json.dumps({"ok": False, "error": message, "provider_errors": report.get("provider_errors", {})}), file=sys.stderr)
        return 2
    finally:
        (out / "timing-report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
