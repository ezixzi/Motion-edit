#!/usr/bin/env python3
"""Bounded motion, template, typography, transition, 3D depth, and Opus 5.5 creative-coding candidate lookup (v4.2)."""
import argparse
import json
import re
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--inventory", required=True)
p.add_argument("--query", required=True)
p.add_argument("--limit", type=int, default=5)
a = p.parse_args()
if not 1 <= a.limit <= 20:
    p.error("limit must be 1..20")


def norm(s):
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", s)
    return re.sub(r"[^\w]+", " ", s.lower()).strip()


query = norm(a.query)
if not query:
    p.error("Nonempty query required")

aliases = {
    "morf": "morph",
    "transisi": "transition",
    "kartu": "card",
    "huruf": "text",
    "tipografi": "type",
    "kamera": "camera",
    "cahaya": "light",
    "berulang": "loop",
    "kaca": "glass",
    "putar": "rotate",
    "gelombang": "wave",
    "mesin": "mechanism",
    "bedah": "cutaway",
    "aliran": "flow",
    "gambar": "illustration",
    "mekanisme": "mechanism",
    "kedalaman": "depth",
    "paralaks": "parallax",
    "teks": "typography",
    "jaringan": "network",
    "panas": "heatmap",
    "suhu": "heatmap",
}
words = [aliases.get(w, w) for w in query.split()]
phrase = " ".join(words)
inv = json.loads(Path(a.inventory).read_text(encoding="utf-8"))
root = Path(inv["repo_path"]).resolve()
matches = []

paths = sorted(set(inv["files"].get("recipes", []) + inv["files"].get("demos", [])))
for relative in paths:
    f = (root / relative).resolve()
    if not f.is_relative_to(root) or not f.is_file():
        continue
    name = norm(f.stem)
    path = norm(relative)
    score = 100 if name == phrase else 30 if phrase in name else 0
    score += sum(5 for w in words if w in name.split()) + sum(1 for w in words if w in path.split())
    evidence = "name/path"
    if f.suffix == ".md":
        text = norm(f.read_text(encoding="utf-8", errors="replace"))
        if phrase in text:
            score += 10
            evidence = "recipe text" if score < 20 else evidence
    if score > 0:
        matches.append(
            {
                "score": score,
                "kind": "upstream recipe" if f.suffix == ".md" else "upstream demo",
                "path": str(f),
                "match": evidence,
            }
        )

comp = inv.get("companion_motion_catalog") or {}
for row in comp.get("recipes", []):
    name = norm(row["id"])
    desc = norm(
        row["id"]
        + " "
        + row["title"]
        + " "
        + " ".join(row.get("upstream_search_hints", []) + row.get("search_terms", []))
    )
    score = (100 if name == phrase else 25 if phrase in desc else 0) + sum(5 for w in words if w in desc.split())
    if score > 0:
        matches.append(
            {
                "score": score,
                "kind": "local adaptation guide",
                "evidence": row.get("evidence", "unverified"),
                "id": row["id"],
                "path": str(Path(comp["path"]).parent / row["recipe"]),
                "match": "companion catalog",
            }
        )

opus = inv.get("opus_creative_coding_catalog") or {}
for row in opus.get("recipes", []):
    name = norm(row["id"])
    desc = norm(
        row["id"]
        + " "
        + row["title"]
        + " "
        + row.get("category", "")
        + " "
        + " ".join(row.get("search_terms", []))
        + " "
        + row.get("grammar", "")
    )
    score = (98 if name == phrase else 25 if phrase in desc else 0) + sum(5 for w in words if w in desc.split())
    if score > 0:
        matches.append(
            {
                "score": score,
                "kind": "opus-5.5 creative-coding recipe",
                "id": row["id"],
                "procedural_mode": row.get("procedural_mode"),
                "path": str(opus["path"]),
                "match": "opus catalog",
            }
        )

tpls = inv.get("companion_templates_catalog") or {}
for row in tpls.get("templates", []):
    name = norm(row["id"])
    desc = norm(
        row["id"]
        + " "
        + row["title"]
        + " "
        + row.get("typography_style", "")
        + " "
        + " ".join(row.get("transitions", []) + row.get("upstream_shots", []))
    )
    score = (95 if name == phrase else 20 if phrase in desc else 0) + sum(4 for w in words if w in desc.split())
    if score > 0:
        matches.append(
            {
                "score": score,
                "kind": "companion blueprint template",
                "id": row["id"],
                "path": str(tpls["path"]),
                "match": "templates catalog",
            }
        )

matches.sort(key=lambda x: (-x["score"], x["path"]))
print(
    json.dumps(
        {
            "query": a.query,
            "candidates": matches[: a.limit],
            "total_candidates": len(matches),
            "note": "Read selected sources and verify previews; this is discovery only",
        },
        ensure_ascii=False,
        indent=2,
    )
)
