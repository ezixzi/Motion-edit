#!/usr/bin/env python3
"""Read-only inventory of a complete video-shotcraft clone + Shotcraft Pro v4.2 companions; Python stdlib only."""
import argparse
import json
import shutil
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--repo", required=True)
p.add_argument("--out", required=True)
p.add_argument("--summary", action="store_true", help="Print bounded counts/tool status, not full inventory")
a = p.parse_args()
r = Path(a.repo).expanduser().resolve()
if not (r / "SKILL.md").is_file():
    p.error("Repository must contain SKILL.md: " + str(r))

groups = {
    "instructions": ["SKILL.md", "README.md", "AGENTS.md", "CLAUDE.md"],
    "catalogs": ["gallery/api/*.json", "gallery/llms.txt", "gallery/source/*.md"],
    "recipes": ["references/shots/**/*.md"],
    "workflows": ["references/*.md", "references/sequences/**/*.md"],
    "demos": ["demos/**/*.tsx"],
    "helpers": ["assets/lib/**/*"],
    "sfx": ["assets/audio/sfx/**/*"],
    "bgm": ["assets/audio/bgm/**/*"],
    "audio_licenses": ["assets/audio/*.md"],
    "previews": ["gallery/media/**/*", "videos/**/*"],
    "template": [
        "template/TEMPLATE.md",
        "template/THEMES.md",
        "template/package*.json",
        "template/scripts/**/*",
        "template/themes/**/*",
    ],
    "workbench": ["workbench/package*.json", "workbench/README*"],
    "exports": [
        "jianying-export/README*",
        "jianying-export/package*.json",
        "publish/README*",
        "publish/package*.json",
    ],
}

files = {
    k: sorted({str(f.relative_to(r)) for pattern in patterns for f in r.glob(pattern) if f.is_file()})
    for k, patterns in groups.items()
}

result = {
    "repo_path": str(r),
    "inventory_is_not_functional_verification": True,
    "counts": {k: len(v) for k, v in files.items()},
    "files": files,
    "tools_on_path": {
        x: shutil.which(x)
        for x in ["git", "node", "npm", "ffmpeg", "ffprobe", "python", "python3", "uv", "claude"]
    },
}

skills_root = Path(__file__).resolve().parents[2]
companion = skills_root / "reels-continuity-lab" / "catalog.json"
if companion.is_file():
    catalog = json.loads(companion.read_text(encoding="utf-8"))
    result["companion_motion_catalog"] = {
        "path": str(companion),
        "namespace": catalog.get("namespace"),
        "recipes": catalog.get("recipes", []),
        "rendered_or_verified": False,
    }
else:
    result["companion_motion_catalog"] = None

opus_cat_file = skills_root / "reels-opus-craft" / "catalog.json"
if opus_cat_file.is_file():
    opus_cat = json.loads(opus_cat_file.read_text(encoding="utf-8"))
    result["opus_creative_coding_catalog"] = {
        "path": str(opus_cat_file),
        "namespace": opus_cat.get("namespace"),
        "upstream_inspiration": opus_cat.get("upstream_inspiration"),
        "recipes": opus_cat.get("recipes", []),
    }
else:
    result["opus_creative_coding_catalog"] = None

templates_file = skills_root / "reels-templates" / "blueprints" / "templates_catalog.json"
if templates_file.is_file():
    tpl_catalog = json.loads(templates_file.read_text(encoding="utf-8"))
    result["companion_templates_catalog"] = {
        "path": str(templates_file),
        "templates": tpl_catalog.get("templates", []),
        "components_dir": str(skills_root / "reels-templates" / "components"),
    }
else:
    result["companion_templates_catalog"] = None

depth_script = skills_root / "reels-depth-motion" / "scripts" / "depth_engine.py"
result["depth_motion_engine"] = {
    "available": depth_script.is_file(),
    "script": str(depth_script) if depth_script.is_file() else None,
    "presets": [
        "cinematic-orbit",
        "dolly-push",
        "vertigo-contra-zoom",
        "crane-rise",
        "parallax-drift",
        "breathing-float",
        "cutaway-peel",
        "hero-pullback",
    ],
}

out = Path(a.out).expanduser().resolve()
try:
    out.relative_to(r)
except ValueError:
    pass
else:
    p.error("--out must be outside the toolkit repository to preserve its source.")

out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
if a.summary:
    print(
        json.dumps(
            {
                "inventory": str(out),
                "counts": result["counts"],
                "companion_recipes": len((result["companion_motion_catalog"] or {}).get("recipes", [])),
                "opus_recipes": len((result["opus_creative_coding_catalog"] or {}).get("recipes", [])),
                "companion_templates": len((result["companion_templates_catalog"] or {}).get("templates", [])),
                "depth_engine_available": result["depth_motion_engine"]["available"],
                "tools_available": {k: bool(v) for k, v in result["tools_on_path"].items()},
            },
            ensure_ascii=False,
        )
    )
else:
    print(str(out))
