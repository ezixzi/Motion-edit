#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Isolated Remotion Workspace Scaffolder, Brand Kit Manager,
Git-like Template Versioning/Rollback & CI/CD Pipeline Generator (`scaffold_project.py`).

Upgrades implementing SHOTCRAFT_PRO_v9.5_IMPROVEMENT_REPORT:
- Section 3.3: Brand Kit System (`--brand-kit`, `--brand-name`, `--primary-color`, `--accent-color`,
  `--font-family`, `--watermark-pos`) — saves/loads `brand_kit.json` and applies brand colors/fonts/watermarks.
- Section 3.4: Multi-Aspect Ratio presets (`9:16`, `16:9`, `1:1`, `4:5`, `2:3`).
- Section 6.2: Template Versioning & Rollback (`--save-version`, `--list-versions`, `--rollback VERSION_ID`) —
  automatically snapshots existing project state before scaffolding/overwriting so any template version can be restored.
- Section 6.4: CI/CD Workflow Generation (`--with-cicd`) — generates GitHub Actions (`.github/workflows/shotcraft-render.yml`)
  and GitLab CI (`.gitlab-ci.yml`) templates for automated manifest rendering & artifact upload.
"""
import argparse
import datetime
import json
import math
import shutil
import sys
from pathlib import Path

ASPECT_DIMENSIONS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
    "2:3": (1080, 1620),
}


def save_project_version_snapshot(ws: Path, label: str = "auto-snapshot") -> dict | None:
    """
    Section 6.2:
    Saves a timestamped version snapshot of `timeline.json`, `brand_kit.json`, and `src/MainReel.tsx`
    into `ws/.shotcraft-versions/` before any overwrite occurs.
    """
    tl_file = ws / "timeline.json"
    tsx_file = ws / "src" / "MainReel.tsx"
    if not tl_file.is_file() and not tsx_file.is_file():
        return None

    v_root = ws / ".shotcraft-versions"
    v_root.mkdir(parents=True, exist_ok=True)
    manifest_file = v_root / "versions_manifest.json"
    history = []
    if manifest_file.is_file():
        try:
            history = json.loads(manifest_file.read_text(encoding="utf-8"))
        except Exception:
            history = []

    ver_num = len(history) + 1
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    ver_id = f"v{ver_num:03d}_{stamp}"
    snap_dir = v_root / ver_id
    snap_dir.mkdir(parents=True, exist_ok=True)

    saved_files = []
    for rel in ("timeline.json", "brand_kit.json", "src/MainReel.tsx", "src/Root.tsx"):
        src_p = ws / rel
        if src_p.is_file():
            dst_p = snap_dir / rel
            dst_p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_p, dst_p)
            saved_files.append(rel)

    entry = {
        "version_id": ver_id,
        "version_number": ver_num,
        "timestamp": stamp,
        "label": label,
        "files": saved_files,
    }
    history.append(entry)
    manifest_file.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")
    return entry


def list_project_versions(ws: Path) -> list:
    manifest_file = ws / ".shotcraft-versions" / "versions_manifest.json"
    if manifest_file.is_file():
        try:
            return json.loads(manifest_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def rollback_project_version(ws: Path, version_id: str) -> dict:
    """
    Section 6.2:
    Rolls back workspace files (`timeline.json`, `brand_kit.json`, `src/MainReel.tsx`) to a previous version snapshot.
    """
    v_root = ws / ".shotcraft-versions"
    history = list_project_versions(ws)
    if not history:
        return {"ok": False, "error": "No version snapshots found in workspace"}

    target_entry = None
    if version_id in ("latest", "last", "-1"):
        target_entry = history[-1]
    else:
        for item in history:
            if item["version_id"] == version_id or str(item["version_number"]) == version_id.lstrip("v0"):
                target_entry = item
                break
    if not target_entry:
        return {"ok": False, "error": f"Version '{version_id}' not found", "available": [h["version_id"] for h in history]}

    snap_dir = v_root / target_entry["version_id"]
    restored = []
    for rel in target_entry.get("files", []):
        s_file = snap_dir / rel
        if s_file.is_file():
            d_file = ws / rel
            d_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s_file, d_file)
            restored.append(rel)
    return {"ok": True, "rolled_back_to": target_entry["version_id"], "restored_files": restored}


def setup_brand_kit(
    ws: Path,
    brand_kit_path: str = None,
    brand_name: str = None,
    primary_color: str = None,
    accent_color: str = None,
    font_family: str = None,
    watermark_pos: str = None,
) -> dict:
    """
    Section 3.3:
    Loads or creates `brand_kit.json` in the workspace for consistent brand colors, typography,
    logo/watermark placement, and intro/outro metadata.
    """
    target_bk = ws / "brand_kit.json"
    bk = {}
    if brand_kit_path and Path(brand_kit_path).expanduser().is_file():
        bk = json.loads(Path(brand_kit_path).expanduser().read_text(encoding="utf-8"))
    elif target_bk.is_file():
        try:
            bk = json.loads(target_bk.read_text(encoding="utf-8"))
        except Exception:
            bk = {}

    if any([brand_name, primary_color, accent_color, font_family, watermark_pos]) or not bk:
        bk = {
            "brandName": brand_name if brand_name is not None else bk.get("brandName", ""),
            "primaryColor": primary_color or bk.get("primaryColor", "#38BDF8"),
            "secondaryColor": bk.get("secondaryColor", "#1E293B"),
            "accentColor": accent_color or bk.get("accentColor", primary_color or "#38BDF8"),
            "backgroundColor": bk.get("backgroundColor", "#090D16"),
            "fontFamily": font_family or bk.get("fontFamily", "sans"),
            "watermarkText": brand_name or bk.get("watermarkText", ""),
            "watermarkPosition": watermark_pos or bk.get("watermarkPosition", "bottom-right"),
            "introTemplate": bk.get("introTemplate", "editorial-badge"),
            "outroTemplate": bk.get("outroTemplate", "summary-cta"),
        }
        target_bk.write_text(json.dumps(bk, indent=2, ensure_ascii=False), encoding="utf-8")
    return bk


def generate_cicd_templates(ws: Path) -> list[str]:
    """
    Section 6.4:
    Generates GitHub Actions and GitLab CI pipeline templates for automated manifest rendering & artifact upload.
    """
    gh_dir = ws / ".github" / "workflows"
    gh_dir.mkdir(parents=True, exist_ok=True)
    gh_yml = gh_dir / "shotcraft-render.yml"
    gh_yml.write_text(
        """name: Shotcraft Pro Auto-Render Reel

on:
  push:
    paths:
      - 'timeline.json'
      - 'narration_manifest.json'
      - 'brand_kit.json'
  workflow_dispatch:

jobs:
  render-reel:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up Python 3.11
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install System Audio/Video Tools
        run: |
          sudo apt-get update
          sudo apt-get install -y ffmpeg flite libflite1

      - name: Install Python Dependencies
        run: |
          pip install numpy Pillow opencv-python-headless scipy edge-tts

      - name: Render Reel MP4 & Run Telemetry QA
        run: |
          python3 reels-templates/scripts/smart_render.py --workspace . --output out/final_reel.mp4 --stills 15,75,135

      - name: Upload Rendered MP4 & QA Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: shotcraft-reel-output
          path: |
            out/final_reel.mp4
            qa/telemetry.json
            qa/stills/*.png
""",
        encoding="utf-8",
    )

    gl_yml = ws / ".gitlab-ci.yml"
    gl_yml.write_text(
        """stages:
  - render
  - qa

shotcraft_render_job:
  stage: render
  image: python:3.11-slim
  before_script:
    - apt-get update && apt-get install -y ffmpeg flite
    - pip install numpy Pillow opencv-python-headless scipy edge-tts
  script:
    - python3 reels-templates/scripts/smart_render.py --workspace . --output out/final_reel.mp4 --stills 15,75,135
  artifacts:
    paths:
      - out/final_reel.mp4
      - qa/telemetry.json
      - qa/stills/
    expire_in: 14 days
""",
        encoding="utf-8",
    )
    return [str(gh_yml), str(gl_yml)]


def main():
    p = argparse.ArgumentParser(description="Scaffold isolated Shotcraft Pro v9.7.0 Remotion workspace with Versioning & Brand Kit")
    p.add_argument("--repo", help="Optional path to video-shotcraft repo (auto-resolved if omitted)")
    p.add_argument("--workspace", required=True, help="Target isolated workspace directory")
    p.add_argument("--template", default="kinetic-fact-story")
    p.add_argument("--aspect", default="9:16", choices=list(ASPECT_DIMENSIONS.keys()))
    p.add_argument("--width", type=int)
    p.add_argument("--height", type=int)
    p.add_argument("--duration", type=float, default=15.0)
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--overwrite", action="store_true", help="Snapshot current version and overwrite timeline.json/MainReel.tsx")
    p.add_argument("--save-version", help="Save a named snapshot of current workspace template state")
    p.add_argument("--list-versions", action="store_true", help="List saved template versions in workspace")
    p.add_argument("--rollback", help="Rollback workspace to specified version ID (or 'latest')")
    p.add_argument("--brand-kit", help="Path to brand_kit.json to apply to workspace")
    p.add_argument("--brand-name", help="Brand name for Brand Kit")
    p.add_argument("--primary-color", help="Primary brand hex color (e.g. #38BDF8)")
    p.add_argument("--accent-color", help="Accent brand hex color (e.g. #F59E0B)")
    p.add_argument("--font-family", choices=["sans", "serif", "mono"], help="Brand typography family")
    p.add_argument("--watermark-pos", choices=["top-left", "top-right", "bottom-left", "bottom-right"])
    p.add_argument("--with-cicd", action="store_true", help="Generate GitHub Actions & GitLab CI auto-render workflows")
    a = p.parse_args()

    ws = Path(a.workspace).expanduser().resolve()
    ws.mkdir(parents=True, exist_ok=True)

    if a.list_versions:
        print(json.dumps({"ok": True, "workspace": str(ws), "versions": list_project_versions(ws)}, indent=2))
        return

    if a.rollback:
        res = rollback_project_version(ws, a.rollback)
        print(json.dumps(res, indent=2))
        return

    if a.save_version:
        snap = save_project_version_snapshot(ws, label=a.save_version)
        print(json.dumps({"ok": True, "snapshot": snap}, indent=2))
        return

    here = Path(__file__).resolve().parent
    tpl_skill = here.parent
    skills_root = tpl_skill.parent

    repo = Path(a.repo).expanduser().resolve() if a.repo else (skills_root / "local-upstream" / "video-shotcraft")
    for cand in [
        repo,
        skills_root / "video-shotcraft",
        skills_root / "local-upstream" / "video-shotcraft",
        skills_root.parent / "local-upstream" / "video-shotcraft",
    ]:
        if (cand / "template" / "package.json").is_file():
            repo = cand
            break

    # Automatically snapshot previous version before any changes (Section 6.2)
    snapshot_info = save_project_version_snapshot(ws, label=f"pre-scaffold-{a.template}")

    (ws / "src" / "components").mkdir(parents=True, exist_ok=True)
    (ws / "public" / "audio" / "sfx").mkdir(parents=True, exist_ok=True)
    (ws / "public" / "audio" / "bgm").mkdir(parents=True, exist_ok=True)
    (ws / "qa").mkdir(parents=True, exist_ok=True)
    (ws / "out").mkdir(parents=True, exist_ok=True)

    if (repo / "template" / "package.json").is_file() and not (ws / "package.json").is_file():
        shutil.copy2(repo / "template" / "package.json", ws / "package.json")

    comp_src = tpl_skill / "components"
    copied_components = []
    for tsx in sorted(comp_src.glob("*.tsx")):
        dst = ws / "src" / "components" / tsx.name
        shutil.copy2(tsx, dst)
        copied_components.append(tsx.name)
    if (comp_src / "custom").is_dir():
        shutil.copytree(comp_src / "custom", ws / "src" / "components" / "custom", dirs_exist_ok=True)

    sfx_studio_assets = skills_root / "reels-sfx-studio" / "assets"
    if sfx_studio_assets.is_dir():
        for wav in (sfx_studio_assets / "sfx").rglob("*.wav"):
            rel = wav.relative_to(sfx_studio_assets / "sfx")
            target = ws / "public" / "audio" / "sfx" / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.is_file():
                shutil.copy2(wav, target)
        for wav in (sfx_studio_assets / "bgm").glob("*.wav"):
            target = ws / "public" / "audio" / "bgm" / wav.name
            if not target.is_file():
                shutil.copy2(wav, target)

    brand_kit = setup_brand_kit(
        ws,
        brand_kit_path=a.brand_kit,
        brand_name=a.brand_name,
        primary_color=a.primary_color,
        accent_color=a.accent_color,
        font_family=a.font_family,
        watermark_pos=a.watermark_pos,
    )

    width, height = ASPECT_DIMENSIONS.get(a.aspect, (1080, 1920))
    width, height = a.width or width, a.height or height
    if not math.isfinite(a.duration) or a.duration <= 0 or a.fps <= 0 or width < 2 or height < 2 or width % 2 or height % 2:
        p.error('Use positive finite duration/fps and even positive dimensions')
    total_frames = max(1, round(a.duration * a.fps))
    scene_count = min(3, total_frames)
    sizes = [total_frames // scene_count + (1 if i < total_frames % scene_count else 0) for i in range(scene_count)]
    default_scenes = [{'id':f'scene-{i+1:02d}', 'eyebrow':'DRAFT', 'headline':text,
                       'subcopy':'Isi dengan naskah dan aset yang sudah diperiksa', 'accent':brand_kit.get('accentColor','#38BDF8'),
                       'visualMode':'ref4-minimal-ui', 'durationInFrames':sizes[i]}
                      for i,text in enumerate(['Pembuka','Penjelasan','Penutup'][:scene_count])]

    timeline_data = {
        "template": a.template,
        "aspect": a.aspect,
        "width": width,
        "height": height,
        "fps": a.fps,
        "duration": a.duration,
        "totalFrames": total_frames,
        "title_badge": brand_kit.get("brandName", ""),
        "brand_kit": brand_kit,
        "scenes": default_scenes,
    }
    timeline_path = ws / "timeline.json"
    if not timeline_path.is_file() or a.overwrite:
        timeline_path.write_text(json.dumps(timeline_data, indent=2, ensure_ascii=False), encoding="utf-8")

    if timeline_path.is_file() and not a.overwrite:
        retained = json.loads(timeline_path.read_text(encoding='utf-8'))
        width, height = retained.get('width', width), retained.get('height', height)
        total_frames = sum(int(sc['durationInFrames']) for sc in retained.get('scenes', [])) or total_frames
        a.fps = retained.get('fps', a.fps)
    (ws / "src" / "index.ts").write_text(
        "import {registerRoot} from 'remotion';\nimport {RemotionRoot} from './Root';\nregisterRoot(RemotionRoot);\n",
        encoding="utf-8",
    )
    root_tsx_code = (
        "import React from 'react';\n"
        "import {Composition} from 'remotion';\n"
        "import {MainReel} from './MainReel';\n"
        "import timeline from '../timeline.json';\n\n"
        "export const RemotionRoot: React.FC = () => {\n"
        "  return (\n"
        '    <Composition\n'
        '      id="MainReel"\n'
        "      component={MainReel}\n"
        "      durationInFrames={timeline.totalFrames}\n"
        "      fps={timeline.fps}\n"
        "      width={timeline.width}\n"
        "      height={timeline.height}\n"
        "    />\n"
        "  );\n"
        "};\n"
    )
    (ws / "src" / "Root.tsx").write_text(root_tsx_code, encoding="utf-8")

    main_reel_path = ws / "src" / "MainReel.tsx"
    if not main_reel_path.is_file() or a.overwrite:
        cfg_path = skills_root / 'shotcraft-local/config.json'
        cfg = json.loads(cfg_path.read_text()) if cfg_path.is_file() else {}
        for mcp_cand in [skills_root / "mcp" / "shotcraft_mcp_server.py", skills_root.parent / "mcp" / "shotcraft_mcp_server.py", Path(cfg.get('mcp_dir', '.'))/'shotcraft_mcp_server.py']:
            if mcp_cand.is_file():
                sys.path.insert(0, str(mcp_cand.parent))
                import shotcraft_mcp_server as mcp_mod

                mcp_mod.generate_clean_3zone_composition(
                    str(main_reel_path),
                    default_scenes,
                    title_badge=brand_kit.get("brandName", ""),
                )
                break

    cicd_files = generate_cicd_templates(ws) if a.with_cicd else []

    print(
        json.dumps(
            {
                "ok": True,
                "workspace": str(ws),
                "template": a.template,
                "aspect": a.aspect,
                "resolution": f"{width}x{height}",
                "fps": a.fps,
                "totalFrames": total_frames,
                "brand_kit": str(ws / "brand_kit.json"),
                "version_snapshot": snapshot_info,
                "cicd_files": cicd_files,
                "components_injected": copied_components,
                "timeline": str(timeline_path),
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
