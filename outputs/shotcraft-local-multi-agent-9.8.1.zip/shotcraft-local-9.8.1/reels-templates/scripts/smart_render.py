#!/usr/bin/env python3
"""
Shotcraft Pro v9.6 — True 3D Volumetric Orbit Renderer, Semantic Animated Subtitles,
Modular 6-World + Brand Kit Engine, Multi-Aspect Export & Live Preview (`smart_render.py`).

Upgrades implementing SHOTCRAFT_PRO_v9.5_IMPROVEMENT_REPORT:
- Section 2.1: Per-word animations (scale-bounce, pop-rotate, glow-pulse, slide-up) & spoken-word exit settle.
- Section 2.2: Semantic caption grouping (keeps Indonesian compound phrases like "tidak boleh" & metrics like "86 MILIAR" together).
- Section 2.3: Configurable y_center + automatic 3D/visual collision avoidance (shifts captions up when bottom 30% is occupied).
- Section 2.4: 7 Caption Styles: karaoke-pill, typewriter, slide-up, glitch, handwritten, neon, minimal.
- Section 2.5: Inline Emoji & Vector Icon rendering (🎯, 💡, 🔥, 📊, ⚡, ⚠️, ✅, ☕, 🧠, ⚙️) inside captions.
- Section 2.6: Multi-speaker color-coded labels (NARATOR:, EXPERT:, USER:, HOST:, GUEST:).
- Section 3.1: True 6+ World modular theming (independent mix & match of backgroundKind, typographyKind, stage3DKind).
- Section 3.2: Real-time 3D camera orbit, dynamic moving point lighting, and depth-sorted text/object occlusion.
- Section 3.3: Brand Kit system (load/apply brand colors, fonts, logo/watermark, intro/outro).
- Section 3.4: Multi-aspect ratio presets (--aspect 9:16|16:9|1:1|4:5|2:3) with responsive layout scaling.
- Section 4.3: Automatic pacing adjustment (fits scene visual durations to actual synthesized TTS audio).
- Section 6.1: --preview-frame N instant PNG preview, --only-scene incremental scene update, & --serve-preview live browser UI.
- Section 7.1 & 7.2: Render telemetry (per-scene ms, FPS, bitrate) & heuristic viewer retention prediction.
"""
import argparse
from contextvars import ContextVar
import hashlib
import concurrent.futures
from functools import lru_cache
import http.server
import json
import math
import os
import re
import shutil
import socketserver
import subprocess
import sys
import time
from pathlib import Path

def _resolve_skills_root() -> Path:
    here = Path(__file__).resolve()
    for cand in (
        here.parents[2],
        Path.home() / ".claude" / "skills",
        here.parents[1] / "intermediate" / "shotcraft_extracted",
    ):
        if (cand / "reels-sfx-studio" / "scripts").is_dir() or (cand / "reels-narration" / "scripts").is_dir():
            return cand
    return here.parents[2]

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ASPECT_PRESETS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
    "2:3": (1080, 1620),
}

# Style compatibility matrix: maps each visual style to recommended voice profile,
# visual mode, and suitable topic categories. Used by voice recommend and plan commands.
STYLE_COMPATIBILITY_MAP = {
    "ref3-cutaway-mechanism": {
        "voice_profile": "zan",
        "visual_mode": "ref3-cutaway-mechanism",
        "topics": ["mekanisme", "mesin", "teknik", "engine", "cutaway", "how-it-works"],
        "description": "Cutaway diagram style for mechanical explanations",
    },
    "ref1-voxel-evidence": {
        "voice_profile": "zan",
        "visual_mode": "ref1-voxel-evidence",
        "topics": ["tools", "evidence", "verifikasi", "data", "voxel", "layer"],
        "description": "Voxel evidence layer for technical verification",
    },
    "ref2-cinematic-character": {
        "voice_profile": "denas",
        "visual_mode": "ref2-cinematic-character",
        "topics": ["storytelling", "karakter", "cinematic", "narasi", "drama"],
        "description": "Cinematic character-driven storytelling style",
    },
    "ref4-minimal-ui": {
        "voice_profile": "nesah_paramitha",
        "visual_mode": "ref4-minimal-ui",
        "topics": ["ui", "workflow", "interface", "desain", "minimal", "app"],
        "description": "Minimal UI workflow style for interface demos",
    },
    "cutaway-turbofan": {
        "voice_profile": "zan",
        "visual_mode": "ref5-editorial-cutaway",
        "topics": ["turbofan", "jet", "aviation", "mesin jet", "turbine"],
        "description": "Turbofan jet engine cutaway 3D stage",
    },
    "cosmic-glass": {
        "voice_profile": "denas",
        "visual_mode": "ref2-cinematic-character",
        "topics": ["luxury", "glass", "premium", "abstract", "futuristik"],
        "description": "Cosmic glass premium background style",
    },
    "ref5-editorial-cutaway": {
        "voice_profile": "denas",
        "visual_mode": "ref5-editorial-cutaway",
        "topics": ["editorial", "fakta", "ilmiah", "general", "umum"],
        "description": "Editorial cutaway style for general facts",
    },
    "ref1-tutorial-deck": {
        "voice_profile": "nesah_paramitha",
        "visual_mode": "ref1-tutorial-deck",
        "topics": ["tutorial", "deck", "presentasi", "panduan", "guide"],
        "description": "Tutorial deck / terminal style for step-by-step guides",
    },
    "talking-head": {
        "voice_profile": "bayu",
        "visual_mode": "talking-head",
        "topics": ["bilingual", "presenter", "spokesperson", "wawancara"],
        "description": "Talking head presenter style for bilingual content",
    },
}

# Topic -> voice profile overrides (per CLAUDE.md recommendations)
TOPIC_VOICE_MAP = {
    "mekanisme": "nesah_paramitha",
    "sains": "nesah_paramitha",
    "voxel": "kak_ceria",
    "tools": "nesah_paramitha",
    "storytelling": "selina",
    "ui": "nesah_paramitha",
    "workflow": "nesah_paramitha",
    "bilingual": "selina",
}

def get_style_compatibility(style: str) -> dict:
    """Return compatibility info for a given visual style."""
    return STYLE_COMPATIBILITY_MAP.get(style, {
        "voice_profile": "denas",
        "visual_mode": style,
        "topics": [],
        "description": f"Custom style: {style}",
    })

def recommend_voice_profile(style: str, topic: str = "") -> str:
    """Recommend a voice profile based on style and topic (per CLAUDE.md mapping)."""
    topic_lower = topic.lower()
    for keyword, voice in TOPIC_VOICE_MAP.items():
        if keyword in topic_lower:
            return voice
    return get_style_compatibility(style)["voice_profile"]

SPEAKER_BADGE_STYLES = {
    "narrator": {"label": "NARATOR", "rgb": (56, 189, 248)},
    "expert": {"label": "EXPERT", "rgb": (245, 158, 11)},
    "user": {"label": "USER", "rgb": (16, 185, 129)},
    "host": {"label": "HOST", "rgb": (168, 85, 247)},
    "guest": {"label": "GUEST", "rgb": (236, 72, 153)},
}

SUPPORTED_EMOJIS = {"🎯", "💡", "🔥", "📊", "⚡", "⚠️", "✅", "☕", "🧠", "⚙️"}

# Indonesian compound phrases that should never be split across subtitle lines/pills
_ID_COMPOUND_PHRASES = {
    ("tidak", "boleh"),
    ("tidak", "bisa"),
    ("tidak", "perlu"),
    ("tidak", "akan"),
    ("jangan", "pernah"),
    ("jangan", "sampai"),
    ("jangan", "digeber"),
    ("sama", "sekali"),
    ("lebih", "dari"),
    ("kurang", "dari"),
    ("di", "dalam"),
    ("di", "atas"),
    ("di", "bawah"),
    ("ke", "atas"),
    ("ke", "bawah"),
    ("ke", "dalam"),
    ("bukan", "cuma"),
    ("bukan", "hanya"),
    ("satu", "sama"),
    ("oleh", "karena"),
    ("agar", "tidak"),
    ("supaya", "tidak"),
}

_METRIC_UNITS = {
    "miliar", "juta", "ribu", "triliun", "persen", "%", "°c", "celcius", "derajat",
    "km/jam", "km/h", "watt", "menit", "detik", "jam", "gram", "gr", "ml", "liter",
    "kali", "x", "rupiah", "rp", "mm2/s",
}


# Point 3: Static Scene Layer Cache for 5x-8x faster rendering
_STATIC_SCENE_BG_CACHE = {}


class FastRGBDraw:
    """
    Native C-accelerated RGBA compositor over RGB/RGBA PIL Images.
    Uses `ImageDraw.Draw(img, "RGBA")` so semi-transparent god-rays, bokeh particles,
    and glass cards alpha-blend genuinely against underlying pixels (zero dark patches).
    """
    def __init__(self, img, bg=(10, 14, 24)):
        self._d = ImageDraw.Draw(img, "RGBA")
        self._bg = bg

    def __getattr__(self, name):
        return getattr(self._d, name)


def hex_to_rgb(hex_str: str) -> tuple[int, int, int]:
    h = str(hex_str).lstrip("#")
    if len(h) == 6:
        try:
            return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        except Exception:
            pass
    return (56, 189, 248)


def ease_out_cubic(x: float) -> float:
    x = max(0.0, min(1.0, float(x)))
    return 1.0 - (1.0 - x) ** 3


def ease_in_out_cubic(x: float) -> float:
    x = max(0.0, min(1.0, float(x)))
    return 4.0 * x * x * x if x < 0.5 else 1.0 - ((-2.0 * x + 2.0) ** 3) / 2.0


def spring_ease(frame: float, delay: float = 0.0, dur: float = 18.0) -> float:
    t = max(0.0, (float(frame) - float(delay)) / max(1.0, float(dur)))
    if t <= 0.0:
        return 0.0
    if t >= 1.5:
        return 1.0
    return float(1.0 - math.exp(-4.8 * t) * math.cos(3.2 * t))



def has_rtl_script(s: str) -> bool:
    return bool(re.search(r"[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]", str(s or "")))


def shape_rtl_mixed_text(s: str) -> str:
    """[P2-4]: Reorders contiguous RTL (Arabic/Hebrew) runs for Pillow rasterization while preserving LTR tokens."""
    if not has_rtl_script(s):
        return s
    tokens = s.split(" ")
    shaped = [tok[::-1] if has_rtl_script(tok) else tok for tok in tokens]
    return " ".join(reversed(shaped))

def sanitize_text(s: str, allow_emoji: bool = False, allow_technical: bool = False) -> str:
    if not s:
        return ""
    out = str(s)
    # Strip SSML tags if any were passed directly into display text
    out = re.sub(r"<break[^>]*>", " ", out, flags=re.IGNORECASE)
    out = re.sub(r"<[^>]+>", "", out)

    if not allow_technical:
        # Strip leaked narration/prompt prefixes ("Narration:", "Narasi:", "NARATOR:", "Voiceover:", "Subcopy:", etc.)
        out = re.sub(
            r"^(?:\[?\s*(?:scene|shot|tahap|bagian)\s*\d+\s*\]?\s*[-:—]?\s*)*"
            r"(?:narration_text|display_text|narration|narasi|narrator|narator|voiceover|vo|subcopy|headline|caption|script|prompt)\s*[:=—-]+\s*",
            "",
            out,
            flags=re.IGNORECASE,
        )
        # Strip inline bracketed stage directions or leaked narration tags: [Narration: ...], (Narasi: ...), [SFX: ...]
        out = re.sub(r"\[(?:narration|narasi|vo|voiceover|sfx|bgm|musik|pause|jeda|intonasi|tone|emotion)[^\]]*\]", "", out, flags=re.IGNORECASE)
        out = re.sub(r"\((?:narration|narasi|vo|voiceover|sfx|bgm|intonasi|nada)[^\)]*\)", "", out, flags=re.IGNORECASE)
        # Strip raw JSON key leaks like `"narration": "..."` or `narration_text:`
        out = re.sub(r"[\"']?(?:narration_text|display_text|narration|subcopy|headline)[\"']?\s*:\s*", "", out, flags=re.IGNORECASE)
        # RAR10: Strip technical metadata patterns that must not leak into display output
        # Template placeholders ({{SCENES_JSON}} etc.)
        out = re.sub(r"\{\{[^}]*\}\}", "", out)
        # Hex color codes (#FA1919 etc.)
        out = re.sub(r"#[0-9a-fA-F]{3,6}\b", "", out)
        # Common font family names when used as technical metadata (Inter Bold etc.)
        out = re.sub(
            r"\b(?:Inter|Arial|Helvetica|Roboto|Open\s+Sans|Montserrat|Lato|Poppins|Source\s+Sans|Noto\s+Sans|Segoe\s+UI|Ubuntu|DejaVu|Liberation)\b(?:\s+(?:Bold|Regular|Light|Medium|SemiBold|ExtraBold|Black|Italic|Oblique|Condensed|Expanded))?\b",
            "",
            out,
            flags=re.IGNORECASE,
        )
        # Asset paths (assets/models/neuron.glb etc.)
        out = re.sub(
            r"\b(?:assets?|models?|images?|fonts?|audio|video|clips?|sfx|bgm|icons?)/[\w/.-]+\b",
            "",
            out,
            flags=re.IGNORECASE,
        )

    out = re.sub(r"\s+([,.;:!?])", r"\1", out)
    replacements = {
        "✳": "*",
        "✓": "v",
        "✔": "v",
        "›": ">",
        "—": "-",
        "–": "-",
        "∞": "UNLIMITED",
        "×": "x",
    }
    for k, v in replacements.items():
        out = out.replace(k, v)
    if allow_emoji:
        # Keep emoji / symbol glyphs (non-BMP too) so captions never lose symbols.
        # The 10 vector icons in SUPPORTED_EMOJIS get custom drawn; other emoji
        # pass through as text glyphs (font permitting) instead of being stripped.
        return re.sub(r"\s+", " ", out).strip()
    return re.sub(r"\s+", " ", "".join(ch for ch in out if ord(ch) < 65535)).strip()


_FONT_RESOLUTION_LOG = {}

DESIGN_TOKENS = {
    "editorial": {"heading_family": "serif", "body_family": "sans", "mono_family": "mono", "h1_size": 40, "body_size": 24, "caption_size": 34, "leading": 1.20, "safe_pad_x": 84, "safe_top_y": 210, "safe_bot_y": 1490},
    "mechanical": {"heading_family": "display", "body_family": "sans", "mono_family": "mono", "h1_size": 38, "body_size": 24, "caption_size": 34, "leading": 1.18, "safe_pad_x": 84, "safe_top_y": 200, "safe_bot_y": 1490},
    "data": {"heading_family": "sans", "body_family": "sans", "mono_family": "mono", "h1_size": 38, "body_size": 23, "caption_size": 32, "leading": 1.18, "safe_pad_x": 84, "safe_top_y": 210, "safe_bot_y": 1490},
    "story": {"heading_family": "display", "body_family": "serif", "mono_family": "mono", "h1_size": 38, "body_size": 25, "caption_size": 34, "leading": 1.22, "safe_pad_x": 84, "safe_top_y": 210, "safe_bot_y": 1490},
}


_ACTIVE_SCENE_CUSTOM_FONT = ContextVar("scene_font", default=None)


@lru_cache(maxsize=512)
def _load_font_cached(size: int, bold: bool = True, mono: bool = False, serif: bool = False, family: str = ""):
    """
    Authentic Font Resolver for all 33 XML + MOGRT files in Premium Text.rar and 42 Visual Styles:
    1. Checks user/system font folders (Windows C:/Windows/Fonts, LocalAppData, macOS /Library/Fonts, Linux ~/.fonts)
       AND bundled skill font folders (`assets/fonts`) for exact original XML/MOGRT fonts (`BarberChop.ttf`,
       `TacticSans-Blk.otf`, `TacticSans-BldIt.otf`, `TacticSans-Ult.otf`, `TacticSans-MedIt.otf`,
       `Triumvirate CG Inserat.ttf`, `UnifrakturCook-Bold.ttf`, `BebasNeue-Bold.ttf`, `Anton-Regular.ttf`,
       `Poppins-Bold.ttf`, `Roboto-Bold.ttf`, `ITCGaramondStd-BdNarrowIta.otf`, `TimesNewRomanPS-BoldItalicMT`,
       `SnellRoundhand`, `ShadowsIntoLight`, `Lobster1.3`, `Arthemis`, `GTProelium`, `JandaManateeSolid`).
    2. Maps to bundled metric/style-matched OpenType & TrueType display/condensed/serif/script/gothic fonts
       shipped directly inside `reels-templates/assets/fonts/` so every platform renders distinct typography!
    """
    here = Path(__file__).resolve().parent
    search_dirs = [
        here / "assets" / "fonts",
        here.parent / "assets" / "fonts",
        Path.home() / ".claude" / "skills" / "reels-templates" / "assets" / "fonts",
        Path("/usr/share/fonts/opentype/inter"),
        Path("/usr/share/fonts/opentype/urw-base35"),
        Path("/usr/share/fonts/truetype/noto"),
        Path("/usr/share/fonts/truetype/liberation2"),
        Path("/usr/share/fonts/truetype/liberation"),
        Path("/usr/share/fonts/truetype/dejavu"),
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts",
        Path.home() / "AppData" / "Local" / "Microsoft" / "Windows" / "Fonts",
        Path("/Library/Fonts"),
        Path.home() / "Library" / "Fonts",
        Path.home() / ".local" / "share" / "fonts",
        Path.home() / ".fonts",
    ]

    def _find_in_dirs(filenames: list[str]) -> list[str]:
        found = []
        for fn in filenames:
            if os.path.isabs(fn) and os.path.exists(fn):
                found.append(fn)
                continue
            for d in search_dirs:
                cand = d / fn
                if cand.is_file():
                    found.append(str(cand))
        return found

    fam_clean = (family or "").strip().lower()
    FONT_FAMILY_FILES = {
        "inter-black": [
            "InterDisplay-Black.otf", "Inter-Black.otf", "Inter-Black.ttf", "arialbd.ttf",
        ],
        "inter-extrabold": [
            "InterDisplay-ExtraBold.otf", "Inter-ExtraBold.otf", "InterDisplay-Bold.otf", "Inter-Bold.otf",
        ],
        "inter-semibold": [
            "Inter-SemiBold.otf", "InterDisplay-Bold.otf", "Inter-Bold.otf",
        ],
        "inter-regular": [
            "Inter-Regular.otf", "NimbusSans-Regular.otf", "LiberationSans-Regular.ttf", "DejaVuSans.ttf",
        ],
        "helvetica-bold": [
            "Helvetica-Bold.ttf", "HelveticaNeue-Bold.otf", "NimbusSans-Bold.otf", "LiberationSans-Bold.ttf", "arialbd.ttf",
        ],
        "helvetica-light": [
            "Helvetica-Light.ttf", "NimbusSans-Regular.otf", "Inter-Regular.otf",
        ],
        "tacticsans-blk": [
            "TacticSans-Blk.otf", "TacticSans-Blk.ttf", "URWGothic-Demi.otf", "InterDisplay-Black.otf",
        ],
        "tacticsans-ult": [
            "TacticSans-Ult.otf", "TacticSans-Ult.ttf", "URWGothic-Demi.otf", "InterDisplay-Black.otf",
        ],
        "tacticsans-bldit": [
            "TacticSans-BldIt.otf", "TacticSans-BldIt.ttf", "URWGothic-DemiOblique.otf",
            "InterDisplay-BlackItalic.otf", "NotoSansDisplay-BoldItalic.ttf",
        ],
        "tacticsans-medit": [
            "TacticSans-MedIt.otf", "URWGothic-DemiOblique.otf", "Inter-BoldItalic.otf", "LiberationSans-BoldItalic.ttf",
        ],
        "bebas-bold": [
            "BebasNeue-Bold.ttf", "BebasNeue-Regular.ttf", "NimbusSansNarrow-Bold.otf",
            "LiberationSansNarrow-Bold.ttf", "DejaVuSansCondensed-Bold.ttf", "impact.ttf",
        ],
        "anton-regular": [
            "Anton-Regular.ttf", "NimbusSansNarrow-Bold.otf", "LiberationSansNarrow-Bold.ttf",
            "DejaVuSansCondensed-Bold.ttf", "impact.ttf",
        ],
        "barberchop": [
            "BarberChop.ttf", "BarberChop.otf", "URWBookman-Demi.otf", "C059-Bold.otf", "InterDisplay-Black.otf",
        ],
        "triumvirate": [
            "Triumvirate CG Inserat.ttf", "NimbusSansNarrow-Bold.otf", "LiberationSansNarrow-Bold.ttf",
        ],
        "unifraktur": [
            "UnifrakturCook-Bold.ttf", "C059-BdIta.otf", "Z003-MediumItalic.otf", "P052-BoldItalic.otf",
        ],
        "garamond-bolditalic": [
            "ITCGaramondStd-BdNarrowIta.otf", "P052-BoldItalic.otf", "NotoSerifDisplay-BoldItalic.ttf",
            "URWBookman-DemiItalic.otf", "georgiaz.ttf",
        ],
        "times-bolditalic": [
            "TimesNewRomanPS-BoldItalicMT.ttf", "timesbi.ttf", "NimbusRoman-BoldItalic.otf",
            "LiberationSerif-BoldItalic.ttf", "C059-BdIta.otf",
        ],
        "script-italic": [
            "SnellRoundhand.ttc", "Arthemis.ttf", "Lobster1.3.otf", "ShadowsIntoLight.ttf",
            "Z003-MediumItalic.otf", "URWBookman-DemiItalic.otf", "NotoSerifDisplay-BoldItalic.ttf",
        ],
        "poppins-bold": [
            "Poppins-Bold.ttf", "GTProelium.ttf", "JandaManateeSolid.ttf",
            "URWGothic-Demi.otf", "NotoSansDisplay-Bold.ttf", "InterDisplay-ExtraBold.otf",
        ],
        "roboto-bold": [
            "Roboto-Bold.ttf", "NotoSansDisplay-Bold.ttf", "LiberationSans-Bold.ttf", "NimbusSans-Bold.otf",
        ],
    }

    if fam_clean in FONT_FAMILY_FILES:
        for p in _find_in_dirs(FONT_FAMILY_FILES[fam_clean]):
            try:
                f_obj = ImageFont.truetype(p, size=size)
                _FONT_RESOLUTION_LOG[fam_clean] = {"requested": family, "resolved": Path(p).name, "fallback": False}
                return f_obj
            except Exception:
                pass

    if fam_clean:
        for p in _find_in_dirs([fam_clean, f"{fam_clean}.ttf", f"{fam_clean}.otf"]):
            try:
                f_obj = ImageFont.truetype(p, size=size)
                _FONT_RESOLUTION_LOG[fam_clean] = {"requested": family, "resolved": Path(p).name, "fallback": False}
                return f_obj
            except Exception:
                pass
        if any(k in fam_clean for k in ("mono", "jetbrains", "fira", "ibm plex mono", "consolas")):
            mono = True
        elif any(k in fam_clean for k in ("serif", "playfair", "charter", "georgia", "times", "handwritten", "garamond", "script", "snell")):
            serif = True
        elif any(k in fam_clean for k in ("inter", "display", "grotesk", "sans", "helvetica", "tactic", "bebas", "anton", "poppins", "roboto")):
            mono = False
            serif = False

    if mono:
        fallbacks = ["DejaVuSansMono-Bold.ttf", "LiberationMono-Bold.ttf"]
    elif serif:
        fallbacks = ["P052-BoldItalic.otf", "NotoSerifDisplay-BoldItalic.ttf", "DejaVuSerif-Bold.ttf"] if bold else ["DejaVuSerif.ttf"]
    elif bold:
        fallbacks = ["InterDisplay-ExtraBold.otf", "Inter-Bold.otf", "NimbusSans-Bold.otf", "DejaVuSans-Bold.ttf"]
    else:
        fallbacks = ["Inter-Regular.otf", "NimbusSans-Regular.otf", "DejaVuSans.ttf"]

    for p in _find_in_dirs(fallbacks):
        try:
            return ImageFont.truetype(p, size=size)
        except Exception:
            pass
    return ImageFont.load_default()


def wrap_text_pixel(draw, text: str, font, max_width_px: int) -> list[str]:
    clean = sanitize_text(text)
    words = clean.split()
    if not words:
        return []
    lines = []
    cur = words[0]
    for w in words[1:]:
        test = f"{cur} {w}"
        if draw.textlength(test, font=font) <= max_width_px:
            cur = test
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines


def fit_text_block(
    draw,
    text: str,
    max_width_px: int,
    max_lines: int = 3,
    start_size: int = 42,
    min_size: int = 24,
    bold: bool = True,
    mono: bool = False,
    serif: bool = False,
) -> tuple[list[str], object, int]:
    for sz in range(start_size, min_size - 1, -2):
        f = load_font(sz, bold=bold, mono=mono, serif=serif)
        lines = wrap_text_pixel(draw, text, f, max_width_px)
        if len(lines) <= max_lines and all(draw.textlength(ln, font=f) <= max_width_px + 8 for ln in lines):
            return lines, f, sz
    f_min = load_font(min_size, bold=bold, mono=mono, serif=serif)
    return wrap_text_pixel(draw, text, f_min, max_width_px), f_min, min_size


def load_font(size: int, bold: bool = True, mono: bool = False, serif: bool = False, family: str = ""):
    eff_fam = family or ""
    if not eff_fam and _ACTIVE_SCENE_CUSTOM_FONT.get():
        ovr = str(_ACTIVE_SCENE_CUSTOM_FONT.get()).strip().lower()
        if ovr in ("serif", "editorial"):
            serif = True
        elif ovr in ("mono", "monospace", "code", "terminal"):
            mono = True
        elif ovr in ("sans", "sans-serif"):
            serif = False
            mono = False
        else:
            eff_fam = ovr
    return _load_font_cached(int(size), bool(bold), bool(mono), bool(serif), str(eff_fam))


def use_serif_for_scene(scene: dict, badge: str = "", brand_kit: dict = None) -> bool:
    if brand_kit and brand_kit.get("fontFamily") in ("serif", "sans", "mono"):
        return brand_kit.get("fontFamily") == "serif"
    theme_cfg = scene.get("theme") or {}
    if theme_cfg.get("typography") == "serif" or scene.get("fontFamily") == "serif":
        return True
    if theme_cfg.get("typography") in ("sans", "mono"):
        return False
    mode = str(scene.get("visualMode", ""))
    if mode in ("coffee-editorial-3d", "luxury-editorial-glass"):
        return True
    combined = f"{scene.get('headline', '')} {scene.get('eyebrow', '')} {badge}".lower()
    # Last-resort keyword hint: match whole words only to avoid false positives
    # (e.g. "kopi" should not match inside unrelated words).
    tokens = set(re.findall(r"[a-zA-ZÀ-ÿ]+", combined))
    serif_hints = {"kopi", "coffee", "espresso", "seduh", "sejarah", "kuliner", "buku", "sastra", "artisan"}
    return bool(tokens & serif_hints)


# ============================================================================
# SECTION 3.2: REAL-TIME 3D LIGHTING & VOLUMETRIC PRIMITIVES
# ============================================================================

@lru_cache(maxsize=256)
def make_shaded_3d_sphere(
    radius: int,
    base_rgb: tuple[int, int, int],
    rim_rgb: tuple[int, int, int] = (255, 255, 255),
    spec_power: float = 28.0,
    spec_strength: float = 0.85,
    light_angle_deg: int = -35,
) -> Image.Image:
    """
    True 3D Blinn-Phong sphere with dynamic light direction (`light_angle_deg` quantized for cache efficiency).
    """
    r = max(3, int(radius))
    size = r * 2 + 4
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    cx = cy = (size - 1) * 0.5
    nx = (xx - cx) / float(r)
    ny = (yy - cy) / float(r)
    r2 = nx * nx + ny * ny
    nz = np.sqrt(np.maximum(0.0, 1.0 - np.minimum(1.0, r2)))

    ang_rad = math.radians(float(light_angle_deg))
    lx = math.sin(ang_rad) * 0.65
    ly = -0.50 + math.cos(ang_rad) * 0.15
    lz = 0.72
    l_norm = math.sqrt(lx * lx + ly * ly + lz * lz)
    lx, ly, lz = lx / l_norm, ly / l_norm, lz / l_norm

    ndotl = np.maximum(0.0, nx * lx + ny * ly + nz * lz)
    # [P1-2]: Subsurface Scattering (SSS) back-light translucency + Fresnel rim + Blinn-Phong specular
    back_ndotl = (np.maximum(0.0, -(nx * lx + ny * ly + nz * 0.35)) ** 2.1) * 0.34

    hx, hy, hz = lx, ly, lz + 1.0
    h_norm = math.sqrt(hx * hx + hy * hy + hz * hz)
    hx, hy, hz = hx / h_norm, hy / h_norm, hz / h_norm
    ndoth = np.maximum(0.0, nx * hx + ny * hy + nz * hz)
    spec = (ndoth ** spec_power) * spec_strength
    fresnel = ((1.0 - nz) ** 2.3) * 0.65

    br, bg, bb = base_rgb
    rr, rg, rb = rim_rgb
    shade = 0.24 + 0.76 * ndotl + back_ndotl

    out_r = np.clip(br * shade + rr * fresnel + 255.0 * spec, 0, 255).astype(np.uint8)
    out_g = np.clip(bg * shade + rg * fresnel + 255.0 * spec, 0, 255).astype(np.uint8)
    out_b = np.clip(bb * shade + rb * fresnel + 255.0 * spec, 0, 255).astype(np.uint8)

    dist = np.sqrt(r2) * float(r)
    alpha = np.clip((float(r) + 0.6 - dist) * 255.0, 0, 255).astype(np.uint8)
    rgba = np.dstack([out_r, out_g, out_b, alpha])
    return Image.fromarray(rgba, mode="RGBA")


@lru_cache(maxsize=64)
def make_shaded_3d_cylinder(
    width_px: int,
    height_px: int,
    cap_ry: int,
    body_rgb: tuple[int, int, int],
    top_rgb: tuple[int, int, int],
    rim_rgb: tuple[int, int, int] = (255, 255, 255),
    metallic: float = 0.75,
) -> Image.Image:
    w = max(16, int(width_px))
    h = max(20, int(height_px))
    ry = max(6, int(cap_ry))
    total_h = h + ry * 2 + 6
    canvas = Image.new("RGBA", (w + 8, total_h), (0, 0, 0, 0))

    xx = np.linspace(-1.0, 1.0, w, dtype=np.float32)[None, :]
    yy = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None]
    nz = np.sqrt(np.maximum(0.0, 1.0 - xx * xx))

    ndotl = np.maximum(0.0, xx * (-0.48) + nz * 0.86)
    spec = (np.maximum(0.0, np.cos((xx + 0.30) * 2.2)) ** 18.0) * metallic
    fresnel = ((1.0 - nz) ** 2.2) * 0.45

    br, bg, bb = body_rgb
    rr, rg, rb = rim_rgb
    v_grad = 1.0 - 0.14 * yy

    r_ch = np.clip((br * (0.28 + 0.72 * ndotl) + rr * fresnel + 255.0 * spec) * v_grad, 0, 255).astype(np.uint8)
    g_ch = np.clip((bg * (0.28 + 0.72 * ndotl) + rg * fresnel + 255.0 * spec) * v_grad, 0, 255).astype(np.uint8)
    b_ch = np.clip((bb * (0.28 + 0.72 * ndotl) + rb * fresnel + 255.0 * spec) * v_grad, 0, 255).astype(np.uint8)
    a_ch = np.full((h, w), 255, dtype=np.uint8)

    body_img = Image.fromarray(np.dstack([r_ch, g_ch, b_ch, a_ch]), mode="RGBA")
    canvas.paste(body_img, (4, ry + 2))

    d = ImageDraw.Draw(canvas)
    d.ellipse([4, h + 2, 4 + w - 1, h + 2 + ry * 2], fill=(*body_rgb, 255))
    d.ellipse([4, 2, 4 + w - 1, 2 + ry * 2], fill=(*top_rgb, 255), outline=(*rim_rgb, 220), width=2)
    return canvas


def paste_3d_sphere(
    base_img: Image.Image,
    cx: float,
    cy: float,
    radius: int,
    base_rgb: tuple[int, int, int],
    rim_rgb: tuple[int, int, int] = (255, 255, 255),
    light_angle_deg: int = -35,
):
    q_ang = int(round(light_angle_deg / 15.0) * 15)
    sp = make_shaded_3d_sphere(max(3, int(round(radius))), base_rgb, rim_rgb, light_angle_deg=q_ang)
    px = int(round(cx - sp.width * 0.5))
    py = int(round(cy - sp.height * 0.5))
    base_img.paste(sp, (px, py), sp)


def draw_3d_tube_segment(
    base_img: Image.Image,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    r1: float,
    r2: float,
    base_rgb: tuple[int, int, int],
    rim_rgb: tuple[int, int, int],
    steps: int = 18,
    light_angle_deg: int = -35,
):
    """
    Point 1 & Point 3 Upgrade:
    Renders a smooth, continuous 3D Blinn-Phong tapered cylinder/axon tube (zero beaded pearl artifacts)
    using multi-layered cylindrical shading quads + spherical end-caps.
    """
    dx = float(x2 - x1)
    dy = float(y2 - y1)
    dist = math.hypot(dx, dy)
    if dist < 1.0:
        paste_3d_sphere(base_img, x1, y1, max(3, int(r1)), base_rgb, rim_rgb, light_angle_deg=light_angle_deg)
        return

    nx = -dy / dist
    ny = dx / dist
    rad_a = max(2.5, float(r1))
    rad_b = max(2.0, float(r2))

    # Shift specular ridge slightly toward light source
    ang_rad = math.radians(float(light_angle_deg))
    light_bias = 0.24 * math.sin(ang_rad)

    d = ImageDraw.Draw(base_img, "RGBA")
    br, bg, bb = base_rgb
    rr, rg, rb = rim_rgb

    def _quad(scale_w: float, offset_n: float, col_rgba: tuple[int, int, int, int]):
        sa = rad_a * scale_w
        sb = rad_b * scale_w
        oa_x, oa_y = nx * rad_a * offset_n, ny * rad_a * offset_n
        ob_x, ob_y = nx * rad_b * offset_n, ny * rad_b * offset_n
        p1 = (x1 + oa_x + nx * sa, y1 + oa_y + ny * sa)
        p2 = (x2 + ob_x + nx * sb, y2 + ob_y + ny * sb)
        p3 = (x2 + ob_x - nx * sb, y2 + ob_y - ny * sb)
        p4 = (x1 + oa_x - nx * sa, y1 + oa_y - ny * sa)
        d.polygon([p1, p2, p3, p4], fill=col_rgba)

    # Layer 1: Outer ambient shadow cylinder edge
    _quad(1.00, 0.0, (max(0, int(br * 0.42)), max(0, int(bg * 0.45)), max(0, int(bb * 0.50)), 245))
    # Layer 2: Main diffuse 3D tube body
    _quad(0.80, light_bias * 0.35, (br, bg, bb, 255))
    # Layer 3: Lit cylindrical mid-ridge
    _quad(
        0.48,
        light_bias * 0.75,
        (
            min(255, int(br * 0.55 + rr * 0.45)),
            min(255, int(bg * 0.55 + rg * 0.45)),
            min(255, int(bb * 0.55 + rb * 0.45)),
            240,
        ),
    )
    # Layer 4: Glossy Blinn-Phong specular core highlight
    _quad(0.20, light_bias * 1.05, (min(255, rr + 20), min(255, rg + 20), min(255, rb + 20), 215))

    # Smooth spherical joints at ends
    paste_3d_sphere(base_img, x1, y1, max(3, int(round(rad_a * 0.92))), base_rgb, rim_rgb, light_angle_deg=light_angle_deg)
    paste_3d_sphere(base_img, x2, y2, max(3, int(round(rad_b * 0.92))), base_rgb, rim_rgb, light_angle_deg=light_angle_deg)


def draw_3d_extruded_box(
    draw,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    dx: int,
    dy: int,
    front_rgb: tuple[int, int, int],
    top_rgb: tuple[int, int, int],
    side_rgb: tuple[int, int, int],
    edge_rgb: tuple[int, int, int],
):
    draw.polygon(
        [(x0 + 10, y1 + 14), (x1 + 10, y1 + 14), (x1 + dx + 12, y1 + dy + 14), (x0 + dx + 12, y1 + dy + 14)],
        fill=(0, 0, 0, 48),
    )
    draw.polygon(
        [(x0, y0), (x1, y0), (x1 + dx, y0 + dy), (x0 + dx, y0 + dy)],
        fill=(*top_rgb, 255),
        outline=(*edge_rgb, 255),
    )
    draw.polygon(
        [(x1, y0), (x1 + dx, y0 + dy), (x1 + dx, y1 + dy), (x1, y1)],
        fill=(*side_rgb, 255),
        outline=(*edge_rgb, 255),
    )
    draw.rectangle([x0, y0, x1, y1], fill=(*front_rgb, 255), outline=(*edge_rgb, 255), width=3)


def format_animated_metric(raw_metric: str, progress: float) -> str:
    s = sanitize_text(str(raw_metric)).strip()
    m = re.match(r"^([^\d]*)(\d+(?:[.,]\d+)?)(.*)$", s)
    if not m:
        return s
    prefix, num_str, suffix = m.groups()
    try:
        val = float(num_str.replace(",", "."))
        cur = val * ease_out_cubic(progress)
        if "." in num_str or "," in num_str:
            sep = "," if "," in num_str else "."
            formatted = f"{cur:.1f}".replace(".", sep)
        else:
            formatted = str(int(round(cur)))
        return f"{prefix}{formatted}{suffix}"
    except Exception:
        return s


def smart_truncate_words(text: str, max_chars: int = 44) -> str:
    s = sanitize_text(str(text or "")).strip()
    if len(s) <= max_chars:
        return s
    cut = s[:max_chars].rsplit(" ", 1)[0].rstrip(",.;:-")
    return cut if len(cut) >= max(8, max_chars // 2) else s[:max_chars].rstrip(",.;:-")


def build_contextual_window_lines(scene: dict, idx: int) -> list[str]:
    custom = scene.get("windowContentLines")
    if isinstance(custom, list) and len(custom) >= 2:
        return [smart_truncate_words(str(x), 48) for x in custom[:4]]
    headline = sanitize_text(scene.get("headline", ""))
    subcopy = sanitize_text(scene.get("subcopy", ""))
    narration = sanitize_text(scene.get("narration", ""))
    metric = sanitize_text(str(scene.get("metric", "")))
    unit = sanitize_text(str(scene.get("unit", "")))
    step_lbl = sanitize_text(str(scene.get("mechanismStep") or scene.get("stateBadge") or f"Tahap 0{idx + 1}")).replace("-", " ").title()
    callouts = scene.get("callouts") or []
    callout_names = []
    for c_it in callouts[:3]:
        if isinstance(c_it, dict) and c_it.get("label"):
            callout_names.append(sanitize_text(c_it["label"]))
        elif isinstance(c_it, (list, tuple)) and len(c_it) > 0:
            callout_names.append(sanitize_text(str(c_it[0])))
    lines = []
    metric_val = f"{metric} {unit}".strip()
    if metric_val:
        lines.append(f"Parameter Uji: {smart_truncate_words(metric_val, 32)}")
    else:
        lines.append(f"Fokus Tahap: {smart_truncate_words(step_lbl, 32)}")
    if callout_names:
        lines.append(f"Komponen Aktif: {smart_truncate_words(' -> '.join(callout_names), 34)}")
    elif headline:
        lines.append(f"Mekanisme: {smart_truncate_words(headline, 34)}")
    detail_src = subcopy if (subcopy and subcopy.lower() != headline.lower()) else narration
    if detail_src:
        clauses = [c.strip() for c in re.split(r"[.!?;]", detail_src) if len(c.strip()) > 6]
        chosen = clauses[-1] if len(clauses) > 1 else clauses[0] if clauses else detail_src
        lines.append(f"Bukti Kerja: {smart_truncate_words(chosen, 36)}")
    else:
        lines.append(f"Alur Kerja: {smart_truncate_words(headline or ' Sinkronisasi sistem terukur', 36)}")
    return lines[:4]


# ============================================================================
# SECTION 3.1: TRUE 6+ WORLD MODULAR THEMING SYSTEM
# ============================================================================

STYLE_TO_WORLD_BG = {
    "cream-editorial": "cream-editorial",
    "ref5-editorial-cutaway": "cream-editorial",
    "editorial-cutaway": "cream-editorial",
    "coffee-editorial": "coffee-editorial",
    "coffee-editorial-3d": "coffee-editorial",
    "ink-press-vertical": "warm-paper",
    "vox-explainer": "vox-grid",
    "charcoal-terminal": "charcoal-terminal",
    "ref1-tutorial-deck": "charcoal-terminal",
    "fireship-kinetic": "cyber-neon",
    "cosmic-glass": "cosmic-glass",
    "ref2-floating-glass": "cosmic-glass",
    "luxury-editorial-glass": "gold-luxury",
    "speed-pulse": "crimson-velocity",
    "cutaway-turbofan": "sapphire-blueprint",
    "wave-interference": "violet-quantum",
    "energy-waves": "cyan-plasma",
    "audio-reactive-rings": "magenta-sonic",
    "supercomputer-core": "emerald-matrix",
    "3d-isometric-growth": "teal-architect",
    "stress-heatmap": "thermal-inferno",
    "deconstructed-ui": "indigo-glass",
    "dual-device-showreel": "slate-studio",
    "gear-train-cutaway": "amber-forge",
    "optical-ray-cutaway": "prism-dark",
    "bio-pulse-flow": "crimson-bio",
    "matrix-bit-decoder": "emerald-matrix",
    "node-network": "sapphire-blueprint",
    "algorithm-stepper": "indigo-glass",
    "hud-terminal-neural": "cyber-neon",
    "retro-crt-shader": "crt-phosphor",
    "liquid-metaballs": "violet-quantum",
    "saas-product-launch": "slate-studio",
    "ref3-pricing-voxel": "indigo-glass",
    "single-line-relay": "cream-editorial",
    "halftone-eye-anchor": "warm-paper",
    "narrated-phrase-sync": "indigo-glass",
    "timeline-camera-flight": "cosmic-glass",
    "chronicle-morph": "cream-editorial",
    "physics-pill-drop": "slate-studio",
    "deterministic-stepper": "charcoal-terminal",
    "mascot-story": "tape-mascot",
    "kaca-gelap": "cosmic-glass",
    "arang-lime": "charcoal-terminal",
    "futuristic": "cyber-neon",
    "rts-modern": "gold-luxury",
    "sci-fi": "sapphire-blueprint",
    "paper-motion": "vox-grid",
    "minimalism": "vox-grid",
    "roman-empire": "warm-paper",
    "variety-show": "cream-editorial",
    "blocks": "vox-grid",
    "y2k-desktop": "sapphire-blueprint",
    "y2k-glam-pop": "magenta-sonic",
    "retro-arcade": "crt-phosphor",
    "pop-magazine": "cream-editorial",
    "comic-book": "warm-paper",
    "kolase-kertas": "warm-paper",
    "doodle-art": "warm-paper",
    "sketch-art": "vox-grid",
    "coffee-lofi": "coffee-editorial",
    "kertas-tipografi": "warm-paper",
    "caption-news": "charcoal-terminal",
    "live-countdown-grid": "cyber-neon",
    "visual-investigation": "warm-paper",
    "constructivist-montage": "warm-paper",
    "sports-telestrator": "emerald-matrix",
    "broadcast-news-package": "sapphire-blueprint",
    "satellite-briefing": "sapphire-blueprint",
    "engineering-briefing-board": "slate-studio",
    "lidar-survey": "emerald-matrix",
    "data-physicalization": "amber-forge",
    "exploded-teardown": "sapphire-blueprint",
    "microscope-story": "cyan-plasma",
    "archive-light-table": "gold-luxury",
    "whiteboard-explainer": "vox-grid",
    "watercolor-brush": "cream-editorial",
    "chinese-ink-wash": "warm-paper",
    "ukiyo-e": "warm-paper",
    "papercut-lightbox": "amber-forge",
    "risograph-print": "cream-editorial",
    "halftone-dossier": "warm-paper",
    "swiss-motion-grid": "vox-grid",
    "material-grid-3d": "slate-studio",
    "onetake-fluid-flow": "cyan-plasma",
    "dribbble-cursor-launch": "indigo-glass",
    "motionmaxxing-kinetic": "crimson-velocity",
    "explainroo-fast": "teal-architect",
    "blueprint-patent": "sapphire-blueprint",
    "pictogram-motion": "vox-grid",
    "data-storytelling": "charcoal-terminal",
    "isometric-infographic": "teal-architect",
    "dark-tech-keynote": "indigo-glass",
    "chat-message-story": "slate-studio",
    "manim-3b1b-math": "dark-science",
    "kurzgesagt-flat-cosmos": "cosmic-glass",
    "khan-blackboard-pen": "charcoal-terminal",
    "git-commit-tree": "charcoal-terminal",
    "arxiv-paper-breakdown": "warm-paper",
    "zackd-curiosity-3d": "sapphire-blueprint",
    "typewriter-vscode": "charcoal-terminal",
    "map-globe-route": "sapphire-blueprint",
    "live-panel-architecture": "emerald-matrix",
    "diary-comic-wipes": "warm-paper",
    "crayon-picture-book": "cream-editorial",
    "impasto-oil-canvas": "gold-luxury",
    "shadow-puppetry-stage": "amber-forge",
    "woodcut-copperplate": "warm-paper",
    "silkscreen-travel-poster": "cream-editorial",
    "stained-glass-cathedral": "prism-dark",
    "art-deco-golden": "gold-luxury",
    "spy-60s-title": "crimson-velocity",
    "rubber-hose-1930s": "warm-paper",
    "cel-anime-80s": "magenta-sonic",
    "pixel-rpg-16bit": "indigo-glass",
    "hd-2d-diorama": "amber-forge",
    "game-show-rhythm": "violet-quantum",
    "silent-film-1920s": "charcoal-terminal",
    "liminal-vhs-footage": "crt-phosphor",
    "brick-toy-lego": "vox-grid",
    "paper-popup-book": "cream-editorial",
    "podcast-audiogram-wave": "magenta-sonic",
    "reddit-thread-story": "charcoal-terminal",
    "vocaloid-lyric-mv": "violet-quantum",
    "appstore-device-showcase": "indigo-glass",
    "ai-presenter-studio": "slate-studio",
}


def normalize_scene_schema(scene: dict) -> dict:
    """Normalizes both snake_case and camelCase scene keys so smart_render never falls back to defaults."""
    if not isinstance(scene, dict):
        return {}
    sc = dict(scene)
    if not sc.get("visualMode"):
        sc["visualMode"] = sc.get("visual_style") or sc.get("style") or sc.get("mode") or "ref5-editorial-cutaway"
    if not sc.get("headline"):
        sc["headline"] = sc.get("title") or sc.get("heading") or "Bedah Cara Kerja & Fakta Ilmiah"
    if not sc.get("subcopy"):
        sc["subcopy"] = sc.get("subtitle") or sc.get("description") or sc.get("narration") or ""
    if not sc.get("narration") and sc.get("subcopy"):
        sc["narration"] = sc["subcopy"]
    if not sc.get("eyebrow"):
        sc["eyebrow"] = sc.get("kicker") or sc.get("badge") or sc.get("category") or ""
    if not sc.get("captionStyle"):
        sc["captionStyle"] = sc.get("caption_style") or sc.get("captionPreset") or ""
    if not sc.get("archetype"):
        sc["archetype"] = sc.get("talking_head_archetype") or sc.get("archetypeKind") or ""
    if not sc.get("cameraPreset"):
        sc["cameraPreset"] = sc.get("camera_preset") or sc.get("camera") or ""
    if not sc.get("cutawayKind") and sc.get("cutaway_kind"):
        sc["cutawayKind"] = sc.get("cutaway_kind")
    if not sc.get("windowContentLines") and sc.get("lines"):
        sc["windowContentLines"] = sc.get("lines")
    return sc


@lru_cache(maxsize=16)
def _load_bundled_world_texture(filename: str, width: int, height: int) -> np.ndarray | None:
    try:
        tex_p = Path(__file__).resolve().parent.parent / "assets" / "images" / filename
        if tex_p.is_file():
            im = Image.open(tex_p).convert("RGB").resize((width, height), Image.Resampling.BILINEAR)
            return np.asarray(im, dtype=np.float32)
    except Exception:
        pass
    return None


def _blend_world_texture(base: Image.Image, filename: str, alpha: float = 0.14) -> Image.Image:
    tex = _load_bundled_world_texture(filename, base.width, base.height)
    if tex is None:
        return base
    arr = np.asarray(base, dtype=np.float32)
    mixed = np.clip(arr * (1.0 - alpha) + tex * alpha, 0, 255).astype(np.uint8)
    return Image.fromarray(mixed, mode="RGB")


@lru_cache(maxsize=64)
def build_world_background(width: int, height: int, world_kind: str, accent_hex: str, scene_idx: int) -> Image.Image:
    ar, ag, ab = hex_to_rgb(accent_hex)

    if world_kind == "cream-editorial":
        base = Image.new("RGB", (width, height), (242, 237, 224))
        draw = FastRGBDraw(base, bg=(242, 237, 224))
        for y in range(1180, 1650, 70):
            draw.line([(60, y), (width - 60, y + 25)], fill=(224, 217, 200, 140), width=2)
        for x in range(120, width - 80, 160):
            draw.line([(x, 1180), (x - 90, 1650)], fill=(224, 217, 200, 110), width=2)
        return _blend_world_texture(base, "cream_cutaway_9x16.png", 0.14)

    if world_kind == "coffee-editorial":
        base = Image.new("RGB", (width, height), (246, 239, 228))
        draw = FastRGBDraw(base, bg=(246, 239, 228))
        for rad, alpha in ((340, 16), (220, 26)):
            draw.ellipse([480 - rad, 950 - rad, 480 + rad, 950 + rad], fill=(180, 83, 9, alpha))
        for y in range(1180, 1650, 68):
            draw.line([(60, y), (width - 60, y + 20)], fill=(218, 202, 182, 145), width=2)
        return _blend_world_texture(base, "coffee_editorial_9x16.png", 0.16)

    if world_kind == "charcoal-terminal":
        base = Image.new("RGB", (width, height), (18, 18, 16))
        draw = FastRGBDraw(base, bg=(18, 18, 16))
        for x in range(84, 880, 42):
            for y in range(210, 1500, 42):
                draw.rectangle([x, y, x + 2, y + 2], fill=(255, 255, 255, 28))
        for rad, alpha in ((340, 18), (240, 30), (150, 44)):
            draw.ellipse([480 - rad, 640 - rad, 480 + rad, 640 + rad], fill=(217, 119, 87, alpha))
        return _blend_world_texture(base, "cyber_terminal_9x16.png", 0.16)

    if world_kind == "cosmic-glass":
        base = Image.new("RGB", (width, height), (19, 13, 38))
        draw = FastRGBDraw(base, bg=(19, 13, 38))
        for rad, alpha in ((360, 22), (250, 38), (150, 56)):
            draw.ellipse([360 - rad, 520 - rad, 360 + rad, 520 + rad], fill=(236, 72, 153, alpha))
            draw.ellipse([600 - rad, 780 - rad, 600 + rad, 780 + rad], fill=(56, 189, 248, alpha))
        return base

    if world_kind == "tape-mascot":
        base = Image.new("RGB", (width, height), (24, 22, 20))
        draw = FastRGBDraw(base, bg=(24, 22, 20))
        for y in range(200, 1520, 48):
            draw.line([(84, y), (876, y)], fill=(255, 255, 255, 10), width=1)
        return base

    if world_kind == "cyber-neon":
        base = Image.new("RGB", (width, height), (6, 8, 18))
        draw = FastRGBDraw(base, bg=(6, 8, 18))
        for y in range(180, 1600, 36):
            draw.line([(60, y), (width - 60, y)], fill=(0, 245, 212, 16), width=1)
        for x in range(60, width - 40, 72):
            draw.line([(x, 180), (x, 1600)], fill=(236, 72, 153, 14), width=1)
        return base

    if world_kind == "warm-paper":
        base = Image.new("RGB", (width, height), (244, 236, 216))
        draw = FastRGBDraw(base, bg=(244, 236, 216))
        for y in range(200, 1680, 44):
            draw.line([(64, y), (width - 64, y)], fill=(208, 192, 164, 135), width=2)
        for x in (140, width - 140):
            draw.line([(x, 180), (x, 1720)], fill=(185, 68, 42, 95), width=3)
        return base

    if world_kind == "vox-grid":
        base = Image.new("RGB", (width, height), (238, 242, 235))
        draw = FastRGBDraw(base, bg=(238, 242, 235))
        for x in range(60, width - 40, 48):
            draw.line([(x, 160), (x, 1720)], fill=(180, 196, 178, 110), width=1)
        for y in range(160, 1720, 48):
            draw.line([(60, y), (width - 60, y)], fill=(180, 196, 178, 110), width=1)
        draw.rectangle([72, 200, width - 72, 214], fill=(250, 204, 21, 220))
        return base

    _SPECIAL_DARK_WORLDS = {
        "gold-luxury": ((24, 18, 10), (245, 158, 11), (217, 119, 6), "diag"),
        "crimson-velocity": ((26, 8, 14), (244, 63, 94), (251, 113, 133), "speed"),
        "sapphire-blueprint": ((7, 18, 38), (56, 189, 248), (37, 99, 235), "blueprint"),
        "violet-quantum": ((18, 10, 36), (168, 85, 247), (236, 72, 153), "rings"),
        "cyan-plasma": ((6, 22, 30), (6, 182, 212), (16, 185, 129), "waves"),
        "magenta-sonic": ((28, 9, 28), (236, 72, 153), (168, 85, 247), "rings"),
        "emerald-matrix": ((5, 20, 14), (16, 185, 129), (52, 211, 153), "matrix"),
        "teal-architect": ((8, 24, 28), (20, 184, 166), (56, 189, 248), "iso"),
        "thermal-inferno": ((28, 12, 8), (239, 68, 68), (245, 158, 11), "rings"),
        "indigo-glass": ((12, 14, 34), (99, 102, 241), (56, 189, 248), "diag"),
        "slate-studio": ((15, 23, 34), (148, 163, 184), (56, 189, 248), "blueprint"),
        "amber-forge": ((26, 16, 8), (245, 158, 11), (234, 88, 12), "rings"),
        "prism-dark": ((10, 12, 24), (239, 68, 68), (56, 189, 248), "diag"),
        "crimson-bio": ((26, 8, 16), (244, 63, 94), (16, 185, 129), "waves"),
        "crt-phosphor": ((6, 16, 10), (34, 197, 94), (16, 185, 129), "scanline"),
    }
    if world_kind in _SPECIAL_DARK_WORLDS:
        bg_rgb, c1, c2, pat = _SPECIAL_DARK_WORLDS[world_kind]
        yy = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
        xx = np.linspace(0.0, 1.0, width, dtype=np.float32)[None, :]
        r1 = np.exp(-3.0 * ((xx - 0.35) ** 2 + (yy - 0.32) ** 2))
        r2 = np.exp(-3.0 * ((xx - 0.68) ** 2 + (yy - 0.62) ** 2))
        r_ch = np.clip(bg_rgb[0] + c1[0] * 0.26 * r1 + c2[0] * 0.20 * r2, 0, 255).astype(np.uint8)
        g_ch = np.clip(bg_rgb[1] + c1[1] * 0.26 * r1 + c2[1] * 0.20 * r2, 0, 255).astype(np.uint8)
        b_ch = np.clip(bg_rgb[2] + c1[2] * 0.26 * r1 + c2[2] * 0.20 * r2, 0, 255).astype(np.uint8)
        base = Image.fromarray(np.dstack([r_ch, g_ch, b_ch]), mode="RGB")
        draw = FastRGBDraw(base, bg=bg_rgb)
        if pat == "blueprint":
            for x in range(72, width - 60, 48):
                draw.line([(x, 180), (x, 1620)], fill=(*c1, 24), width=1)
            for y in range(180, 1620, 48):
                draw.line([(72, y), (width - 72, y)], fill=(*c1, 24), width=1)
        elif pat == "rings":
            for rad in (140, 230, 320, 410):
                draw.ellipse([480 - rad, 595 - rad, 480 + rad, 595 + rad], outline=(*c1, 34), width=2)
        elif pat == "diag":
            for d_i in range(-600, 1600, 72):
                draw.line([(72, d_i), (width - 72, d_i + 420)], fill=(*c1, 22), width=2)
        elif pat == "speed":
            for y in range(220, 1520, 56):
                draw.line([(60, y), (width - 60, y - 35)], fill=(*c1, 32), width=3)
        elif pat == "matrix":
            for x in range(84, width - 84, 52):
                for y in range(200, 1520, 64):
                    draw.rectangle([x, y, x + 6, y + 18], fill=(*c1, 28))
        elif pat == "iso":
            for y in range(220, 1520, 64):
                draw.line([(84, y), (width - 84, y + 140)], fill=(*c1, 24), width=1)
                draw.line([(84, y + 140), (width - 84, y)], fill=(*c2, 24), width=1)
        elif pat == "scanline":
            for y in range(160, 1720, 8):
                draw.line([(0, y), (width, y)], fill=(0, 0, 0, 95), width=2)
        return base

    # Default 6th world: dark-science with multi-stop gradient mapping + deep atmospheric nebula
    yy = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
    xx = np.linspace(0.0, 1.0, width, dtype=np.float32)[None, :]
    radial = np.exp(-2.8 * ((xx - 0.5) ** 2 + (yy - 0.34) ** 2))
    r_ch = np.clip(6.0 + 12.0 * (1.0 - yy) + ar * 0.22 * radial, 0, 255).astype(np.uint8)
    g_ch = np.clip(10.0 + 18.0 * (1.0 - yy) + ag * 0.22 * radial, 0, 255).astype(np.uint8)
    b_ch = np.clip(22.0 + 28.0 * (1.0 - yy) + ab * 0.25 * radial, 0, 255).astype(np.uint8)
    base = Image.fromarray(np.dstack([r_ch, g_ch, b_ch]), mode="RGB")
    draw = FastRGBDraw(base, bg=(9, 13, 22))
    step = 54
    for x in range(84, 880, step):
        draw.line([(x, 200), (x, 1520)], fill=(ar, ag, ab, 18), width=1)
    for y in range(200, 1520, step):
        draw.line([(84, y), (880, y)], fill=(ar, ag, ab, 16), width=1)
    cx, cy = 480, 595
    for rad, alpha in ((380, 18), (280, 30), (195, 44), (115, 62)):
        draw.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=(ar, ag, ab, alpha))
    return _blend_world_texture(base, "neural_nebula_9x16.png", 0.18)


def draw_check_badge(draw, x: int, y: int, r: int, accent_rgb: tuple[int, int, int], scale: float = 1.0, light_bg: bool = False):
    if scale <= 0.05:
        return
    rs = max(4, int(round(r * scale)))
    cx, cy = x + r, y + r
    draw.ellipse([cx - rs, cy - rs, cx + rs, cy + rs], fill=(*accent_rgb, 45 if light_bg else 55), outline=(*accent_rgb, 255), width=2)
    if rs >= 8:
        fg = (*accent_rgb, 255) if light_bg else (248, 250, 252, 255)
        draw.line(
            [(cx - int(rs * 0.45), cy), (cx - int(rs * 0.1), cy + int(rs * 0.38)), (cx + int(rs * 0.5), cy - int(rs * 0.38))],
            fill=fg,
            width=3,
        )


# ============================================================================
# SECTION 2: SEMANTIC CAPTION GROUPING, INLINE EMOJI ICONS, SPEAKER LABELS,
# COLLISION DETECTION & 7 CAPTION STYLES
# ============================================================================

def draw_inline_emoji_icon(draw, emoji_char: str, cx: int, cy: int, size: int = 28):
    """
    Section 2.5:
    Draws crisp colorful vector icons inline for 🎯, 💡, 🔥, 📊, ⚡, ⚠️, ✅, ☕, 🧠, ⚙️
    so captions always have vibrant visual reinforcement without relying on OS color emoji fonts.
    """
    r = size // 2
    if emoji_char == "🎯":
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(239, 68, 68, 255), outline=(255, 255, 255, 255), width=2)
        draw.ellipse([cx - int(r * 0.6), cy - int(r * 0.6), cx + int(r * 0.6), cy + int(r * 0.6)], fill=(255, 255, 255, 255))
        draw.ellipse([cx - int(r * 0.28), cy - int(r * 0.28), cx + int(r * 0.28), cy + int(r * 0.28)], fill=(239, 68, 68, 255))
    elif emoji_char == "💡":
        draw.ellipse([cx - int(r * 0.8), cy - r, cx + int(r * 0.8), cy + int(r * 0.5)], fill=(250, 204, 21, 255), outline=(254, 240, 138, 255), width=2)
        draw.rectangle([cx - int(r * 0.4), cy + int(r * 0.45), cx + int(r * 0.4), cy + r], fill=(148, 163, 184, 255))
    elif emoji_char == "🔥":
        draw.polygon([(cx, cy - r), (cx + int(r * 0.85), cy + int(r * 0.35)), (cx, cy + r), (cx - int(r * 0.85), cy + int(r * 0.35))], fill=(249, 115, 22, 255))
        draw.ellipse([cx - int(r * 0.45), cy - int(r * 0.1), cx + int(r * 0.45), cy + int(r * 0.85)], fill=(250, 204, 21, 255))
    elif emoji_char == "📊":
        draw.rectangle([cx - r + 2, cy + 2, cx - int(r * 0.35), cy + r], fill=(56, 189, 248, 255))
        draw.rectangle([cx - int(r * 0.2), cy - int(r * 0.45), cx + int(r * 0.25), cy + r], fill=(250, 204, 21, 255))
        draw.rectangle([cx + int(r * 0.4), cy - r, cx + r - 2, cy + r], fill=(16, 185, 129, 255))
    elif emoji_char in ("⚡", "⚠️"):
        draw.polygon([(cx + 2, cy - r), (cx - int(r * 0.7), cy + 2), (cx, cy + 2), (cx - 3, cy + r), (cx + int(r * 0.75), cy - 2), (cx + 1, cy - 2)], fill=(250, 204, 21, 255))
    else:
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(16, 185, 129, 255), outline=(255, 255, 255, 255), width=2)
        draw.line([(cx - int(r * 0.45), cy), (cx - 2, cy + int(r * 0.4)), (cx + int(r * 0.5), cy - int(r * 0.35))], fill=(255, 255, 255, 255), width=3)


def group_words_semantically(words: list[str], max_words_per_row: int = 3) -> list[list[tuple[int, str]]]:
    """
    Section 2.2:
    Semantic Caption Grouping:
    Groups indexed words into balanced rows (typically 2-4 words per row, 2 rows per window)
    while NEVER splitting:
    - Indonesian compound negations/phrases ("tidak boleh", "jangan pernah", "sama sekali", "di dalam", etc.)
    - Number + unit pairs ("86 MILIAR", "92 °C", "400 KM/JAM", "14 KALI", "20 WATT", "Rp 50")
    - Clause punctuation boundaries (breaks naturally after commas/periods/questions).
    """
    if not words:
        return []

    n = len(words)
    # Build atomic semantic units first (pairs that must stay together)
    units = []
    i = 0
    while i < n:
        w_cur = words[i]
        w_low = re.sub(r"[^\w%/°]", "", w_cur.lower())
        if i + 1 < n:
            w_next = words[i + 1]
            w_next_low = re.sub(r"[^\w%/°]", "", w_next.lower())
            is_compound = (w_low, w_next_low) in _ID_COMPOUND_PHRASES
            is_num_unit = (any(ch.isdigit() for ch in w_cur) and w_next_low in _METRIC_UNITS) or (
                w_low in ("rp", "±", "+-") and any(ch.isdigit() for ch in w_next)
            )
            if (is_compound or is_num_unit) and not any(p in w_cur for p in (",", ".", "!", "?", ";", ":")):
                units.append([(i, w_cur), (i + 1, w_next)])
                i += 2
                continue
        units.append([(i, w_cur)])
        i += 1

    rows = []
    cur_row = []
    for u_items in units:
        if len(cur_row) + len(u_items) > max_words_per_row and cur_row:
            rows.append(cur_row)
            cur_row = list(u_items)
        else:
            cur_row.extend(u_items)
        # Break row naturally after clause punctuation
        last_w = cur_row[-1][1]
        if any(last_w.endswith(p) for p in (",", ".", "!", "?", ":", ";")) and len(cur_row) >= 2:
            rows.append(cur_row)
            cur_row = []
    if cur_row:
        rows.append(cur_row)
    return rows


def detect_caption_collision_and_adjust_y(scene: dict, default_y: int = 1335, height: int = 1920) -> int:
    """
    Section 2.3 & Quick Win #5 & #9:
    - Honors explicit `y_center` or `captionY` in scene manifest if provided.
    - Performs collision detection against 3D objects, callout badges, or lower-third cards occupying
      the bottom portion of the canvas, automatically shifting captions to a collision-free vertical slot
      that stays inside the mobile safe zone.
    """
    if scene.get("y_center") is not None:
        return int(scene["y_center"])
    if scene.get("captionY") is not None:
        return int(scene["captionY"])

    # Mobile safe zone: caption pill must stay above ~78% of canvas height (y <= 1490 at 1920).
    pill_h = max(40, int(height * 0.030))
    safe_bottom_y = int(height * 0.78) - pill_h  # center must be above this
    safe_top_y = int(height * 0.12) + pill_h      # center must be below this

    occupied_bboxes = scene.get("occupiedBboxes") or []
    mode = str(scene.get("visualMode", ""))
    callouts = scene.get("callouts") or []

    max_callout_py = 0
    for c in callouts:
        if isinstance(c, dict) and c.get("py"):
            max_callout_py = max(max_callout_py, int(c["py"]))
        elif isinstance(c, (list, tuple)) and len(c) >= 5:
            max_callout_py = max(max_callout_py, int(c[4]))

    bottom_band_threshold = int(height * 0.68)
    has_bottom_collision = (
        bool(scene.get("bottom3DOccupied"))
        or max_callout_py >= bottom_band_threshold
        or any(
            b[3] >= bottom_band_threshold and b[1] <= default_y + int(height * 0.06)
            for b in occupied_bboxes
            if len(b) == 4
        )
    )
    if has_bottom_collision:
        # Shift up into the safe gap; clamp within safe zone.
        upper_slot = int(height * 0.52)
        return min(max(safe_top_y, upper_slot), safe_bottom_y)

    if mode in ("ref4-tape-mascot", "mascot-story"):
        return min(max(safe_top_y, int(height * 0.68)), safe_bottom_y)

    # Default: keep caption within safe zone
    return min(max(safe_top_y, default_y), safe_bottom_y)



# ============================================================================
# ALIGHT MOTION XML & PREMIUM MOGRT CAPTION ENGINE (`Copy of Text Animation (1).xml` & `Copy of Text animation .xml`)
# ============================================================================
# Complete 33 Premium Text.rar Registry (2 Alight Motion XML files + 31 After Effects MOGRT files)
# Zero forced background boxes! Every preset renders free-standing typography with its authentic
# font family, gradient stops, bevel, long-shadow, softglow, CC Light Sweep, or custom MOGRT shape.
XML_CAPTION_PRESETS = {
    # --- FILE 1: Copy of Text Animation (1).xml (5 Alight Motion Text Layers) ---
    "xml-text1-gold-bevel": {
        "source_file": "Copy of Text Animation (1).xml — Text 1",
        "font_family": "barberchop",
        "font_size": 44,
        "stops": ["#FAE965", "#FADF0D", "#F4B446", "#FFA100"],
        "glow_rgb": (255, 168, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 24,
        "layout": "free",
    },
    "xml-text2-magenta-stroke": {
        "source_file": "Copy of Text Animation (1).xml — Text 2",
        "font_family": "roboto-bold",
        "font_size": 44,
        "stops": ["#DD44DD", "#FF77EE", "#FFFFFF", "#FF5566"],
        "glow_rgb": (255, 85, 102),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": (255, 255, 255),
        "stroke_w": 3,
        "shadow_angle_deg": 48,
        "shadow_dist": 8,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 28,
        "layout": "free",
    },
    "xml-text3-cobalt-cyan": {
        "source_file": "Copy of Text Animation (1).xml — Text 3",
        "font_family": "roboto-bold",
        "font_size": 44,
        "stops": ["#003796", "#0080FF", "#38BDF8", "#FFFFFF"],
        "glow_rgb": (255, 85, 102),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 8,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 28,
        "layout": "free",
    },
    "xml-text4-tactic-cyber": {
        "source_file": "Copy of Text Animation (1).xml — Text 4",
        "font_family": "tacticsans-bldit",
        "font_size": 42,
        "stops": ["#5EB7D9", "#5EB7D9", "#3B82F6", "#FF00FF"],
        "glow_rgb": (255, 168, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 45,
        "shadow_dist": 7,
        "shadow_rgb": (0, 255, 255),
        " shadow2_rgb": (255, 0, 255),
        "shimmer": False,
        "offset_y": 26,
        "layout": "free",
    },
    "xml-text5-purple-shimmer": {
        "source_file": "Copy of Text Animation (1).xml — Text 5 (embedScene)",
        "font_family": "triumvirate",
        "font_size": 46,
        "stops": ["#DD44DD", "#DD44DD", "#9333EA", "#540075"],
        "glow_rgb": (255, 168, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 26,
        "layout": "free",
    },
    # --- FILE 2: Copy of Text animation .xml ---
    "xml2-ridges-purple": {
        "source_file": "Copy of Text animation .xml",
        "font_family": "unifraktur",
        "font_size": 42,
        "stops": ["#C084FC", "#7D00FF", "#EC4899", "#FFFFFF"],
        "glow_rgb": (170, 0, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": (125, 0, 255),
        "stroke_w": 2,
        "shadow_angle_deg": 45,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": -25,
        "letter_spacing_px": 2,
        "layout": "free",
    },
    # --- FILES 3–33: ALL 31 AFTER EFFECTS MOGRT PRESETS FROM Premium Text.rar ---
    "mogrt-01-blur-fade-shine": {
        "source_file": "Copy of Blur Fade In WIth Shine.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FF6000", "#FF8533", "#FFFFFF", "#FF6000"],
        "glow_rgb": (255, 96, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 14,
        "layout": "blur-fade",
    },
    "mogrt-02-bounce-green": {
        "source_file": "Copy of Bounce.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#FFFFFF", "#E2F8E8", "#4ADE80", "#00FF1C"],
        "glow_rgb": (0, 255, 28),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 32,
        "layout": "bounce-two-tone",
    },
    "mogrt-03-broken-shatter": {
        "source_file": "Copy of Broken.mogrt",
        "font_family": "poppins-bold",
        "font_size": 44,
        "stops": ["#FF0000", "#FF3B3B", "#DC2626", "#FF6B6B"],
        "glow_rgb": (255, 0, 0),
        "bevel_rgb": (255, 200, 200),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 45,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 18,
        "layout": "broken-shatter",
    },
    "mogrt-04-cinematic-blur": {
        "source_file": "Copy of Cinematic Blur Animation.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FFFFFF", "#E0F2FE", "#BAE6FD", "#FFFFFF"],
        "glow_rgb": (255, 255, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 10,
        "layout": "blur-fade",
    },
    "mogrt-05-clean-apple": {
        "source_file": "Copy of Clean Apple.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 42,
        "stops": ["#FFFFFF", "#FFFFFF", "#F1F5F9", "#FFFFFF"],
        "glow_rgb": (255, 255, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 16,
        "layout": "free",
    },
    "mogrt-06-davin-jatho-1": {
        "source_file": "Copy of Davin Jatho text 1 by Creative Sparrow Graphics.mogrt",
        "font_family": "tacticsans-blk",
        "font_size": 44,
        "stops": ["#FF1E1E", "#FF4D4D", "#DC2626", "#FF1E1E"],
        "glow_rgb": (255, 0, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 24,
        "uppercase": True,
        "layout": "davin-split-red",
    },
    "mogrt-07-davin-jatho-2": {
        "source_file": "Copy of Davin Jatho text 2 by Creative Sparrow Graphics.mogrt",
        "font_family": "tacticsans-blk",
        "font_size": 44,
        "stops": ["#0ECA00", "#4ADE80", "#FFFFFF", "#0ECA00"],
        "glow_rgb": (14, 202, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 24,
        "uppercase": True,
        "layout": "davin-ghost-bg",
    },
    "mogrt-08-davin-jatho-3": {
        "source_file": "Copy of Davin Jatho text 3 by Creative Sparrow Graphics.mogrt",
        "font_family": "tacticsans-blk",
        "font_size": 44,
        "stops": ["#FFD800", "#FACC15", "#FFFFFF", "#FFD800"],
        "glow_rgb": (255, 216, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 24,
        "uppercase": True,
        "layout": "davin-ghost-xxxx",
    },
    "mogrt-09-devin-jatho-ult": {
        "source_file": "Copy of Devin Jatho.mogrt",
        "font_family": "tacticsans-ult",
        "font_size": 44,
        "stops": ["#0090FF", "#38BDF8", "#7DD3FC", "#0090FF"],
        "glow_rgb": (0, 144, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 20,
        "uppercase": True,
        "layout": "devin-silver-blue",
    },
    "mogrt-10-fast-wip": {
        "source_file": "Copy of Fast Wip Animation.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FFFFFF", "#F1F5F9", "#E2E8F0", "#FFFFFF"],
        "glow_rgb": (255, 255, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 0,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 12,
        "layout": "fast-wip",
    },
    "mogrt-11-fast-wip-shine": {
        "source_file": "Copy of Fast Wip Shine Animation.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FF6000", "#FF9A3C", "#FFFFFF", "#FF6000"],
        "glow_rgb": (255, 96, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 0,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 14,
        "layout": "fast-wip",
    },
    "mogrt-12-flicker-glowing": {
        "source_file": "Copy of Flicker Glowing.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 42,
        "stops": ["#FFDE00", "#FFF066", "#FACC15", "#FFDE00"],
        "glow_rgb": (255, 222, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 16,
        "layout": "flicker-glow",
    },
    "mogrt-13-flicker-shine": {
        "source_file": "Copy of Flicker Shine Effect.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FF6000", "#FF8533", "#FFFFFF", "#FF4500"],
        "glow_rgb": (255, 96, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 16,
        "layout": "flicker-glow",
    },
    "mogrt-14-gradient-amber": {
        "source_file": "Copy of Gradient.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#FFB000", "#FF9500", "#FF7B00", "#FFB000"],
        "glow_rgb": (255, 160, 0),
        "bevel_rgb": (255, 235, 180),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 18,
        "layout": "free",
    },
    "mogrt-15-hero-garamond": {
        "source_file": "Copy of Hero.mogrt",
        "font_family": "garamond-bolditalic",
        "font_size": 46,
        "stops": ["#FF00D6", "#A855F7", "#5400FF", "#EC4899"],
        "glow_rgb": (168, 85, 247),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 20,
        "layout": "hero-editorial",
    },
    "mogrt-16-regular-clean": {
        "source_file": "Copy of Regular Animation.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"],
        "glow_rgb": (255, 255, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 5,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 24,
        "layout": "free",
    },
    "mogrt-17-shadow-3d": {
        "source_file": "Copy of Shadow.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#FFE700", "#FACC15", "#AA9A00", "#FFE700"],
        "glow_rgb": (255, 231, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 9,
        "shadow_rgb": (170, 154, 0),
        "shimmer": True,
        "offset_y": 22,
        "layout": "shadow-sub",
    },
    "mogrt-18-shine-text": {
        "source_file": "Copy of Shine Text Effect.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FF6000", "#FF7F2A", "#FFFFFF", "#FF5500"],
        "glow_rgb": (255, 96, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 18,
        "layout": "free",
    },
    "mogrt-19-shiny-cyan": {
        "source_file": "Copy of Shiny.mogrt",
        "font_family": "inter-extrabold",
        "font_size": 44,
        "stops": ["#009FFC", "#38BDF8", "#FFFDF0", "#009FFC"],
        "glow_rgb": (0, 159, 252),
        "bevel_rgb": (255, 250, 240),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 18,
        "layout": "free",
    },
    "mogrt-20-sliding-lime": {
        "source_file": "Copy of Sliding.mogrt",
        "font_family": "times-bolditalic",
        "font_size": 46,
        "stops": ["#8CFF00", "#A3E635", "#FFFFFF", "#8CFF00"],
        "glow_rgb": (140, 255, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 18,
        "layout": "sliding-serif",
    },
    "mogrt-21-smooth-cross": {
        "source_file": "Copy of Smooth Cross.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#A855F7", "#C084FC", "#9500FF", "#D8B4FE"],
        "glow_rgb": (149, 0, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 18,
        "layout": "smooth-cross",
    },
    "mogrt-22-smooth-fade-bebas": {
        "source_file": "Copy of Smooth Fade.mogrt",
        "font_family": "bebas-bold",
        "font_size": 48,
        "stops": ["#FF4E00", "#EC4899", "#8800FF", "#FF4E00"],
        "glow_rgb": (236, 72, 153),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 16,
        "uppercase": True,
        "layout": "bebas-echo",
    },
    "mogrt-23-smooth-slide-teal": {
        "source_file": "Copy of Smooth Slide.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#00DBE1", "#00FF1C", "#FFFFFF", "#00DBE1"],
        "glow_rgb": (0, 219, 225),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 18,
        "layout": "smooth-cross",
    },
    "mogrt-24-super-trendy": {
        "source_file": "Copy of Super Trendy.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#FF6D00", "#FF9E00", "#F97316", "#FFB703"],
        "glow_rgb": (255, 109, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 20,
        "layout": "super-trendy",
    },
    "mogrt-25-trending-1-anton": {
        "source_file": "Copy of Trending Text Animation 1 by Creative Sparrow Graphics.mogrt",
        "font_family": "anton-regular",
        "font_size": 48,
        "stops": ["#007EFF", "#38BDF8", "#FF6600", "#FFFFFF"],
        "glow_rgb": (0, 126, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 24,
        "uppercase": True,
        "layout": "trending-script-combo",
    },
    "mogrt-26-trending-2-arthemis": {
        "source_file": "Copy of Trending Text Animation 2 by Creative Sparrow Graphics.mogrt",
        "font_family": "script-italic",
        "font_size": 46,
        "stops": ["#38BDF8", "#007EFF", "#FF6600", "#FFFFFF"],
        "glow_rgb": (0, 126, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 22,
        "layout": "trending-script-combo",
    },
    "mogrt-27-trending-3-proelium": {
        "source_file": "Copy of Trending Text Animation 3 by Creative Sparrow Graphics.mogrt",
        "font_family": "poppins-bold",
        "font_size": 46,
        "stops": ["#FF6600", "#FF0000", "#FFFFFF", "#FF6600"],
        "glow_rgb": (255, 0, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 7,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 24,
        "uppercase": True,
        "layout": "free",
    },
    "mogrt-28-viral-caption-1": {
        "source_file": "Copy of Viral Caption Style 1 Animation by Creative Sparrow Graphics.mogrt",
        "font_family": "inter-semibold",
        "font_size": 42,
        "stops": ["#FF0000", "#DC2626", "#FFFFFF", "#FF0000"],
        "glow_rgb": (255, 0, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 20,
        "layout": "viral-ribbon-1",
    },
    "mogrt-29-viral-caption-2": {
        "source_file": "Copy of Viral Caption Style 2 Animation by Creative Sparrow Graphics.mogrt",
        "font_family": "inter-black",
        "font_size": 44,
        "stops": ["#FFFFFF", "#FFFFFF", "#F8FAFC", "#FFFFFF"],
        "glow_rgb": (255, 0, 0),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": False,
        "offset_y": 20,
        "layout": "viral-loop-2",
    },
    "mogrt-30-white-bevel": {
        "source_file": "Copy of White.mogrt",
        "font_family": "helvetica-bold",
        "font_size": 44,
        "stops": ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"],
        "glow_rgb": (255, 255, 255),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 90,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 16,
        "layout": "free",
    },
    "mogrt-31-metallic-script": {
        "source_file": "Copy of metallic.mogrt",
        "font_family": "script-italic",
        "font_size": 48,
        "stops": ["#F8FAFC", "#FFFFFF", "#E2E8F0", "#FFFFFF"],
        "glow_rgb": (226, 232, 240),
        "bevel_rgb": (255, 255, 255),
        "stroke_rgb": None,
        "stroke_w": 0,
        "shadow_angle_deg": 48,
        "shadow_dist": 6,
        "shadow_rgb": (0, 0, 0),
        "shimmer": True,
        "offset_y": 16,
        "layout": "free",
    },
}

# Add backward-compatible aliases into XML_CAPTION_PRESETS so any legacy ID resolves to its exact 33-file spec
for _alias_k, _target_k in {
    "xml-4color-gold": "xml-text1-gold-bevel",
    "xml-magenta-stroke": "xml-text2-magenta-stroke",
    "xml-cyan-cobalt": "xml-text3-cobalt-cyan",
    "xml-cyber-longshadow": "xml-text4-tactic-cyber",
    "xml-purple-shimmer": "xml-text5-purple-shimmer",
    "xml-ridges-glow": "xml2-ridges-purple",
    "clean-apple": "mogrt-05-clean-apple",
    "viral-bounce": "mogrt-02-bounce-green",
    "cinematic-blur": "mogrt-04-cinematic-blur",
    "shiny-metallic": "mogrt-19-shiny-cyan",
}.items():
    XML_CAPTION_PRESETS[_alias_k] = XML_CAPTION_PRESETS[_target_k]


def _get_target_image_from_draw(draw) -> Image.Image | None:
    """Extract underlying PIL Image from FastRGBDraw or ImageDraw."""
    for attr in ("_img", "_image", "im"):
        cand = getattr(draw, attr, None)
        if isinstance(cand, Image.Image):
            return cand
    return None


def _draw_soft_text_shadow_halo(
    draw,
    x: int,
    y: int,
    text: str,
    font,
    shadow_rgb=(0, 0, 0),
    glow_rgb=None,
    sh_ang: float = 0.84,
    sh_dist: int = 6,
    shadow2_rgb: tuple[int, int, int] | None = None,
    alpha_scale: float = 1.0,
):
    """
    Renders genuine After Effects / Alight Motion Gaussian-blurred outer glow (`deepglow2` / `softglow`)
    + directional extruded `longshadow2new` (including dual cyan-magenta shadow on `xml-text4-tactic-cyber`).
    """
    if alpha_scale <= 0.02:
        return
    rad = sh_ang if abs(sh_ang) <= 6.5 else math.radians(sh_ang)
    dx_s = int(round(math.cos(rad) * max(2, min(11, sh_dist))))
    dy_s = int(round(math.sin(rad) * max(2, min(11, sh_dist))))
    target_im = _get_target_image_from_draw(draw)
    try:
        tw = max(16, int(draw.textlength(text, font=font)))
    except Exception:
        tw = max(16, len(text) * 24)
    th = max(32, int(getattr(font, "size", 42) * 1.70))
    pad = 30

    if target_im is not None:
        pw, ph = tw + pad * 2, th + pad * 2
        patch = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        pd = ImageDraw.Draw(patch, "RGBA")
        # 1. Soft Gaussian outer glow (`deepglow2` / `ADBE Glo2`)
        if glow_rgb:
            glow_layer = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
            gd = ImageDraw.Draw(glow_layer, "RGBA")
            gd.text((pad, pad), text, fill=(*glow_rgb, int(190 * alpha_scale)), font=font)
            glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(radius=9.0))
            patch.alpha_composite(glow_layer)
        # 2. Soft Gaussian drop shadow
        sh_layer = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh_layer, "RGBA")
        sd.text((pad + dx_s, pad + dy_s), text, fill=(*shadow_rgb, int(215 * alpha_scale)), font=font)
        sh_layer = sh_layer.filter(ImageFilter.GaussianBlur(radius=3.4))
        patch.alpha_composite(sh_layer)
        # 3. Extruded directional `longshadow2new` (with optional color1->color2 gradient extrusion)
        steps = max(2, min(7, sh_dist))
        for s_i in range(steps, 0, -1):
            frac_s = s_i / float(max(1, steps))
            sx = int(round(dx_s * 0.85 * frac_s))
            sy = int(round(dy_s * 0.85 * frac_s))
            if shadow2_rgb:
                c_sh = (
                    int(shadow_rgb[0] + (shadow2_rgb[0] - shadow_rgb[0]) * frac_s),
                    int(shadow_rgb[1] + (shadow2_rgb[1] - shadow_rgb[1]) * frac_s),
                    int(shadow_rgb[2] + (shadow2_rgb[2] - shadow_rgb[2]) * frac_s),
                )
                alpha = int(210 * alpha_scale)
            else:
                c_sh = shadow_rgb
                alpha = int(180 * alpha_scale * (1.0 - (s_i - 1) / float(steps + 2)))
            pd.text((pad + sx, pad + sy), text, fill=(*c_sh, alpha), font=font)

        px0, py0 = int(x - pad), int(y - pad)
        cx0 = max(0, -px0)
        cy0 = max(0, -py0)
        cx1 = min(pw, target_im.width - px0)
        cy1 = min(ph, target_im.height - py0)
        if cx1 > cx0 and cy1 > cy0:
            sub_patch = patch.crop((cx0, cy0, cx1, cy1))
            dst_x, dst_y = px0 + cx0, py0 + cy0
            if target_im.mode == "RGBA":
                target_im.alpha_composite(sub_patch, dest=(dst_x, dst_y))
            else:
                bg_crop = target_im.crop((dst_x, dst_y, dst_x + (cx1 - cx0), dst_y + (cy1 - cy0))).convert("RGBA")
                bg_crop.alpha_composite(sub_patch)
                target_im.paste(bg_crop.convert("RGB"), (dst_x, dst_y))
        return

    for step_s in range(sh_dist, 0, -2):
        sx_i = int(round(math.cos(rad) * step_s))
        sy_i = int(round(math.sin(rad) * step_s))
        draw.text((x + sx_i, y + sy_i), text, fill=(*shadow_rgb, int(180 * alpha_scale)), font=font)


def _draw_whole_word_xml_gradient(
    draw,
    wx: int,
    wy: int,
    word: str,
    font,
    stops: list[str],
    bevel_rgb: tuple[int, int, int] = (255, 255, 255),
    stroke_rgb: tuple[int, int, int] | None = None,
    stroke_w: int = 0,
    shimmer: bool = True,
    word_sub_progress: float = 0.5,
    local_frame: int = 0,
    layout_kind: str = "free",
    alpha_scale: float = 1.0,
    blur_entry_px: float = 0.0,
    grad_dir: str = "horizontal",
):
    """
    Renders a word or phrase using a single whole-string FreeType mask so kerning is 100% preserved,
    supporting:
    - Alight Motion `fourcolorgradient` / vertical linear `gradient` (`grad_dir="vertical"`)
    - `smoothbevel` / `ADBE Bevel Alpha` top-left specular bevel highlight
    - `CC Light Sweep` diagonal shimmer beam + spark particles (`mogrt-01`, `mogrt-11`, `mogrt-13`, `mogrt-18`)
    - Genuine per-character progressive `ImageFilter.GaussianBlur` entry (`blur-fade` for `mogrt-01` & `mogrt-04`)
    - `APC Shatter` horizontal/diagonal fracture slice displacement (`broken-shatter` for `mogrt-03`)
    """
    if alpha_scale <= 0.02:
        return
    target_im = _get_target_image_from_draw(draw)
    try:
        tw = max(12, int(draw.textlength(word, font=font)))
    except Exception:
        tw = max(12, len(word) * 22)
    th = max(28, int(getattr(font, "size", 42) * 1.60))
    pad = 18

    if target_im is not None:
        pw, ph = tw + pad * 2, th + pad * 2
        word_patch = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        wd = ImageDraw.Draw(word_patch, "RGBA")

        # 1. Optional path-stroke outline (`xml-text2-magenta-stroke`, `xml2-ridges-purple`)
        if stroke_rgb and stroke_w > 0:
            for ox in range(-stroke_w, stroke_w + 1):
                for oy in range(-stroke_w, stroke_w + 1):
                    if ox * ox + oy * oy <= (stroke_w + 0.5) ** 2 and (ox != 0 or oy != 0):
                        wd.text((pad + ox, pad + oy), word, fill=(*stroke_rgb, int(248 * alpha_scale)), font=font)

        # 2. Top-left specular bevel highlight (`smoothbevel` / `ADBE Bevel Alpha`)
        wd.text((pad - 1, pad - 2), word, fill=(*bevel_rgb, int(220 * alpha_scale)), font=font)

        # 3. Glyph alpha mask
        mask = Image.new("L", (pw, ph), 0)
        md = ImageDraw.Draw(mask)
        md.text((pad, pad), word, fill=int(255 * alpha_scale), font=font)

        # 4. Vectorized NumPy gradient + CC Light Sweep shimmer across the glyph
        sweep_pos = (word_sub_progress * 1.35) % 1.0
        stop_rgbs = np.array([hex_to_rgb(s) for s in (stops or ["#38BDF8", "#38BDF8"])], dtype=np.float32)
        if len(stop_rgbs) == 1:
            stop_rgbs = np.vstack([stop_rgbs, stop_rgbs])
        stop_xs = np.linspace(0.0, 1.0, len(stop_rgbs), dtype=np.float32)
        if grad_dir == "vertical":
            ys = np.linspace(0.0, 1.0, ph, dtype=np.float32)
            col_col = np.zeros((ph, 1, 4), dtype=np.uint8)
            for ch_i in range(3):
                col_col[:, 0, ch_i] = np.interp(ys, stop_xs, stop_rgbs[:, ch_i]).astype(np.uint8)
            col_col[:, 0, 3] = 255
            grad_arr = np.repeat(col_col, pw, axis=1)
            if shimmer:
                xs = np.linspace(0.0, 1.0, pw, dtype=np.float32)
                dist = np.abs(xs - sweep_pos)
                boost = np.clip(1.0 - dist / 0.16, 0.0, 1.0)[None, :, None] * 0.55
                grad_arr[:, :, :3] = np.clip(grad_arr[:, :, :3] * (1.0 - boost) + 255.0 * boost, 0, 255).astype(np.uint8)
        else:
            xs = np.linspace(0.0, 1.0, pw, dtype=np.float32)
            u_x = (xs + local_frame * 0.012) % 1.0
            col_row = np.zeros((1, pw, 4), dtype=np.float32)
            for ch_i in range(3):
                col_row[0, :, ch_i] = np.interp(u_x, stop_xs, stop_rgbs[:, ch_i])
            if shimmer:
                dist = np.abs(xs - sweep_pos)
                boost = np.clip(1.0 - dist / 0.18, 0.0, 1.0)[None, :, None] * 0.58
                col_row[:, :, :3] = col_row[:, :, :3] * (1.0 - boost) + 255.0 * boost
            col_row[0, :, 3] = 255.0
            grad_arr = np.repeat(np.clip(col_row, 0, 255).astype(np.uint8), ph, axis=0)

        grad_im = Image.fromarray(grad_arr, mode="RGBA")
        grad_im.putalpha(mask)
        word_patch.alpha_composite(grad_im)

        # 5. Authentic MOGRT #3 (`Copy of Broken.mogrt`): APC Shatter horizontal/diagonal slice displacement!
        if layout_kind == "broken-shatter":
            shatter_prog = max(0.0, 1.0 - min(1.0, word_sub_progress * 1.45))
            shatter_amp = max(2, int(round(6.0 * shatter_prog + 2.0)))
            sliced = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
            band1 = ph // 3
            band2 = (ph * 2) // 3
            s_top = word_patch.crop((0, 0, pw, band1))
            s_mid = word_patch.crop((0, band1, pw, band2))
            s_bot = word_patch.crop((0, band2, pw, ph))
            sliced.paste(s_top, (max(0, shatter_amp), 0))
            sliced.paste(s_mid, (0, band1))
            sliced.paste(s_bot, (max(0, shatter_amp // 2), band2))
            # Diagonal fracture cut line through the glyph
            sd_draw = ImageDraw.Draw(sliced, "RGBA")
            sd_draw.line([(pad, band1 + 4), (pw - pad, band2 - 4)], fill=(0, 0, 0, 210), width=2)
            word_patch = sliced

        # 6. Authentic MOGRT #1 & #4 (`Blur Fade In WIth Shine` & `Cinematic Blur Animation`):
        # Progressive left-to-right GaussianBlur ramp across the entering word!
        if blur_entry_px > 0.4 or layout_kind == "blur-fade":
            eff_blur = blur_entry_px if blur_entry_px > 0.4 else max(0.0, (1.0 - min(1.0, word_sub_progress * 1.5)) * 6.5)
            if eff_blur > 0.45:
                blurred_right = word_patch.filter(ImageFilter.GaussianBlur(radius=eff_blur))
                # Sharp on the left, transitioning smoothly to Gaussian-blurred on the right (like "Sparvol" in MOGRT #4!)
                ramp_mask = Image.new("L", (pw, ph), 0)
                split_px = int(pw * min(0.92, max(0.25, word_sub_progress * 1.25)))
                ramp_arr = np.zeros((ph, pw), dtype=np.uint8)
                for xi in range(pw):
                    if xi > split_px:
                        ramp_arr[:, xi] = min(255, int((xi - split_px) / max(1.0, pw * 0.28) * 255))
                ramp_mask = Image.fromarray(ramp_arr, mode="L")
                word_patch = Image.composite(blurred_right, word_patch, ramp_mask)

        px0, py0 = int(wx - pad), int(wy - pad)
        cx0 = max(0, -px0)
        cy0 = max(0, -py0)
        cx1 = min(pw, target_im.width - px0)
        cy1 = min(ph, target_im.height - py0)
        if cx1 > cx0 and cy1 > cy0:
            sub_patch = word_patch.crop((cx0, cy0, cx1, cy1))
            dst_x, dst_y = px0 + cx0, py0 + cy0
            if target_im.mode == "RGBA":
                target_im.alpha_composite(sub_patch, dest=(dst_x, dst_y))
            else:
                bg_crop = target_im.crop((dst_x, dst_y, dst_x + (cx1 - cx0), dst_y + (cy1 - cy0))).convert("RGBA")
                bg_crop.alpha_composite(sub_patch)
                target_im.paste(bg_crop.convert("RGB"), (dst_x, dst_y))
        return

    c_rgb = th_gradient_rgb(stops, 0.35)
    draw.text((wx, wy), word, fill=(*c_rgb, int(255 * alpha_scale)), font=font)


def draw_xml_premium_text_caption(
    draw,
    pill_rows: list,
    active_idx: int,
    word_sub_progress: float,
    y_center: int,
    cx: int,
    preset_name: str,
    local_frame: int = 0,
) -> None:
    """
    Authentic Box-Free Renderer for all 33 XML & MOGRT files in `Premium Text.rar`:
    - ZERO forced dark background boxes!
    - Preserves each XML/MOGRT file's exact font family, multi-tier color/font hierarchy,
      and authentic keyframe entry animation ("cara text masuk"):
      * Alight Motion XML 1-5 (`texttransform` upward slide + fade-in + `smoothbevel` + `deepglow2` + `longshadow2new`)
      * Alight Motion XML 6 (`xml2-ridges-purple`: downward drop + `textspacing` tracking expansion + `ridges2` + crimson glow)
      * MOGRT #1 & #4 (`blur-fade`: progressive left-to-right Gaussian blur fade-in + `CC Light Sweep` sparks)
      * MOGRT #2 (`bounce-two-tone`: white Row 0 + neon green `#00FF1C` Row 1 with spring bounce)
      * MOGRT #3 (`broken-shatter`: APC Shatter 3-strip horizontal fracture slice on red glyphs)
      * MOGRT #6, #7, #8, #9 (Davin/Devin Jatho: 2-tier scale/color split, hollow ghost background text, radial glow)
      * MOGRT #10, #11, #16 (`fast-wip` horizontal slide-in & `regular-up` vertical rise in translucent gray-to-white)
      * MOGRT #12, #13 (`flicker-glow`: high-frequency neon opacity flicker on entry)
      * MOGRT #15, #17, #20, #21, #22, #23, #24, #25, #26, #27 (Hero Garamond, Shadow+Script, Sliding Serif, Smooth Cross/Slide, Bebas Echo, Super Trendy, Trending 1/2/3)
      * MOGRT #28 (`viral-ribbon-1`: white solid banner + red text + red pin sticks with circle tips)
      * MOGRT #29 (`viral-loop-2`: animated hand-drawn double red neon marker oval loop)
    """
    spec = XML_CAPTION_PRESETS.get(preset_name, XML_CAPTION_PRESETS["xml-text1-gold-bevel"])
    stops = spec["stops"]
    glow_rgb = spec["glow_rgb"]
    bevel_rgb = spec["bevel_rgb"]
    stroke_rgb = spec.get("stroke_rgb")
    stroke_w = int(spec.get("stroke_w", 0))
    sh_ang = math.radians(float(spec.get("shadow_angle_deg", 48)))
    sh_dist = int(spec.get("shadow_dist", 6))
    sh_rgb = spec.get("shadow_rgb", (0, 0, 0))
    sh2_rgb = spec.get("shadow2_rgb") or spec.get(" shadow2_rgb")
    offset_y_base = int(spec.get("offset_y", 24))
    font_fam = spec.get("font_family", "inter-black")
    base_sz = int(spec.get("font_size", 44))
    is_upper = bool(spec.get("uppercase", False))
    layout_kind = spec.get("layout", "free")
    grad_dir = "vertical" if preset_name in ("xml-text2-magenta-stroke", "xml-text3-cobalt-cyan", "mogrt-25-trending-1-anton") else "horizontal"

    f_base = load_font(base_sz, bold=True, family=font_fam)
    f_italic_accent = load_font(max(32, base_sz - 2), bold=True, family="script-italic")
    cur_y = y_center

    # Bespoke MOGRT #7 & #8 (`Davin Jatho text 2 & 3`): Radial ambient glow + wide hollow ghost background text
    if layout_kind in ("davin-ghost-bg", "davin-ghost-xxxx") and pill_rows and pill_rows[0]:
        target_im = _get_target_image_from_draw(draw)
        if target_im is not None and glow_rgb:
            amb = Image.new("RGBA", (520, 140), (0, 0, 0, 0))
            ad = ImageDraw.Draw(amb, "RGBA")
            ad.ellipse([40, 15, 480, 125], fill=(*glow_rgb, 68))
            amb = amb.filter(ImageFilter.GaussianBlur(radius=22))
            dst_x = max(0, min(target_im.width - 520, cx - 260))
            dst_y = max(0, min(target_im.height - 140, cur_y - 18))
            if target_im.mode == "RGBA":
                target_im.alpha_composite(amb, dest=(dst_x, dst_y))
        ghost_str = "X X X X" if layout_kind == "davin-ghost-xxxx" else " ".join(w for _, w in pill_rows[0] if w not in SUPPORTED_EMOJIS)
        if is_upper:
            ghost_str = ghost_str.upper()
        f_ghost = load_font(int(base_sz * 1.32), bold=True, family=font_fam)
        gw = int(draw.textlength(ghost_str, font=f_ghost))
        gx0 = cx - gw // 2
        gy0 = cur_y - 10
        for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
            draw.text((gx0 + ox, gy0 + oy), ghost_str, fill=(226, 232, 240, 58), font=f_ghost)

    # XML #6 (`Copy of Text animation .xml` — `xml2-ridges-purple`): Animated `textspacing` letter-spacing expansion!
    extra_space_px = 0
    if preset_name == "xml2-ridges-purple":
        bez_t = ease_out_cubic(min(1.0, word_sub_progress * 1.3))
        extra_space_px = int(round(bez_t * 10))

    space_px = max(14, int(base_sz * 0.34)) + extra_space_px
    for r_idx, row in enumerate(pill_rows):
        if not row:
            continue
        disp_row = [(g_i, w.upper() if is_upper else w) for g_i, w in row]

        # Multi-tier row styling matching the exact MOGRT thumbnails (`all_31_mogrt_thumbs.png` & `mp4_mogrt_thumbs.png`)
        row_scale = 1.0
        row_fam = font_fam
        if layout_kind == "davin-split-red":
            # MOGRT #6: Row 0 smaller white uppercase, Row 1 huge 1.28x red uppercase
            row_scale = 0.82 if r_idx == 0 else 1.18
        elif layout_kind == "davin-ghost-bg" and r_idx == 1:
            # MOGRT #7: Row 1 smaller italic white ("Creative Sparrow")
            row_scale = 0.76
            row_fam = "tacticsans-medit"
        elif layout_kind == "sliding-serif" and r_idx == 0 and len(pill_rows) > 1:
            # MOGRT #20: Top row small light sans ("here is the"), bottom row large lime serif italic
            row_scale = 0.65
            row_fam = "helvetica-light"
        elif layout_kind == "shadow-sub" and r_idx == 1:
            # MOGRT #17: Bottom row overlapping script ("Text Effect")
            row_scale = 0.78
            row_fam = "script-italic"
        elif layout_kind == "viral-ribbon-1" and r_idx == 0 and len(pill_rows) > 1:
            # MOGRT #28: Top row white italic script ("this is viral")
            row_scale = 0.84
            row_fam = "script-italic"
        elif layout_kind == "smooth-cross":
            # MOGRT #21 & #23: Row 0 bold sans, Row 1 italic serif
            if r_idx == 1:
                row_fam = "garamond-bolditalic" if preset_name == "mogrt-21-smooth-cross" else "times-bolditalic"
                row_scale = 1.08

        eff_row_sz = max(24, int(round(base_sz * row_scale)))
        f_row_base = load_font(eff_row_sz, bold=(row_fam != "helvetica-light"), family=row_fam)

        word_specs = []
        for g_idx, w in disp_row:
            if w in SUPPORTED_EMOJIS:
                word_specs.append((g_idx, w, None, 0, 0, 36, False, False, 1.0, 0.0))
                continue
            is_act = g_idx == active_idx
            is_spk = g_idx < active_idx
            f_word = f_row_base
            if layout_kind in ("trending-script-combo", "hero-editorial") and is_act:
                act_f_name = "garamond-bolditalic" if preset_name == "mogrt-15-hero-garamond" else "script-italic"
                f_word = load_font(eff_row_sz + 6, bold=True, family=act_f_name)

            dx = 0
            dy = 0
            alpha_w = 1.0
            blur_px = 0.0
            if is_act:
                pop_prog = ease_out_cubic(min(1.0, word_sub_progress * 1.65))
                if layout_kind == "fast-wip":
                    # MOGRT #10 & #11: Horizontal wipe entry from right (`offset=(150, 0)`) with translucent gray-to-white ramp
                    dx = int(round((1.0 - pop_prog) * 28))
                    dy = 0
                    alpha_w = 0.45 + 0.55 * pop_prog
                    f_use = f_word
                elif layout_kind == "blur-fade":
                    # MOGRT #1 & #4: Progressive Gaussian blur fade-in
                    dy = int(round((1.0 - pop_prog) * 10))
                    blur_px = max(0.0, (1.0 - pop_prog) * 7.5)
                    alpha_w = 0.55 + 0.45 * pop_prog
                    f_use = f_word
                elif layout_kind == "flicker-glow":
                    # MOGRT #12 & #13: High-frequency neon flicker on word entry
                    flicker = 0.35 if (word_sub_progress < 0.42 and (local_frame % 2 == 1)) else 1.0
                    alpha_w = flicker
                    dy = int(round((1.0 - pop_prog) * 12))
                    f_use = f_word
                elif layout_kind == "smooth-cross":
                    # MOGRT #21 & #23: Row 0 slides from left, Row 1 slides from right (crossing each other)
                    dir_sign = -1 if r_idx == 0 else 1
                    dx = int(round(dir_sign * (1.0 - pop_prog) * 34))
                    f_use = f_word
                elif layout_kind in ("bounce-two-tone", "davin-split-red"):
                    # MOGRT #2 & #6: Spring bounce overshoot
                    sp_v = th_spring(min(1.2, word_sub_progress * 1.8))
                    dy = int(round((1.0 - sp_v) * offset_y_base))
                    font_sz = int(round(eff_row_sz + 5 * math.sin(word_sub_progress * math.pi)))
                    f_use = load_font(font_sz, bold=True, family=row_fam)
                else:
                    # Alight Motion `texttransform` upward rise (or downward drop on `xml2-ridges-purple`) + scale pop
                    dy = int(round((1.0 - pop_prog) * offset_y_base * 0.45)) - int(round(math.sin(word_sub_progress * math.pi) * 4))
                    scale_boost = 5 if layout_kind != "viral-ribbon-1" else 2
                    font_sz = int(round(eff_row_sz + scale_boost * math.sin(word_sub_progress * math.pi)))
                    act_fam = "garamond-bolditalic" if preset_name == "mogrt-15-hero-garamond" else ("script-italic" if layout_kind == "trending-script-combo" else row_fam)
                    f_use = load_font(font_sz, bold=True, family=act_fam)
            elif is_spk:
                f_use = f_word
            else:
                # Upcoming word in current 2-row window
                dy = 6 if layout_kind not in ("fast-wip", "smooth-cross") else 0
                alpha_w = 0.46 if layout_kind in ("blur-fade", "fast-wip") else 0.72
                blur_px = 2.8 if layout_kind == "blur-fade" else 0.0
                f_use = f_word

            ww = int(draw.textlength(w, font=f_use))
            word_specs.append((g_idx, w, f_use, dx, dy, ww, is_act, is_spk, alpha_w, blur_px))

        tw = sum(ws[5] for ws in word_specs) + space_px * max(0, len(word_specs) - 1)
        ph = int(eff_row_sz * 1.36)
        # MOGRT #21 & #23 (`smooth-cross`): Slight horizontal stagger between Row 0 and Row 1
        stagger_x = (-22 if r_idx == 0 else 22) if (layout_kind == "smooth-cross" and len(pill_rows) > 1) else 0
        px0 = cx - tw // 2 + stagger_x

        # Bespoke MOGRT #29 (`Viral Caption Style 2`): Hand-drawn double red neon marker oval loop (`Round line`)
        if layout_kind == "viral-loop-2" and any(ws[6] for ws in word_specs):
            loop_pad_x, loop_pad_y = 38, 16
            lx0, ly0 = px0 - loop_pad_x, cur_y - loop_pad_y
            lx1, ly1 = px0 + tw + loop_pad_x, cur_y + ph + loop_pad_y - 4
            sweep_deg = int(min(360, max(90, word_sub_progress * 420)))
            # Outer soft red neon glow ring + double hand-drawn marker arcs
            draw.arc([lx0 - 5, ly0 - 5, lx1 + 5, ly1 + 5], start=170, end=170 + sweep_deg, fill=(255, 0, 0, 90), width=14)
            draw.arc([lx0, ly0, lx1, ly1], start=170, end=170 + sweep_deg, fill=(255, 18, 18, 255), width=6)
            draw.arc([lx0 + 8, ly0 - 6, lx1 - 4, ly1 - 4], start=185, end=185 + int(sweep_deg * 0.88), fill=(255, 42, 42, 235), width=4)

        wx = px0
        wy = cur_y + 4
        for g_idx, w, f_use, dx, dy, ww, is_active, is_spoken, alpha_w, blur_px in word_specs:
            if w in SUPPORTED_EMOJIS:
                draw_inline_emoji_icon(draw, w, wx + 14, wy + 20, size=28)
                wx += ww + space_px
                continue

            # Bespoke MOGRT #28 (`Viral Caption Style 1`): Solid white banner + red text + left/right red pin sticks with circle tips
            if layout_kind == "viral-ribbon-1" and is_active:
                bx0, by0 = wx - 14, wy + dy - 4
                bx1, by1 = wx + ww + 14, wy + dy + int(eff_row_sz * 1.14)
                draw.rectangle([bx0, by0, bx1, by1], fill=(255, 255, 255, 255))
                # Left red vertical pin stick (circle at bottom)
                draw.line([(bx0, by0 - 6), (bx0, by1 + 14)], fill=(255, 0, 0, 255), width=4)
                draw.ellipse([bx0 - 6, by1 + 8, bx0 + 6, by1 + 20], fill=(255, 0, 0, 255))
                # Right red vertical pin stick (circle at top)
                draw.line([(bx1, by0 - 14), (bx1, by1 + 6)], fill=(255, 0, 0, 255), width=4)
                draw.ellipse([bx1 - 6, by0 - 20, bx1 + 6, by0 - 8], fill=(255, 0, 0, 255))
                draw.text((wx, wy + dy), w, fill=(230, 0, 0, 255), font=f_use)
                wx += ww + space_px
                continue

            # Choose row-specific stops when layout has two-tone rows (`bounce-two-tone`, `davin-split-red`, `devin-silver-blue`, `super-trendy`, `smooth-cross`, `davin-ghost-xxxx`)
            word_stops = stops
            if layout_kind == "bounce-two-tone":
                word_stops = ["#FFFFFF", "#F8FAFC", "#FFFFFF", "#E2E8F0"] if (r_idx == 0 and len(pill_rows) > 1) else ["#00FF1C", "#4ADE80", "#00FF1C", "#86EFAC"]
            elif layout_kind == "davin-split-red":
                word_stops = ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"] if (r_idx == 0 and len(pill_rows) > 1) else ["#FF1E1E", "#FF4D4D", "#DC2626", "#FF1E1E"]
            elif layout_kind == "davin-ghost-xxxx":
                word_stops = ["#FFD800", "#FACC15", "#FFE866", "#FFD800"] if r_idx == 0 else ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"]
            elif layout_kind == "devin-silver-blue":
                word_stops = ["#E2E8F0", "#FFFFFF", "#CBD5E1", "#FFFFFF"] if (r_idx == 0 and len(pill_rows) > 1) else ["#0090FF", "#38BDF8", "#7DD3FC", "#0090FF"]
            elif layout_kind == "super-trendy":
                word_stops = ["#E2E8F0", "#FFFFFF", "#CBD5E1", "#FFFFFF"] if (r_idx == 0 and len(pill_rows) > 1) else ["#FF6D00", "#FF9E00", "#F97316", "#FFB703"]
            elif layout_kind == "smooth-cross":
                if preset_name == "mogrt-21-smooth-cross":
                    word_stops = ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"] if r_idx == 0 else ["#A855F7", "#C084FC", "#9500FF", "#D8B4FE"]
                else:
                    word_stops = ["#00DBE1", "#00FF1C", "#34D399", "#00DBE1"] if r_idx == 0 else ["#FFFFFF", "#F8FAFC", "#E2E8F0", "#FFFFFF"]

            if is_active:
                _draw_soft_text_shadow_halo(
                    draw, wx + dx, wy + dy, w, f_use,
                    shadow_rgb=sh_rgb,
                    glow_rgb=glow_rgb,
                    sh_ang=sh_ang,
                    sh_dist=sh_dist,
                    shadow2_rgb=sh2_rgb,
                    alpha_scale=alpha_w,
                )
                _draw_whole_word_xml_gradient(
                    draw=draw,
                    wx=wx + dx,
                    wy=wy + dy,
                    word=w,
                    font=f_use,
                    stops=word_stops,
                    bevel_rgb=bevel_rgb,
                    stroke_rgb=stroke_rgb,
                    stroke_w=stroke_w,
                    shimmer=bool(spec.get("shimmer")),
                    word_sub_progress=word_sub_progress,
                    local_frame=local_frame,
                    layout_kind=layout_kind,
                    alpha_scale=alpha_w,
                    blur_entry_px=blur_px,
                    grad_dir=grad_dir,
                )
                # Subtle golden-orange shine sparks above active word on Shine MOGRTs (#1, #11, #13, #18)
                if preset_name in ("mogrt-01-blur-fade-shine", "mogrt-11-fast-wip-shine", "mogrt-13-flicker-shine", "mogrt-18-shine-text"):
                    for sp_i in range(3):
                        spx = wx + int(ww * (0.22 + 0.28 * sp_i)) + int(math.sin(local_frame * 0.3 + sp_i) * 6)
                        spy = wy + dy - 6 - int((local_frame * 2 + sp_i * 7) % 14)
                        draw.ellipse([spx - 3, spy - 2, spx + 3, spy + 2], fill=(255, 185, 40, 210))
            elif is_spoken:
                _draw_soft_text_shadow_halo(draw, wx + dx, wy + dy, w, f_use, shadow_rgb=(0, 0, 0), glow_rgb=None, sh_ang=sh_ang, sh_dist=4)
                if layout_kind in ("bounce-two-tone", "davin-split-red", "davin-ghost-xxxx", "devin-silver-blue", "super-trendy", "smooth-cross"):
                    _draw_whole_word_xml_gradient(
                        draw=draw, wx=wx + dx, wy=wy + dy, word=w, font=f_use,
                        stops=word_stops, bevel_rgb=bevel_rgb, stroke_rgb=None, stroke_w=0,
                        shimmer=False, word_sub_progress=1.0, local_frame=local_frame,
                        layout_kind="free", alpha_scale=0.96, grad_dir=grad_dir,
                    )
                else:
                    draw.text((wx + dx, wy + dy), w, fill=(255, 255, 255, 252), font=f_use)
            else:
                up_alpha = int(255 * alpha_w)
                _draw_soft_text_shadow_halo(draw, wx + dx, wy + dy, w, f_use, shadow_rgb=(0, 0, 0), glow_rgb=None, sh_ang=sh_ang, sh_dist=3, alpha_scale=alpha_w)
                draw.text((wx + dx, wy + dy), w, fill=(241, 245, 249, up_alpha), font=f_use)

            wx += ww + space_px
        cur_y += ph + 6

    # Bespoke MOGRT #22 (`Copy of Smooth Fade.mogrt` — `bebas-echo`): Centered small white condensed uppercase echo subline below!
    if layout_kind == "bebas-echo" and pill_rows and pill_rows[0]:
        echo_str = " ".join(w.upper() for _, w in pill_rows[0] if w not in SUPPORTED_EMOJIS)[:28]
        f_echo = load_font(max(18, int(base_sz * 0.42)), bold=True, family="bebas-bold")
        ew = int(draw.textlength(echo_str, font=f_echo))
        _draw_soft_text_shadow_halo(draw, cx - ew // 2, cur_y - 2, echo_str, f_echo, shadow_rgb=(0, 0, 0), sh_dist=3)
        draw.text((cx - ew // 2, cur_y - 2), echo_str, fill=(248, 250, 252, 235), font=f_echo)


def draw_compact_editorial_subtitle_pills(
    draw,
    text: str,
    progress_u: float,
    y_center: int = 1355,
    pad_x: int = 84,
    right_x: int = 876,
    highlight_rgb: tuple[int, int, int] = (250, 204, 21),
    words_timed: list = None,
    scene_elapsed_sec: float = None,
    scene_start_sec: float = 0.0,
    scene: dict = None,
    local_frame: int = 0,
):
    """
    Upgraded Subtitle & Caption Engine (Sections 2.1 - 2.6 & Quick Wins #2, #3, #4, #5, #8, #9):
    Supports:
    - Semantic phrase & metric grouping (`group_words_semantically`)
    - 7 Caption Styles (`karaoke-pill`, `typewriter`, `slide-up`, `glitch`, `handwritten`, `neon`, `minimal`)
    - Per-word animations (`scale-bounce`, `pop-rotate`, `glow-pulse`) & emphasis words (`emphasisWords`)
    - Spoken word exit/settle animation
    - Multi-speaker badges (`speaker: "narrator"|"expert"|"user"|"host"|"guest"`)
    - Inline emoji vector icons (`🎯`, `💡`, `🔥`, `📊`, `⚡`, `✅`)
    - Automatic collision detection & `y_center` override
    """
    sc = scene or {}
    y_center = detect_caption_collision_and_adjust_y(sc, default_y=y_center)
    _MODERN_CAPTION_ROTATION = (
        "xml-4color-gold",
        "slide-up",
        "xml-magenta-stroke",
        "minimal",
        "xml-cyan-cobalt",
        "neon",
        "xml-cyber-longshadow",
        "xml-purple-shimmer",
        "handwritten",
        "typewriter",
        "glitch",
    )
    _CAP_ALIASES = {
        "xml": "xml-4color-gold",
        "xml-gold": "xml-4color-gold",
        "4color-gold": "xml-4color-gold",
        "xml-magenta": "xml-magenta-stroke",
        "xml-cyan": "xml-cyan-cobalt",
        "xml-cyber": "xml-cyber-longshadow",
        "xml-purple": "xml-purple-shimmer",
        "xml-ridges": "xml-ridges-glow",
        "apple": "clean-apple",
        "bounce": "viral-bounce",
        "blur": "cinematic-blur",
        "metallic": "shiny-metallic",
    }
    raw_cap_style = str(sc.get("captionStyle") or "").strip().lower()
    if raw_cap_style in ("none", "off", "hidden", "false"):
        return
    if sc.get("customCaption"):
        text = str(sc.get("customCaption"))
    if sc.get("captionY"):
        y_center = int(sc.get("captionY"))
    if sc.get("captionHighlightColor"):
        highlight_rgb = hex_to_rgb(str(sc.get("captionHighlightColor")))
    raw_cap_style = _CAP_ALIASES.get(raw_cap_style, raw_cap_style)
    if not raw_cap_style or raw_cap_style in ("default", "auto"):
        sc_idx_hint = int(re.sub(r"\D", "", str(sc.get("id", "0"))) or "0")
        caption_style = _MODERN_CAPTION_ROTATION[sc_idx_hint % len(_MODERN_CAPTION_ROTATION)]
    else:
        caption_style = raw_cap_style

    clean_str = sanitize_text(text, allow_emoji=True)
    # Inject optional scene captionEmoji if provided
    if sc.get("captionEmoji") and sc["captionEmoji"] in SUPPORTED_EMOJIS and sc["captionEmoji"] not in clean_str:
        clean_str = f"{sc['captionEmoji']} {clean_str}"

    words = [w for w in clean_str.split() if w]
    if not words:
        return

    # Build emphasis & animation lookup from scene.emphasisWords, scene.wordAnimations, and words_timed
    emphasis_set = set()
    for ew in sc.get("emphasisWords") or []:
        for sub_w in str(ew).split():
            emphasis_set.add(re.sub(r"[^\w]", "", sub_w.lower()))

    anim_map = {}
    for wa in sc.get("wordAnimations") or []:
        if isinstance(wa, dict) and wa.get("word"):
            anim_map[re.sub(r"[^\w]", "", str(wa["word"]).lower())] = {
                "animation": wa.get("animation", "scale-bounce"),
                "intensity": float(wa.get("intensity", 1.3)),
            }

    active_idx = None
    word_sub_progress = 0.5
    speaker_id = str(sc.get("speaker") or "narrator").lower()

    if isinstance(words_timed, list) and len(words_timed) > 0 and scene_elapsed_sec is not None:
        abs_t = scene_start_sec + scene_elapsed_sec
        for idx, w_obj in enumerate(words_timed):
            if idx >= len(words):
                break
            w_s = float(w_obj.get("start", 0.0))
            w_e = float(w_obj.get("end", w_s + 0.25))
            if w_obj.get("emphasis") in ("strong", "moderate"):
                emphasis_set.add(re.sub(r"[^\w]", "", str(w_obj.get("word", "")).lower()))
            if w_obj.get("speaker"):
                speaker_id = str(w_obj["speaker"]).lower()
            if w_s - 0.04 <= abs_t <= w_e + 0.06:
                active_idx = idx
                word_sub_progress = max(0.0, min(1.0, (abs_t - w_s) / max(0.05, w_e - w_s)))
                break
        if active_idx is None:
            if abs_t < float(words_timed[0].get("start", 0.0)):
                active_idx = 0
            else:
                active_idx = len(words) - 1

    if active_idx is None:
        norm_u = max(0.0, min(0.999, (progress_u - 0.02) / 0.88))
        exact_pos = norm_u * len(words)
        active_idx = int(exact_pos)
        word_sub_progress = exact_pos - active_idx

    # Semantic grouping into rows of 2-3 words, then 2 rows per visible window
    all_semantic_rows = group_words_semantically(words, max_words_per_row=3)
    active_row_idx = 0
    for r_i, r_items in enumerate(all_semantic_rows):
        if any(g_i == active_idx for g_i, _ in r_items):
            active_row_idx = r_i
            break
    win_row_start = (active_row_idx // 2) * 2
    pill_rows = all_semantic_rows[win_row_start : win_row_start + 2]

    cx = (pad_x + right_x) // 2
    cur_y = y_center

    # Section 2.6: Draw Speaker Badge if speaker is specified or multi-speaker dialogue is active
    if sc.get("showSpeakerLabel") is True:
        spk_info = SPEAKER_BADGE_STYLES.get(speaker_id, {"label": speaker_id.upper()[:12], "rgb": highlight_rgb})
        f_spk = load_font(18, bold=True)
        spk_txt = f"{spk_info['label']}:"
        spk_w = int(draw.textlength(spk_txt, font=f_spk)) + 28
        spk_x0 = cx - spk_w // 2
        spk_y0 = cur_y - 34
        draw.rounded_rectangle([spk_x0, spk_y0, spk_x0 + spk_w, spk_y0 + 28], radius=14, fill=(*spk_info["rgb"], 255))
        draw.text((spk_x0 + 14, spk_y0 + 4), spk_txt, fill=(12, 14, 22, 255), font=f_spk)

    # Style 0: ALIGHT MOTION XML & PREMIUM MOGRT TEXT PRESETS (`xml-4color-gold`, `xml-magenta-stroke`, `xml-cyan-cobalt`, `xml-cyber-longshadow`, `xml-purple-shimmer`, `xml-ridges-glow`, `clean-apple`, `viral-bounce`, `cinematic-blur`, `shiny-metallic`)
    if caption_style in XML_CAPTION_PRESETS:
        draw_xml_premium_text_caption(
            draw=draw,
            pill_rows=pill_rows,
            active_idx=active_idx,
            word_sub_progress=word_sub_progress,
            y_center=cur_y,
            cx=cx,
            preset_name=caption_style,
            local_frame=local_frame,
        )
        return

    # Style 1: MINIMAL (clean single line, box-free smooth fade in/out with crisp drop shadow)
    if caption_style == "minimal":
        active_row = all_semantic_rows[active_row_idx] if all_semantic_rows else []
        line_str = " ".join(w for _, w in active_row if w not in SUPPORTED_EMOJIS)
        f_min = load_font(38, bold=True, family="helvetica-bold")
        tw = int(draw.textlength(line_str, font=f_min))
        fade_alpha = int(255 * min(1.0, math.sin(max(0.05, min(0.95, progress_u)) * math.pi) * 2.2))
        _draw_soft_text_shadow_halo(draw, cx - tw // 2, cur_y + 10, line_str, f_min, shadow_rgb=(0, 0, 0), sh_dist=5)
        draw.text((cx - tw // 2, cur_y + 10), line_str, fill=(248, 250, 252, fade_alpha), font=f_min)
        return

    # Style 2: TYPEWRITER (character-by-character reveal with blinking cursor)
    if caption_style == "typewriter":
        f_tw = load_font(30, bold=True, mono=True)
        for row in pill_rows:
            if not row:
                continue
            vis_chars = []
            for g_idx, w in row:
                if w in SUPPORTED_EMOJIS:
                    continue
                if g_idx < active_idx:
                    vis_chars.append(w)
                elif g_idx == active_idx:
                    n_ch = max(1, int(round(len(w) * min(1.0, word_sub_progress * 1.35))))
                    vis_chars.append(w[:n_ch])
            row_vis = " ".join(vis_chars)
            cursor_ch = "█" if (local_frame // 4) % 2 == 0 and any(g_i == active_idx for g_i, _ in row) else ""
            full_str = " ".join(w for _, w in row if w not in SUPPORTED_EMOJIS)
            pw = int(draw.textlength(full_str + " █", font=f_tw)) + 44
            ph = 54
            px0 = cx - pw // 2
            draw.rounded_rectangle([px0, cur_y, px0 + pw, cur_y + ph], radius=12, fill=(16, 20, 18, 248), outline=(*highlight_rgb, 210), width=2)
            draw.text((px0 + 22, cur_y + 11), row_vis + cursor_ch, fill=(*highlight_rgb, 255), font=f_tw)
            cur_y += ph + 10
        return

    # Style 2B: SLIDE-UP (Clean box-free typography with smooth vertical word slide-up & glowing underline indicator)
    if caption_style == "slide-up":
        f_su = load_font(38, bold=True, family="inter-extrabold")
        active_row = all_semantic_rows[active_row_idx] if all_semantic_rows else []
        if not active_row:
            return
        row_str = " ".join(w for _, w in active_row if w not in SUPPORTED_EMOJIS)
        tw = int(draw.textlength(row_str, font=f_su))
        px0 = cx - tw // 2
        wx = px0
        wy = cur_y + 10
        for g_idx, w in active_row:
            if w in SUPPORTED_EMOJIS:
                continue
            is_act = g_idx == active_idx
            is_spk = g_idx < active_idx
            slide_dy = int((1.0 - ease_out_cubic(min(1.0, word_sub_progress * 1.6))) * 14) if is_act else 0
            ww = int(draw.textlength(w, font=f_su))
            _draw_soft_text_shadow_halo(draw, wx, wy + (slide_dy - 3 if is_act else 0), w, f_su, shadow_rgb=(0, 0, 0), sh_dist=5)
            if is_act:
                draw.text((wx, wy - 3 + slide_dy), w, fill=(56, 189, 248, 255), font=f_su)
                draw.rounded_rectangle([wx, wy + 42, wx + ww, wy + 47], radius=2, fill=(56, 189, 248, 255))
            elif is_spk:
                draw.text((wx, wy), w, fill=(248, 250, 252, 255), font=f_su)
            else:
                draw.text((wx, wy + 3), w, fill=(185, 198, 214, 180), font=f_su)
            wx += int(draw.textlength(w + " ", font=f_su))
        return

    # Styles 3, 4, 5, 6, 7: KARAOKE-PILL, SLIDE-UP, GLITCH, HANDWRITTEN, NEON
    is_handwritten = caption_style == "handwritten"
    is_neon = caption_style == "neon"
    is_glitch = caption_style == "glitch"
    is_slide_up = caption_style == "slide-up"

    # Per-style accent color so captions harmonize with visual theme instead of always yellow.
    style_accent = {
        "karaoke-pill": highlight_rgb,
        "slide-up": (56, 189, 248),      # blue / cyan
        "glitch": (236, 72, 153),        # magenta / pink
        "handwritten": (180, 83, 9),     # burnt orange
        "neon": (0, 245, 212),           # neon mint
        "minimal": highlight_rgb,
        "typewriter": highlight_rgb,
    }.get(caption_style, highlight_rgb)

    f_sub = load_font(32, bold=True, serif=is_handwritten, mono=is_glitch)

    for row in pill_rows:
        if not row:
            continue
        row_str = " ".join("  " if w in SUPPORTED_EMOJIS else w for _, w in row)
        tw = int(draw.textlength(row_str, font=f_sub))
        pw = tw + 48
        ph = 58
        px0 = cx - pw // 2

        if is_neon:
            # Outer neon glow aura
            for g_rad, g_alpha in ((8, 45), (4, 95)):
                draw.rounded_rectangle(
                    [px0 - g_rad, cur_y - g_rad, px0 + pw + g_rad, cur_y + ph + g_rad],
                    radius=18 + g_rad,
                    fill=(*style_accent, g_alpha),
                )
            draw.rounded_rectangle([px0, cur_y, px0 + pw, cur_y + ph], radius=16, fill=(8, 10, 24, 248), outline=(*style_accent, 255), width=3)
        elif is_handwritten:
            draw.rounded_rectangle([px0 + 4, cur_y + 5, px0 + pw + 4, cur_y + ph + 5], radius=14, fill=(0, 0, 0, 55))
            draw.rounded_rectangle([px0, cur_y, px0 + pw, cur_y + ph], radius=14, fill=(250, 245, 232, 252), outline=(180, 83, 9, 220), width=2)
        else:
            draw.rounded_rectangle([px0 + 3, cur_y + 4, px0 + pw + 3, cur_y + ph + 4], radius=16, fill=(0, 0, 0, 48))
            draw.rounded_rectangle([px0, cur_y, px0 + pw, cur_y + ph], radius=16, fill=(24, 24, 27, 245))

        wx = px0 + 24
        wy = cur_y + 10
        for g_idx, w in row:
            if w in SUPPORTED_EMOJIS:
                draw_inline_emoji_icon(draw, w, wx + 14, wy + 18, size=28)
                wx += 36
                continue

            clean_w = re.sub(r"[^\w]", "", w.lower())
            is_emph = clean_w in emphasis_set or (w.isupper() and len(clean_w) >= 4)
            w_anim = anim_map.get(clean_w, {"animation": "scale-bounce" if is_emph else "none", "intensity": 1.3 if is_emph else 1.12})
            intensity = float(w_anim.get("intensity", 1.25))

            is_active = g_idx == active_idx
            is_spoken = g_idx < active_idx

            # Per-word animation & exit settle computation
            y_off = 0
            font_use = f_sub
            if is_active:
                bounce = math.sin(word_sub_progress * math.pi)
                if is_slide_up:
                    y_off = int((1.0 - ease_out_cubic(min(1.0, word_sub_progress * 1.8))) * 14)
                elif w_anim["animation"] in ("scale-bounce", "pop-rotate") or is_emph:
                    scaled_sz = min(44, int(round(32 * (1.0 + (intensity - 1.0) * bounce))))
                    font_use = load_font(scaled_sz, bold=True, serif=is_handwritten, mono=is_glitch)
                    y_off = -int(round((scaled_sz - 32) * 0.55))
                else:
                    y_off = -int(round(4 * bounce))
            elif is_spoken:
                # Subtle spoken-word exit settle
                y_off = 1

            ww = int(draw.textlength(w, font=font_use))

            if is_active:
                if is_glitch:
                    # Chromatic RGB split + scanline jitter
                    jx = ((local_frame * 3) % 5) - 2
                    draw.rounded_rectangle([wx - 8 + jx, wy - 3 + y_off, wx + ww + 8 + jx, wy + 40 + y_off], radius=8, fill=(24, 24, 32, 255), outline=(*style_accent, 255), width=2)
                    draw.text((wx - 3 + jx, wy + y_off), w, fill=(236, 72, 153, 220), font=font_use)
                    draw.text((wx + 3 + jx, wy + y_off), w, fill=(56, 189, 248, 220), font=font_use)
                    draw.text((wx + jx, wy + y_off), w, fill=(255, 255, 255, 255), font=font_use)
                elif is_neon:
                    draw.rounded_rectangle([wx - 8, wy - 3 + y_off, wx + ww + 8, wy + 40 + y_off], radius=10, fill=(*style_accent, 65), outline=(*style_accent, 255), width=2)
                    draw.text((wx, wy + y_off), w, fill=(255, 255, 255, 255), font=font_use)
                elif is_handwritten:
                    draw.rounded_rectangle([wx - 6, wy - 2 + y_off, wx + ww + 6, wy + 38 + y_off], radius=8, fill=(*style_accent, 235))
                    draw.text((wx, wy + y_off), w, fill=(28, 24, 18, 255), font=font_use)
                    draw.line([(wx, wy + 36 + y_off), (wx + ww, wy + 34 + y_off)], fill=(180, 83, 9, 255), width=3)
                else:
                    pill_pad = 10 if is_emph else 8
                    draw.rounded_rectangle(
                        [wx - pill_pad, wy - 4 + y_off, wx + ww + pill_pad, wy + 40 + y_off],
                        radius=10,
                        fill=(*style_accent, 255),
                    )
                    draw.text((wx, wy + y_off), w, fill=(24, 24, 27, 255), font=font_use)
            else:
                if is_handwritten:
                    txt_col = (40, 34, 28, 220 if is_spoken else 145)
                elif is_spoken:
                    # Spoken exit state: slightly dimmed warm white
                    txt_col = (212, 218, 228, 215)
                elif is_emph:
                    txt_col = (*style_accent, 245)
                else:
                    txt_col = (255, 255, 255, 245)
                draw.text((wx, wy + y_off), w, fill=txt_col, font=font_use)

            wx += int(draw.textlength(w + " ", font=f_sub))
        # Alternate vertical gap slightly so consecutive caption rows don't feel metronomic.
        cur_y += ph + 10 + (6 if len(pill_rows) > 1 else 0)


# ============================================================================
# SECTION 3.2: TRUE 3D CAMERA ORBIT, DYNAMIC LIGHTING & DEPTH INTERACTION
# ============================================================================


# ============================================================================
# REAL BINARY glTF 2.0 (.glb) 3D MESH PARSER & BLINN-PHONG PROJECTOR
# ============================================================================
import struct as _struct

@lru_cache(maxsize=24)
def _load_glb_meshes(glb_filename: str) -> list[tuple[str, np.ndarray, np.ndarray, np.ndarray]]:
    """
    Loads a binary glTF 2.0 (.glb) model from `reels-templates/assets/models/`
    and returns a list of `(mesh_name, vertices_Nx3, normals_Nx3, triangles_Mx3)`.
    """
    try:
        model_p = Path(__file__).resolve().parent.parent / "assets" / "models" / glb_filename
        if not model_p.is_file():
            return []
        data = model_p.read_bytes()
        if len(data) < 28:
            return []
        magic, _ver, _total_len = _struct.unpack("<III", data[:12])
        if magic != 0x46546C67:  # 'glTF'
            return []
        c0_len, _c0_type = _struct.unpack("<II", data[12:20])
        gltf = json.loads(data[20 : 20 + c0_len].decode("utf-8"))
        bin_off = 20 + c0_len + 8
        bin_buf = data[bin_off:]
        meshes = []
        for m in gltf.get("meshes", []):
            m_name = str(m.get("name", "Mesh"))
            for prim in m.get("primitives", []):
                attrs = prim.get("attributes", {})
                if "POSITION" not in attrs or "indices" not in prim:
                    continue
                pos_acc = gltf["accessors"][attrs["POSITION"]]
                pos_bv = gltf["bufferViews"][pos_acc["bufferView"]]
                pos_start = int(pos_bv.get("byteOffset", 0)) + int(pos_acc.get("byteOffset", 0))
                verts = np.frombuffer(
                    bin_buf, dtype=np.float32, count=int(pos_acc["count"]) * 3, offset=pos_start
                ).reshape(-1, 3).copy()

                if "NORMAL" in attrs:
                    norm_acc = gltf["accessors"][attrs["NORMAL"]]
                    norm_bv = gltf["bufferViews"][norm_acc["bufferView"]]
                    norm_start = int(norm_bv.get("byteOffset", 0)) + int(norm_acc.get("byteOffset", 0))
                    norms = np.frombuffer(
                        bin_buf, dtype=np.float32, count=int(norm_acc["count"]) * 3, offset=norm_start
                    ).reshape(-1, 3).copy()
                else:
                    norms = np.zeros_like(verts)
                    norms[:, 2] = 1.0

                idx_acc = gltf["accessors"][prim["indices"]]
                idx_bv = gltf["bufferViews"][idx_acc["bufferView"]]
                idx_start = int(idx_bv.get("byteOffset", 0)) + int(idx_acc.get("byteOffset", 0))
                idx_dtype = np.uint16 if int(idx_acc.get("componentType", 5123)) == 5123 else np.uint32
                tris = np.frombuffer(
                    bin_buf, dtype=idx_dtype, count=int(idx_acc["count"]), offset=idx_start
                ).reshape(-1, 3).copy()
                meshes.append((m_name, verts, norms, tris))
        return meshes
    except Exception:
        return []


def render_glb_3d_mesh(
    draw,
    glb_filename: str,
    cx: float,
    cy: float,
    scale: float,
    yaw: float,
    pitch: float,
    base_rgb: tuple[int, int, int],
    rim_rgb: tuple[int, int, int] = (248, 250, 252),
    light_angle_deg: float = -35.0,
    alpha: int = 235,
    part_colors: dict[str, tuple[int, int, int]] | None = None,
) -> bool:
    """
    Projects and renders a true 3D `.glb` triangle mesh with painter's algorithm z-sorting,
    backface culling, and Blinn-Phong + Fresnel rim lighting onto `draw`.
    """
    meshes = _load_glb_meshes(glb_filename)
    if not meshes:
        return False

    cy_m, sy_m = math.cos(yaw), math.sin(yaw)
    cx_m, sx_m = math.cos(pitch), math.sin(pitch)
    rot_y = np.array([[cy_m, 0.0, sy_m], [0.0, 1.0, 0.0], [-sy_m, 0.0, cy_m]], dtype=np.float32)
    rot_x = np.array([[1.0, 0.0, 0.0], [0.0, cx_m, -sx_m], [0.0, sx_m, cx_m]], dtype=np.float32)
    rot = rot_x @ rot_y

    l_rad = math.radians(light_angle_deg)
    light_dir = np.array([math.cos(l_rad) * 0.65, math.sin(l_rad) * 0.65, 0.72], dtype=np.float32)
    light_dir /= max(1e-6, float(np.linalg.norm(light_dir)))
    view_dir = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    half_vec = light_dir + view_dir
    half_vec /= max(1e-6, float(np.linalg.norm(half_vec)))

    all_polys = []
    fov = 520.0
    cam_dist = 4.2

    for m_name, verts, norms, tris in meshes:
        p_col = (part_colors or {}).get(m_name, base_rgb)
        rv = verts @ rot.T
        rn = norms @ rot.T
        persp = fov / np.maximum(1.2, cam_dist - rv[:, 2])
        sx = cx + rv[:, 0] * scale * persp / (fov / cam_dist)
        sy = cy - rv[:, 1] * scale * persp / (fov / cam_dist)

        t_v0 = rv[tris[:, 0]]
        t_v1 = rv[tris[:, 1]]
        t_v2 = rv[tris[:, 2]]
        fn = np.cross(t_v1 - t_v0, t_v2 - t_v0)
        fn_len = np.linalg.norm(fn, axis=1, keepdims=True)
        fn = fn / np.maximum(1e-6, fn_len)

        # Average vertex normal with face normal for smooth shading
        vn_avg = (rn[tris[:, 0]] + rn[tris[:, 1]] + rn[tris[:, 2]]) / 3.0
        vn_len = np.linalg.norm(vn_avg, axis=1, keepdims=True)
        n_use = np.where(vn_len > 1e-4, vn_avg / np.maximum(1e-6, vn_len), fn)

        # Keep front-facing or slightly grazing triangles
        vis_mask = (fn[:, 2] >= -0.15) | (n_use[:, 2] >= -0.10)
        if not np.any(vis_mask):
            vis_mask = np.ones(len(tris), dtype=bool)

        vis_indices = np.nonzero(vis_mask)[0]
        z_depths = (t_v0[vis_indices, 2] + t_v1[vis_indices, 2] + t_v2[vis_indices, 2]) / 3.0
        n_vis = n_use[vis_indices]

        ndotl = np.clip(n_vis @ light_dir, 0.0, 1.0)
        ndoth = np.clip(n_vis @ half_vec, 0.0, 1.0) ** 18.0
        fresnel = (1.0 - np.clip(np.abs(n_vis[:, 2]), 0.0, 1.0)) ** 2.2

        amb = 0.34
        diff = 0.62 * ndotl
        spec = 0.38 * ndoth + 0.25 * fresnel

        r_arr = np.clip(p_col[0] * (amb + diff) + rim_rgb[0] * spec, 0, 255).astype(np.uint8)
        g_arr = np.clip(p_col[1] * (amb + diff) + rim_rgb[1] * spec, 0, 255).astype(np.uint8)
        b_arr = np.clip(p_col[2] * (amb + diff) + rim_rgb[2] * spec, 0, 255).astype(np.uint8)

        for k_i, tri_idx in enumerate(vis_indices):
            i0, i1, i2 = tris[tri_idx]
            pts = [(float(sx[i0]), float(sy[i0])), (float(sx[i1]), float(sy[i1])), (float(sx[i2]), float(sy[i2]))]
            col_rgba = (int(r_arr[k_i]), int(g_arr[k_i]), int(b_arr[k_i]), alpha)
            all_polys.append((float(z_depths[k_i]), pts, col_rgba))

    if not all_polys:
        return False

    all_polys.sort(key=lambda item: item[0])
    for _z, pts, col_rgba in all_polys:
        draw.polygon(pts, fill=col_rgba)
    return True


def draw_true_3d_neuron_network(
    img: Image.Image,
    draw,
    cx: int,
    cy: int,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int],
    scale_factor: float = 1.0,
    scene: dict = None,
):
    t = local_frame / max(1.0, float(fps))
    enter = min(1.0, max(0.15, spring_ease(local_frame, delay=0, dur=14))) * scale_factor
    sc = scene or {}

    branches_3d = [
        (-255, -85, -70, True),
        (265, -75, 65, True),
        (-220, 105, 85, False),
        (240, 110, -60, False),
        (-95, -145, 50, False),
        (115, 145, 45, False),
        (-310, 12, 30, True),
        (315, -10, -40, True),
    ]

    orbit_speed = float(sc.get("cameraOrbitSpeed", 0.85))
    yaw_base = float(sc.get("cameraOrbitYaw", 0.0))
    pitch_base = float(sc.get("cameraOrbitPitch", 0.0))
    yaw = yaw_base + math.sin(t * orbit_speed) * 0.34
    pitch = pitch_base + math.cos(t * (orbit_speed * 0.72)) * 0.16
    cos_y, sin_y = math.cos(yaw), math.sin(yaw)
    cos_x, sin_x = math.cos(pitch), math.sin(pitch)

    # Dynamic orbiting point light angle (Section 3.2)
    light_deg = int(round(-35 + math.sin(t * 1.2) * 45))

    fov = float(sc.get("cameraFov", 620.0))
    cam_z = 520.0

    def project_3d(x, y, z):
        rx = x * cos_y + z * sin_y
        rz0 = -x * sin_y + z * cos_y
        ry = y * cos_x - rz0 * sin_x
        rz = y * sin_x + rz0 * cos_x
        persp = fov / max(180.0, cam_z - rz)
        sx = cx + rx * enter * persp
        sy = cy + ry * enter * persp
        return sx, sy, rz, persp

    projected_branches = []
    for idx, (bx, by, bz, is_myelinated) in enumerate(branches_3d):
        sx, sy, rz, persp = project_3d(bx, by, bz)
        projected_branches.append((rz, idx, sx, sy, persp, is_myelinated))
    projected_branches.sort(key=lambda item: item[0])

    soma_sx, soma_sy, soma_z, soma_p = project_3d(0.0, 0.0, 0.0)
    soma_drawn = False

    for rz, idx, sx, sy, persp, is_myelinated in projected_branches:

        if not soma_drawn and rz >= soma_z:
            soma_r = int(round(56 * enter * soma_p))
            draw.ellipse([soma_sx - soma_r - 22, soma_sy - soma_r - 22, soma_sx + soma_r + 22, soma_sy + soma_r + 22], fill=(*accent_rgb, 48))
            paste_3d_sphere(img, soma_sx, soma_sy, soma_r, accent_rgb, (224, 242, 254), light_angle_deg=light_deg)
            render_glb_3d_mesh(
                draw, "neuron.glb", soma_sx, soma_sy, scale=soma_r * 1.15,
                yaw=yaw, pitch=pitch, base_rgb=accent_rgb, rim_rgb=(224, 242, 254),
                light_angle_deg=light_deg, alpha=210
            )
            paste_3d_sphere(img, soma_sx - soma_r * 0.16, soma_sy - soma_r * 0.14, max(8, int(soma_r * 0.42)), (240, 253, 250), accent_rgb, light_angle_deg=light_deg)
            soma_drawn = True

        depth_shade = max(0.55, min(1.15, 0.88 + rz / 320.0))
        tube_rgb = (
            min(255, int(accent_rgb[0] * 0.65 * depth_shade + 30)),
            min(255, int(accent_rgb[1] * 0.72 * depth_shade + 40)),
            min(255, int(accent_rgb[2] * 0.80 * depth_shade + 55)),
        )
        draw_3d_tube_segment(
            img,
            soma_sx,
            soma_sy,
            sx,
            sy,
            r1=15 * enter * soma_p,
            r2=6 * enter * persp,
            base_rgb=tube_rgb,
            rim_rgb=(224, 242, 254),
            steps=16,
            light_angle_deg=light_deg,
        )

        if is_myelinated:
            for m0, m1 in ((0.26, 0.46), (0.56, 0.76)):
                mx0 = soma_sx + (sx - soma_sx) * m0
                my0 = soma_sy + (sy - soma_sy) * m0
                mx1 = soma_sx + (sx - soma_sx) * m1
                my1 = soma_sy + (sy - soma_sy) * m1
                mr = max(6, int(round(12 * enter * persp)))
                draw_3d_tube_segment(
                    img, mx0, my0, mx1, my1, r1=mr, r2=mr * 0.92,
                    base_rgb=(217, 119, 6), rim_rgb=(254, 240, 138), steps=6, light_angle_deg=light_deg
                )

        term_r = max(8, int(round(16 * enter * persp)))
        paste_3d_sphere(img, sx, sy, term_r, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)

        pulse_u = (t * 0.95 + idx * 0.21) % 1.0
        px = soma_sx + (sx - soma_sx) * pulse_u
        py = soma_sy + (sy - soma_sy) * pulse_u
        pr = max(5, int(round(9 * enter * persp)))
        draw.ellipse([px - pr * 2, py - pr * 2, px + pr * 2, py + pr * 2], fill=(250, 204, 21, 90))
        paste_3d_sphere(img, px, py, pr, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    if not soma_drawn:
        soma_r = int(round(56 * enter * soma_p))
        paste_3d_sphere(img, soma_sx, soma_sy, soma_r, accent_rgb, (224, 242, 254), light_angle_deg=light_deg)


def draw_true_3d_engine_cutaway(img: Image.Image, draw, diag_cy: int, local_frame: int, fps: float):
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-30 + math.sin(t * 2.0) * 30))
    orbit_dx = int(round(math.sin(t * 0.9) * 8))

    draw_3d_extruded_box(
        draw,
        x0=155 + orbit_dx,
        y0=diag_cy - 135,
        x1=465 + orbit_dx,
        y1=diag_cy + 135,
        dx=28 - orbit_dx // 2,
        dy=-24,
        front_rgb=(203, 213, 225),
        top_rgb=(232, 238, 246),
        side_rgb=(148, 163, 184),
        edge_rgb=(51, 65, 85),
    )
    draw_3d_extruded_box(
        draw,
        x0=455 + orbit_dx,
        y0=diag_cy - 105,
        x1=755 + orbit_dx,
        y1=diag_cy + 85,
        dx=26 - orbit_dx // 2,
        dy=-22,
        front_rgb=(186, 198, 214),
        top_rgb=(220, 228, 238),
        side_rgb=(128, 142, 162),
        edge_rgb=(51, 65, 85),
    )

    for fy in range(diag_cy - 88, diag_cy + 72, 22):
        draw.line([(470, fy), (655, fy)], fill=(71, 85, 105, 255), width=5)
        draw.line([(470, fy - 2), (655, fy - 2)], fill=(241, 245, 249, 220), width=2)

    draw.rounded_rectangle([185, diag_cy - 102, 442, diag_cy + 105], radius=22, fill=(51, 65, 85, 255), outline=(30, 41, 59, 255), width=3)
    draw.rectangle([440, diag_cy - 66, 725, diag_cy + 42], fill=(38, 48, 64, 255), outline=(30, 41, 59, 255), width=2)

    oil_y = diag_cy + 30
    draw.polygon([(190, oil_y), (436, oil_y), (436, diag_cy + 100), (190, diag_cy + 100)], fill=(180, 83, 9, 242), outline=(120, 53, 15, 255))
    draw.ellipse([192, oil_y - 10, 434, oil_y + 10], fill=(245, 158, 11, 255), outline=(254, 240, 138, 220), width=2)

    cyl_filter = make_shaded_3d_cylinder(52, 46, 8, (148, 163, 184), (226, 232, 240), (255, 255, 255), metallic=0.85)
    img.paste(cyl_filter, (335, diag_cy + 34), cyl_filter)

    piston_dx = int(math.sin(t * 14.0) * 38)
    crank_cx, crank_cy = 285, diag_cy - 12
    paste_3d_sphere(img, crank_cx, crank_cy, 52, (100, 116, 139), (226, 232, 240), light_angle_deg=light_deg)
    paste_3d_sphere(img, crank_cx, crank_cy, 20, (51, 65, 85), (203, 213, 225), light_angle_deg=light_deg)

    piston_x = 525 + piston_dx
    draw_3d_tube_segment(
        img,
        crank_cx + math.cos(t * 14.0) * 24,
        crank_cy + math.sin(t * 14.0) * 24,
        piston_x,
        diag_cy - 12,
        r1=12,
        r2=10,
        base_rgb=(148, 163, 184),
        rim_rgb=(241, 245, 249),
        steps=14,
        light_angle_deg=light_deg,
    )

    piston_cyl = make_shaded_3d_cylinder(82, 86, 12, (203, 213, 225), (241, 245, 249), (255, 255, 255), metallic=0.92)
    piston_rot = piston_cyl.rotate(-90, expand=True)
    img.paste(piston_rot, (piston_x - 42, diag_cy - 56), piston_rot)
    paste_3d_sphere(img, piston_x - 4, diag_cy - 12, 12, (71, 85, 105), (226, 232, 240), light_angle_deg=light_deg)

    glow_r = int(24 + 8 * math.sin(t * 14.0))
    paste_3d_sphere(img, piston_x + 68, diag_cy - 12, glow_r, (234, 88, 12), (254, 240, 138), light_angle_deg=light_deg)

    flow_u = min(1.0, local_frame / 24.0)
    for d_i in range(9):
        u_d = (d_i / 8.0) * flow_u
        ox = 385 + u_d * 200
        oy = diag_cy + 68
        paste_3d_sphere(img, ox, oy, 7, (217, 119, 6), (254, 240, 138), light_angle_deg=light_deg)
    if flow_u > 0.3:
        for d_i in range(6):
            u_v = (d_i / 5.0) * ((flow_u - 0.3) / 0.7)
            ox = 585
            oy = diag_cy + 68 - u_v * 140
            paste_3d_sphere(img, ox, oy, 7, (245, 158, 11), (254, 240, 138), light_angle_deg=light_deg)
    render_glb_3d_mesh(
        draw, "crankshaft.glb", crank_cx, crank_cy, scale=46.0,
        yaw=t * 3.2, pitch=0.25, base_rgb=(148, 163, 184), rim_rgb=(241, 245, 249),
        light_angle_deg=light_deg, alpha=215
    )
    render_glb_3d_mesh(
        draw, "engine_piston.glb", piston_x, diag_cy - 12, scale=44.0,
        yaw=0.4, pitch=1.57, base_rgb=(203, 213, 225), rim_rgb=(255, 255, 255),
        light_angle_deg=light_deg, alpha=195
    )


def draw_true_3d_coffee_stage(img: Image.Image, draw, diag_cy: int, local_frame: int, fps: float):
    t = local_frame / max(1.0, float(fps))
    cx = 480
    light_deg = int(round(-35 + math.sin(t * 1.1) * 40))

    draw.ellipse([cx - 210, diag_cy + 82, cx + 210, diag_cy + 146], fill=(68, 42, 24, 55))
    saucer = make_shaded_3d_cylinder(380, 26, 34, (214, 198, 178), (245, 238, 226), (255, 255, 255), metallic=0.65)
    img.paste(saucer, (cx - saucer.width // 2, diag_cy + 42), saucer)

    # Background orbiting coffee beans (behind the cup, z < 0)
    for b_i in range(5):
        ang = t * 1.1 + b_i * (math.pi * 2.0 / 5.0)
        if math.sin(ang) < 0:
            bx = cx + math.cos(ang) * 235
            by = diag_cy - 15 + math.sin(ang) * 65
            br = int(16 + 4 * math.sin(ang))
            paste_3d_sphere(img, bx, by, br, (68, 34, 16), (217, 119, 6), light_angle_deg=light_deg)
            draw.line([(bx - br * 0.5, by - 3), (bx + br * 0.5, by + 3)], fill=(28, 14, 6, 230), width=3)

    for a_deg in range(-75, 85, 12):
        rad = math.radians(a_deg)
        hx = cx + 135 + math.cos(rad) * 48
        hy = diag_cy - 8 + math.sin(rad) * 54
        paste_3d_sphere(img, hx, hy, 12, (214, 198, 178), (255, 255, 255), light_angle_deg=light_deg)

    cup = make_shaded_3d_cylinder(276, 155, 42, (120, 53, 15), (180, 83, 9), (254, 243, 199), metallic=0.82)
    img.paste(cup, (cx - cup.width // 2, diag_cy - 102), cup)

    draw.ellipse([cx - 124, diag_cy - 92, cx + 124, diag_cy - 22], fill=(194, 106, 28, 255), outline=(245, 235, 218, 255), width=4)
    draw.ellipse([cx - 78, diag_cy - 76, cx + 78, diag_cy - 38], fill=(217, 132, 45, 255), outline=(254, 243, 199, 220), width=3)
    draw.ellipse([cx - 32, diag_cy - 64, cx + 32, diag_cy - 50], fill=(254, 243, 199, 235))

    # Foreground orbiting coffee beans (in front of the cup, z >= 0)
    for b_i in range(5):
        ang = t * 1.1 + b_i * (math.pi * 2.0 / 5.0)
        if math.sin(ang) >= 0:
            bx = cx + math.cos(ang) * 235
            by = diag_cy - 15 + math.sin(ang) * 65
            br = int(19 + 5 * math.sin(ang))
            paste_3d_sphere(img, bx, by, br, (68, 34, 16), (217, 119, 6), light_angle_deg=light_deg)
            draw.line([(bx - br * 0.5, by - 3), (bx + br * 0.5, by + 3)], fill=(28, 14, 6, 230), width=3)

    for s_i in range(6):
        su = (t * 0.55 + s_i * 0.17) % 1.0
        sx = cx - 45 + (s_i % 3) * 45 + math.sin(t * 3.0 + s_i) * 18
        sy = (diag_cy - 95) - su * 115
        sr = int(14 + su * 16)
        alpha = int((1.0 - su) * 95)
        draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(255, 255, 255, alpha))
    render_glb_3d_mesh(
        draw, "bean.glb", cx - 185, diag_cy + 48, scale=42.0,
        yaw=t * 1.4, pitch=0.45, base_rgb=(92, 45, 18), rim_rgb=(217, 119, 6),
        light_angle_deg=light_deg, alpha=235,
        part_colors={"RoastedBeanShell": (92, 45, 18), "CenterCrease": (38, 18, 8)},
    )
    render_glb_3d_mesh(
        draw, "bean.glb", cx + 195, diag_cy + 44, scale=38.0,
        yaw=-t * 1.2 + 1.0, pitch=-0.35, base_rgb=(92, 45, 18), rim_rgb=(217, 119, 6),
        light_angle_deg=light_deg, alpha=235,
        part_colors={"RoastedBeanShell": (92, 45, 18), "CenterCrease": (38, 18, 8)},
    )
    render_glb_3d_mesh(
        draw, "steam.glb", cx, diag_cy - 135 - int(math.sin(t * 2.5) * 8), scale=68.0,
        yaw=math.sin(t * 1.5) * 0.4, pitch=0.1, base_rgb=(245, 238, 230), rim_rgb=(255, 255, 255),
        light_angle_deg=light_deg, alpha=110
    )


# ============================================================================
# POINT 1 & POINT 2: MULTI-SHOT CAMERA CUTS & CONTEXTUAL 3D STAGES
# ============================================================================


def apply_cinematic_camera_transform(
    img: Image.Image,
    local_frame: int,
    dur_frames: int,
    fps: float,
    scene: dict = None,
) -> Image.Image:
    """
    Applies real-time continuous camera movement (dolly zoom, pan X/Y, orbital sway,
    and intra-scene 3-shot focal cuts) to the rendered canvas so every scene has
    genuine cinematic camera motion instead of static text+HUD only.
    """
    sc = scene or {}
    cam_cfg = sc.get("camera") if isinstance(sc.get("camera"), dict) else {}
    preset = str(sc.get("cameraPreset") or cam_cfg.get("preset") or "dolly-push").lower()
    cam_cut = compute_intrascene_camera_cut(local_frame, dur_frames, fps, sc)
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))

    # Compute continuous zoom + pan trajectory per preset
    if preset == "cinematic-orbit":
        zoom = 1.04 + 0.05 * math.sin(u * math.pi)
        pan_x = int(round(math.sin(t * 1.35) * 22))
        pan_y = int(round(math.cos(t * 1.10) * 14))
    elif preset == "focus-pull":
        # Smooth push-in on Shot 1, wide settle on Shot 2, tight focus pull on Shot 3
        zoom = 1.0 + (cam_cut["zoom"] - 1.0) * 0.42
        pan_x = int(round(math.sin(u * math.pi * 2.0) * 14))
        pan_y = cam_cut["y_shift"]
    elif preset == "macro-sweep":
        zoom = 1.06 + 0.04 * ease_in_out_cubic(u)
        pan_x = int(round((u - 0.5) * 36))
        pan_y = int(round(math.sin(t * 1.6) * 10))
    elif preset == "breathing-float":
        zoom = 1.02 + 0.025 * math.sin(t * 2.2)
        pan_x = int(round(math.sin(t * 1.1) * 10))
        pan_y = int(round(math.cos(t * 1.6) * 14))
    elif preset == "crane-up":
        zoom = 1.05 - 0.03 * u
        pan_x = 0
        pan_y = int(round((0.5 - u) * 34))
    else:
        # Default dolly-push
        zoom = 1.01 + 0.065 * ease_in_out_cubic(u)
        pan_x = int(round(math.sin(t * 1.0) * 12))
        pan_y = int(round((0.5 - u) * 18))

    if abs(zoom - 1.0) < 0.004 and pan_x == 0 and pan_y == 0:
        return img

    w, h = img.size
    zw = max(w, int(round(w * max(1.02, zoom))))
    zh = max(h, int(round(h * max(1.02, zoom))))
    scaled = img.resize((zw, zh), Image.Resampling.BILINEAR)
    max_dx = max(0, (zw - w) // 2)
    max_dy = max(0, (zh - h) // 2)
    cx0 = max(0, min(zw - w, max_dx + max(-max_dx, min(max_dx, pan_x))))
    cy0 = max(0, min(zh - h, max_dy + max(-max_dy, min(max_dy, pan_y))))
    return scaled.crop((cx0, cy0, cx0 + w, cy0 + h))


def compute_intrascene_camera_cut(local_frame: int, dur_frames: int, fps: float, scene: dict = None) -> dict:
    """
    Point 2 Upgrade:
    Automatically divides a scene into 3 dynamic sub-shot camera cuts to eliminate static template fatigue:
    - Shot 1 (0% - 28%): CAM 01 · MACRO HOOK 85mm (1.22x focal zoom on 3D centerpiece)
    - Shot 2 (28% - 72%): CAM 02 · WIDE ORBIT 35mm (1.00x wide establish with orbital motion)
    - Shot 3 (72% - 100%): CAM 03 · FOCUS PULL 50mm (1.12x focus pull toward metrics & evidence cards)
    """
    u = local_frame / max(1.0, float(dur_frames - 1))
    if u < 0.28:
        sub_u = u / 0.28
        zoom = 1.24 - 0.06 * ease_out_cubic(sub_u)
        shot_id = 1
        shot_label = "CAM 01 · MACRO 85mm"
        y_shift = 10
    elif u < 0.72:
        sub_u = (u - 0.28) / 0.44
        zoom = 1.18 - 0.18 * ease_out_cubic(min(1.0, sub_u * 2.5))
        shot_id = 2
        shot_label = "CAM 02 · WIDE 35mm"
        y_shift = 0
    else:
        sub_u = (u - 0.72) / 0.28
        zoom = 1.00 + 0.12 * ease_out_cubic(min(1.0, sub_u * 2.2))
        shot_id = 3
        shot_label = "CAM 03 · FOCUS 50mm"
        y_shift = -8
    return {
        "shot_id": shot_id,
        "shot_label": shot_label,
        "zoom": zoom,
        "y_shift": y_shift,
        "u": u,
    }


def draw_camera_hud_pill(draw, right_x: int, top_y: int, cam_info: dict, accent_rgb: tuple[int, int, int], light_bg: bool = False):
    """Draws a subtle, high-craft cinema camera cut indicator pill in the upper-right header zone."""
    if os.environ.get("SHOTCRAFT_DEBUG_OVERLAYS") != "1":
        return
    f_cam = load_font(16, bold=True, mono=True)
    lbl = cam_info["shot_label"]
    cw = int(draw.textlength(lbl, font=f_cam)) + 42
    cx0 = right_x - cw
    cy0 = top_y + 42
    bg_c = (28, 27, 24, 215) if light_bg else (15, 23, 42, 210)
    draw.rounded_rectangle([cx0, cy0, right_x, cy0 + 28], radius=14, fill=bg_c, outline=(*accent_rgb, 175), width=1)
    # Pulsing red/accent REC dot
    dot_c = (239, 68, 68, 255) if cam_info["shot_id"] == 1 else (*accent_rgb, 255)
    draw.ellipse([cx0 + 11, cy0 + 9, cx0 + 21, cy0 + 19], fill=dot_c)
    draw.text((cx0 + 27, cy0 + 5), lbl, fill=(248, 250, 252, 240), font=f_cam)


def draw_true_3d_rotary_turbine_cutaway(
    img: Image.Image,
    draw,
    diag_cy: int,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int] = (29, 122, 70),
    scale_factor: float = 1.0,
):
    """
    Context-Aware 3D High-Speed Rotary Blade / Turbine / Mechanical Deck Cutaway
    (Used for lawnmowers, turbines, fans, electric motors, rotors, and cutting mechanisms).
    """
    t = local_frame / max(1.0, float(fps))
    cx = 480
    light_deg = int(round(-35 + math.sin(t * 1.8) * 35))

    # Outer protective deck housing (3D metallic ring + cutaway deck)
    deck_w = int(420 * scale_factor)
    deck_h = int(140 * scale_factor)
    draw.ellipse(
        [cx - deck_w // 2 - 20, diag_cy - deck_h // 2 + 18, cx + deck_w // 2 + 20, diag_cy + deck_h // 2 + 52],
        fill=(15, 23, 42, 55),
    )
    housing = make_shaded_3d_cylinder(deck_w, 54, 48, (71, 85, 105), (148, 163, 184), (241, 245, 249), metallic=0.88)
    img.paste(housing, (cx - housing.width // 2, diag_cy - 34), housing)

    # Inner vortex chamber
    draw.ellipse([cx - 175, diag_cy - 32, cx + 175, diag_cy + 58], fill=(24, 34, 48, 255), outline=(*accent_rgb, 220), width=3)

    # Spinning 3D high-speed cutting blades (4-blade rotor with motion trails)
    spin_ang = t * 11.5
    for b_i in range(4):
        ang = spin_ang + b_i * (math.pi * 0.5)
        bx1 = cx + math.cos(ang) * 32
        by1 = diag_cy + 12 + math.sin(ang) * 14
        bx2 = cx + math.cos(ang) * 158 * scale_factor
        by2 = diag_cy + 12 + math.sin(ang) * 42 * scale_factor
        draw_3d_tube_segment(
            img, bx1, by1, bx2, by2, r1=11, r2=6,
            base_rgb=(203, 213, 225), rim_rgb=(255, 255, 255), light_angle_deg=light_deg
        )
        # Glowing airflow / cutting arc trail
        trail_ang = ang - 0.35
        tx = cx + math.cos(trail_ang) * 148 * scale_factor
        ty = diag_cy + 12 + math.sin(trail_ang) * 38 * scale_factor
        draw.line([(bx2, by2), (tx, ty)], fill=(*accent_rgb, 190), width=4)

    # Upper electric/combustion drive motor cylinder shaft
    motor_cyl = make_shaded_3d_cylinder(132, 92, 22, accent_rgb, (226, 232, 240), (255, 255, 255), metallic=0.85)
    img.paste(motor_cyl, (cx - motor_cyl.width // 2, diag_cy - 118), motor_cyl)
    paste_3d_sphere(img, cx, diag_cy + 10, 26, (226, 232, 240), accent_rgb, light_angle_deg=light_deg)


def draw_solar_photovoltaic_cutaway_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (234, 179, 8), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Solar Photovoltaic Cutaway: Sun rays & photons -> N/P Silicon Wafer -> Inverter -> AC Grid."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.5) * 30))
    f_lbl = load_font(16, bold=True)

    # 1. Sun emitter (top-left) + animated golden photon rays hitting the solar panel
    sun_x, sun_y = cx - 235, cy - 82
    for r_g, a_g in ((52, 45), (38, 95)):
        draw.ellipse([sun_x - r_g, sun_y - r_g, sun_x + r_g, sun_y + r_g], fill=(250, 204, 21, a_g))
    paste_3d_sphere(img, sun_x, sun_y, 28, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # 2. 3D Layered Silicon Photovoltaic Panel in center-left (`N-Type` blue + `P-Type` slate)
    px0, py0 = cx - 155, cy - 18
    draw_3d_extruded_box(
        draw, px0, py0 + 22, px0 + 235, py0 + 62, 24, -18,
        front_rgb=(30, 58, 138), top_rgb=(59, 130, 246), side_rgb=(23, 37, 84), edge_rgb=(147, 197, 253)
    )
    draw_3d_extruded_box(
        draw, px0, py0 - 16, px0 + 235, py0 + 22, 24, -18,
        front_rgb=(37, 99, 235), top_rgb=(96, 165, 250), side_rgb=(29, 78, 216), edge_rgb=(224, 242, 254)
    )
    # Solar cell grid lines on top plane
    for gx in range(px0 + 35, px0 + 220, 42):
        draw.line([(gx, py0 - 16), (gx + 22, py0 - 34)], fill=(224, 242, 254, 210), width=2)
    draw.text((px0 + 18, py0 - 10), "LAPISAN SILIKON N / P", fill=(255, 255, 255, 245), font=f_lbl)

    # Photon rays & animated photon spheres striking panel
    for r_i in range(4):
        tx = px0 + 35 + r_i * 52
        ty = py0 - 20
        draw.line([(sun_x + 18, sun_y + 18), (tx, ty)], fill=(250, 204, 21, 145), width=3)
        pu = (t * 1.4 + r_i * 0.25) % 1.0
        ph_x = sun_x + 18 + (tx - (sun_x + 18)) * pu
        ph_y = sun_y + 18 + (ty - (sun_y + 18)) * pu
        paste_3d_sphere(img, ph_x, ph_y, 7, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # 3. DC -> AC Inverter Box & House Load on the right
    inv_x, inv_y = cx + 165, cy - 8
    draw_3d_tube_segment(
        img, px0 + 245, py0 + 8, inv_x - 48, inv_y + 8, r1=8, r2=8,
        base_rgb=(16, 185, 129), rim_rgb=(167, 243, 208), light_angle_deg=light_deg
    )
    # Electron flow pulse from panel to inverter
    eu = (t * 1.8) % 1.0
    ex = (px0 + 245) + ((inv_x - 48) - (px0 + 245)) * eu
    paste_3d_sphere(img, ex, py0 + 8, 9, (56, 189, 248), (255, 255, 255), light_angle_deg=light_deg)

    draw_3d_extruded_box(
        draw, inv_x - 48, inv_y - 42, inv_x + 68, inv_y + 54, 18, -14,
        front_rgb=(16, 185, 129), top_rgb=(52, 211, 153), side_rgb=(5, 150, 105), edge_rgb=(255, 255, 255)
    )
    draw.text((inv_x - 36, inv_y - 12), "INVERTER", fill=(10, 20, 16, 255), font=f_lbl)
    draw.text((inv_x - 34, inv_y + 12), "DC -> AC", fill=(255, 255, 255, 255), font=f_lbl)


def draw_food_chain_ecology_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (22, 163, 74), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Food-Chain & Trophic Ecology Stage: Producer -> Herbivore -> Carnivore -> Decomposer Cycle."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.4) * 30))
    f_lbl = load_font(16, bold=True)

    trophic_nodes = [
        (cx - 245, cy + 12, (34, 197, 94), "PRODUSEN", "Fotosintesis"),
        (cx - 82, cy - 38, (56, 189, 248), "HERBIVORA", "Konsumen I"),
        (cx + 85, cy - 38, (249, 115, 22), "KARNIVORA", "Predator"),
        (cx + 245, cy + 12, (168, 85, 247), "PENGURAI", "Nutrisi Tanah"),
    ]
    # Connect trophic chain + return nutrient arc underneath
    for i in range(3):
        x1, y1, _, _, _ = trophic_nodes[i]
        x2, y2, _, _, _ = trophic_nodes[i + 1]
        draw_3d_tube_segment(img, x1, y1, x2, y2, r1=9, r2=9, base_rgb=(71, 85, 105), rim_rgb=(226, 232, 240), light_angle_deg=light_deg)
        pu = (t * 1.2 + i * 0.33) % 1.0
        paste_3d_sphere(img, x1 + (x2 - x1) * pu, y1 + (y2 - y1) * pu, 8, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # Nutrient return loop at bottom from Decomposer back to Producer
    draw.arc([cx - 245, cy - 10, cx + 245, cy + 92], start=15, end=165, fill=(34, 197, 94, 195), width=4)

    for idx, (nx, ny, ncol, title_t, sub_t) in enumerate(trophic_nodes):
        bob = int(math.sin(t * 2.5 + idx) * 6)
        ny_b = ny + bob
        # 3D pedestal + sphere + trophic badge
        draw_3d_extruded_box(
            draw, nx - 44, ny_b - 28, nx + 44, ny_b + 28, 14, -10,
            front_rgb=ncol, top_rgb=tuple(min(255, c + 45) for c in ncol),
            side_rgb=tuple(max(20, int(c * 0.65)) for c in ncol), edge_rgb=(255, 255, 255)
        )
        paste_3d_sphere(img, nx, ny_b - 36, 22, ncol, (255, 255, 255), light_angle_deg=light_deg)
        tw = int(draw.textlength(title_t, font=f_lbl))
        draw.text((nx - tw // 2, ny_b - 8), title_t, fill=(10, 14, 24, 255), font=f_lbl)


def draw_water_thermodynamics_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (234, 88, 12), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Water Boiling & Thermodynamics Cutaway: Burner -> Conduction -> Convection Loop -> 100°C Steam."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.6) * 30))

    # 1. Bottom thermal burner flame ring
    for f_i in range(-120, 130, 30):
        fx = cx + f_i
        fh = int(22 + 8 * math.sin(t * 9.0 + f_i))
        draw.polygon([(fx - 12, cy + 98), (fx + 12, cy + 98), (fx, cy + 98 - fh)], fill=(249, 115, 22, 240))
        draw.polygon([(fx - 6, cy + 98), (fx + 6, cy + 98), (fx, cy + 98 - fh + 8)], fill=(56, 189, 248, 245))

    # 2. Cutaway metallic thermal vessel & water volume
    draw.rounded_rectangle([cx - 175, cy - 68, cx + 175, cy + 78], radius=22, fill=(30, 58, 138, 215), outline=(203, 213, 225, 255), width=5)
    draw.rounded_rectangle([cx - 165, cy - 32, cx + 165, cy + 68], radius=16, fill=(14, 116, 144, 235))

    # 3. Convection arrows (warm red rising in center, cool blue sinking at sides) + rising vapor bubbles
    for b_i in range(8):
        bu = (t * 0.95 + b_i * 0.13) % 1.0
        bx = cx - 105 + (b_i % 4) * 70 + int(math.sin(t * 4.0 + b_i) * 10)
        by = (cy + 58) - int(bu * 115)
        br = int(6 + bu * 10)
        b_col = (249, 115, 22) if bu < 0.35 else (56, 189, 248) if bu < 0.75 else (248, 250, 252)
        paste_3d_sphere(img, bx, by, br, b_col, (255, 255, 255), light_angle_deg=light_deg)

    # 4. 3D Steam mesh rising above boiling surface
    render_glb_3d_mesh(
        draw, "steam.glb", cx, cy - 95, scale=58.0,
        yaw=math.sin(t * 1.8) * 0.45, pitch=0.1, base_rgb=(226, 232, 240), rim_rgb=(255, 255, 255),
        light_angle_deg=light_deg, alpha=145
    )


def draw_combustion_fire_triangle_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (225, 29, 72), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Gas Stove Burner & Fire Triangle Cutaway: Venturi Air-Gas Mix -> Burner Ring -> Blue vs Red Flame."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.5) * 30))
    f_lbl = load_font(16, bold=True)

    # Left: Venturi mixing tube (`GAS LPG + OKSIGEN O2`)
    draw_3d_tube_segment(img, cx - 265, cy + 28, cx - 45, cy + 28, r1=18, r2=16, base_rgb=(100, 116, 139), rim_rgb=(226, 232, 240), light_angle_deg=light_deg)
    for p_i in range(5):
        pu = (t * 1.5 + p_i * 0.2) % 1.0
        px = (cx - 255) + pu * 195
        paste_3d_sphere(img, px, cy + 28, 7, (56, 189, 248) if p_i % 2 == 0 else (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # Center: 3D Brass Burner Head + Blue Complete Combustion Crown
    burner = make_shaded_3d_cylinder(185, 42, 24, (180, 83, 9), (245, 158, 11), (254, 240, 138), metallic=0.88)
    img.paste(burner, (cx - burner.width // 2, cy + 4), burner)
    for f_ang in range(-70, 75, 20):
        fx = cx + int(math.sin(math.radians(f_ang)) * 74)
        fh = int(38 + 10 * math.sin(t * 10.0 + f_ang))
        draw.polygon([(fx - 10, cy + 6), (fx + 10, cy + 6), (fx, cy + 6 - fh)], fill=(56, 189, 248, 235))
        draw.polygon([(fx - 5, cy + 6), (fx + 5, cy + 6), (fx, cy + 14 - fh)], fill=(224, 242, 254, 250))

    # Right: Fire Triangle 3D Nodes (`BAHAN BAKAR`, `OKSIGEN`, `PANAS`)
    tri_cx, tri_cy = cx + 195, cy - 5
    tri_pts = [(tri_cx, tri_cy - 68), (tri_cx - 68, tri_cy + 48), (tri_cx + 68, tri_cy + 48)]
    draw.polygon(tri_pts, fill=(225, 29, 72, 45), outline=(250, 204, 21, 235))
    for (tx, ty), tcol, tlbl in zip(tri_pts, [(239, 68, 68), (56, 189, 248), (250, 204, 21)], ["PANAS", "O2", "GAS"]):
        paste_3d_sphere(img, tx, ty, 18, tcol, (255, 255, 255), light_angle_deg=light_deg)
        draw.text((tx - 18, ty + 20), tlbl, fill=(248, 250, 252, 255), font=f_lbl)


def draw_software_api_architecture_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (37, 99, 235), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Software API & Cloud Microservice Stage: Client UI -> API Gateway -> Worker/DB -> JSON Response."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.4) * 30))
    f_mono = load_font(15, bold=True, mono=True)

    boxes = [
        (cx - 235, cy - 8, (56, 189, 248), "CLIENT APP", "POST /req"),
        (cx, cy - 22, accent_rgb, "API GATEWAY", "Auth & Route"),
        (cx + 235, cy - 8, (16, 185, 129), "CLOUD ENGINE", "200 OK JSON"),
    ]
    # Bi-directional request (top) and response (bottom) conduits
    for i in range(2):
        x1, y1, _, _, _ = boxes[i]
        x2, y2, _, _, _ = boxes[i + 1]
        draw_3d_tube_segment(img, x1 + 52, y1 - 12, x2 - 52, y2 - 12, r1=7, r2=7, base_rgb=(56, 189, 248), rim_rgb=(224, 242, 254), light_angle_deg=light_deg)
        draw_3d_tube_segment(img, x2 - 52, y2 + 18, x1 + 52, y1 + 18, r1=7, r2=7, base_rgb=(16, 185, 129), rim_rgb=(167, 243, 208), light_angle_deg=light_deg)
        pu = (t * 1.5 + i * 0.4) % 1.0
        paste_3d_sphere(img, (x1 + 52) + ((x2 - 52) - (x1 + 52)) * pu, y1 - 12, 8, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        paste_3d_sphere(img, (x2 - 52) - ((x2 - 52) - (x1 + 52)) * pu, y1 + 18, 8, (16, 185, 129), (255, 255, 255), light_angle_deg=light_deg)

    for bx, by, bcol, btitle, bsub in boxes:
        draw_3d_extruded_box(
            draw, bx - 64, by - 46, bx + 64, by + 46, 18, -14,
            front_rgb=(15, 23, 42), top_rgb=bcol, side_rgb=(30, 41, 59), edge_rgb=bcol
        )
        draw.text((bx - 52, by - 24), btitle, fill=(*bcol, 255), font=f_mono)
        draw.text((bx - 52, by + 4), bsub, fill=(248, 250, 252, 240), font=f_mono)


def draw_building_structure_cutaway_stage(
    img: Image.Image, draw, cx: int, cy: int, local_frame: int, fps: float,
    accent_rgb: tuple[int, int, int] = (217, 119, 6), scale_factor: float = 1.0, scene: dict = None
):
    """Dedicated 3D Architectural & Structural Cutaway: Deep Pile Foundation -> Columns -> Floor Slabs -> Roof Truss."""
    t = local_frame / max(1.0, float(fps))
    light_deg = int(round(-35 + math.sin(t * 1.3) * 30))

    # Foundation base slab
    draw_3d_extruded_box(
        draw, cx - 220, cy + 52, cx + 220, cy + 88, 28, -18,
        front_rgb=(100, 116, 139), top_rgb=(148, 163, 184), side_rgb=(71, 85, 105), edge_rgb=(226, 232, 240)
    )
    # 4 vertical structural columns with load-transfer pulses
    for col_x in (cx - 175, cx - 58, cx + 58, cx + 175):
        draw_3d_tube_segment(img, col_x, cy - 68, col_x, cy + 52, r1=11, r2=11, base_rgb=accent_rgb, rim_rgb=(254, 240, 138), light_angle_deg=light_deg)
        pu = (t * 1.4 + col_x * 0.01) % 1.0
        paste_3d_sphere(img, col_x, (cy - 68) + pu * 115, 7, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # Mid-floor beam slab & upper roof deck
    draw_3d_extruded_box(
        draw, cx - 198, cy - 12, cx + 198, cy + 8, 24, -16,
        front_rgb=(56, 189, 248), top_rgb=(125, 211, 252), side_rgb=(2, 132, 199), edge_rgb=(255, 255, 255)
    )
    draw_3d_extruded_box(
        draw, cx - 210, cy - 84, cx + 210, cy - 62, 26, -18,
        front_rgb=accent_rgb, top_rgb=(251, 191, 36), side_rgb=(180, 83, 9), edge_rgb=(255, 255, 255)
    )


def draw_true_3d_system_flowchart(
    img: Image.Image,
    draw,
    cx: int,
    cy: int,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int],
    scale_factor: float = 1.0,
    scene: dict = None,
):
    """
    Domain-Aware & Multi-Stage 3D Cutaway Dispatcher (`draw_true_3d_system_flowchart`):
    - Automatically routes `solar-panel`, `food-chain-ecology`, `water-thermodynamics`,
      `combustion-fire-triangle`, `software-api-system`, and `building-structure` to their
      dedicated 3D interactive cutaway stages!
    - For general topics (`system-mechanism`), varies the 3D stage layout across scenes
      (Stage 0: Isometric Component Blueprint; Stage 1: Core Mechanism & Force Conduits;
      Stage 2: Telemetry Radar & Harmonics; Stage 3: Closed-Loop Architecture) so consecutive
      scenes NEVER repeat the same static 3 spheres!
    """
    sc = scene or {}
    subj = str(sc.get("subjectId") or sc.get("cutawayKind") or "").lower()
    t_all = f"{subj} {sc.get('headline', '')} {sc.get('subcopy', '')} {sc.get('eyebrow', '')}".lower()

    if "solar" in subj or any(k in t_all for k in ("panel surya", "fotovoltaik", "silikon", "foton", "surya")):
        draw_solar_photovoltaic_cutaway_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return
    if "ecology" in subj or "food-chain" in subj or any(k in t_all for k in ("rantai makanan", "ekosistem", "produsen", "herbivora", "karnivora", "pengurai", "fotosintesis")):
        draw_food_chain_ecology_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return
    if "water" in subj or "thermo" in subj or any(k in t_all for k in ("air mendidih", "konveksi", "konduksi", "kalor", "uap", "100°c", "titik didih")):
        draw_water_thermodynamics_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return
    if "fire" in subj or "stove" in subj or any(k in t_all for k in ("kompor", "segitiga api", "lpg", "venturi", "api biru", "kebakaran")):
        draw_combustion_fire_triangle_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return
    if "api" in subj or "software" in subj or "ui-workflow" in subj or any(k in t_all for k in ("endpoint", "gateway", "json", "backend", "server", "database", "kode", "aplikasi")):
        draw_software_api_architecture_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return
    if "building" in subj or "architect" in subj or any(k in t_all for k in ("pondasi", "beton", "kolom", "gedung", "struktur", "konstruksi", "arsitektur")):
        draw_building_structure_cutaway_stage(img, draw, cx, cy, local_frame, fps, accent_rgb, scale_factor, sc)
        return

    t = local_frame / max(1.0, float(fps))
    enter = min(1.0, max(0.2, spring_ease(local_frame, delay=0, dur=14))) * scale_factor
    light_deg = int(round(-35 + math.sin(t * 1.3) * 40))

    # Extract meaningful labels from callouts or contextual window lines
    callouts = sc.get("callouts") or []
    node_labels = []
    for c_it in callouts[:3]:
        if isinstance(c_it, dict) and c_it.get("label"):
            node_labels.append(sanitize_text(c_it["label"]).upper()[:14])
        elif isinstance(c_it, (list, tuple)) and len(c_it) > 0:
            node_labels.append(sanitize_text(str(c_it[0])).upper()[:14])
    if len(node_labels) < 3:
        ctx = build_contextual_window_lines(sc, 0)
        for i, ln in enumerate(ctx[:3]):
            lbl = ln.split(":", 1)[0].strip().upper()[:14]
            if not lbl or lbl.startswith("PARAMETER") or lbl.startswith("FOKUS"):
                lbl = ["KOMPONEN A", "INTI SISTEM", "OUTPUT AKHIR"][i]
            if lbl not in node_labels:
                node_labels.append(lbl)
    while len(node_labels) < 3:
        node_labels.append(["INPUT UTAMA", "PROSES INTI", "HASIL AKHIR"][len(node_labels)])

    sc_idx_num = int(re.sub(r"\D", "", str(sc.get("id", "1"))) or "1") - 1
    variant = sc_idx_num % 3
    f_nd = load_font(16, bold=True)

    if variant == 1:
        # Variant 1: 3D Isometric Cutaway Core Box + Dual Orbiting Telemetry Rings & Conduits
        draw_3d_extruded_box(
            draw, cx - 82, cy - 54, cx + 82, cy + 46, 26, -20,
            front_rgb=accent_rgb, top_rgb=tuple(min(255, c + 45) for c in accent_rgb),
            side_rgb=tuple(max(20, int(c * 0.65)) for c in accent_rgb), edge_rgb=(255, 255, 255)
        )
        for side_i, (sx_off, scol, slbl) in enumerate(((-225, (56, 189, 248), node_labels[0]), (225, (16, 185, 129), node_labels[2]))):
            nx = cx + sx_off
            ny = cy - 6 + int(math.sin(t * 2.4 + side_i) * 10)
            draw_3d_tube_segment(img, cx + (-82 if side_i == 0 else 82), cy - 4, nx, ny, r1=10, r2=10, base_rgb=(100, 116, 139), rim_rgb=(226, 232, 240), light_angle_deg=light_deg)
            paste_3d_sphere(img, nx, ny, 34, scol, (255, 255, 255), light_angle_deg=light_deg)
            lw = int(draw.textlength(slbl, font=f_nd)) + 20
            draw.rounded_rectangle([nx - lw // 2, ny + 40, nx + lw // 2, ny + 66], radius=12, fill=(12, 18, 32, 230), outline=(*scol, 215), width=2)
            draw.text((nx - lw // 2 + 10, ny + 44), slbl, fill=(248, 250, 252, 255), font=f_nd)
        cw = int(draw.textlength(node_labels[1], font=f_nd)) + 22
        draw.rounded_rectangle([cx - cw // 2, cy + 54, cx + cw // 2, cy + 80], radius=12, fill=(12, 18, 32, 235), outline=(*accent_rgb, 230), width=2)
        draw.text((cx - cw // 2 + 11, cy + 58), node_labels[1], fill=(255, 255, 255, 255), font=f_nd)
        return

    if variant == 2:
        # Variant 2: 3D Ascending Stepped Mechanism Blocks + Live Signal Wave
        steps_cfg = [
            (cx - 210, cy + 18, 52, (56, 189, 248), node_labels[0]),
            (cx, cy - 8, 78, accent_rgb, node_labels[1]),
            (cx + 210, cy - 32, 104, (16, 185, 129), node_labels[2]),
        ]
        for i in range(2):
            x1, y1, _, _, _ = steps_cfg[i]
            x2, y2, _, _, _ = steps_cfg[i + 1]
            draw_3d_tube_segment(img, x1, y1 - 24, x2, y2 - 24, r1=9, r2=9, base_rgb=(250, 204, 21), rim_rgb=(255, 255, 255), light_angle_deg=light_deg)
        for bx, by, bh, bcol, blbl in steps_cfg:
            draw_3d_extruded_box(
                draw, bx - 52, by - bh // 2, bx + 52, by + bh // 2, 20, -14,
                front_rgb=bcol, top_rgb=tuple(min(255, c + 45) for c in bcol),
                side_rgb=tuple(max(20, int(c * 0.65)) for c in bcol), edge_rgb=(255, 255, 255)
            )
            lw = int(draw.textlength(blbl, font=f_nd)) + 20
            draw.rounded_rectangle([bx - lw // 2, by + bh // 2 + 8, bx + lw // 2, by + bh // 2 + 34], radius=12, fill=(12, 18, 32, 230), outline=(*bcol, 215), width=2)
            draw.text((bx - lw // 2 + 10, by + bh // 2 + 12), blbl, fill=(248, 250, 252, 255), font=f_nd)
        return

    # Variant 0: Classic 3-Node 3D Conduit with Central Gear/Hub Ring
    span_x = int(235 * enter)
    nodes = [
        (cx - span_x, cy - 18 + int(math.sin(t * 2.2) * 8), (56, 189, 248), node_labels[0]),
        (cx, cy - 34 + int(math.cos(t * 2.2) * 8), accent_rgb, node_labels[1]),
        (cx + span_x, cy - 18 + int(math.sin(t * 2.2 + 1.5) * 8), (16, 185, 129), node_labels[2]),
    ]
    for i in range(2):
        x1, y1, c1, _ = nodes[i]
        x2, y2, c2, _ = nodes[i + 1]
        draw_3d_tube_segment(
            img, x1, y1, x2, y2, r1=11 * enter, r2=11 * enter,
            base_rgb=(71, 85, 105), rim_rgb=(226, 232, 240), light_angle_deg=light_deg
        )
        pu = (t * 1.15 + i * 0.45) % 1.0
        px = x1 + (x2 - x1) * pu
        py = y1 + (y2 - y1) * pu
        paste_3d_sphere(img, px, py, max(6, int(11 * enter)), (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    for idx, (nx, ny, ncol, nlbl) in enumerate(nodes):
        r_node = int((46 if idx == 1 else 36) * enter)
        draw.ellipse([nx - r_node - 14, ny - r_node - 14, nx + r_node + 14, ny + r_node + 14], fill=(*ncol, 42))
        paste_3d_sphere(img, nx, ny, r_node, ncol, (248, 250, 252), light_angle_deg=light_deg)
        lw = int(draw.textlength(nlbl, font=f_nd)) + 24
        lx0 = nx - lw // 2
        ly0 = ny + r_node + 10
        draw.rounded_rectangle([lx0, ly0, lx0 + lw, ly0 + 28], radius=14, fill=(12, 18, 32, 225), outline=(*ncol, 210), width=2)
        draw.text((lx0 + 12, ly0 + 4), nlbl, fill=(248, 250, 252, 255), font=f_nd)


# ============================================================================
# SECTION 3.3: BRAND KIT OVERLAY & WATERMARK SYSTEM
# ============================================================================

def load_brand_kit(ws: Path, explicit_path: str = None) -> dict:
    candidates = []
    if explicit_path:
        candidates.append(Path(explicit_path).expanduser().resolve())
    if ws:
        candidates.append(ws / "brand_kit.json")
    for c in candidates:
        if c.is_file():
            try:
                return json.loads(c.read_text(encoding="utf-8"))
            except Exception:
                pass
    return {}


def apply_brand_kit_overlay(img: Image.Image, brand_kit: dict, local_frame: int, total_frames: int, is_last_scene: bool = False):
    """
    [P2-5]: Full Brand Kit System:
    Supports schema `{colors, logo, fonts, tagline, watermark, themeVariant: 'light'|'dark'}`,
    applying watermark badge, animated lower-third tagline bar, and end-card CTA overlay.
    """
    if not brand_kit:
        return
    w, h = img.size
    colors = brand_kit.get("colors") if isinstance(brand_kit.get("colors"), dict) else {}
    is_light = str(brand_kit.get("themeVariant", "dark")).lower() == "light"
    accent_hex = colors.get("accent") or brand_kit.get("accentColor") or brand_kit.get("primaryColor") or "#38BDF8"
    accent_rgb = hex_to_rgb(accent_hex)
    surface_rgba = (248, 250, 252, 232) if is_light else (12, 16, 28, 215)
    text_rgba = (15, 23, 42, 245) if is_light else (248, 250, 252, 240)

    draw = FastRGBDraw(img, bg=img.getpixel((w // 2, 20)))
    wm_text = sanitize_text(str(brand_kit.get("watermark") or brand_kit.get("watermarkText") or brand_kit.get("brandName") or "")).strip()
    if wm_text:
        pos = str(brand_kit.get("watermarkPosition") or "bottom-right").lower()
        f_wm = load_font(18, bold=True)
        tw = int(draw.textlength(wm_text, font=f_wm)) + 28
        th = 34
        if pos == "top-left":
            x0, y0 = 42, 140
        elif pos == "top-right":
            x0, y0 = w - tw - 42, 140
        elif pos == "bottom-left":
            x0, y0 = 42, h - 180
        else:
            x0, y0 = w - tw - 42, h - 180
        draw.rounded_rectangle([x0, y0, x0 + tw, y0 + th], radius=17, fill=surface_rgba, outline=(*accent_rgb, 195), width=2)
        draw.text((x0 + 14, y0 + 6), wm_text, fill=text_rgba, font=f_wm)

    # Lower-Third Tagline Banner (visible during middle frames of scene)
    tagline = sanitize_text(str(brand_kit.get("tagline") or "")).strip()
    if tagline and 8 <= local_frame <= max(24, total_frames - 10):
        f_lt = load_font(19, bold=True)
        lt_w = min(w - 168, int(draw.textlength(tagline, font=f_lt)) + 48)
        lx0 = 84
        ly0 = h - 465
        draw.rounded_rectangle([lx0, ly0, lx0 + lt_w, ly0 + 38], radius=10, fill=surface_rgba, outline=(*accent_rgb, 220), width=2)
        draw.rectangle([lx0, ly0, lx0 + 8, ly0 + 38], fill=(*accent_rgb, 255))
        draw.text((lx0 + 20, ly0 + 7), tagline[:54], fill=text_rgba, font=f_lt)

    # End-Card CTA Banner on the final 24 frames of the last scene
    end_card_cta = sanitize_text(str(brand_kit.get("endCardCta") or "")).strip()
    if is_last_scene and end_card_cta and local_frame >= max(0, total_frames - 28):
        f_ec = load_font(24, bold=True)
        ec_w = min(w - 168, int(draw.textlength(end_card_cta, font=f_ec)) + 56)
        ex0 = (w - ec_w) // 2
        ey0 = h - 420
        draw.rounded_rectangle([ex0, ey0, ex0 + ec_w, ey0 + 48], radius=24, fill=(*accent_rgb, 250))
        draw.text((ex0 + 28, ey0 + 10), end_card_cta[:42], fill=(10, 14, 24, 255), font=f_ec)


def draw_lawnmower_scene_graph_rig(
    img: Image.Image,
    draw,
    cx: int,
    diag_cy: int,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int] = (29, 122, 70),
    scale_factor: float = 1.0,
    scene: dict = None,
):
    """
    RQ02 & Section 9:
    Scene Graph & 6-Step Mechanism State Machine for the Walk-Behind Rotary Lawnmower (`lawnmower-rotary`):
    Components with persistent IDs:
    - `grass_soil_bed`: Turf & soil cross-section with uncut grass ahead (left) and cleanly cut grass behind (right)
    - `mower_handle_frame`: Push handle & wheel chassis
    - `protective_deck`: Cutaway metallic deck housing with spiral airflow chamber
    - `motor_unit`: Upper electric/combustion drive motor
    - `vertical_shaft`: Central drive shaft connecting motor to blade hub
    - `rotary_blade`: Horizontal airfoil blade rotating around central pivot `(deck_cx, blade_y)`
    - `discharge_chute_bag`: Rear chute & collection bag receiving grass clipping particles
    """
    t = local_frame / max(1.0, float(fps))
    sc = scene or {}
    step = str(sc.get("mechanismStep") or (sc.get("visual") or {}).get("mechanism_step") or "overview-deck").lower()
    light_deg = int(round(-30 + math.sin(t * 1.6) * 25))

    # Determine camera focus & cutaway peel factor from state machine step
    peel_alpha = 215
    focus_dx, focus_dy = 0, 0
    if "power" in step or "stage-02" in step:
        focus_dy = 25
        peel_alpha = 185
    elif "shaft" in step or "stage-03" in step:
        focus_dy = 10
        peel_alpha = 150
    elif "contact" in step or "stage-04" in step:
        focus_dx = 35
        focus_dy = -25
        peel_alpha = 140
    elif "bag" in step or "clippings" in step or "stage-05" in step:
        focus_dx = -55
        peel_alpha = 165

    deck_cx = cx - 45 + focus_dx
    deck_cy = diag_cy + 15 + focus_dy

    # 1. Component: `grass_soil_bed` (Ground & Turf cross-section)
    ground_y = deck_cy + 78
    draw.rounded_rectangle([84, ground_y, 996, ground_y + 42], radius=10, fill=(116, 184, 67, 255))
    draw.rounded_rectangle([84, ground_y + 34, 996, ground_y + 115], radius=12, fill=(158, 98, 48, 255))
    draw.rounded_rectangle([84, ground_y + 92, 996, ground_y + 150], radius=12, fill=(124, 77, 38, 255))

    # Grass blades: Left side (ahead of mower, tall & lifted under deck) vs Right side (already cut evenly)
    for gx in range(110, 960, 18):
        if gx < deck_cx - 145:
            # Uncut tall grass ahead of mower
            sway = int(math.sin(t * 3.0 + gx * 0.05) * 4)
            draw.line([(gx, ground_y + 6), (gx + sway, ground_y - 44)], fill=(74, 158, 38, 255), width=4)
        elif deck_cx - 145 <= gx <= deck_cx + 135:
            # Grass under deck: lifted upright by vacuum airflow!
            lift_h = 48 if gx < deck_cx else 26
            draw.line([(gx, ground_y + 6), (gx, ground_y - lift_h)], fill=(101, 196, 52, 255), width=4)
        else:
            # Evenly cut short grass behind mower
            draw.line([(gx, ground_y + 6), (gx, ground_y - 18)], fill=(88, 172, 46, 255), width=4)

    # 2. Component: `mower_handle_frame` (Diagonal push handle to upper right)
    draw.line([(deck_cx + 95, deck_cy - 18), (deck_cx + 275, deck_cy - 205)], fill=(71, 85, 105, 255), width=12)
    draw.line([(deck_cx + 95, deck_cy - 18), (deck_cx + 275, deck_cy - 205)], fill=(203, 213, 225, 220), width=4)

    # 3. Component: `discharge_chute_bag` (Rear collection chute & bag on the right)
    bag_x0 = deck_cx + 145
    bag_y0 = deck_cy - 92
    draw.polygon(
        [
            (deck_cx + 110, deck_cy - 12),
            (bag_x0 + 18, bag_y0 + 12),
            (bag_x0 + 215, bag_y0 - 8),
            (bag_x0 + 230, deck_cy + 58),
            (deck_cx + 125, deck_cy + 58),
        ],
        fill=(30, 41, 59, 245),
        outline=(*accent_rgb, 240),
        width=4,
    )
    f_bag = load_font(16, bold=True)
    draw.text((bag_x0 + 48, bag_y0 + 26), "KANTONG RUMPUT", fill=(226, 232, 240, 235), font=f_bag)

    # 4. Component: `protective_deck` (Cutaway metallic deck shell)
    deck_w = int(310 * scale_factor)
    draw.rounded_rectangle(
        [deck_cx - deck_w // 2, deck_cy - 34, deck_cx + deck_w // 2, deck_cy + 58],
        radius=32,
        fill=(51, 65, 85, peel_alpha),
        outline=(203, 213, 225, 255),
        width=4,
    )
    # Cutaway interior window revealing shaft and blade
    draw.rounded_rectangle(
        [deck_cx - deck_w // 2 + 18, deck_cy - 18, deck_cx + deck_w // 2 - 18, deck_cy + 52],
        radius=20,
        fill=(15, 23, 42, 235),
        outline=(*accent_rgb, 220),
        width=2,
    )

    # 5. Component: `motor_unit` (Upper motor cylinder mounted on top of deck)
    motor_cyl = make_shaded_3d_cylinder(124, 96, 20, accent_rgb, (226, 232, 240), (255, 255, 255), metallic=0.85)
    img.paste(motor_cyl, (deck_cx - motor_cyl.width // 2, deck_cy - 142), motor_cyl)

    # 6. Component: `vertical_shaft` (Central vertical shaft from motor to blade hub)
    blade_y = deck_cy + 22
    draw_3d_tube_segment(
        img,
        deck_cx,
        deck_cy - 44,
        deck_cx,
        blade_y,
        r1=11,
        r2=11,
        base_rgb=(203, 213, 225),
        rim_rgb=(255, 255, 255),
        light_angle_deg=light_deg,
    )
    # Energy pulse along shaft when in power/shaft step
    shaft_pulse_y = (deck_cy - 42) + ((t * 2.2) % 1.0) * 60
    paste_3d_sphere(img, deck_cx, shaft_pulse_y, 8, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)

    # 7. Component: `rotary_blade` (Horizontal airfoil blade spinning around exact center pivot `(deck_cx, blade_y)`)
    spin_ang = t * 10.5
    blade_half_span = int(126 * scale_factor)
    bx_left = deck_cx - math.cos(spin_ang) * blade_half_span
    by_left = blade_y + math.sin(spin_ang) * 14
    bx_right = deck_cx + math.cos(spin_ang) * blade_half_span
    by_right = blade_y - math.sin(spin_ang) * 14

    # Swept rotation disc ellipse for clear visual motion
    draw.ellipse(
        [deck_cx - blade_half_span, blade_y - 18, deck_cx + blade_half_span, blade_y + 18],
        fill=(56, 189, 248, 38),
        outline=(56, 189, 248, 145),
        width=2,
    )
    draw_3d_tube_segment(
        img,
        bx_left,
        by_left,
        bx_right,
        by_right,
        r1=9,
        r2=9,
        base_rgb=(226, 232, 240),
        rim_rgb=(255, 255, 255),
        light_angle_deg=light_deg,
    )
    # Central blade hub bolt (Pivot marker)
    paste_3d_sphere(img, deck_cx, blade_y, 14, (245, 158, 11), (255, 255, 255), light_angle_deg=light_deg)

    # Upward vacuum airflow arrows inside deck
    for a_i in (-85, 85):
        ax = deck_cx + a_i
        ay_bot = ground_y - 6
        ay_top = blade_y - 6
        draw.line([(ax, ay_bot), (ax, ay_top)], fill=(56, 189, 248, 195), width=3)
        draw.polygon([(ax - 7, ay_top + 10), (ax + 7, ay_top + 10), (ax, ay_top - 2)], fill=(56, 189, 248, 225))

    # 8. Clipping particles flowing from blade contact -> through rear chute -> into collector bag
    for p_i in range(10):
        pu = (t * 0.95 + p_i * 0.10) % 1.0
        px = (deck_cx + 15) + pu * 295
        py = (blade_y + 4) - math.sin(pu * math.pi) * 58 - pu * 28
        draw.ellipse([px - 6, py - 4, px + 6, py + 4], fill=(101, 196, 52, 245), outline=(22, 101, 52, 255), width=1)

    # Front & Rear Wheels
    for wx in (deck_cx - 135, deck_cx + 125):
        wy = ground_y - 16
        paste_3d_sphere(img, wx, wy, 28, (30, 41, 59), (148, 163, 184), light_angle_deg=light_deg)
        paste_3d_sphere(img, wx, wy, 12, (203, 213, 225), (255, 255, 255), light_angle_deg=light_deg)


_VIDEO_FRAME_CACHE = {}
_VIDEO_SEQ_CACHE = {}


def _get_preloaded_video_frame(video_path_str: str, source_sec: float) -> Image.Image | None:
    """
    Sequentially pre-decodes short raw videos (<45s) into RAM once per worker process (taking ~0.2s total)
    so frame extraction never spawns hundreds of random-access seeks over FUSE!
    """
    seq_info = _VIDEO_SEQ_CACHE.get(video_path_str)
    if seq_info is None:
        try:
            import cv2
            # Copy to /tmp local disk if on FUSE mount for instant sequential decode
            src_p = Path(video_path_str)
            local_p = Path("/tmp") / f"_sc_raw_cache_{src_p.stat().st_size}_{src_p.name}"
            if not local_p.is_file():
                shutil.copy2(src_p, local_p)
            cap = cv2.VideoCapture(str(local_p))
            if cap.isOpened():
                fps_v = float(cap.get(cv2.CAP_PROP_FPS) or 24.0)
                n_frames_v = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                if 0 < n_frames_v <= 1500:
                    frames_list = []
                    while True:
                        ok, frame_bgr = cap.read()
                        if not ok or frame_bgr is None:
                            break
                        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
                        frames_list.append(Image.fromarray(frame_rgb, mode="RGB"))
                    cap.release()
                    if frames_list:
                        seq_info = {"fps": fps_v, "frames": frames_list}
                        _VIDEO_SEQ_CACHE[video_path_str] = seq_info
                else:
                    cap.release()
                    _VIDEO_SEQ_CACHE[video_path_str] = False
        except Exception:
            _VIDEO_SEQ_CACHE[video_path_str] = False
            seq_info = False

    if isinstance(seq_info, dict) and seq_info.get("frames"):
        frames_list = seq_info["frames"]
        idx = min(len(frames_list) - 1, max(0, int(round(source_sec * seq_info["fps"]))))
        return frames_list[idx]
    return None


_VIDEO_FACE_TRACK_CACHE = {}
_OPENCV_CASCADES = {}


def _get_opencv_cascades() -> list:
    """Lazy-load OpenCV Haar Cascades for frontal and profile face tracking."""
    if _OPENCV_CASCADES.get("loaded"):
        return _OPENCV_CASCADES["cascades"]
    cascades = []
    try:
        import cv2
        base = cv2.data.haarcascades
        for name in ("haarcascade_frontalface_default.xml", "haarcascade_frontalface_alt2.xml", "haarcascade_profileface.xml"):
            p = os.path.join(base, name)
            if os.path.exists(p):
                c = cv2.CascadeClassifier(p)
                if not c.empty():
                    cascades.append(c)
    except Exception:
        pass
    _OPENCV_CASCADES["loaded"] = True
    _OPENCV_CASCADES["cascades"] = cascades
    return cascades


def _detect_primary_face_in_rgb(rgb_arr: np.ndarray) -> tuple[float, float, float, float] | None:
    """
    Detects the primary speaker's face in an RGB numpy array using OpenCV Haar Cascades
    (with skin-tone/upper-body fallback if the speaker turns away).
    Returns normalized `(cx_norm, cy_norm, fw_norm, fh_norm)` in `[0.0, 1.0]`,
    filtering out small lower-body false positives.
    """
    try:
        import cv2
        sh, sw = rgb_arr.shape[:2]
        if sw < 32 or sh < 32:
            return None
        scale_det = min(1.0, 380.0 / float(min(sw, sh)))
        dw, dh = max(32, int(round(sw * scale_det))), max(32, int(round(sh * scale_det)))
        small = cv2.resize(rgb_arr, (dw, dh), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
        gray = cv2.equalizeHist(gray)

        min_dim = max(24, int(min(dw, dh) * 0.13))
        candidates = []
        for cas in _get_opencv_cascades():
            rects = cas.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(min_dim, min_dim))
            if rects is not None and len(rects) > 0:
                for (rx, ry, rw, rh) in rects:
                    cx_n = (rx + rw * 0.5) / float(dw)
                    cy_n = (ry + rh * 0.5) / float(dh)
                    w_n = rw / float(dw)
                    h_n = rh / float(dh)
                    # Reject tiny lower-edge false positives (e.g. shirt buttons near bottom)
                    if cy_n > 0.78 and w_n < 0.22:
                        continue
                    # Score by area and plausible human head zone
                    zone_weight = 1.25 if 0.14 <= cy_n <= 0.68 else 0.75
                    score = (w_n * h_n) * zone_weight
                    candidates.append((score, cx_n, cy_n, w_n, h_n))
                if candidates:
                    break

        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            _, cx_n, cy_n, w_n, h_n = candidates[0]
            return (float(cx_n), float(cy_n), float(w_n), float(h_n))

        # Skin-tone YCrCb fallback in upper-middle region when face is at an extreme angle
        ycrcb = cv2.cvtColor(small, cv2.COLOR_RGB2YCrCb)
        mask = cv2.inRange(ycrcb, np.array([45, 133, 77], dtype=np.uint8), np.array([255, 173, 127], dtype=np.uint8))
        mask[int(dh * 0.72):, :] = 0
        ys, xs = np.nonzero(mask)
        if len(xs) > (dw * dh * 0.015):
            cx_n = float(np.median(xs)) / float(dw)
            cy_n = float(np.median(ys)) / float(dh)
            w_n = min(0.45, max(0.18, float(np.percentile(xs, 85) - np.percentile(xs, 15)) / float(dw)))
            h_n = min(0.42, max(0.18, float(np.percentile(ys, 85) - np.percentile(ys, 15)) / float(dh)))
            return (cx_n, cy_n, w_n, h_n)
    except Exception:
        pass
    return None


def get_video_face_trajectory(video_path: str) -> dict:
    """
    Samples `video_path` across its timeline (every ~0.35s), detects the speaker's real face
    with OpenCV (`_detect_primary_face_in_rgb`), rejects outliers, and applies forward-backward
    Exponential Moving Average (EMA) smoothing so camera pan, punch-in zoom, and safe-zone layout
    track the speaker's real face movement smoothly!
    """
    p_str = str(Path(video_path).expanduser().resolve())
    if p_str in _VIDEO_FACE_TRACK_CACHE:
        return _VIDEO_FACE_TRACK_CACHE[p_str]

    samples = []
    sw, sh = 1080, 1920
    try:
        import cv2
        cap = cv2.VideoCapture(p_str)
        if cap.isOpened():
            fps_v = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
            n_f = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            sw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1080)
            sh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1920)
            step_f = max(1, int(round(fps_v * 0.45)))
            max_f = min(n_f, 900) if n_f > 0 else 180
            # Fast sequential grab/retrieve (avoids slow H.264 random-access keyframe seeking!)
            for f_i in range(0, max_f):
                if f_i % step_f == 0:
                    ok, bgr = cap.read()
                    if not ok or bgr is None:
                        break
                    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
                    det = _detect_primary_face_in_rgb(rgb)
                    if det is not None:
                        samples.append((f_i / max(1.0, fps_v), det[0], det[1], det[2], det[3]))
                else:
                    if not cap.grab():
                        break
            cap.release()
    except Exception:
        pass

    if not samples:
        # Fallback if video cannot be opened
        default_track = {
            "width": sw,
            "height": sh,
            "samples": [(0.0, 0.50, 0.34, 0.32, 0.24)],
            "median_box": (0.50, 0.34, 0.32, 0.24),
            "real_detected": False,
        }
        _VIDEO_FACE_TRACK_CACHE[p_str] = default_track
        return default_track

    # Forward + backward EMA smoothing (`alpha=0.35`) to eliminate single-frame jitter while tracking real motion
    arr = np.array(samples, dtype=np.float32)
    med_cx = float(np.median(arr[:, 1]))
    med_cy = float(np.median(arr[:, 2]))
    med_fw = float(np.median(arr[:, 3]))
    med_fh = float(np.median(arr[:, 4]))

    # Clamp extreme >25% single-frame jumps to median neighborhood before smoothing
    for i in range(len(arr)):
        if abs(arr[i, 1] - med_cx) > 0.26:
            arr[i, 1] = med_cx
        if abs(arr[i, 2] - med_cy) > 0.24:
            arr[i, 2] = med_cy

    alpha = 0.35
    fwd = arr.copy()
    for i in range(1, len(fwd)):
        fwd[i, 1:] = alpha * arr[i, 1:] + (1.0 - alpha) * fwd[i - 1, 1:]
    bwd = fwd.copy()
    for i in range(len(bwd) - 2, -1, -1):
        bwd[i, 1:] = alpha * fwd[i, 1:] + (1.0 - alpha) * bwd[i + 1, 1:]

    smoothed = [(float(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])) for r in bwd]
    track_info = {
        "width": sw,
        "height": sh,
        "samples": smoothed,
        "median_box": (med_cx, med_cy, med_fw, med_fh),
        "real_detected": True,
    }
    _VIDEO_FACE_TRACK_CACHE[p_str] = track_info
    return track_info


def get_tracked_face_at_time(video_path: str, source_sec: float) -> tuple[float, float, float, float]:
    """Interpolate tracked `(cx_norm, cy_norm, fw_norm, fh_norm)` at exact `source_sec`."""
    tr = get_video_face_trajectory(video_path)
    s_list = tr.get("samples") or [(0.0, 0.50, 0.34, 0.32, 0.24)]
    if len(s_list) == 1 or source_sec <= s_list[0][0]:
        return s_list[0][1:]
    if source_sec >= s_list[-1][0]:
        return s_list[-1][1:]
    for i in range(len(s_list) - 1):
        t0, cx0, cy0, w0, h0 = s_list[i]
        t1, cx1, cy1, w1, h1 = s_list[i + 1]
        if t0 <= source_sec <= t1:
            u = (source_sec - t0) / max(1e-4, t1 - t0)
            return (
                cx0 + (cx1 - cx0) * u,
                cy0 + (cy1 - cy0) * u,
                w0 + (w1 - w0) * u,
                h0 + (h1 - h0) * u,
            )
    return s_list[-1][1:]


def extract_video_frame_pil(
    video_path: str,
    source_sec: float,
    target_w: int = 1080,
    target_h: int = 1920,
    zoom: float = 1.0,
    crop_mode: str = "cover",
    scene: dict | None = None,
) -> Image.Image | None:
    """
    Extracts an exact video frame at `source_sec` from a user-supplied raw video (`.mp4`/`.mov`/`.mkv`/`.webm`)
    and applies:
    - Real OpenCV Face-Tracked Smart Crop (`get_tracked_face_at_time`):
      If the source video is landscape (16:9) or zoomed in (`zoom > 1.0`), the 9:16 crop window
      automatically pans horizontally and vertically to follow the speaker's tracked face!
    - Face-Anchored Dynamic Punch-In Zoom:
      Zooms directly toward the speaker's face `(fcx_norm, fcy_norm)` rather than dead center,
      and records the resulting head bounding box in `scene["_cropped_face_box"]` for collision-free
      overlay & subtitle placement!
    """
    p = Path(video_path).expanduser().resolve()
    if not p.is_file():
        return None

    q_sec = round(max(0.0, float(source_sec)), 2)
    cache_key = (str(p), q_sec)
    raw_im = _VIDEO_FRAME_CACHE.get(cache_key)
    if raw_im is None:
        raw_im = _get_preloaded_video_frame(str(p), q_sec)

    if raw_im is None:
        try:
            import cv2
            cap = cv2.VideoCapture(str(p))
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_POS_MSEC, q_sec * 1000.0)
                ok, frame_bgr = cap.read()
                if not ok:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, frame_bgr = cap.read()
                cap.release()
                if ok and frame_bgr is not None:
                    frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
                    raw_im = Image.fromarray(frame_rgb, mode="RGB")
        except Exception:
            raw_im = None

        if raw_im is None and shutil.which("ffmpeg"):
            try:
                proc = subprocess.run(
                    [
                        "ffmpeg", "-nostdin", "-v", "error",
                        "-ss", f"{q_sec:.2f}",
                        "-i", str(p),
                        "-frames:v", "1",
                        "-f", "image2pipe",
                        "-vcodec", "png",
                        "-",
                    ],
                    stdin=subprocess.DEVNULL,
                    capture_output=True,
                    timeout=8,
                )
                if proc.returncode == 0 and len(proc.stdout) > 256:
                    import io
                    raw_im = Image.open(io.BytesIO(proc.stdout)).convert("RGB")
            except Exception:
                raw_im = None

        if raw_im is not None:
            if len(_VIDEO_FRAME_CACHE) > 64:
                _VIDEO_FRAME_CACHE.clear()
            _VIDEO_FRAME_CACHE[cache_key] = raw_im

    if raw_im is None:
        return None

    sw, sh = raw_im.size
    eff_zoom = max(1.0, min(1.65, float(zoom)))
    fcx_n, fcy_n, fw_n, fh_n = get_tracked_face_at_time(str(p), q_sec)

    if crop_mode == "blur-pad":
        # R2 benchmark style: blurred atmospheric full-bleed background + crisp aspect-preserved foreground
        bg = raw_im.resize((target_w // 8, target_h // 8), Image.Resampling.BILINEAR).resize((target_w, target_h), Image.Resampling.BICUBIC)
        bg = bg.filter(ImageFilter.GaussianBlur(radius=14))
        arr_bg = (np.asarray(bg, dtype=np.float32) * 0.45).astype(np.uint8)
        canvas = Image.fromarray(arr_bg, mode="RGB")
        fg_scale = min(target_w / float(sw), (target_h * 0.72) / float(sh)) * eff_zoom
        fw, fh = max(64, int(round(sw * fg_scale))), max(64, int(round(sh * fg_scale)))
        fg = raw_im.resize((fw, fh), Image.Resampling.LANCZOS)
        ox = (target_w - fw) // 2
        oy = (target_h - fh) // 2
        canvas.paste(fg, (ox, oy))
        if isinstance(scene, dict):
            hx0 = max(0, int(ox + (fcx_n - fw_n * 0.65) * fw))
            hy0 = max(0, int(oy + (fcy_n - fh_n * 0.90) * fh))
            hx1 = min(target_w, int(ox + (fcx_n + fw_n * 0.65) * fw))
            hy1 = min(target_h, int(oy + (fcy_n + fh_n * 0.75) * fh))
            scene["_cropped_face_box"] = (hx0, hy0, hx1, hy1)
        return canvas

    # Face-Tracked Smart 9:16 Crop + Face-Anchored Punch-In Zoom!
    scale = max(target_w / float(sw), target_h / float(sh)) * eff_zoom
    nw, nh = max(target_w, int(round(sw * scale))), max(target_h, int(round(sh * scale)))
    resized = raw_im.resize((nw, nh), Image.Resampling.BILINEAR)

    # Center crop horizontally on the tracked face (`fcx_n * nw -> target_w * 0.50`)
    # and frame the speaker's eye-line near `target_h * 0.34` when vertical pan headroom exists!
    face_px_x = fcx_n * nw
    face_px_y = fcy_n * nh
    cx0 = max(0, min(nw - target_w, int(round(face_px_x - target_w * 0.50))))
    cy0 = max(0, min(nh - target_h, int(round(face_px_y - target_h * 0.34))))

    if isinstance(scene, dict):
        # Compute full head + hair + chin bounding box in the cropped 1080x1920 frame
        face_cx_crop = face_px_x - cx0
        face_cy_crop = face_px_y - cy0
        face_w_crop = fw_n * nw
        face_h_crop = fh_n * nh
        hx0 = max(0, int(round(face_cx_crop - face_w_crop * 0.62)))
        hy0 = max(0, int(round(face_cy_crop - face_h_crop * 0.88)))  # includes hair/crown above forehead
        hx1 = min(target_w, int(round(face_cx_crop + face_w_crop * 0.62)))
        hy1 = min(target_h, int(round(face_cy_crop + face_h_crop * 0.68)))  # includes chin/neck
        scene["_cropped_face_box"] = (hx0, hy0, hx1, hy1)
        scene["detectedFaceBox"] = [hx0, hy0, hx1, hy1]

    return resized.crop((cx0, cy0, cx0 + target_w, cy0 + target_h))


def render_raw_video_footage_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image | None:
    """
    Renders a scene backed by a real user-supplied raw video (`videoSrc` / `rawVideoPath`):
    - Extracts the frame at `sourceStartSec + local_frame / fps`
    - Applies dynamic punch-in zoom (`zoom` or intra-scene camera cut zoom)
    - Overlays optional frosted-glass or editorial header & callout cards + synced animated captions!
    """
    vid_src = scene.get("videoSrc") or scene.get("rawVideoPath") or (scene.get("visual") or {}).get("video_src")
    if not vid_src or not Path(str(vid_src)).expanduser().is_file():
        return None

    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    src_start = float(scene.get("sourceStartSec", 0.0))
    src_end = float(scene.get("sourceEndSec", src_start + dur_frames / float(fps)))
    src_sec = min(src_end, src_start + scene.get("_jumpcut_src_sec", t))

    base_zoom = float(scene.get("zoom", 1.06))
    cam_info = compute_intrascene_camera_cut(local_frame, dur_frames, fps, scene)
    eff_zoom = base_zoom * (0.94 + 0.08 * cam_info["zoom"])
    crop_mode = str(scene.get("videoCropMode") or "cover")

    frame_im = extract_video_frame_pil(str(vid_src), src_sec, target_w=1080, target_h=1920, zoom=eff_zoom, crop_mode=crop_mode, scene=scene)
    if frame_im is None:
        return None

    img = frame_im.copy()
    draw = FastRGBDraw(img, bg=(10, 14, 24))
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent") or "#38BDF8"
    accent_rgb = hex_to_rgb(accent_hex)
    pad_x, right_x = 84, 876
    usable_w = right_x - pad_x

    # Top sleek translucent header bar for raw video edit
    eyebrow = sanitize_text(scene.get("eyebrow") or badge or f"CLIP 0{scene_idx + 1}").upper()
    f_kicker = load_font(20, bold=True)
    ew = int(draw.textlength(eyebrow, font=f_kicker)) + 36
    draw.rounded_rectangle([pad_x, 210, pad_x + ew, 250], radius=20, fill=(10, 14, 24, 215), outline=(*accent_rgb, 230), width=2)
    draw.text((pad_x + 18, 218), eyebrow, fill=(248, 250, 252, 255), font=f_kicker)

    draw_camera_hud_pill(draw, right_x, 168, cam_info, accent_rgb, light_bg=False)

    # Optional upper frosted-glass headline card ONLY if showOverlayCard is explicitly True
    if scene.get("showOverlayCard", False) and scene.get("headline"):
        h_raw = sanitize_text(scene.get("headline", ""))
        h_lines, f_h1, h_sz = fit_text_block(draw, h_raw, usable_w - 48, max_lines=2, start_size=34, min_size=24, bold=True)
        card_h = 36 + len(h_lines) * int(h_sz * 1.22)
        draw.rounded_rectangle([pad_x, 268, right_x, 268 + card_h], radius=22, fill=(12, 18, 32, 215), outline=(*accent_rgb, 210), width=2)
        hy = 286
        for ln in h_lines:
            draw.text((pad_x + 24, hy), ln, fill=(248, 250, 252, 255), font=f_h1)
            hy += int(h_sz * 1.22)

    # Synced lower-third subtitles over the edited video
    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1335,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(250, 204, 21),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=scene,
        local_frame=local_frame,
    )
    img = apply_cinematic_camera_transform(img, local_frame, dur_frames, fps, scene)
    if brand_kit:
        apply_brand_kit_overlay(img, brand_kit, local_frame, dur_frames, is_last_scene=(scene_idx == total_scenes - 1))
    return adapt_frame_to_aspect(img, width, height)


def draw_opus_55_procedural_stage(
    img: Image.Image,
    draw,
    cx: int,
    cy: int,
    mode: str,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int],
    scale_factor: float = 1.0,
    scene: dict = None,
) -> bool:
    """
    Fixes `pebaikan claude.txt` Section 3.3 ("opus 5.5 style ga keluar sama sekali potensinya"):
    Provides dedicated, high-craft procedural renderers in Pillow for Opus 5.5 modes:
    - `cutaway-turbofan`
    - `wave-interference` / `energy-waves` / `audio-reactive-rings`
    - `gear-train-cutaway`
    - `optical-ray-cutaway`
    - `stress-heatmap`
    - `matrix-bit-decoder` / `algorithm-stepper` / `hud-terminal-neural`
    - `liquid-metaballs`
    Returns True if handled, False otherwise.
    """
    t = local_frame / max(1.0, float(fps))
    m_low = (mode or "").strip().lower()
    light_deg = int(round(-35 + math.sin(t * 1.5) * 35))

    if m_low == "cutaway-turbofan":
        # If the subject is lawnmower, combine cyber-futuristic turbofan/vortex streamlines with the rotary mower rig!
        subj = str((scene or {}).get("subjectId") or "").lower()
        if "lawnmower" in subj or "rumput" in f"{(scene or {}).get('headline', '')} {(scene or {}).get('subcopy', '')}".lower():
            draw_lawnmower_scene_graph_rig(img, draw, cx, cy + 10, local_frame, fps, accent_rgb=accent_rgb, scale_factor=scale_factor, scene=scene)
            return True
        # Otherwise draw 3D multi-stage axial turbofan with bypass streamlines
        draw_true_3d_rotary_turbine_cutaway(img, draw, cy, local_frame, fps, accent_rgb=accent_rgb, scale_factor=scale_factor)
        for s_i in range(6):
            sy = cy - 75 + s_i * 30
            phase = (t * 220 + s_i * 45) % 620
            x0 = cx - 310 + phase
            draw.line([(x0, sy), (min(cx + 310, x0 + 85), sy)], fill=(*accent_rgb, 210), width=3)
        return True

    if m_low in ("wave-interference", "energy-waves", "audio-reactive-rings"):
        # Multi-source constructive/destructive wave interference field + harmonic rings
        s1_x, s1_y = cx - 125, cy - 15
        s2_x, s2_y = cx + 125, cy + 15
        for r_i in range(1, 9):
            r_px = int(((r_i * 34 + t * 55) % 270) * scale_factor)
            alpha = max(25, int(220 * (1.0 - r_px / 280.0)))
            if r_px > 8:
                draw.ellipse([s1_x - r_px, s1_y - r_px, s1_x + r_px, s1_y + r_px], outline=(*accent_rgb, alpha), width=3)
                draw.ellipse([s2_x - r_px, s2_y - r_px, s2_x + r_px, s2_y + r_px], outline=(168, 85, 247, alpha), width=3)
        # Interference standing wave envelope across center
        pts = []
        for i in range(72):
            u_x = i / 71.0
            px = (cx - 330) + u_x * 660
            w1 = math.sin(u_x * math.pi * 6.0 - t * 6.5)
            w2 = math.cos(u_x * math.pi * 4.0 + t * 4.5)
            py = cy + (w1 + w2) * 38 * math.sin(u_x * math.pi)
            pts.append((px, py))
        draw.line(pts, fill=(248, 250, 252, 245), width=5)
        paste_3d_sphere(img, s1_x, s1_y, 20, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        paste_3d_sphere(img, s2_x, s2_y, 20, (168, 85, 247), (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low == "gear-train-cutaway":
        # Planetary / escapement 3D interlocking gear train
        gears = [
            (cx - 115, cy - 10, 82, 12, t * 2.2, accent_rgb),
            (cx + 45, cy - 10, 68, 10, -t * 2.68, (245, 158, 11)),
            (cx + 165, cy + 25, 48, 8, t * 3.8, (56, 189, 248)),
        ]
        for gx, gy, gr, n_teeth, gang, gcol in gears:
            for ti in range(n_teeth):
                a = gang + ti * (2.0 * math.pi / n_teeth)
                tx1 = gx + math.cos(a) * (gr - 8)
                ty1 = gy + math.sin(a) * (gr - 8)
                tx2 = gx + math.cos(a) * (gr + 14)
                ty2 = gy + math.sin(a) * (gr + 14)
                draw.line([(tx1, ty1), (tx2, ty2)], fill=(*gcol, 255), width=10)
            paste_3d_sphere(img, gx, gy, gr - 6, gcol, (248, 250, 252), light_angle_deg=light_deg)
            paste_3d_sphere(img, gx, gy, int(gr * 0.35), (30, 41, 59), (203, 213, 225), light_angle_deg=light_deg)
        return True

    if m_low == "optical-ray-cutaway":
        # Multi-element optical lens cutaway with refracting RGB rays
        lens_xs = [cx - 135, cx - 25, cx + 85]
        ray_cols = [(239, 68, 68), (56, 189, 248), (16, 185, 129)]
        for r_i, r_off in enumerate((-55, 0, 55)):
            y_in = cy + r_off
            y_mid = cy + int(r_off * 0.55)
            y_focus = cy + int(math.sin(t * 2.0) * 12)
            pts = [(cx - 310, y_in), (lens_xs[0], y_in), (lens_xs[1], y_mid), (lens_xs[2], y_mid * 0.4 + cy * 0.6), (cx + 275, y_focus)]
            draw.line(pts, fill=(*ray_cols[r_i], 235), width=4)
        for lx in lens_xs:
            draw.ellipse([lx - 22, cy - 110, lx + 22, cy + 110], fill=(56, 189, 248, 75), outline=(224, 242, 254, 240), width=3)
        paste_3d_sphere(img, cx + 275, cy + int(math.sin(t * 2.0) * 12), 18, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("stress-heatmap", "liquid-metaballs"):
        # Thermal / stress iso-contours or metaball blobs
        centers = [
            (cx - int(95 * math.cos(t * 1.4)), cy + int(35 * math.sin(t * 1.8)), (239, 68, 68)),
            (cx + int(95 * math.cos(t * 1.1)), cy - int(35 * math.sin(t * 1.5)), (245, 158, 11)),
            (cx, cy, accent_rgb),
        ]
        for bx, by, bcol in centers:
            for rad, alpha in ((115, 45), (82, 85), (52, 155)):
                draw.ellipse([bx - rad, by - rad, bx + rad, by + rad], fill=(*bcol, alpha))
            paste_3d_sphere(img, bx, by, 38, bcol, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("matrix-bit-decoder", "algorithm-stepper", "hud-terminal-neural", "retro-crt-shader"):
        # Interactive bit-matrix & pointer stepper
        cell_sz = 34
        cols_n, rows_n = 12, 5
        gx0 = cx - (cols_n * cell_sz) // 2
        gy0 = cy - (rows_n * cell_sz) // 2
        active_cell = int(t * 8) % (cols_n * rows_n)
        for r_i in range(rows_n):
            for c_i in range(cols_n):
                idx_c = r_i * cols_n + c_i
                x0 = gx0 + c_i * cell_sz
                y0 = gy0 + r_i * cell_sz
                is_act = idx_c == active_cell
                is_on = ((idx_c * 7 + int(t * 3)) % 5) in (0, 2)
                fill_c = (*accent_rgb, 250) if is_act else ((30, 58, 138, 190) if is_on else (15, 23, 42, 180))
                draw.rounded_rectangle([x0 + 2, y0 + 2, x0 + cell_sz - 2, y0 + cell_sz - 2], radius=6, fill=fill_c, outline=(*accent_rgb, 140), width=1)
        return True

    if m_low == "bio-pulse-flow":
        # Double-helix DNA / vascular bio-pulse + neural soma
        pts_a, pts_b = [], []
        for i in range(36):
            u_x = i / 35.0
            px = (cx - 290) + u_x * 580
            ang = u_x * math.pi * 4.0 + t * 3.5
            ya = cy + math.sin(ang) * 72
            yb = cy - math.sin(ang) * 72
            pts_a.append((px, ya))
            pts_b.append((px, yb))
            if i % 3 == 0:
                draw.line([(px, ya), (px, yb)], fill=(255, 255, 255, 110), width=3)
                paste_3d_sphere(img, px, ya, 11, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
                paste_3d_sphere(img, px, yb, 11, (16, 185, 129), (255, 255, 255), light_angle_deg=light_deg)
        draw.line(pts_a, fill=(*accent_rgb, 235), width=5)
        draw.line(pts_b, fill=(16, 185, 129, 235), width=5)
        return True

    if m_low == "node-network":
        # 3D Constellation Mesh Topology with packet routing
        nodes = [
            (cx - 210, cy - 65, 24, accent_rgb),
            (cx - 75, cy - 95, 28, (56, 189, 248)),
            (cx + 95, cy - 80, 26, (168, 85, 247)),
            (cx + 225, cy - 35, 22, accent_rgb),
            (cx - 145, cy + 65, 25, (16, 185, 129)),
            (cx + 10, cy + 15, 42, (250, 204, 21)),
            (cx + 165, cy + 70, 26, (236, 72, 153)),
        ]
        edges = [(0, 1), (1, 2), (2, 3), (0, 4), (4, 5), (1, 5), (2, 5), (5, 6), (3, 6)]
        for i_a, i_b in edges:
            x1, y1, _, _ = nodes[i_a]
            x2, y2, _, _ = nodes[i_b]
            draw_3d_tube_segment(img, x1, y1, x2, y2, 7, 7, (71, 85, 105), (226, 232, 240), steps=10, light_angle_deg=light_deg)
            pu = (t * 1.4 + (i_a + i_b) * 0.17) % 1.0
            px, py = x1 + (x2 - x1) * pu, y1 + (y2 - y1) * pu
            paste_3d_sphere(img, px, py, 8, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        for nx, ny, nr, ncol in nodes:
            paste_3d_sphere(img, nx, ny, nr, ncol, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("3d-isometric-growth", "ref3-pricing-voxel"):
        # Ascending 3D Isometric Skyscraper / Revenue Bars with glowing trend trajectory
        bar_specs = [
            (-210, 56, (56, 189, 248), "Q1"),
            (-105, 92, (20, 184, 166), "Q2"),
            (0, 134, (16, 185, 129), "Q3"),
            (105, 178, (250, 204, 21), "Q4"),
            (210, 224, accent_rgb, "PEAK"),
        ]
        base_y = cy + 95
        top_pts = []
        for ox, bh, bcol, blbl in bar_specs:
            bx = cx + ox
            top_y = base_y - bh
            top_pts.append((bx + 12, top_y - 18))
            draw_3d_extruded_box(
                draw, bx - 32, top_y, bx + 32, base_y, 24, -18,
                front_rgb=bcol,
                top_rgb=tuple(min(255, c + 45) for c in bcol),
                side_rgb=tuple(max(20, int(c * 0.65)) for c in bcol),
                edge_rgb=(255, 255, 255),
            )
        draw.line(top_pts, fill=(250, 204, 21, 255), width=5)
        for tx, ty in top_pts:
            paste_3d_sphere(img, tx, ty, 10, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low == "deconstructed-ui":
        # Exploded 3D Layered Glass UI Deck (3 floating isometric planes)
        layers = [
            (cy + 42, (30, 41, 59, 220), (148, 163, 184), "BASE LAYER · DATABASE & API"),
            (cy - 6, (37, 99, 235, 195), (96, 165, 250), "LOGIC LAYER · STATE ENGINE"),
            (cy - 54, (*accent_rgb, 215), (255, 255, 255), "UI SURFACE · INTERACTIVE VIEW"),
        ]
        f_ly = load_font(17, bold=True, mono=True)
        for ly_y, fill_c, out_c, lbl_txt in layers:
            pts = [(cx - 250, ly_y + 20), (cx - 110, ly_y - 38), (cx + 250, ly_y - 20), (cx + 110, ly_y + 38)]
            draw.polygon(pts, fill=fill_c, outline=(*out_c, 255))
            draw.text((cx - 135, ly_y - 12), lbl_txt, fill=(255, 255, 255, 255), font=f_ly)
        return True

    if m_low in ("dual-device-showreel", "saas-product-launch"):
        # Desktop SaaS Dashboard Window + Floating Mobile Companion Mockup
        draw.rounded_rectangle([cx - 275, cy - 105, cx + 145, cy + 95], radius=18, fill=(15, 23, 42, 248), outline=(*accent_rgb, 235), width=3)
        draw.rounded_rectangle([cx - 255, cy - 65, cx - 85, cy + 75], radius=10, fill=(30, 41, 59, 240))
        draw.rounded_rectangle([cx - 68, cy - 65, cx + 125, cy + 5], radius=10, fill=(*accent_rgb, 55), outline=(*accent_rgb, 200), width=2)
        # Mobile phone overlapping on right
        draw.rounded_rectangle([cx + 95, cy - 75, cx + 275, cy + 115], radius=24, fill=(9, 13, 24, 255), outline=(248, 250, 252, 245), width=4)
        paste_3d_sphere(img, cx + 185, cy + 18, 34, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("luxury-editorial-glass", "ref2-floating-glass", "cosmic-glass"):
        # Frosted Luxury Glass Prism Card + Golden/Cyan Orbiting Jewels
        for r_i, ang_off in enumerate((0.0, 2.1, 4.2)):
            ang = t * 1.6 + ang_off
            ox = cx + math.cos(ang) * 215
            oy = cy + math.sin(ang) * 68
            paste_3d_sphere(img, ox, oy, 24 if r_i == 0 else 18, accent_rgb if r_i % 2 == 0 else (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        draw.rounded_rectangle([cx - 185, cy - 82, cx + 185, cy + 82], radius=28, fill=(255, 255, 255, 38), outline=(*accent_rgb, 245), width=3)
        paste_3d_sphere(img, cx, cy, 46, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("single-line-relay", "chronicle-morph"):
        # Continuous 3D Relay Trajectory & Era Morph Nodes
        waypoints = [
            (cx - 255, cy + 45, (56, 189, 248)),
            (cx - 85, cy - 55, accent_rgb),
            (cx + 85, cy + 45, (250, 204, 21)),
            (cx + 255, cy - 55, (16, 185, 129)),
        ]
        for i in range(len(waypoints) - 1):
            x1, y1, _ = waypoints[i]
            x2, y2, _ = waypoints[i + 1]
            draw_3d_tube_segment(img, x1, y1, x2, y2, r1=9, r2=9, base_rgb=accent_rgb, rim_rgb=(255, 255, 255), light_angle_deg=light_deg)
            pu = (t * 1.4 + i * 0.3) % 1.0
            paste_3d_sphere(img, x1 + (x2 - x1) * pu, y1 + (y2 - y1) * pu, 10, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        for idx_w, (wx, wy, wcol) in enumerate(waypoints):
            if m_low == "chronicle-morph" and idx_w % 2 == 1:
                draw_3d_extruded_box(
                    draw, wx - 28, wy - 28, wx + 28, wy + 28, 14, -10,
                    front_rgb=wcol, top_rgb=tuple(min(255, c + 40) for c in wcol),
                    side_rgb=tuple(max(20, int(c * 0.65)) for c in wcol), edge_rgb=(255, 255, 255)
                )
            else:
                paste_3d_sphere(img, wx, wy, 28, wcol, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low == "halftone-eye-anchor":
        # Concentric Optical Iris + Halftone Dot Matrix Ring
        for r_ring, col_r in ((115, accent_rgb), (78, (56, 189, 248)), (42, (15, 23, 42))):
            draw.ellipse([cx - r_ring, cy - int(r_ring * 0.68), cx + r_ring, cy + int(r_ring * 0.68)], outline=(*col_r, 235), width=4)
        for d_i in range(16):
            ang = d_i * (math.pi * 2.0 / 16.0) + t * 0.9
            dx = cx + int(math.cos(ang) * 145)
            dy = cy + int(math.sin(ang) * 82)
            paste_3d_sphere(img, dx, dy, 8, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        paste_3d_sphere(img, cx, cy, 34, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("timeline-camera-flight", "narrated-phrase-sync"):
        # Z-Axis Perspective Portals & Beat-Synced 3D Bars
        for p_i, z_scale in enumerate((1.0, 0.72, 0.46)):
            pw = int(260 * z_scale)
            ph = int(105 * z_scale)
            py_off = int((p_i - 1) * 18)
            draw.rounded_rectangle(
                [cx - pw, cy - ph + py_off, cx + pw, cy + ph + py_off],
                radius=22, outline=(*accent_rgb, int(240 * z_scale)), width=3
            )
        paste_3d_sphere(img, cx, cy, 36, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("physics-pill-drop", "deterministic-stepper"):
        # Gravity-Stacked 3D Capsules & Frame-Clock Stepper
        pills = [
            (cx - 125, cy + 48, (56, 189, 248), "STEP 01"),
            (cx + 115, cy + 48, (16, 185, 129), "STEP 02"),
            (cx, cy - 28 + int(abs(math.sin(t * 3.2)) * 14), accent_rgb, "LOCKED"),
        ]
        f_p = load_font(17, bold=True, mono=True)
        for px, py, pcol, plbl in pills:
            draw.rounded_rectangle([px - 95, py - 28, px + 95, py + 28], radius=28, fill=(*pcol, 235), outline=(255, 255, 255, 245), width=3)
            tw = int(draw.textlength(plbl, font=f_p))
            draw.text((px - tw // 2, py - 10), plbl, fill=(10, 14, 24, 255), font=f_p)
        return True

    if m_low in ("kaca-gelap", "rts-modern", "sci-fi", "futuristic"):
        # Staikhouse Dark & Tech Category: Tactical HUD / Glassmorphic 3D Core + Unit Frames
        gold_or_cyan = (245, 158, 11) if m_low == "rts-modern" else (0, 245, 212) if m_low == "futuristic" else (56, 189, 248)
        draw.rounded_rectangle([cx - 265, cy - 95, cx + 265, cy + 95], radius=24, fill=(14, 18, 28, 215), outline=(*gold_or_cyan, 240), width=3)
        for i_u, ux in enumerate((cx - 165, cx, cx + 165)):
            draw.rounded_rectangle([ux - 65, cy - 62, ux + 65, cy + 62], radius=14, fill=(24, 32, 48, 200), outline=(*gold_or_cyan, 185), width=2)
            paste_3d_sphere(img, ux, cy - 6, 26 if i_u == 1 else 20, gold_or_cyan if i_u == 1 else accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("arang-lime", "paper-motion", "minimalism", "roman-empire"):
        # Editorial Serif Behind-Subject / Chrome 3D Object / Swiss Grid / Roman Plaque
        f_ed = load_font(38, bold=True, serif=(m_low in ("arang-lime", "roman-empire")))
        lbl_ed = sanitize_text((scene or {}).get("stickerText") or (scene or {}).get("eyebrow") or m_low.upper())[:18]
        accent_ed = (163, 230, 53) if m_low == "arang-lime" else (220, 38, 38) if m_low == "minimalism" else (217, 119, 6) if m_low == "roman-empire" else (59, 130, 246)
        draw.rounded_rectangle([cx - 255, cy - 88, cx + 255, cy + 88], radius=20, fill=(24, 24, 27, 235) if m_low == "arang-lime" else (250, 248, 242, 240), outline=(*accent_ed, 255), width=4)
        tw = int(draw.textlength(lbl_ed, font=f_ed))
        draw.text((cx - tw // 2, cy - 58), lbl_ed, fill=(*accent_ed, 255), font=f_ed)
        paste_3d_sphere(img, cx, cy + 24, 38, (203, 213, 225) if m_low == "paper-motion" else accent_ed, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("variety-show", "blocks", "y2k-desktop", "y2k-glam-pop", "retro-arcade", "pop-magazine", "comic-book"):
        # Staikhouse Ceria & Pop Category: Y2K Window / Toy Blocks / Variety Pop Callout
        pop_col = (236, 72, 153) if "y2k" in m_low or "pop" in m_low else (250, 204, 21) if m_low in ("variety-show", "comic-book") else (56, 189, 248)
        draw.rounded_rectangle([cx - 250, cy - 92, cx + 250, cy + 92], radius=18, fill=(18, 24, 42, 235), outline=(*pop_col, 255), width=4)
        draw.rectangle([cx - 250, cy - 92, cx + 250, cy - 52], fill=(*pop_col, 255))
        f_bar = load_font(18, bold=True, mono=True)
        draw.text((cx - 230, cy - 82), f"STAIKHOUSE // {m_low.upper()}", fill=(12, 14, 22, 255), font=f_bar)
        for b_i, bx in enumerate((cx - 135, cx, cx + 135)):
            b_c = [(56, 189, 248), (250, 204, 21), (236, 72, 153)][b_i]
            draw_3d_extruded_box(draw, bx - 42, cy - 18, bx + 42, cy + 56, 16, -12, b_c, tuple(min(255, c + 40) for c in b_c), tuple(max(20, int(c * 0.65)) for c in b_c), (255, 255, 255))
        return True

    if m_low in ("kolase-kertas", "doodle-art", "sketch-art", "coffee-lofi", "kertas-tipografi"):
        # Staikhouse Kertas & Tangan Category: Torn Paper / Blueprint / Notebook Card + Red Marker Accent
        draw.rounded_rectangle([cx - 260, cy - 90, cx + 260, cy + 90], radius=14, fill=(248, 242, 228, 248), outline=(185, 28, 28, 245), width=4)
        for ly in range(cy - 60, cy + 75, 28):
            draw.line([(cx - 235, ly), (cx + 235, ly)], fill=(148, 163, 184, 110), width=2)
        draw.rounded_rectangle([cx - 195, cy - 42, cx + 195, cy + 16], radius=8, fill=(220, 38, 38, 240))
        f_kp = load_font(24, bold=True, serif=True)
        lbl_kp = sanitize_text((scene or {}).get("windowTitle") or m_low.replace("-", " ").upper())[:24]
        tw = int(draw.textlength(lbl_kp, font=f_kp))
        draw.text((cx - tw // 2, cy - 28), lbl_kp, fill=(255, 255, 255, 255), font=f_kp)
        return True

    if m_low in ("caption-news", "broadcast-news-package", "live-countdown-grid", "sports-telestrator"):
        # Edit & Documentary Broadcast / Telestrator / Split-Screen Grid Stage
        f_bn = load_font(18, bold=True, mono=True)
        if m_low == "live-countdown-grid":
            # 3x3 Split-Screen Telemetry Cells with live countdown clock
            for r_i in range(3):
                for c_i in range(3):
                    gx0 = cx - 240 + c_i * 165
                    gy0 = cy - 96 + r_i * 66
                    is_focus = (r_i * 3 + c_i) == (int(t * 3) % 9)
                    draw.rounded_rectangle([gx0, gy0, gx0 + 150, gy0 + 56], radius=8, fill=(14, 24, 38, 235), outline=(*accent_rgb, 255 if is_focus else 110), width=3 if is_focus else 1)
                    draw.text((gx0 + 14, gy0 + 16), f"CAM 0{r_i*3+c_i+1} · T-{max(0, 60-int(t*12)):02d}", fill=(250, 204, 21, 255) if is_focus else (148, 163, 184, 220), font=f_bn)
            return True
        if m_low == "sports-telestrator":
            # Tactical pitch + yellow telestrator rings & trajectory vector arrows
            draw.rounded_rectangle([cx - 265, cy - 95, cx + 265, cy + 95], radius=18, fill=(6, 48, 32, 235), outline=(52, 211, 153, 220), width=3)
            draw.line([(cx, cy - 95), (cx, cy + 95)], fill=(255, 255, 255, 95), width=2)
            draw.ellipse([cx - 52, cy - 52, cx + 52, cy + 52], outline=(255, 255, 255, 95), width=2)
            p_nodes = [(cx - 175, cy + 32), (cx - 25, cy - 38), (cx + 165, cy + 12)]
            draw.line(p_nodes, fill=(250, 204, 21, 255), width=5)
            for px, py in p_nodes:
                draw.ellipse([px - 26, py - 14, px + 26, py + 14], outline=(250, 204, 21, 255), width=4)
                paste_3d_sphere(img, px, py - 8, 14, (239, 68, 68), (255, 255, 255), light_angle_deg=light_deg)
            return True
        # Broadcast News Package / Caption News Strap + Live Ticker
        draw.rounded_rectangle([cx - 270, cy - 92, cx + 270, cy + 92], radius=16, fill=(12, 18, 32, 245), outline=(*accent_rgb, 240), width=3)
        draw.rectangle([cx - 270, cy + 44, cx + 270, cy + 92], fill=(220, 38, 38, 245))
        draw.text((cx - 245, cy + 56), f"BREAKING BRIEF // {sanitize_text((scene or {}).get('eyebrow') or 'LIVE REPORT')[:28].upper()}", fill=(255, 255, 255, 255), font=f_bn)
        for b_i, bh in enumerate((48, 76, 102, 64, 114)):
            bx = cx - 180 + b_i * 82
            draw.rounded_rectangle([bx, cy + 28 - bh, bx + 46, cy + 28], radius=6, fill=(*accent_rgb, 235))
        return True

    if m_low in ("visual-investigation", "constructivist-montage", "archive-light-table", "halftone-dossier"):
        # Investigation Board / Red String Connectors / Magnifying Loupe / Constructivist Wedges
        draw.rounded_rectangle([cx - 265, cy - 95, cx + 265, cy + 95], radius=16, fill=(244, 236, 218, 245), outline=(185, 28, 28, 240), width=3)
        cards_xy = [(cx - 165, cy - 18, "EVIDENCE A"), (cx + 5, cy + 16, "DOSSIER 02"), (cx + 170, cy - 22, "VERIFIED")]
        # Red string connecting evidence pins
        draw.line([(c[0], c[1]) for c in cards_xy], fill=(220, 38, 38, 245), width=4)
        f_ev = load_font(15, bold=True, mono=True)
        for ex, ey, elbl in cards_xy:
            draw.rounded_rectangle([ex - 64, ey - 38, ex + 64, ey + 38], radius=8, fill=(255, 255, 255, 250), outline=(40, 36, 32, 235), width=2)
            draw.ellipse([ex - 7, ey - 32, ex + 7, ey - 18], fill=(220, 38, 38, 255))
            draw.text((ex - 48, ey + 4), elbl, fill=(24, 24, 27, 255), font=f_ev)
        return True

    if m_low in ("satellite-briefing", "lidar-survey", "engineering-briefing-board", "exploded-teardown", "microscope-story", "data-physicalization", "blueprint-patent"):
        # Evidence & Technical Blueprint / LiDAR Point Cloud / Exploded Teardown Stage
        draw.rounded_rectangle([cx - 270, cy - 96, cx + 270, cy + 96], radius=22, fill=(7, 22, 42, 240), outline=(56, 189, 248, 235), width=3)
        if m_low in ("lidar-survey", "satellite-briefing"):
            # Topographic contours + scanning laser beam + 3D point cloud
            for r_c in (42, 78, 118):
                draw.ellipse([cx - r_c * 2, cy - int(r_c * 0.72), cx + r_c * 2, cy + int(r_c * 0.72)], outline=(16, 185, 129, 170), width=2)
            scan_x = cx - 240 + int(((t * 180) % 480))
            draw.line([(scan_x, cy - 90), (scan_x, cy + 90)], fill=(52, 211, 153, 245), width=4)
            paste_3d_sphere(img, cx, cy, 32, (16, 185, 129), (255, 255, 255), light_angle_deg=light_deg)
            return True
        if m_low in ("exploded-teardown", "blueprint-patent", "engineering-briefing-board"):
            # Radial exploded 3D parts with dimension leader lines
            spread = int(55 + 25 * math.sin(t * 2.2))
            for ox, oy, pcol in ((-spread * 2, 0, (56, 189, 248)), (0, -spread // 2, accent_rgb), (spread * 2, 0, (250, 204, 21))):
                draw_3d_extruded_box(draw, cx + ox - 38, cy + oy - 38, cx + ox + 38, cy + oy + 38, 16, -12, pcol, tuple(min(255, c + 40) for c in pcol), tuple(max(20, int(c * 0.65)) for c in pcol), (255, 255, 255))
            draw.line([(cx - spread * 2, cy + 58), (cx + spread * 2, cy + 58)], fill=(224, 242, 254, 220), width=2)
            return True
        # Microscope / Data Physicalization spiral plates
        for s_i in range(6):
            ang = t * 1.4 + s_i * (math.pi / 3.0)
            sx = cx + int(math.cos(ang) * (45 + s_i * 22))
            sy = cy + int(math.sin(ang) * (22 + s_i * 10))
            paste_3d_sphere(img, sx, sy, 18, accent_rgb if s_i % 2 == 0 else (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("whiteboard-explainer", "watercolor-brush", "chinese-ink-wash", "ukiyo-e", "papercut-lightbox", "risograph-print"):
        # Hand-Drawn / Papercut Lightbox / Ink Wash / Risograph Overprint Stage
        bg_card = (255, 255, 255, 248) if m_low == "whiteboard-explainer" else (248, 240, 224, 245)
        draw.rounded_rectangle([cx - 265, cy - 95, cx + 265, cy + 95], radius=24, fill=bg_card, outline=(*accent_rgb, 235), width=4)
        if m_low == "papercut-lightbox":
            # Multi-plane backlit paper-cut arches & glowing warm core
            for l_i, (rad_p, col_p) in enumerate(((105, (180, 83, 9)), (78, (217, 119, 6)), (52, (250, 204, 21)))):
                draw.ellipse([cx - rad_p * 2, cy - rad_p, cx + rad_p * 2, cy + rad_p], fill=(*col_p, 165))
            paste_3d_sphere(img, cx, cy, 34, (254, 240, 138), (255, 255, 255), light_angle_deg=light_deg)
            return True
        # Overlapping Risograph / Watercolor / Ink Wash organic circles + seal stamp
        draw.ellipse([cx - 145, cy - 65, cx + 15, cy + 65], fill=(236, 72, 153, 135) if m_low == "risograph-print" else (*accent_rgb, 135))
        draw.ellipse([cx - 15, cy - 65, cx + 145, cy + 65], fill=(56, 189, 248, 135))
        draw.rounded_rectangle([cx + 165, cy - 52, cx + 225, cy + 28], radius=6, fill=(185, 28, 28, 235))
        return True

    if m_low in (
        "swiss-motion-grid", "material-grid-3d", "onetake-fluid-flow", "dribbble-cursor-launch",
        "motionmaxxing-kinetic", "explainroo-fast", "pictogram-motion", "data-storytelling",
        "isometric-infographic", "dark-tech-keynote", "chat-message-story"
    ):
        # Launch Motion, Dribbble Cursor, Chat Story, Swiss Grid & Onetake Continuous Stage
        if m_low == "chat-message-story":
            bubbles = [
                (cx - 235, cy - 72, cx + 65, cy - 22, (30, 41, 59, 240), "Bagaimana alur kerja sistem ini?"),
                (cx - 55, cy - 8, cx + 240, cy + 42, (*accent_rgb, 245), "Otomatis, presisi, & terukur!"),
            ]
            f_ch = load_font(18, bold=True)
            for bx0, by0, bx1, by1, bcol, btxt in bubbles:
                draw.rounded_rectangle([bx0, by0, bx1, by1], radius=20, fill=bcol)
                draw.text((bx0 + 18, by0 + 12), btxt, fill=(255, 255, 255, 255), font=f_ch)
            return True
        if m_low == "dribbble-cursor-launch":
            # Interactive SaaS Launch Card + Animated Pointer Cursor clicking CTA
            draw.rounded_rectangle([cx - 245, cy - 82, cx + 245, cy + 82], radius=24, fill=(15, 23, 42, 245), outline=(*accent_rgb, 240), width=3)
            btn_x, btn_y = cx + 55, cy - 26
            draw.rounded_rectangle([btn_x, btn_y, btn_x + 155, btn_y + 52], radius=26, fill=(*accent_rgb, 255))
            paste_3d_sphere(img, cx - 115, cy, 42, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
            # Animated cursor arrow moving toward the button
            cur_u = ease_out_cubic(min(1.0, (local_frame % 45) / 28.0))
            cx_cur = int((cx - 180) + ((btn_x + 75) - (cx - 180)) * cur_u)
            cy_cur = int((cy + 70) + ((btn_y + 26) - (cy + 70)) * cur_u)
            draw.polygon([(cx_cur, cy_cur), (cx_cur + 28, cy_cur + 12), (cx_cur + 12, cy_cur + 28)], fill=(255, 255, 255, 255), outline=(10, 14, 24, 255))
            return True
        # Swiss Grid / Material Grid 3D / Onetake / Keynote Bento Stage
        draw.rounded_rectangle([cx - 260, cy - 90, cx + 260, cy + 90], radius=22, fill=(15, 23, 42, 235), outline=(*accent_rgb, 235), width=3)
        for g_i, gx in enumerate((cx - 155, cx, cx + 155)):
            col_g = [(56, 189, 248), accent_rgb, (250, 204, 21)][g_i]
            if m_low in ("material-grid-3d", "isometric-infographic"):
                draw_3d_extruded_box(draw, gx - 46, cy - 42, gx + 46, cy + 42, 18, -14, col_g, tuple(min(255, c + 40) for c in col_g), tuple(max(20, int(c * 0.65)) for c in col_g), (255, 255, 255))
            else:
                paste_3d_sphere(img, gx, cy, 38 if g_i == 1 else 28, col_g, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("manim-3b1b-math", "khan-blackboard-pen", "arxiv-paper-breakdown"):
        # 3Blue1Brown Manim Coordinate Plane & Parametric Curve / Khan Blackboard Chalk / ArXiv Paper
        bg_m = (8, 12, 20, 248) if m_low != "arxiv-paper-breakdown" else (250, 246, 238, 248)
        draw.rounded_rectangle([cx - 270, cy - 96, cx + 270, cy + 96], radius=18, fill=bg_m, outline=(*accent_rgb, 235), width=3)
        grid_c = (56, 189, 248, 45) if m_low != "arxiv-paper-breakdown" else (148, 163, 184, 70)
        for gx in range(cx - 240, cx + 250, 48):
            draw.line([(gx, cy - 88), (gx, cy + 88)], fill=grid_c, width=1)
        for gy in range(cy - 72, cy + 80, 36):
            draw.line([(cx - 255, gy), (cx + 255, gy)], fill=grid_c, width=1)
        # Axes
        axis_c = (226, 232, 240, 180) if m_low != "arxiv-paper-breakdown" else (30, 41, 59, 200)
        draw.line([(cx - 250, cy), (cx + 250, cy)], fill=axis_c, width=2)
        draw.line([(cx, cy - 86), (cx, cy + 86)], fill=axis_c, width=2)
        # Animated Fourier / Sine-Cosine wave + tangent vector arrow
        pts_m = []
        for i in range(64):
            ux = i / 63.0
            px = (cx - 235) + ux * 470
            py = cy - math.sin(ux * math.pi * 3.0 - t * 3.5) * 58 * math.cos(ux * math.pi * 0.5)
            pts_m.append((px, py))
        draw.line(pts_m, fill=(56, 189, 248, 255) if m_low == "manim-3b1b-math" else (*accent_rgb, 255), width=4)
        tan_pt = pts_m[min(len(pts_m) - 1, int((t * 18) % len(pts_m)))]
        draw.line([(cx, cy), tan_pt], fill=(250, 204, 21, 255), width=4)
        paste_3d_sphere(img, tan_pt[0], tan_pt[1], 11, (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
        f_eq = load_font(20, bold=True, serif=True)
        draw.text((cx - 240, cy - 82), "f(x, t) = A · sin(ωt - kx)", fill=(250, 204, 21, 255) if m_low != "arxiv-paper-breakdown" else (185, 28, 28, 255), font=f_eq)
        return True

    if m_low in ("git-commit-tree", "typewriter-vscode", "live-panel-architecture"):
        # Git Commit Graph / VS Code Dark Editor / Live Architecture Panel
        draw.rounded_rectangle([cx - 270, cy - 96, cx + 270, cy + 96], radius=16, fill=(13, 17, 23, 248), outline=(48, 54, 61, 245), width=3)
        f_code = load_font(16, bold=True, mono=True)
        if m_low == "git-commit-tree":
            # Main branch + feature branch merge graph
            draw.line([(cx - 220, cy - 28), (cx + 220, cy - 28)], fill=(56, 189, 248, 235), width=4)
            draw.line([(cx - 120, cy - 28), (cx - 45, cy + 38), (cx + 95, cy + 38), (cx + 165, cy - 28)], fill=(168, 85, 247, 235), width=4)
            for gx, gy, gcol, gsha in (
                (cx - 200, cy - 28, (56, 189, 248), "a1f9c2"),
                (cx - 120, cy - 28, (56, 189, 248), "b4e801"),
                (cx - 45, cy + 38, (168, 85, 247), "feat/ai"),
                (cx + 95, cy + 38, (168, 85, 247), "c92d11"),
                (cx + 165, cy - 28, (16, 185, 129), "HEAD"),
            ):
                paste_3d_sphere(img, gx, gy, 15, gcol, (255, 255, 255), light_angle_deg=light_deg)
                draw.text((gx - 28, gy - 38 if gy < cy else gy + 18), gsha, fill=(226, 232, 240, 240), font=f_code)
            return True
        # VS Code / Live Panel syntax lines with active cursor
        for l_i, (ln_col, ln_w) in enumerate((((249, 115, 22), 180), ((56, 189, 248), 290), ((16, 185, 129), 240), ((168, 85, 247), 320))):
            ly = cy - 64 + l_i * 34
            draw.text((cx - 245, ly), f"0{l_i+1}", fill=(100, 116, 139, 200), font=f_code)
            draw.rounded_rectangle([cx - 195, ly + 4, cx - 195 + ln_w, ly + 20], radius=6, fill=(*ln_col, 220))
        return True

    if m_low in ("kurzgesagt-flat-cosmos", "zackd-curiosity-3d", "map-globe-route"):
        # Kurzgesagt Vibrant Flat Cosmos / Zack D 3D Macro / Animated Globe Route
        draw.rounded_rectangle([cx - 265, cy - 95, cx + 265, cy + 95], radius=26, fill=(14, 22, 48, 242), outline=(*accent_rgb, 240), width=3)
        paste_3d_sphere(img, cx, cy, 56, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        draw.arc([cx - 165, cy - 48, cx + 165, cy + 48], start=0, end=360, fill=(250, 204, 21, 215), width=3)
        orb_ang = t * 2.4
        ox = cx + int(math.cos(orb_ang) * 155)
        oy = cy + int(math.sin(orb_ang) * 44)
        paste_3d_sphere(img, ox, oy, 18, (249, 115, 22), (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in (
        "diary-comic-wipes", "crayon-picture-book", "impasto-oil-canvas", "shadow-puppetry-stage",
        "woodcut-copperplate", "silkscreen-travel-poster", "stained-glass-cathedral", "art-deco-golden",
        "spy-60s-title", "rubber-hose-1930s", "cel-anime-80s", "silent-film-1920s", "liminal-vhs-footage",
        "paper-popup-book"
    ):
        # Stories, Art Traditions, Cinema & Era Stage
        if m_low == "diary-comic-wipes":
            # 3 Horizontal Comic Panels (Text -> Sketch -> Full Color)
            for p_i, (px0, pcol, plbl) in enumerate(((cx - 255, (241, 245, 249), "01. STORY"), (cx - 80, (226, 232, 240), "02. SKETCH"), (cx + 95, (*accent_rgb,), "03. COLOR"))):
                draw.rounded_rectangle([px0, cy - 82, px0 + 160, cy + 82], radius=12, fill=(*pcol, 235), outline=(24, 24, 27, 255), width=3)
                paste_3d_sphere(img, px0 + 80, cy + 8, 28, accent_rgb if p_i < 2 else (250, 204, 21), (255, 255, 255), light_angle_deg=light_deg)
            return True
        if m_low in ("stained-glass-cathedral", "art-deco-golden"):
            # Golden Art Deco / Stained Glass Geometric Sunburst Arch
            draw.rounded_rectangle([cx - 260, cy - 92, cx + 260, cy + 92], radius=20, fill=(18, 14, 28, 245), outline=(245, 158, 11, 255), width=4)
            for ray_deg in range(-75, 80, 25):
                rx = cx + int(math.sin(math.radians(ray_deg)) * 210)
                ry = cy - int(math.cos(math.radians(ray_deg)) * 80)
                draw.line([(cx, cy + 75), (rx, ry)], fill=(245, 158, 11, 210), width=3)
            paste_3d_sphere(img, cx, cy + 10, 42, (245, 158, 11), (254, 240, 138), light_angle_deg=light_deg)
            return True
        # General Cinema / Art Frame with projector/VHS/Shadow-Puppet styling
        draw.rounded_rectangle([cx - 260, cy - 90, cx + 260, cy + 90], radius=18, fill=(24, 20, 18, 240), outline=(*accent_rgb, 240), width=4)
        paste_3d_sphere(img, cx, cy, 46, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        return True

    if m_low in ("pixel-rpg-16bit", "hd-2d-diorama", "game-show-rhythm", "brick-toy-lego"):
        # Games & Brick Toy Stage
        if m_low == "brick-toy-lego":
            # 3D Interlocking Studded Bricks
            for b_i, (bx, bcol) in enumerate(((cx - 145, (239, 68, 68)), (cx, (250, 204, 21)), (cx + 145, (37, 99, 235)))):
                draw_3d_extruded_box(draw, bx - 54, cy - 28, bx + 54, cy + 48, 16, -12, bcol, tuple(min(255, c + 40) for c in bcol), tuple(max(20, int(c * 0.65)) for c in bcol), (255, 255, 255))
                # Studs on top of each brick
                for sx_off in (-24, 24):
                    draw.ellipse([bx + sx_off - 14, cy - 44, bx + sx_off + 14, cy - 26], fill=tuple(min(255, c + 35) for c in bcol), outline=(255, 255, 255, 230), width=2)
            return True
        # RPG Save Window / Game Show Scoreboard
        draw.rounded_rectangle([cx - 265, cy - 92, cx + 265, cy + 92], radius=14, fill=(18, 28, 78, 245), outline=(255, 255, 255, 250), width=4)
        f_rpg = load_font(19, bold=True, mono=True)
        draw.text((cx - 235, cy - 68), "LV 99  SHOTCRAFT HERO     HP 999/999", fill=(250, 204, 21, 255), font=f_rpg)
        draw.rounded_rectangle([cx - 235, cy - 24, cx + 235, cy + 12], radius=8, fill=(16, 185, 129, 240))
        draw.text((cx - 235, cy + 32), "▶ SAVE POINT REACHED · CONTINUE", fill=(255, 255, 255, 255), font=f_rpg)
        return True

    if m_low in ("podcast-audiogram-wave", "reddit-thread-story", "vocaloid-lyric-mv", "appstore-device-showcase", "ai-presenter-studio"):
        # Social, Podcast Audiogram, Vocaloid Lyric MV, AppStore & AI Presenter Studio
        draw.rounded_rectangle([cx - 265, cy - 94, cx + 265, cy + 94], radius=24, fill=(15, 23, 42, 242), outline=(*accent_rgb, 240), width=3)
        if m_low in ("podcast-audiogram-wave", "vocaloid-lyric-mv"):
            for w_i in range(24):
                wx = cx - 220 + w_i * 19
                wh = int(18 + 58 * abs(math.sin(t * 6.0 + w_i * 0.45)))
                draw.rounded_rectangle([wx, cy - wh, wx + 11, cy + wh], radius=5, fill=(*accent_rgb, 245) if w_i % 2 == 0 else (236, 72, 153, 235))
            return True
        paste_3d_sphere(img, cx - 155, cy, 42, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)
        draw.rounded_rectangle([cx - 85, cy - 48, cx + 230, cy - 8], radius=10, fill=(30, 41, 59, 240))
        draw.rounded_rectangle([cx - 85, cy + 8, cx + 185, cy + 48], radius=10, fill=(*accent_rgb, 185))
        return True

    return False


def render_ref3_cutaway_mechanism_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    """
    RQ01 & Section 14.4:
    R3 Benchmark Family (`ref3-cutaway-mechanism`):
    - Clean sky-to-turf-to-soil environmental cutaway canvas (inspired by `snapgram.io_xa8zgeyyv9wv.mp4`)
    - Crisp white rounded caption pill near the top (`y=235`) so captions NEVER cover the mechanism
    - Persistent scene graph in the center/lower-middle with callout labels anchored to components
    - Structured mechanism summary card below the soil bed
    """
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent") or "#1D7A46"
    accent_rgb = hex_to_rgb(accent_hex)

    # Build sky-blue to soft horizon gradient background
    yy = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
    r_ch = np.clip(92.0 + (215.0 - 92.0) * np.minimum(1.0, yy * 1.4), 0, 255).astype(np.uint8)
    g_ch = np.clip(178.0 + (238.0 - 178.0) * np.minimum(1.0, yy * 1.4), 0, 255).astype(np.uint8)
    b_ch = np.clip(247.0 + (252.0 - 247.0) * np.minimum(1.0, yy * 1.4), 0, 255).astype(np.uint8)
    img = Image.fromarray(np.dstack([np.broadcast_to(r_ch, (height, width)), np.broadcast_to(g_ch, (height, width)), np.broadcast_to(b_ch, (height, width))]), mode="RGB")
    draw = FastRGBDraw(img, bg=(120, 195, 250))

    pad_x, right_x = 84, 876
    usable_w = right_x - pad_x
    cx = (pad_x + right_x) // 2

    # Top Eyebrow & Step Indicator Pill
    f_kicker = load_font(20, bold=True)
    eyebrow_txt = sanitize_text(scene.get("eyebrow") or f"TAHAP 0{scene_idx + 1} · MEKANISME").upper()
    ew = int(draw.textlength(eyebrow_txt, font=f_kicker)) + 36
    draw.rounded_rectangle([cx - ew // 2, 195, cx + ew // 2, 233], radius=19, fill=(15, 23, 42, 220), outline=(*accent_rgb, 240), width=2)
    draw.text((cx - ew // 2 + 18, 202), eyebrow_txt, fill=(248, 250, 252, 255), font=f_kicker)

    # Top R3-Style White Rounded Caption Pill (keeps mechanism 100% unobstructed!)
    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=260,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(250, 204, 21),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene={**scene, "y_center": 260},
        local_frame=local_frame,
    )

    # Headline Card cleanly above the cutaway stage
    h_raw = sanitize_text(scene.get("headline", ""))
    h_lines, f_h1, h_sz = fit_text_block(draw, h_raw, usable_w - 48, max_lines=2, start_size=34, min_size=24, bold=True)
    draw.rounded_rectangle([pad_x, 410, right_x, 535], radius=22, fill=(255, 255, 255, 242), outline=(*accent_rgb, 215), width=3)
    hy = 428
    for ln in h_lines:
        lw = int(draw.textlength(ln, font=f_h1))
        draw.text((cx - lw // 2, hy), ln, fill=(15, 23, 42, 255), font=f_h1)
        hy += int(h_sz * 1.18)

    # Main Cutaway Mechanism Stage (`y=560..1120`)
    subj = str(scene.get("subjectId") or scene.get("cutawayKind") or "").lower()
    diag_cy = 815
    if "lawnmower" in subj or "rumput" in f"{h_raw} {scene.get('subcopy', '')}".lower():
        draw_lawnmower_scene_graph_rig(img, draw, cx, diag_cy, local_frame, fps, accent_rgb=accent_rgb, scale_factor=1.0, scene=scene)
    elif "engine" in subj or "motor" in subj:
        draw_true_3d_engine_cutaway(img, draw, diag_cy, local_frame, fps)
    elif "coffee" in subj or "kopi" in subj:
        draw_true_3d_coffee_stage(img, draw, diag_cy, local_frame, fps)
    elif "brain" in subj or "neural" in subj:
        draw.rounded_rectangle([110, diag_cy - 140, 850, diag_cy + 140], radius=36, fill=(15, 23, 42, 245), outline=(*accent_rgb, 220), width=3)
        draw_true_3d_neuron_network(img, draw, cx, diag_cy, local_frame, fps, accent_rgb, scale_factor=0.85, scene=scene)
    else:
        # Environmental ground + 3-node mechanism cutaway for solar, ecology, boiling water, fire safety, etc.
        ground_y = diag_cy + 85
        draw.rounded_rectangle([84, ground_y, 996, ground_y + 40], radius=10, fill=(116, 184, 67, 255))
        draw.rounded_rectangle([84, ground_y + 34, 996, ground_y + 135], radius=12, fill=(158, 98, 48, 255))
        draw.rounded_rectangle([110, diag_cy - 125, 850, diag_cy + 95], radius=32, fill=(18, 28, 46, 242), outline=(*accent_rgb, 230), width=3)
        draw_true_3d_system_flowchart(img, draw, cx, diag_cy - 10, local_frame, fps, accent_rgb, scale_factor=0.88, scene=scene)

    # Callout Pills below the cutaway mechanism (`y=1075..1135`)
    f_callout = load_font(18, bold=True)
    callouts = scene.get("callouts") or []
    for c_i, c_item in enumerate(callouts[:3]):
        if isinstance(c_item, dict):
            lbl = sanitize_text(c_item.get("label", "KOMPONEN"))[:18]
            tx, ty = int(c_item.get("tx", 300)), int(c_item.get("ty", diag_cy))
            px = int(c_item.get("px", 230 + c_i * 250))
            py_c = 1095
        else:
            lbl, tx, ty, px, py_c = str(c_item[0])[:18], int(c_item[1]), int(c_item[2]), int(c_item[3]), 1095
        draw.line([(tx, min(ty, 960)), (px, py_c - 18)], fill=(15, 23, 42, 200), width=3)
        cw = int(draw.textlength(lbl, font=f_callout)) + 28
        draw.rounded_rectangle([px - cw // 2, py_c - 20, px + cw // 2, py_c + 20], radius=10, fill=(254, 240, 138, 255), outline=(202, 138, 4, 255), width=2)
        draw.text((px - cw // 2 + 14, py_c - 11), lbl, fill=(15, 23, 42, 255), font=f_callout)

    # Bottom Structured Mechanism Notes Card (`y=1165..1455`)
    draw.rounded_rectangle([pad_x, 1165, right_x, 1455], radius=24, fill=(255, 255, 255, 248), outline=(203, 213, 225, 255), width=3)
    f_wt = load_font(19, bold=True)
    f_wb = load_font(23, bold=True)
    win_title = sanitize_text(scene.get("windowTitle") or f"DETAIL MEKANISME — TAHAP 0{scene_idx + 1}")[:48]
    draw.text((pad_x + 28, 1188), win_title, fill=(*accent_rgb, 255), font=f_wt)
    draw.line([(pad_x + 28, 1222), (right_x - 28, 1222)], fill=(226, 232, 240, 255), width=2)

    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    ry = 1242
    for idx_l, ln_txt in enumerate(ctx_lines[:3]):
        draw_check_badge(draw, pad_x + 28, ry + 4, 14, accent_rgb, scale=1.0, light_bg=True)
        draw.text((pad_x + 68, ry + 2), ln_txt[:46], fill=(15, 23, 42, 255), font=f_wb)
        ry += 62

    return img


def render_ref1_voxel_evidence_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    """
    RQ01, RQ04 & Section 14.2:
    R1 Benchmark Family (`ref1-voxel-evidence`, inspired by `snapgram.io_bls6ci1y8rpw.mp4`):
    - Deep dark navy background (`#060A17`) with electric blue accents (`#2563EB`)
    - Outlined step number (`01`, `02`, ...) + Title + Pill tags at the top
    - Dark browser/UI evidence window in the upper-middle (`y=360..960`) with table/specs and blue callout badge
    - Large bold emphasis caption at `y=1020..1130`
    - Consistent Voxel Presenter character with blue knit beanie, striped shirt, and speech-driven pose at bottom-right (`y=1170..1480`)
    """
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    accent_rgb = (37, 99, 235)

    img = Image.new("RGB", (width, height), (6, 10, 23))
    draw = FastRGBDraw(img, bg=(6, 10, 23))
    for rad, alpha in ((420, 26), (260, 42)):
        draw.ellipse([480 - rad, 560 - rad, 480 + rad, 560 + rad], fill=(37, 99, 235, alpha))

    pad_x, right_x = 84, 876
    usable_w = right_x - pad_x

    # Top Number (`01`) + Subject Title + Pill Tags
    f_num = load_font(68, bold=True)
    f_title = load_font(44, bold=True)
    f_tag = load_font(18, bold=True, mono=True)
    num_str = f"0{scene_idx + 1}"
    draw.text((pad_x, 205), num_str, fill=(56, 189, 248, 255), font=f_num)

    short_title = sanitize_text(scene.get("windowTitle") or scene.get("eyebrow") or "FITUR UTAMA")[:24]
    draw.text((pad_x + 115, 212), short_title, fill=(248, 250, 252, 255), font=f_title)

    tag1 = sanitize_text(scene.get("subjectId", "SYSTEM")).upper()[:16]
    tag2 = f"TAHAP 0{scene_idx + 1}"
    draw.rounded_rectangle([pad_x + 115, 272, pad_x + 295, 308], radius=10, fill=(15, 23, 42, 255), outline=(37, 99, 235, 220), width=2)
    draw.text((pad_x + 130, 279), tag1, fill=(147, 197, 253, 255), font=f_tag)
    draw.rounded_rectangle([pad_x + 310, 272, pad_x + 455, 308], radius=10, fill=(15, 23, 42, 255), outline=(71, 85, 105, 220), width=2)
    draw.text((pad_x + 328, 279), tag2, fill=(203, 213, 225, 255), font=f_tag)

    # Browser / Evidence Window (`y=345..945`)
    wt, wb = 345, 945
    draw.rounded_rectangle([pad_x, wt, right_x, wb], radius=24, fill=(15, 20, 32, 252), outline=(51, 65, 85, 220), width=3)
    draw.ellipse([pad_x + 24, wt + 20, pad_x + 38, wt + 34], fill=(239, 68, 68, 255))
    draw.ellipse([pad_x + 48, wt + 20, pad_x + 62, wt + 34], fill=(245, 158, 11, 255))
    draw.ellipse([pad_x + 72, wt + 20, pad_x + 86, wt + 34], fill=(16, 185, 129, 255))
    url_txt = f"docs.shotcraft.local/{sanitize_text(scene.get('subjectId', 'explainer')).lower()}/stage-{scene_idx+1}"
    draw.rounded_rectangle([pad_x + 106, wt + 12, right_x - 24, wt + 44], radius=10, fill=(9, 13, 22, 255), outline=(51, 65, 85, 180), width=1)
    draw.text((pad_x + 122, wt + 17), url_txt[:46], fill=(148, 163, 184, 255), font=f_tag)

    # Headline inside evidence browser
    h_raw = sanitize_text(scene.get("headline", ""))
    h_lines, f_h, h_sz = fit_text_block(draw, h_raw, usable_w - 56, max_lines=2, start_size=30, min_size=22, bold=True)
    hy = wt + 68
    for ln in h_lines:
        draw.text((pad_x + 28, hy), ln, fill=(226, 232, 240, 255), font=f_h)
        hy += int(h_sz * 1.2)

    # Structured comparison table inside evidence window
    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    tbl_y = wt + 175
    draw.rounded_rectangle([pad_x + 24, tbl_y, right_x - 24, tbl_y + 52], radius=12, fill=(30, 41, 59, 240))
    f_th = load_font(20, bold=True)
    f_td = load_font(22, bold=False)
    draw.text((pad_x + 44, tbl_y + 14), "KOMPONEN / PARAMETER", fill=(148, 163, 184, 255), font=f_th)
    draw.text((pad_x + 360, tbl_y + 14), "PERAN & BUKTI MEKANISME", fill=(248, 250, 252, 255), font=f_th)

    row_y = tbl_y + 68
    for r_i, r_ln in enumerate(ctx_lines[:3]):
        parts = r_ln.split(":", 1)
        k_txt = parts[0].strip()[:20]
        v_txt = parts[1].strip()[:32] if len(parts) > 1 else r_ln[:32]
        draw.text((pad_x + 44, row_y), k_txt, fill=(203, 213, 225, 255), font=f_th)
        draw.text((pad_x + 360, row_y), v_txt, fill=(248, 250, 252, 255), font=f_td)
        if r_i < 2:
            draw.line([(pad_x + 36, row_y + 42), (right_x - 36, row_y + 42)], fill=(51, 65, 85, 160), width=2)
        row_y += 62

    # Blue Floating Highlight Card on top-right of evidence table (like R1 "infinity gratis" badge)
    badge_txt = sanitize_text(scene.get("stickerText") or f"TAHAP 0{scene_idx + 1}")[:16]
    draw.rounded_rectangle([right_x - 275, wt + 88, right_x - 28, wt + 195], radius=20, fill=(37, 99, 235, 255), outline=(147, 197, 253, 255), width=3)
    draw.text((right_x - 252, wt + 104), "FOKUS INTI", fill=(219, 234, 254, 255), font=f_tag)
    draw.text((right_x - 252, wt + 134), badge_txt, fill=(255, 255, 255, 255), font=load_font(28, bold=True))

    # Center Bold Blue/White Caption Band (`y=1015`)
    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1025,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(59, 130, 246),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene={**scene, "y_center": 1025},
        local_frame=local_frame,
    )

    # Bottom-Left 3D Volumetric Hologram Stage (`x=140..470, y=1185..1440`) so 3D object is always visible alongside Voxel Presenter
    draw.rounded_rectangle([pad_x, 1175, 485, 1455], radius=24, fill=(12, 18, 34, 235), outline=(56, 189, 248, 195), width=2)
    draw_30fps_center_stage(
        img=img,
        draw=draw,
        cx=284,
        cy=1315,
        mode=str(scene.get("stage3DKind") or "supercomputer-core"),
        scene_idx=scene_idx,
        local_frame=local_frame,
        fps=fps,
        accent_rgb=(56, 189, 248),
        metric_Display="",
        unit_display="",
        scene=scene,
    )

    # Bottom-Right Consistent Voxel Presenter Character (`x=540..840, y=1185..1480`)
    # Pose changes deterministically with scene progress (pointing, explaining, nodding)
    bob = int(math.sin(t * 4.5) * 6)
    vx, vy = 685, 1368 + bob
    # Blue Knit Beanie (Voxel blocks)
    draw_3d_extruded_box(draw, vx - 78, vy - 165, vx + 78, vy - 105, 16, -12, (37, 99, 235), (59, 130, 246), (29, 78, 216), (147, 197, 253))
    draw_3d_extruded_box(draw, vx - 24, vy - 190, vx + 24, vy - 165, 12, -10, (37, 99, 235), (96, 165, 250), (29, 78, 216), (147, 197, 253))
    # Voxel Face
    draw_3d_extruded_box(draw, vx - 72, vy - 105, vx + 72, vy + 5, 16, -12, (238, 180, 140), (247, 202, 168), (196, 140, 102), (255, 237, 213))
    # Eyes & Open/Closed Speech Mouth
    draw.rectangle([vx - 42, vy - 68, vx - 22, vy - 42], fill=(15, 23, 42, 255))
    draw.rectangle([vx + 22, vy - 68, vx + 42, vy - 42], fill=(15, 23, 42, 255))
    mouth_h = 14 if int(t * 6) % 2 == 0 else 6
    draw.rounded_rectangle([vx - 10, vy - 26, vx + 10, vy - 26 + mouth_h], radius=4, fill=(30, 20, 16, 255))
    # Striped Shirt Torso
    draw_3d_extruded_box(draw, vx - 76, vy + 5, vx + 76, vy + 135, 16, -12, (241, 245, 249), (255, 255, 255), (203, 213, 225), (148, 163, 184))
    for sy in range(vy + 22, vy + 125, 28):
        draw.rectangle([vx - 74, sy, vx + 74, sy + 12], fill=(37, 99, 235, 255))
    # Pointing Left Arm (pointing up toward the UI evidence card!)
    arm_lift = int(math.sin(t * 3.0) * 10)
    draw_3d_extruded_box(draw, vx - 135, vy - 55 + arm_lift, vx - 82, vy + 35 + arm_lift, 12, -10, (238, 180, 140), (247, 202, 168), (196, 140, 102), (255, 237, 213))

    return img


def render_ref4_minimal_ui_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    """
    RQ01 & Section 14.5:
    R4 Benchmark Family (`ref4-minimal-ui`, inspired by `snapgram.io_rjbniockibb0.mp4`):
    - Clean warm off-white canvas (`#F5F4F0`)
    - Top centered pill counter (`01 / 04 · Tahap Mekanisme`) with pink/accent status square
    - Elevated white UI card in the center (`y=460..980`) with soft drop shadow, colored category rows,
      waveform/progress bar, and data-grounded status
    - High-contrast dark typography caption below (`y=1280`)
    """
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent") or "#EC4899"
    accent_rgb = hex_to_rgb(accent_hex)

    img = Image.new("RGB", (width, height), (245, 244, 240))
    draw = FastRGBDraw(img, bg=(245, 244, 240))

    pad_x, right_x = 84, 876
    usable_w = right_x - pad_x
    cx = (pad_x + right_x) // 2

    # Top Progress Pill (`01 / 04 · ...`)
    f_top = load_font(22, bold=True)
    top_txt = f"0{scene_idx + 1} / 0{total_scenes}  {sanitize_text(scene.get('eyebrow') or 'Tahap Inti')[:24]}"
    tw = int(draw.textlength(top_txt, font=f_top)) + 68
    px0 = cx - tw // 2
    draw.rounded_rectangle([px0 + 3, 248, px0 + tw + 3, 304], radius=28, fill=(0, 0, 0, 18))
    draw.rounded_rectangle([px0, 244, px0 + tw, 300], radius=28, fill=(255, 255, 255, 255), outline=(226, 232, 240, 255), width=2)
    draw.rounded_rectangle([px0 + 18, 258, px0 + 46, 286], radius=8, fill=(*accent_rgb, 255))
    draw.text((px0 + 58, 258), top_txt, fill=(24, 24, 27, 255), font=f_top)

    # Center Elevated White UI Card (`y=460..990`)
    ct, cb = 460, 990
    draw.rounded_rectangle([pad_x + 8, ct + 14, right_x + 8, cb + 14], radius=32, fill=(0, 0, 0, 22))
    draw.rounded_rectangle([pad_x, ct, right_x, cb], radius=32, fill=(255, 255, 255, 255), outline=(228, 228, 231, 255), width=2)

    f_cmd = load_font(24, bold=True, mono=True)
    f_lbl = load_font(19, bold=True, mono=True)
    f_val = load_font(23, bold=True)

    cmd_title = f"/{sanitize_text(scene.get('subjectId', 'workflow')).lower()} — {sanitize_text(scene.get('windowTitle', 'tahap'))[:28].lower()}"
    draw.text((pad_x + 36, ct + 34), cmd_title, fill=(219, 39, 119, 255), font=f_cmd)
    draw.line([(pad_x + 28, ct + 84), (right_x - 28, ct + 84)], fill=(241, 245, 249, 255), width=2)

    # Row 1: Headline pill
    h_raw = sanitize_text(scene.get("headline", ""))[:54]
    draw.text((pad_x + 36, ct + 112), "INTI", fill=(219, 39, 119, 255), font=f_lbl)
    draw.rounded_rectangle([pad_x + 175, ct + 98, right_x - 36, ct + 154], radius=12, fill=(252, 231, 243, 255))
    draw.text((pad_x + 195, ct + 112), h_raw[:38], fill=(24, 24, 27, 255), font=f_val)

    # Rows 2..4: Context lines as structured UI tracks
    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    track_colors = [
        ((124, 58, 237), (237, 233, 254)),
        ((37, 99, 235), (219, 234, 254)),
        ((22, 163, 74), (220, 252, 231)),
    ]
    ry = ct + 180
    for idx_r, raw_ln in enumerate(ctx_lines[:3]):
        fg_c, bg_c = track_colors[idx_r % len(track_colors)]
        parts = raw_ln.split(":", 1)
        left_k = parts[0].strip().upper()[:12]
        right_v = parts[1].strip()[:36] if len(parts) > 1 else raw_ln[:36]
        draw.text((pad_x + 36, ry + 14), left_k, fill=(*fg_c, 255), font=f_lbl)
        draw.rounded_rectangle([pad_x + 175, ry, right_x - 36, ry + 54], radius=12, fill=(*bg_c, 255))
        draw.text((pad_x + 195, ry + 13), right_v, fill=(24, 24, 27, 255), font=f_val)
        ry += 74

    # Embedded 3D Volumetric Emblem inside R4 Minimal UI Card (top-right corner of card) so 3D stage is always present
    light_deg_r4 = int(round(-35 + math.sin(t * 1.6) * 35))
    orb_x, orb_y = right_x - 86, ct + 46
    for r_i in range(3):
        ang_r4 = t * 1.8 + r_i * (2.0 * math.pi / 3.0)
        ox = orb_x + math.cos(ang_r4) * 32
        oy = orb_y + math.sin(ang_r4) * 14
        paste_3d_sphere(img, ox, oy, 9, accent_rgb, (255, 255, 255), light_angle_deg=light_deg_r4)
    paste_3d_sphere(img, orb_x, orb_y, 20, accent_rgb, (255, 255, 255), light_angle_deg=light_deg_r4)

    # Bottom Progress Bar inside Card
    bar_y = cb - 56
    prog_u = min(1.0, (scene_idx + u) / float(max(1, total_scenes)))
    draw.rounded_rectangle([pad_x + 36, bar_y, right_x - 210, bar_y + 18], radius=9, fill=(241, 245, 249, 255))
    fill_w = max(24, int((usable_w - 246) * prog_u))
    draw.rounded_rectangle([pad_x + 36, bar_y, pad_x + 36 + fill_w, bar_y + 18], radius=9, fill=(24, 24, 27, 255))
    draw.text((right_x - 190, bar_y - 4), f"tahap {scene_idx+1}/{total_scenes}", fill=(113, 113, 122, 255), font=f_lbl)

    # Bottom Minimal Dark Caption on Off-White Canvas (`y=1240`)
    words = sanitize_text(scene.get("narration") or scene.get("subcopy") or scene.get("headline", "")).split()
    if words:
        active_i = min(len(words) - 1, int(u * len(words)))
        chunk_start = (active_i // 3) * 3
        vis_words = words[chunk_start : chunk_start + 3]
        f_cap_b = load_font(46, bold=True)
        f_cap_i = load_font(46, bold=False, serif=True)
        line_str = " ".join(vis_words)
        lw = int(draw.textlength(line_str, font=f_cap_b))
        wx = cx - lw // 2
        word_fonts = [(w_tok, f_cap_i if (chunk_start + w_i) == active_i else f_cap_b, (chunk_start + w_i) == active_i) for w_i, w_tok in enumerate(vis_words)]
        total_w_px = sum(int(draw.textlength(wt, font=wf)) for wt, wf, _ in word_fonts) + 18 * max(0, len(word_fonts) - 1)
        wx = cx - total_w_px // 2
        for wt, wf, is_act in word_fonts:
            col = (*accent_rgb, 255) if is_act else (24, 24, 27, 255)
            draw.text((wx, 1245), wt, fill=col, font=wf)
            wx += int(draw.textlength(wt, font=wf)) + 18

    return img


def render_cream_editorial_cutaway_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))

    is_serif = use_serif_for_scene(scene, badge, brand_kit=brand_kit)
    h_raw = sanitize_text(scene.get("headline", "Bedah Cara Kerja & Fakta Ilmiah"))
    theme_cfg = scene.get("theme") or {}
    cutaway_kind = theme_cfg.get("stage3D") or scene.get("cutawayKind")
    ctx_joined = " ".join(str(x) for x in (scene.get("windowContentLines") or []))
    t_check = (h_raw + " " + badge + " " + ctx_joined + " " + str(scene.get("visualMode", ""))).lower()
    if not cutaway_kind:
        if any(k in t_check for k in ("kopi", "coffee", "espresso", "seduh", "kafein", "teh", "kuliner")):
            cutaway_kind = "coffee"
        elif any(k in t_check for k in ("rumput", "lawnmower", "mower")):
            cutaway_kind = "lawnmower"
        elif any(k in t_check for k in ("pisau", "bilah", "turbin", "kipas", "rotasi", "dinamo", "potong", "rpm")):
            cutaway_kind = "rotary"
        elif any(k in t_check for k in ("turbofan", "jet", "aviation", "mesin jet")):
            cutaway_kind = "turbofan"
        elif any(k in t_check for k in ("oli", "piston", "silinder", "injeksi", "knalpot", "busi", "karburator")):
            cutaway_kind = "engine"
        elif any(k in t_check for k in ("otak", "neuron", "saraf", "sinapsis", "neural", "transformer", "llm", "gpt", "parameter")):
            cutaway_kind = "brain"
        else:
            cutaway_kind = "flowchart"

    bg_kind = theme_cfg.get("background") or (
        "warm-paper" if scene.get("visualMode") == "ink-press-vertical"
        else "vox-grid" if scene.get("visualMode") == "vox-explainer"
        else "coffee-editorial" if cutaway_kind == "coffee"
        else "cream-editorial"
    )
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent") or "#1D7A46"
    accent_rgb = hex_to_rgb(accent_hex)
    img = build_world_background(width, height, bg_kind, accent_hex, scene_idx).copy()
    draw = FastRGBDraw(img, bg=(246, 239, 228) if bg_kind == "coffee-editorial" else (242, 237, 224))

    # Point 1 Z-Order Fix: Render background atmosphere particles BEFORE any text or cards
    try:
        skills_root_p = _resolve_skills_root()
        if str(skills_root_p / "reels-motion" / "scripts") not in sys.path:
            sys.path.insert(0, str(skills_root_p / "reels-motion" / "scripts"))
        import particles as part_mod
        part_mod.apply_particles_and_atmosphere(
            img, draw, local_frame=local_frame, fps=fps, accent_rgb=accent_rgb,
            style_mode="coffee-editorial-3d" if cutaway_kind == "coffee" else "ref5-editorial-cutaway",
            audio_rms=float(scene.get("_audio_rms", 0.0)),
        )
    except Exception:
        pass

    cam_info = compute_intrascene_camera_cut(local_frame, dur_frames, fps, scene)
    draw_camera_hud_pill(draw, 876, 180, cam_info, accent_rgb, light_bg=True)

    pad_x = 84
    right_x = 876
    usable_w = right_x - pad_x

    f_kicker = load_font(20, bold=True, serif=False)
    f_badge = load_font(19, bold=True, serif=False)
    f_callout = load_font(19, bold=True, serif=False)

    kicker = sanitize_text(scene.get("eyebrow") or f"{badge} - 00:0{scene_idx * 4}").upper()
    draw.text((pad_x, 222), kicker, fill=(108, 92, 76, 255) if cutaway_kind == "coffee" else (98, 94, 84, 255), font=f_kicker)

    h_lines, f_h1, h_sz = fit_text_block(
        draw,
        h_raw,
        usable_w,
        max_lines=3,
        start_size=40,
        min_size=26,
        bold=True,
        serif=is_serif,
    )
    hy = 252
    line_step = int(h_sz * 1.20)
    green_rgb = (146, 64, 14) if cutaway_kind == "coffee" else (29, 122, 70)
    red_rgb = (180, 83, 9) if cutaway_kind == "coffee" else (200, 67, 25)
    charcoal_rgb = (38, 24, 16) if cutaway_kind == "coffee" else (28, 27, 24)

    for l_idx, ln in enumerate(h_lines):
        wx = pad_x
        words_ln = ln.split()
        for w_i, w in enumerate(words_ln):
            w_low = w.lower().strip(".,?!:")
            if w_low in ("perlu", "awet", "injeksi", "santai", "sebentar", "hemat", "aktif", "padat", "cepat", "ideal", "emas", "seimbang", "92", "92°c", "1:15", "09.30", "1", "86", "20"):
                col = green_rgb
            elif w_low in ("buang", "bensin", "bensin?", "kental", "panas", "gesekan", "pahit", "asam?", "asam", "gosong", "14x", "+14x", "400", "jangan"):
                col = red_rgb
            elif l_idx == len(h_lines) - 1 and w_i >= len(words_ln) - 2:
                col = green_rgb if scene_idx % 2 == 0 else red_rgb
            else:
                col = charcoal_rgb
            draw.text((wx, hy), w, fill=(*col, 255), font=f_h1)
            wx += int(draw.textlength(w + " ", font=f_h1))
        hy += line_step

    state_txt = sanitize_text(scene.get("stateBadge") or scene.get("windowTitle") or f"TAHAP #{scene_idx + 1} - BEDAH MEKANISME").upper()[:36]
    pill_colors = [(146, 64, 14), (180, 83, 9), (120, 53, 15)] if cutaway_kind == "coffee" else [(37, 99, 235), (200, 67, 25), (29, 122, 70)]
    p_col = pill_colors[scene_idx % len(pill_colors)]
    pw = int(draw.textlength(state_txt, font=f_badge)) + 36
    py = hy + 4
    draw.rounded_rectangle([pad_x, py, pad_x + pw, py + 38], radius=19, fill=(*p_col, 255))
    draw.text((pad_x + 18, py + 7), state_txt, fill=(255, 255, 255, 255), font=f_badge)

    diag_cy = 975 + cam_info["y_shift"]
    cam_zoom = cam_info["zoom"]
    ctx_for_callouts = build_contextual_window_lines(scene, scene_idx)
    dyn_labels = [ln.split(":", 1)[0].strip().upper()[:20] for ln in ctx_for_callouts[:3]]
    while len(dyn_labels) < 3:
        dyn_labels.append(f"POIN INTI #{len(dyn_labels)+1}")

    if cutaway_kind in ("lawnmower", "lawnmower-rotary", "lawnmower-rotary-rig"):
        draw_lawnmower_scene_graph_rig(img, draw, 480, diag_cy, local_frame, fps, accent_rgb=accent_rgb, scale_factor=min(1.08, cam_zoom * 0.94), scene=scene)
        default_callouts = [
            (dyn_labels[0], 330, diag_cy + 10, 220, diag_cy + 165),
            (dyn_labels[1], 480, diag_cy - 55, 480, diag_cy + 165),
            (dyn_labels[2], 630, diag_cy + 10, 740, diag_cy + 165),
        ]
    elif cutaway_kind == "engine":
        draw_true_3d_engine_cutaway(img, draw, diag_cy, local_frame, fps)
        default_callouts = [
            (dyn_labels[0] if "oli" not in t_check else "OLI 0,65 L", 245, diag_cy + 65, 210, diag_cy + 165),
            (dyn_labels[1] if "oli" not in t_check else "POMPA OLI", 365, diag_cy + 68, 455, diag_cy + 165),
            (dyn_labels[2] if "oli" not in t_check else "KE SILINDER", 585, diag_cy - 35, 695, diag_cy + 150),
        ]
    elif cutaway_kind == "rotary":
        draw_true_3d_rotary_turbine_cutaway(img, draw, diag_cy, local_frame, fps, accent_rgb=accent_rgb, scale_factor=min(1.12, cam_zoom * 0.94))
        default_callouts = [
            (dyn_labels[0], 330, diag_cy + 10, 220, diag_cy + 165),
            (dyn_labels[1], 480, diag_cy - 55, 480, diag_cy + 165),
            (dyn_labels[2], 630, diag_cy + 10, 740, diag_cy + 165),
        ]
    elif cutaway_kind == "turbofan":
        draw_true_3d_rotary_turbine_cutaway(img, draw, diag_cy, local_frame, fps, accent_rgb=accent_rgb, scale_factor=min(1.14, cam_zoom * 0.96))
        default_callouts = [
            ("INTAKE", 300, diag_cy + 10, 210, diag_cy + 165),
            ("KOMPRESOR", 480, diag_cy - 55, 480, diag_cy + 165),
            ("EKHAUS", 660, diag_cy + 10, 750, diag_cy + 165),
        ]
    elif cutaway_kind == "coffee":
        draw_true_3d_coffee_stage(img, draw, diag_cy, local_frame, fps)
        default_callouts = [
            ("CREMA EMAS", 480, diag_cy - 55, 230, diag_cy + 165),
            ("SUHU 92°C", 480, diag_cy + 15, 480, diag_cy + 165),
            ("BIJI ARABIKA", 640, diag_cy - 10, 730, diag_cy + 165),
        ]
    elif cutaway_kind == "brain":
        draw.rounded_rectangle([140, diag_cy - 130, 820, diag_cy + 130], radius=48, fill=(18, 25, 42, 255), outline=(56, 189, 248, 220), width=4)
        draw_true_3d_neuron_network(img, draw, 480, diag_cy, local_frame, fps, (56, 189, 248), scale_factor=0.80 * cam_zoom, scene=scene)
        metric_lbl = f"{scene.get('metric', '86')} {scene.get('unit', 'MILIAR')}".strip()[:16]
        default_callouts = [
            (metric_lbl, 300, diag_cy, 235, diag_cy + 165),
            ("INTI SOMA 3D", 480, diag_cy, 480, diag_cy + 165),
            ("SINAPSIS 3D", 660, diag_cy, 725, diag_cy + 165),
        ]
    else:
        draw.rounded_rectangle([125, diag_cy - 132, 835, diag_cy + 128], radius=40, fill=(18, 25, 42, 255), outline=(*accent_rgb, 220), width=4)
        draw_true_3d_system_flowchart(img, draw, 480, diag_cy, local_frame, fps, accent_rgb, scale_factor=0.86 * cam_zoom, scene=scene)
        default_callouts = [
            (dyn_labels[0], 280, diag_cy, 225, diag_cy + 165),
            (dyn_labels[1], 480, diag_cy, 480, diag_cy + 165),
            (dyn_labels[2], 680, diag_cy, 735, diag_cy + 165),
        ]

    callouts = scene.get("callouts") or default_callouts
    for c_i, c_item in enumerate(callouts[:3]):
        c_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - (6 + c_i * 6)) / 12.0)))
        if c_u <= 0.05:
            continue
        if isinstance(c_item, dict):
            lbl = sanitize_text(c_item.get("label", "INFO"))[:20]
            tx, ty = int(c_item.get("tx", 300)), int(c_item.get("ty", diag_cy))
            px, py_c = int(c_item.get("px", 300)), int(c_item.get("py", diag_cy + 165))
        else:
            lbl, tx, ty, px, py_c = c_item[0], c_item[1], c_item[2], c_item[3], c_item[4]
        draw.line([(tx, ty), (px, py_c)], fill=(28, 27, 24, int(220 * c_u)), width=3)
        draw.ellipse([tx - 6, ty - 6, tx + 6, ty + 6], fill=(217, 119, 6, 255), outline=(28, 27, 24, 255), width=2)
        cw = int(draw.textlength(lbl, font=f_callout)) + 32
        draw.rounded_rectangle([px - cw // 2, py_c - 21, px + cw // 2, py_c + 21], radius=11, fill=(254, 240, 138, 255), outline=(202, 138, 4, 255), width=2)
        draw.text((px - cw // 2 + 16, py_c - 12), lbl, fill=(28, 27, 24, 255), font=f_callout)

    card_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - 8) / 14.0)))
    if card_u > 0.05:
        cy0 = max(py + 52, int(452 + (1.0 - card_u) * 24))
        cy1 = min(805, cy0 + 335)
        draw.rounded_rectangle([pad_x + 4, cy0 + 8, right_x + 4, cy1 + 8], radius=24, fill=(205, 198, 182, 160))
        draw.rounded_rectangle([pad_x, cy0, right_x, cy1], radius=24, fill=(255, 255, 255, 252), outline=(224, 217, 202, 255), width=3)

        ctx_lines = build_contextual_window_lines(scene, scene_idx)
        card_kind = scene.get("evidenceCardKind") or (["bars", "quote", "checklist"][scene_idx % 3])
        f_ckicker = load_font(18, bold=True)
        f_cbody = load_font(24, bold=True, serif=is_serif)
        f_csub = load_font(19, bold=False)

        win_title = sanitize_text(scene.get("windowTitle") or f"DATA TERUKUR - {kicker}")[:56]
        draw.text((pad_x + 28, cy0 + 20), win_title, fill=(101, 97, 87, 255), font=f_ckicker)

        if card_kind == "bars":
            b_rows = ctx_lines[:2]
            ratios = [0.92, 0.64]
            bar_cols = [(214, 206, 190), (234, 179, 8)]
            by = cy0 + 62
            f_bar_val = load_font(20, bold=True, serif=is_serif)
            for r_i, r_txt in enumerate(b_rows):
                if ":" in r_txt:
                    parts = r_txt.split(":", 1)
                    lbl = parts[0].strip()[:16]
                    val = parts[1].strip()[:34]
                else:
                    lbl = f"TAHAP 0{r_i + 1}"
                    val = r_txt.strip()[:34]
                draw.text((pad_x + 28, by + 9), lbl, fill=(28, 27, 24, 255), font=f_cbody)
                bx0 = pad_x + 235
                bx1 = right_x - 28
                prog_r = ratios[r_i % 2] * ease_out_cubic(min(1.0, max(0.0, (local_frame - (12 + r_i * 6)) / 18.0)))
                bw = max(120, int((bx1 - bx0) * prog_r))
                draw.rounded_rectangle([bx0, by, bx0 + bw, by + 46], radius=10, fill=(*bar_cols[r_i % 2], 255))
                vw = int(draw.textlength(val, font=f_bar_val))
                if bw >= vw + 28:
                    draw.text((bx0 + 16, by + 11), val, fill=(28, 27, 24, 255), font=f_bar_val)
                else:
                    draw.text((bx0 + 14, by + 11), val[:24], fill=(28, 27, 24, 255), font=f_bar_val)
                by += 62
            foot = ctx_lines[2] if len(ctx_lines) > 2 else sanitize_text(scene.get("subcopy", ""))[:65]
            draw.text((pad_x + 28, cy1 - 44), foot[:62], fill=(87, 83, 78, 255), font=f_csub)

        elif card_kind == "quote":
            f_big_green = load_font(42, bold=True, serif=is_serif)
            count_prog = min(1.0, max(0.0, (local_frame - 6) / 22.0))
            raw_m = str(scene.get("metric") or "").strip()
            raw_u = str(scene.get("unit") or "").strip()
            if raw_m:
                anim_m = format_animated_metric(raw_m, count_prog)
                hero_str = f"{anim_m} {sanitize_text(raw_u)}".strip()
            else:
                hero_str = sanitize_text(scene.get("stickerText") or f"TAHAP 0{scene_idx + 1} · INTI MEKANISME")[:28]
            draw.text((pad_x + 28, cy0 + 54), hero_str, fill=(*green_rgb, 255), font=f_big_green)

            q_txt = f'"{ctx_lines[0]}"' if ctx_lines else f'"{scene.get("headline", "")}"'
            q_wrapped, f_q, _ = fit_text_block(draw, q_txt, usable_w - 56, max_lines=2, start_size=24, min_size=19, bold=True, serif=is_serif)
            qy = cy0 + 120
            for ql in q_wrapped:
                draw.text((pad_x + 28, qy), ql, fill=(28, 27, 24, 255), font=f_q)
                qy += 32
            src_line = ctx_lines[-1] if len(ctx_lines) > 1 else "Sumber: Lembar Data & Riset Terverifikasi"
            draw.text((pad_x + 28, cy1 - 44), src_line[:62], fill=(101, 97, 87, 255), font=f_csub)

        else:
            cy_row = cy0 + 60
            for r_i, r_txt in enumerate(ctx_lines[:3]):
                r_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - (10 + r_i * 6)) / 12.0)))
                if r_u <= 0.05:
                    continue
                parts = r_txt.split(":", 1)
                left_k = parts[0].strip()[:20]
                right_v = parts[1].strip()[:28] if len(parts) > 1 else r_txt[:28]
                draw.text((pad_x + 28, cy_row), left_k, fill=(28, 27, 24, 255), font=f_cbody)
                draw.text((pad_x + 275, cy_row), right_v, fill=(*green_rgb, 255), font=f_cbody)
                draw_check_badge(draw, right_x - 62, cy_row + 2, 15, green_rgb, scale=r_u, light_bg=True)
                if r_i < 2:
                    draw.line([(pad_x + 28, cy_row + 40), (right_x - 28, cy_row + 40)], fill=(231, 226, 214, 255), width=2)
                cy_row += 52
            src_foot = ctx_lines[3] if len(ctx_lines) > 3 else f"Rangkuman Inti - {badge}"
            draw.text((pad_x + 28, cy1 - 44), src_foot[:62], fill=(101, 97, 87, 255), font=f_csub)

    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1335,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(250, 204, 21),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=scene,
        local_frame=local_frame,
    )
    return img


def render_charcoal_terminal_deck_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent") or "#D97757"
    accent_rgb = hex_to_rgb(accent_hex)

    bg_kind = (scene.get("theme") or {}).get("background") or "charcoal-terminal"
    img = build_world_background(width, height, bg_kind, accent_hex, scene_idx).copy()
    draw = FastRGBDraw(img, bg=(18, 18, 16))
    try:
        skills_root_p = _resolve_skills_root()
        if str(skills_root_p / "reels-motion" / "scripts") not in sys.path:
            sys.path.insert(0, str(skills_root_p / "reels-motion" / "scripts"))
        import particles as part_mod
        part_mod.apply_particles_and_atmosphere(
            img, draw, local_frame=local_frame, fps=fps, accent_rgb=accent_rgb,
            style_mode="ref1-tutorial-deck", audio_rms=float(scene.get("_audio_rms", 0.0))
        )
    except Exception:
        pass
    pad_x, right_x = 84, 876
    cam_info = compute_intrascene_camera_cut(local_frame, dur_frames, fps, scene)
    draw_camera_hud_pill(draw, right_x, 185, cam_info, accent_rgb, light_bg=False)
    usable_w = right_x - pad_x

    f_pill = load_font(20, bold=True)
    f_mono = load_font(24, bold=True, mono=True)
    f_sticker = load_font(23, bold=True)

    if badge and badge.strip():
        b_txt = f"* {sanitize_text(badge)[:22]}"
        bw = int(draw.textlength(b_txt, font=f_pill)) + 44
        draw.rounded_rectangle([pad_x, 224, pad_x + bw, 274], radius=25, fill=(30, 30, 26, 255), outline=(*accent_rgb, 140), width=2)
        draw.text((pad_x + 22, 236), b_txt, fill=(245, 242, 235, 255), font=f_pill)

    step_txt = sanitize_text(scene.get("eyebrow", f"STEP 0{scene_idx + 1}")).upper()
    sw = int(draw.textlength(step_txt, font=f_pill)) + 40
    draw.rounded_rectangle([pad_x, 300, pad_x + sw, 344], radius=22, fill=(*accent_rgb, 42), outline=(*accent_rgb, 230), width=2)
    draw.text((pad_x + 20, 310), step_txt, fill=(*accent_rgb, 255), font=f_pill)

    h_lines, f_h1, h_sz = fit_text_block(
        draw,
        sanitize_text(scene.get("headline", "")).upper(),
        usable_w,
        max_lines=3,
        start_size=42,
        min_size=26,
        bold=True,
    )
    hy = 360
    for ln in h_lines:
        draw.text((pad_x, hy), ln, fill=(245, 242, 235, 255), font=f_h1)
        hy += int(h_sz * 1.18)

    count_prog = min(1.0, max(0.0, (local_frame - 2) / 24.0))
    anim_m = format_animated_metric(scene.get("metric", ""), count_prog)
    accent_line = f"{anim_m} {sanitize_text(str(scene.get('unit', '')))}".strip().upper()
    draw.text((pad_x, hy + 4), accent_line, fill=(*accent_rgb, 255), font=f_h1)

    card_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - 4) / 14.0)))
    wt = max(hy + int(h_sz * 1.35), int(585 + cam_info['y_shift'] * 2 + (1.0 - card_u) * 28))
    wb = 1165
    draw.rounded_rectangle([pad_x, wt, right_x, wb], radius=28, fill=(28, 28, 25, 252), outline=(255, 255, 255, 48), width=3)
    draw.ellipse([pad_x + 28, wt + 24, pad_x + 44, wt + 40], fill=(255, 95, 86, 255))
    draw.ellipse([pad_x + 54, wt + 24, pad_x + 70, wt + 40], fill=(255, 189, 46, 255))
    draw.ellipse([pad_x + 80, wt + 24, pad_x + 96, wt + 40], fill=(39, 201, 63, 255))
    w_title = sanitize_text(scene.get("windowTitle") or "TERMINAL / INSPECTOR")[:36]
    draw.text((pad_x + 116, wt + 20), w_title, fill=(168, 162, 158, 255), font=f_pill)
    draw.line([(pad_x, wt + 60), (right_x, wt + 60)], fill=(255, 255, 255, 28), width=2)

    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    ty = wt + 84
    for idx, raw_ln in enumerate(ctx_lines[:4]):
        r_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - (6 + idx * 6)) / 12.0)))
        if r_u <= 0.05:
            continue
        prefix = "$ " if idx == 0 else "> "
        wrapped = wrap_text_pixel(draw, prefix + raw_ln, f_mono, usable_w - 72)[:2]
        for w_i, w_ln in enumerate(wrapped):
            col = (245, 242, 235, 255) if idx % 2 == 0 else (*accent_rgb, 255)
            draw.text((pad_x + 34, ty + w_i * 32), w_ln, fill=col, font=f_mono)
        ty += len(wrapped) * 32 + 18

    subj_t = str(scene.get("subjectId") or scene.get("cutawayKind") or "").lower()
    if "lawnmower" in subj_t or "rumput" in f"{scene.get('headline', '')} {scene.get('subcopy', '')}".lower():
        draw_lawnmower_scene_graph_rig(img, draw, (pad_x + right_x) // 2, wb - 165, local_frame, fps, accent_rgb=accent_rgb, scale_factor=0.68, scene=scene)
    bar_y = wb - 52
    draw.rounded_rectangle([pad_x + 34, bar_y, right_x - 34, bar_y + 16], radius=8, fill=(255, 255, 255, 28))
    pw = max(24, int((usable_w - 68) * min(1.0, 0.20 + u * 0.80)))
    draw.rounded_rectangle([pad_x + 34, bar_y, pad_x + 34 + pw, bar_y + 16], radius=8, fill=(*accent_rgb, 255))

    sticker = sanitize_text(scene.get("stickerText") or accent_line or "WAJIB!")[:16]
    st_w = int(draw.textlength(sticker, font=f_sticker)) + 44
    draw.rounded_rectangle([right_x - st_w - 20, wb - 26, right_x - 20, wb + 24], radius=12, fill=(245, 240, 230, 255), outline=(*accent_rgb, 255), width=3)
    draw.text((right_x - st_w + 2, wb - 14), sticker, fill=(18, 18, 16, 255), font=f_sticker)

    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1315,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=accent_rgb,
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=scene,
        local_frame=local_frame,
    )
    return img


def render_tape_mascot_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))

    bg_kind = (scene.get("theme") or {}).get("background") or "tape-mascot"
    img = build_world_background(width, height, bg_kind, "#D97757", scene_idx).copy()
    draw = FastRGBDraw(img, bg=(24, 22, 20))
    pad_x, right_x = 84, 876
    usable_w = right_x - pad_x
    cx = (pad_x + right_x) // 2

    f_banner = load_font(34, bold=True)
    f_body = load_font(25, bold=True)

    draw.rounded_rectangle([pad_x + 12, 232, right_x - 12, 336], radius=14, fill=(245, 240, 228, 255), outline=(214, 206, 190, 255), width=3)
    draw.rectangle([pad_x - 4, 252, pad_x + 36, 314], fill=(228, 218, 195, 235))
    draw.rectangle([right_x - 36, 252, right_x + 4, 314], fill=(228, 218, 195, 235))
    b_txt = sanitize_text(scene.get("eyebrow") or badge).upper()[:28]
    bw = int(draw.textlength(b_txt, font=f_banner))
    draw.text((cx - bw // 2, 262), b_txt, fill=(28, 27, 24, 255), font=f_banner)

    draw.rounded_rectangle([pad_x, 370, right_x, 885], radius=26, fill=(250, 246, 238, 255), outline=(214, 206, 190, 255), width=3)
    for hx in (cx - 180, cx, cx + 180):
        draw.ellipse([hx - 14, 392, hx + 14, 420], fill=(24, 22, 20, 255))

    paste_3d_sphere(img, pad_x + 62, 472, 30, (217, 119, 87), (255, 237, 213))
    h_lines, f_card_h, h_sz = fit_text_block(
        draw,
        sanitize_text(scene.get("headline", "")),
        usable_w - 140,
        max_lines=3,
        start_size=34,
        min_size=24,
        bold=True,
    )
    draw.text((pad_x + 52, 452), str(scene_idx + 1), fill=(255, 255, 255, 255), font=f_card_h)

    hy = 440
    for ln in h_lines:
        draw.text((pad_x + 112, hy), ln, fill=(28, 27, 24, 255), font=f_card_h)
        hy += int(h_sz * 1.18)

    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    cy_row = max(565, hy + 18)
    for idx, raw_ln in enumerate(ctx_lines[:3]):
        draw.line([(pad_x + 32, cy_row + 46), (right_x - 32, cy_row + 46)], fill=(226, 218, 202, 255), width=2)
        draw_check_badge(draw, pad_x + 36, cy_row + 6, 14, (217, 119, 87), scale=1.0, light_bg=True)
        draw.text((pad_x + 76, cy_row + 6), raw_ln[:42], fill=(41, 37, 36, 255), font=f_body)
        cy_row += 68

    bob_y = int(math.sin(t * 6.0) * 8)
    mcx, mcy = cx, 1085 + bob_y
    draw.rounded_rectangle([cx - 260, 1175, cx + 260, 1215], radius=10, fill=(120, 82, 52, 255), outline=(80, 52, 32, 255), width=3)
    subj_m = str(scene.get("subjectId") or scene.get("cutawayKind") or "").lower()
    if "lawnmower" in subj_m or "rumput" in f"{scene.get('headline', '')} {scene.get('subcopy', '')}".lower():
        draw_lawnmower_scene_graph_rig(img, draw, mcx, 1020, local_frame, fps, accent_rgb=(217, 119, 87), scale_factor=0.72, scene=scene)
    else:
        draw_3d_extruded_box(
            draw,
            x0=mcx - 95,
            y0=mcy - 85,
            x1=mcx + 95,
            y1=mcy + 65,
            dx=24,
            dy=-20,
            front_rgb=(217, 119, 87),
            top_rgb=(242, 162, 132),
            side_rgb=(168, 78, 52),
            edge_rgb=(255, 255, 255),
        )
    draw.rectangle([mcx - 48, mcy - 35, mcx - 22, mcy - 5], fill=(24, 22, 20, 255))
    draw.rectangle([mcx + 22, mcy - 35, mcx + 48, mcy - 5], fill=(24, 22, 20, 255))
    m_txt = f"{scene.get('metric', '')} {scene.get('unit', '')}".strip()
    if m_txt:
        draw.rounded_rectangle([mcx + 115, mcy - 65, mcx + 335, mcy + 5], radius=18, fill=(250, 204, 21, 255), outline=(24, 22, 20, 255), width=3)
        draw.text((mcx + 135, mcy - 45), m_txt[:14], fill=(24, 22, 20, 255), font=f_body)

    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1365,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(250, 204, 21),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=scene,
        local_frame=local_frame,
    )
    return img


def draw_30fps_center_stage(
    img: Image.Image,
    draw,
    cx: int,
    cy: int,
    mode: str,
    scene_idx: int,
    local_frame: int,
    fps: float,
    accent_rgb: tuple[int, int, int],
    metric_Display: str,
    unit_display: str,
    scene: dict = None,
):
    t = local_frame / max(1.0, float(fps))
    stage_enter = min(1.05, max(0.0, spring_ease(local_frame, delay=0, dur=16)))
    light_deg = int(round(-35 + math.sin(t * 1.4) * 40))

    theme_3d = ((scene or {}).get("theme") or {}).get("stage3D")
    if theme_3d == "speed-gauge" or mode in ("speed-pulse", "ref2-floating-glass", "luxury-editorial-glass"):
        vis_type = 1
    elif theme_3d == "voxel-core" or mode in ("supercomputer-core", "ref3-pricing-voxel", "saas-product-launch", "3d-isometric-growth"):
        vis_type = 2
    else:
        vis_type = 0

    dur_f = max(30, int((scene or {}).get("durationInFrames", 120)))
    cam_info = compute_intrascene_camera_cut(local_frame, dur_f, fps, scene)
    cam_zoom = cam_info["zoom"]
    cy_adj = cy + cam_info["y_shift"]

    if draw_opus_55_procedural_stage(img, draw, cx, cy_adj + 12, mode, local_frame, fps, accent_rgb, scale_factor=0.92 * cam_zoom, scene=scene):
        pass
    elif vis_type == 0:
        t_ctx = (
            f"{(scene or {}).get('headline', '')} {(scene or {}).get('subcopy', '')} "
            f"{(scene or {}).get('eyebrow', '')} {' '.join(str(x) for x in ((scene or {}).get('windowContentLines') or []))}"
        ).lower()
        if any(k in t_ctx for k in ("ai", "neuron", "otak", "saraf", "sinapsis", "neural", "llm", "gpt", "transformer", "parameter", "token", "deep learning", "machine learning")):
            draw_true_3d_neuron_network(img, draw, cx, cy_adj + 12, local_frame, fps, accent_rgb, scale_factor=0.84 * cam_zoom, scene=scene)
        elif any(k in t_ctx for k in ("rumput", "pisau", "bilah", "turbin", "kipas", "rotasi", "dinamo", "potong", "rpm")):
            draw_true_3d_rotary_turbine_cutaway(img, draw, cy_adj + 12, local_frame, fps, accent_rgb=accent_rgb, scale_factor=0.92 * cam_zoom)
        else:
            draw_true_3d_system_flowchart(img, draw, cx, cy_adj + 12, local_frame, fps, accent_rgb, scale_factor=0.88 * cam_zoom, scene=scene)

    elif vis_type == 1:
        r_arc = int(128 * stage_enter)
        if r_arc > 20:
            bbox_arc = [cx - r_arc, cy - r_arc, cx + r_arc, cy + r_arc]
            draw.arc(bbox_arc, start=135, end=405, fill=(255, 255, 255, 45), width=14)
            sweep_prog = ease_out_cubic(min(1.0, local_frame / 28.0)) * (0.92 + 0.08 * math.sin(t * 4.5))
            end_deg = int(135 + 270 * sweep_prog)
            draw.arc(bbox_arc, start=135, end=end_deg, fill=(*accent_rgb, 255), width=16)
            needle_rad = math.radians(end_deg)
            nx = cx + math.cos(needle_rad) * (r_arc - 18)
            ny = cy + math.sin(needle_rad) * (r_arc - 18)
            draw_3d_tube_segment(img, cx, cy, nx, ny, 7, 3, (248, 250, 252), accent_rgb, steps=10, light_angle_deg=light_deg)
            paste_3d_sphere(img, cx, cy, 16, accent_rgb, (255, 255, 255), light_angle_deg=light_deg)

        for w_layer, (amp, speed, alpha) in enumerate(((46, 7.5, 230), (30, -5.5, 130), (18, 9.5, 85))):
            pts = []
            for i in range(56):
                u_x = i / 55.0
                px = (cx - 320) + u_x * 640
                env_x = math.sin(u_x * math.pi)
                py = cy + math.sin(u_x * math.pi * 4.0 - t * speed + w_layer) * amp * env_x * stage_enter
                pts.append((px, py))
            draw.line(pts, fill=(*accent_rgb, alpha), width=5 if w_layer == 0 else 3)

    else:
        bars = 32
        base_r = 104 * stage_enter
        for i in range(bars):
            ang = (i / float(bars)) * math.pi * 2.0 + t * 0.4
            wave_val = 0.5 + 0.5 * math.sin(t * 7.0 + i * 0.55)
            bar_len = (16 + wave_val * 46) * stage_enter
            x1 = cx + math.cos(ang) * base_r
            y1 = cy + math.sin(ang) * base_r
            x2 = cx + math.cos(ang) * (base_r + bar_len)
            y2 = cy + math.sin(ang) * (base_r + bar_len)
            draw.line([(x1, y1), (x2, y2)], fill=(*accent_rgb, 230 if i % 2 == 0 else 150), width=6)

        voxel_offsets = [(-75, 18, 68), (75, 18, 78), (0, -24, 108), (0, 46, 56)]
        for v_i, (vx, vy, vh) in enumerate(voxel_offsets):
            bob = int(math.sin(t * 4.5 + v_i) * 7)
            bx = cx + vx
            by = cy + vy + bob
            top_c = tuple(min(255, int(c * 1.15 + 35)) for c in accent_rgb)
            front_c = accent_rgb
            side_c = tuple(max(20, int(c * 0.62)) for c in accent_rgb)
            draw_3d_extruded_box(
                draw,
                x0=bx - 28,
                y0=by - vh // 2,
                x1=bx + 28,
                y1=by + vh // 2,
                dx=20,
                dy=-16,
                front_rgb=front_c,
                top_rgb=top_c,
                side_rgb=side_c,
                edge_rgb=(248, 250, 252),
            )

    f_hero = load_font(42, bold=True)
    hero_txt = f"{metric_Display} {unit_display}".strip()
    if hero_txt:
        hw = int(draw.textlength(hero_txt, font=f_hero)) + 48
        hx0 = cx - hw // 2
        hy0 = cy + 114
        draw.rounded_rectangle([hx0, hy0, hx0 + hw, hy0 + 64], radius=32, fill=(10, 15, 28, 238), outline=(*accent_rgb, 255), width=3)
        draw.text((hx0 + 24, hy0 + 8), hero_txt, fill=(248, 250, 252, 255), font=f_hero)


def draw_middle_stage_by_archetype(
    draw,
    scene: dict,
    scene_idx: int,
    local_frame: int,
    u: float,
    pad_x: int,
    right_x: int,
    accent_rgb: tuple[int, int, int],
    anim_metric: str,
    unit_str: str,
):
    usable_w = right_x - pad_x
    ctx_lines = build_contextual_window_lines(scene, scene_idx)
    f_title = load_font(21, bold=True)
    f_val = load_font(26, bold=True)
    f_sub = load_font(21, bold=False)
    f_sticker = load_font(22, bold=True)

    mode = str(scene.get("visualMode", ""))
    if mode in ("speed-pulse", "ref2-floating-glass", "luxury-editorial-glass", "wave-interference", "energy-waves", "audio-reactive-rings", "bio-pulse-flow", "optical-ray-cutaway"):
        arch = 1
    elif mode in ("supercomputer-core", "ref3-pricing-voxel", "saas-product-launch", "3d-isometric-growth", "deconstructed-ui", "dual-device-showreel", "stress-heatmap", "gear-train-cutaway"):
        arch = 2
    else:
        arch = 0

    if arch == 0:
        gap = 18
        col_w = (usable_w - gap) // 2
        row_h = 198
        y0 = 795
        semantic_headers = ["MEKANISME INTI", "PROSES UTAMA", "FAKTOR KUNCI", "HASIL TERUKUR"]
        bento_items = []
        raw_custom = scene.get("windowContentLines")
        source_lines = [sanitize_text(str(x)) for x in raw_custom[:4]] if isinstance(raw_custom, list) and len(raw_custom) >= 2 else ctx_lines[:4]
        for idx, raw_ln in enumerate(source_lines):
            if ":" in raw_ln:
                parts = raw_ln.split(":", 1)
                lbl = parts[0].strip().upper()[:22]
                val = parts[1].strip()
            else:
                lbl = semantic_headers[idx % len(semantic_headers)]
                val = raw_ln.strip()
            bento_items.append((lbl, val))

        n_items = len(bento_items)
        for idx, (lbl, val) in enumerate(bento_items[:4]):
            is_full_width_bottom = (n_items == 3 and idx == 2)
            c_idx = 0 if is_full_width_bottom else (idx % 2)
            r_idx = 1 if is_full_width_bottom else (idx // 2)
            this_card_w = usable_w if is_full_width_bottom else col_w

            card_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - (4 + idx * 5)) / 13.0)))
            if card_u <= 0.02:
                continue
            bx0 = pad_x + c_idx * (col_w + gap)
            by0 = int(y0 + r_idx * (row_h + gap) + (1.0 - card_u) * 24)
            is_primary = idx == 0 or is_full_width_bottom
            bg_col = (15, 23, 42, int(232 * card_u)) if is_primary else (17, 24, 42, int(238 * card_u))
            out_col = (*accent_rgb, int(235 * card_u)) if is_primary else (255, 255, 255, int(65 * card_u))
            draw.rounded_rectangle([bx0, by0, bx0 + this_card_w, by0 + row_h], radius=24, fill=bg_col, outline=out_col, width=3 if is_primary else 2)

            draw_check_badge(draw, bx0 + 22, by0 + 20, 14, accent_rgb, scale=card_u)
            draw.text((bx0 + 60, by0 + 21), lbl, fill=(*accent_rgb, 255) if is_primary else (148, 163, 184, 255), font=f_title)

            v_lines, f_v_fit, _ = fit_text_block(draw, val, this_card_w - 44, max_lines=2, start_size=26, min_size=19, bold=True)
            vy = by0 + 68
            for v_ln in v_lines:
                draw.text((bx0 + 22, vy), v_ln, fill=(248, 250, 252, 255), font=f_v_fit)
                vy += 32

            bar_w = int((this_card_w - 44) * min(1.0, 0.35 + u * 0.65) * card_u)
            draw.rounded_rectangle([bx0 + 22, by0 + row_h - 24, bx0 + 22 + max(16, bar_w), by0 + row_h - 14], radius=5, fill=(*accent_rgb, 210))

    elif arch == 1:
        y_cursor = 795
        track_h = 132
        pct_targets = [1.0, 0.86, 0.74]
        for idx, raw_ln in enumerate(ctx_lines[:3]):
            row_u = ease_out_cubic(min(1.0, max(0.0, (local_frame - (5 + idx * 6)) / 14.0)))
            if row_u <= 0.02:
                continue
            dx = int((1.0 - row_u) * 48)
            tx0 = pad_x + dx
            tx1 = right_x
            is_top = idx == 0
            draw.rounded_rectangle(
                [tx0, y_cursor, tx1, y_cursor + track_h],
                radius=22,
                fill=(24, 18, 48, 242),
                outline=(*accent_rgb, 230 if is_top else 85),
                width=3 if is_top else 2,
            )
            parts = raw_ln.split(":", 1)
            left_lbl = parts[0].strip().upper()[:28]
            right_val = parts[1].strip()[:26] if len(parts) > 1 else f"{anim_metric} {unit_str}"

            draw.text((tx0 + 26, y_cursor + 20), left_lbl, fill=(192, 132, 252, 255) if is_top else (148, 163, 184, 255), font=f_title)
            rw = int(draw.textlength(right_val, font=f_val))
            draw.text((tx1 - rw - 26, y_cursor + 16), right_val, fill=(*accent_rgb, 255) if is_top else (248, 250, 252, 255), font=f_val)

            bar_x0 = tx0 + 26
            bar_x1 = tx1 - 26
            bar_y = y_cursor + 76
            draw.rounded_rectangle([bar_x0, bar_y, bar_x1, bar_y + 26], radius=13, fill=(255, 255, 255, 28))
            race_pct = pct_targets[idx % len(pct_targets)] * ease_out_cubic(min(1.0, max(0.0, (local_frame - (8 + idx * 6)) / 22.0)))
            fill_w = max(28, int((bar_x1 - bar_x0) * race_pct))
            draw.rounded_rectangle([bar_x0, bar_y, bar_x0 + fill_w, bar_y + 26], radius=13, fill=(*accent_rgb, 255 if is_top else 175))
            y_cursor += track_h + 18

    else:
        gap = 28
        col_w = (usable_w - gap) // 2
        card_top = 795
        card_bot = 1235
        enter_l = ease_out_cubic(min(1.0, max(0.0, (local_frame - 4) / 14.0)))
        enter_r = ease_out_cubic(min(1.0, max(0.0, (local_frame - 10) / 14.0)))

        lx0 = pad_x - int((1.0 - enter_l) * 36)
        draw.rounded_rectangle(
            [lx0, card_top, lx0 + col_w, card_bot],
            radius=28,
            fill=(*accent_rgb, 36),
            outline=(*accent_rgb, 245),
            width=3,
        )
        draw.rounded_rectangle([lx0 + 24, card_top + 24, lx0 + col_w - 24, card_top + 64], radius=20, fill=(*accent_rgb, 255))
        hdr_l = "METRIK UTAMA" if anim_metric else "FOKUS TAHAP"
        draw.text((lx0 + 42, card_top + 32), hdr_l, fill=(10, 14, 24, 255), font=f_title)

        f_big = load_font(52, bold=True)
        big_txt = anim_metric if anim_metric else f"0{scene_idx + 1}"
        sub_unit_txt = unit_str if unit_str else smart_truncate_words(scene.get("stickerText") or scene.get("mechanismStep") or "TAHAP INTI", 18).upper()
        draw.text((lx0 + 24, card_top + 88), big_txt, fill=(248, 250, 252, 255), font=f_big)
        draw.text((lx0 + 24, card_top + 150), sub_unit_txt, fill=(*accent_rgb, 255), font=f_val)

        l_desc = wrap_text_pixel(draw, ctx_lines[0] if ctx_lines else scene.get("headline", ""), f_sub, col_w - 48)[:3]
        ly = card_top + 215
        for ln in l_desc:
            draw.text((lx0 + 24, ly), ln, fill=(226, 232, 240, 255), font=f_sub)
            ly += 30

        rx0 = pad_x + col_w + gap + int((1.0 - enter_r) * 36)
        draw.rounded_rectangle(
            [rx0, card_top, rx0 + col_w, card_bot],
            radius=28,
            fill=(16, 22, 36, 242),
            outline=(255, 255, 255, 65),
            width=2,
        )
        draw.rounded_rectangle([rx0 + 24, card_top + 24, rx0 + col_w - 24, card_top + 64], radius=20, fill=(255, 255, 255, 28))
        draw.text((rx0 + 42, card_top + 32), "DATA FAKTA", fill=(148, 163, 184, 255), font=f_title)

        f_vs_item = load_font(23, bold=True)
        ry = card_top + 88
        for raw_ln in ctx_lines[1:4]:
            w_lns = wrap_text_pixel(draw, raw_ln, f_vs_item, col_w - 48)[:3]
            for wl in w_lns:
                draw.text((rx0 + 24, ry), wl, fill=(248, 250, 252, 255), font=f_vs_item)
                ry += 30
            ry += 16

        vs_cx = pad_x + col_w + gap // 2
        vs_cy = (card_top + card_bot) // 2
        draw.ellipse([vs_cx - 30, vs_cy - 30, vs_cx + 30, vs_cy + 30], fill=(10, 14, 24, 255), outline=(*accent_rgb, 255), width=3)
        draw.text((vs_cx - 16, vs_cy - 12), "VS", fill=(*accent_rgb, 255), font=f_title)

    stk_scale = min(1.08, max(0.0, spring_ease(local_frame, delay=16, dur=14)))
    if stk_scale > 0.15:
        sticker = sanitize_text(scene.get("stickerText") or f"{anim_metric} {unit_str}" or f"TAHAP 0{scene_idx + 1}").strip()[:16]
        if sticker and sticker.lower() not in ("none", "off"):
            stk_w = int(draw.textlength(sticker, font=f_sticker)) + 40
            sx0 = right_x - stk_w - 12
            sy0 = 1196
            draw.rounded_rectangle([sx0, sy0, sx0 + stk_w, sy0 + 44], radius=12, fill=(248, 250, 252, 255), outline=(*accent_rgb, 255), width=3)
            draw.text((sx0 + 20, sy0 + 9), sticker, fill=(10, 14, 24, 255), font=f_sticker)


def adapt_frame_to_aspect(base_1080x1920: Image.Image, target_w: int, target_h: int) -> Image.Image:
    """
    Section 3.4 & Quick Win #10:
    Adapts the canonical 1080x1920 render to any target aspect ratio (9:16, 16:9, 1:1, 4:5, 2:3)
    without stretching or losing safe-zone content.
    """
    if (target_w, target_h) == (1080, 1920):
        return base_1080x1920

    # Sample background color from top-left margin of canonical frame
    bg_col = base_1080x1920.getpixel((40, 40))
    canvas = Image.new("RGB", (target_w, target_h), bg_col)

    # Crop active content band (y=190..1520, height=1330, width=960) and fit into target canvas with breathing room
    active_crop = base_1080x1920.crop((40, 185, 1000, 1525))
    cw, ch = active_crop.size
    scale = min((target_w * 0.92) / float(cw), (target_h * 0.92) / float(ch))
    new_w = max(64, int(round(cw * scale)))
    new_h = max(64, int(round(ch * scale)))
    resized = active_crop.resize((new_w, new_h), Image.Resampling.LANCZOS)
    ox = (target_w - new_w) // 2
    oy = (target_h - new_h) // 2
    canvas.paste(resized, (ox, oy))
    return canvas


# ============================================================================
# TALKING HEAD: FACE-AWARE FRAMING & MULTILAYER COMPOSITOR
# ============================================================================

def talking_head_face_anchor(
    scene: dict,
    width: int = 1080,
    height: int = 1920,
    frame_img: Image.Image | None = None,
    source_sec: float | None = None,
) -> tuple[int, int, int, int]:
    """
    Real OpenCV Face & Head Framing Anchor:
    Returns `(x0, y0, x1, y1)` full head bounding box (including hair crown to chin)
    in canonical `width x height` (`1080x1920`) coordinates.
    Priority order:
    1. Exact `_cropped_face_box` computed by face-tracked `extract_video_frame_pil` on the active video frame.
    2. Direct OpenCV Haar-cascade detection (`_detect_primary_face_in_rgb`) on `frame_img` if supplied.
    3. Smoothed video face trajectory (`get_tracked_face_at_time`) when `rawVideoPath` or `videoSrc` is present.
    4. Explicit `facePosition` / `personBox` / `faceBox` in `scene`.
    5. Offline fallback framing hint (`closeup` / `medium` / `default`) ONLY when no video or image exists.
    """
    if isinstance(scene.get("_cropped_face_box"), (list, tuple)) and len(scene["_cropped_face_box"]) == 4:
        bx0, by0, bx1, by1 = [int(v) for v in scene["_cropped_face_box"]]
        if bx1 > bx0 + 40 and by1 > by0 + 40:
            return (bx0, by0, bx1, by1)

    if frame_img is not None:
        det = _detect_primary_face_in_rgb(np.asarray(frame_img.convert("RGB")))
        if det is not None:
            fcx_n, fcy_n, fw_n, fh_n = det
            cx = int(fcx_n * width)
            cy = int(fcy_n * height)
            fw = int(fw_n * width)
            fh = int(fh_n * height)
            x0 = max(0, int(cx - fw * 0.62))
            y0 = max(0, int(cy - fh * 0.88))
            x1 = min(width, int(cx + fw * 0.62))
            y1 = min(height, int(cy + fh * 0.68))
            scene["detectedFaceBox"] = [x0, y0, x1, y1]
            return (x0, y0, x1, y1)

    raw_vid = scene.get("rawVideoPath") or scene.get("videoSrc") or (scene.get("visual") or {}).get("video_src")
    if raw_vid and Path(str(raw_vid)).expanduser().is_file():
        sec_q = float(source_sec if source_sec is not None else scene.get("sourceStartSec", 0.0))
        fcx_n, fcy_n, fw_n, fh_n = get_tracked_face_at_time(str(raw_vid), sec_q)
        cx = int(fcx_n * width)
        cy = int(fcy_n * height)
        fw = int(fw_n * width)
        fh = int(fh_n * height)
        x0 = max(0, int(cx - fw * 0.62))
        y0 = max(0, int(cy - fh * 0.88))
        x1 = min(width, int(cx + fw * 0.62))
        y1 = min(height, int(cy + fh * 0.68))
        scene["detectedFaceBox"] = [x0, y0, x1, y1]
        return (x0, y0, x1, y1)

    face_pos = scene.get("facePosition") or scene.get("personBox") or scene.get("faceBox")
    if isinstance(face_pos, (list, tuple)) and len(face_pos) >= 4:
        fx, fy, fw, fh = [float(v) for v in face_pos[:4]]
        if all(0.0 <= v <= 1.0 for v in (fx, fy, fw, fh)):
            fx, fy, fw, fh = fx * width, fy * height, fw * width, fh * height
        cx = int(fx + fw / 2.0)
        cy = int(fy + fh / 2.0)
        box_w = max(220, int(fw * 1.4))
        box_h = max(320, int(fh * 1.7))
        x0 = max(0, cx - box_w // 2)
        y0 = max(0, cy - box_h // 2)
        x1 = min(width, x0 + box_w)
        y1 = min(height, y0 + box_h)
        return (x0, y0, x1, y1)

    framing = str(scene.get("framing", "")).lower()
    if "closeup" in framing:
        box_w, box_h = 520, 680
        cy_frac = 0.36
    elif "medium" in framing:
        box_w, box_h = 480, 740
        cy_frac = 0.40
    else:
        box_w, box_h = 460, 700
        cy_frac = 0.38

    cx = width // 2
    cy = int(height * cy_frac)
    x0 = max(0, cx - box_w // 2)
    y0 = max(0, cy - box_h // 2)
    x1 = min(width, x0 + box_w)
    y1 = min(height, y0 + box_h)
    return (x0, y0, x1, y1)


def compute_talking_head_safe_zones(
    face_box: tuple[int, int, int, int],
    width: int = 1080,
    height: int = 1920,
) -> dict:
    """
    Dynamic Face-Aware Safe Zone Calculator:
    Replaces static `top_y = 153` and `y_center = 1375` with collision-free zones computed
    from the speaker's real detected head bounding box `(hx0, hy0, hx1, hy1)`:
    - If the speaker's head is high in the frame (`hy0 < 400`, e.g. `hy0 ~ 115, hy1 ~ 835`),
      placing a card at `y=153` would cover their forehead/eyes! So the floating Topic Motion
      & Visual Card is dynamically placed in the spacious Chest Safe Zone below the chin
      (`card_y0 = max(hy1 + 38, 865)` .. `card_y0 + 310`), and the XML/MOGRT subtitle sits
      cleanly in the lower third (`caption_y = max(card_y1 + 125, 1465)`).
    - If the speaker's head is low in the frame (`hy0 >= 440`), the spacious zone is ABOVE
      the speaker's head (`card_y0 = max(88, hy0 - 340)`), and if `hy1 > 1280` (where `y=1375`
      would cover the speaker's mouth/chin!), `caption_y` shifts below `hy1 + 58` or into the
      safe upper gap above `hy0`!
    """
    hx0, hy0, hx1, hy1 = face_box
    top_room = hy0 - 64
    bot_room = (height - 150) - hy1

    if top_room >= 330 and top_room >= bot_room * 0.65:
        # Speaker is positioned lower: place Topic Motion Card ABOVE the speaker's head
        card_h = min(300, max(210, top_room - 36))
        card_y0 = max(84, hy0 - card_h - 32)
        card_y1 = card_y0 + card_h
        hook_y = max(48, card_y0 - 64) if card_y0 >= 140 else None
        if hy1 + 75 <= height - 220:
            caption_y = max(hy1 + 65, 1390)
        else:
            # Speaker's face is at the very bottom: place captions safely above the face!
            caption_y = max(card_y1 + 40, hy0 - 135)
        zone_mode = "top-above-head"
    else:
        # Speaker's head is high/upper-middle (like most vertical talking-head reels):
        # Keep the speaker's hair, forehead, eyes, and mouth (0..hy1) 100% unobstructed!
        # Place the XML/MOGRT hook header & glassmorphic Topic Motion Card below the chin (hy1):
        card_h = 210
        hook_y = max(hy1 + 22, 825)
        card_y0 = hook_y + 68
        if card_y0 + card_h > 1290:
            card_y0 = max(hy1 + 48, 1290 - card_h)
            hook_y = card_y0 - 64
        card_y1 = card_y0 + card_h
        caption_y = min(height - 240, max(card_y1 + 125, 1385))
        zone_mode = "chest-below-chin"

    return {
        "zone_mode": zone_mode,
        "face_box": (hx0, hy0, hx1, hy1),
        "hook_y": hook_y,
        "card_y0": int(card_y0),
        "card_y1": int(card_y1),
        "caption_y": int(caption_y),
    }


def draw_talking_head_face_layer(
    width: int,
    height: int,
    anchor: tuple[int, int, int, int],
    accent_rgb: tuple[int, int, int],
    local_frame: int,
    fps: float,
) -> Image.Image:
    """
    Renders the face/person layer as a stylized presenter avatar (head + shoulders)
    on a transparent RGBA canvas, positioned by the face-aware anchor.
    Works fully offline with no real video dependency.
    """
    layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer, "RGBA")
    x0, y0, x1, y1 = anchor
    cx = (x0 + x1) // 2
    cy = (y0 + y1) // 2
    head_r = max(70, min(int(min(x1 - x0, y1 - y0) / 3.4), 190))
    head_cx = cx
    head_cy = y0 + int((y1 - y0) * 0.34)

    glow = head_r + 44
    d.ellipse([head_cx - glow, head_cy - glow, head_cx + glow, head_cy + glow],
              fill=(*accent_rgb, 24))

    shoulder_w = int(head_r * 2.5)
    shoulder_top = head_cy + int(head_r * 0.92)
    shoulder_bot = min(height - 20, y1 + 180)
    d.polygon([
        (cx - shoulder_w // 2, shoulder_top),
        (cx + shoulder_w // 2, shoulder_top),
        (cx + int(shoulder_w * 0.82), shoulder_bot),
        (cx - int(shoulder_w * 0.82), shoulder_bot),
    ], fill=(232, 230, 226, 255), outline=(*accent_rgb, 170), width=3)

    neck_w = int(head_r * 0.6)
    d.rectangle([cx - neck_w // 2, head_cy + int(head_r * 0.90), cx + neck_w // 2, shoulder_top],
                fill=(210, 208, 202, 255))

    d.ellipse([head_cx - head_r, head_cy - head_r, head_cx + head_r, head_cy + head_r],
              fill=(235, 213, 190, 255), outline=(*accent_rgb, 150), width=2)

    feat_r = max(4, head_r // 20)
    eye_y = head_cy - int(head_r * 0.13)
    d.ellipse([head_cx - int(head_r * 0.28) - feat_r, eye_y - feat_r,
               head_cx - int(head_r * 0.28) + feat_r, eye_y + feat_r], fill=(45, 45, 50, 255))
    d.ellipse([head_cx + int(head_r * 0.28) - feat_r, eye_y - feat_r,
               head_cx + int(head_r * 0.28) + feat_r, eye_y + feat_r], fill=(45, 45, 50, 255))
    d.ellipse([head_cx - feat_r, head_cy + int(head_r * 0.11) - feat_r,
               head_cx + feat_r, head_cy + int(head_r * 0.11) + feat_r], fill=(190, 95, 75, 255))

    return layer


def composite_talking_head_layers(
    bg: Image.Image,
    face_layer: Image.Image,
    caption_layer: Image.Image,
    overlay_layer: Image.Image,
) -> Image.Image:
    """
    Multilayer talking-head compositor.
    Z-order: background -> face/person -> captions -> overlay.
    """
    canvas = bg.convert("RGBA")
    canvas.alpha_composite(face_layer.convert("RGBA"))
    canvas.alpha_composite(caption_layer.convert("RGBA"))
    canvas.alpha_composite(overlay_layer.convert("RGBA"))
    return canvas.convert("RGB")


# ============================================================================
# TALKING HEAD: REAL GAUSSIAN-BLUR GLASSMORPHISM & TOPIC MOTION OVERLAYS
# ============================================================================

TH_GRADIENT_STOPS = ["#60A5FA", "#A855F7", "#EC4899", "#F97316"]
TH_GLASS_FILL = (20, 24, 36, 152)            # Translucent dark frost over real Gaussian-blurred video
TH_GLASS_FILL_LIGHT = (255, 255, 255, 48)    # Translucent light frost over real Gaussian-blurred video
TH_GLASS_OUTLINE = (255, 255, 255, 84)
TH_DARK_CHARCOAL = (22, 25, 34, 165)
TH_CLAUDE_ORANGE = (236, 99, 44)
TH_WHITE = (248, 250, 252, 255)
TH_DIM_WHITE = (226, 232, 240, 210)

TH_TOP_ZONE_Y0 = int(0.08 * 1920)
TH_TOP_ZONE_Y1 = int(0.36 * 1920)
TH_CENTER_ZONE_Y0 = int(0.36 * 1920)
TH_CENTER_ZONE_Y1 = int(0.75 * 1920)
TH_SUB_ZONE_Y0 = int(0.75 * 1920)
TH_SUB_ZONE_Y1 = int(0.88 * 1920)
TH_SUB_TITLE_Y = int(0.80 * 1920)


def th_gradient_rgb(stops: list[str], t: float) -> tuple[int, int, int]:
    """Interpolate across multiple hex stops for t in [0, 1]."""
    if not stops:
        return (56, 189, 248)
    t = max(0.0, min(1.0, float(t)))
    n = len(stops) - 1
    idx = t * n
    i = min(int(idx), n - 1)
    frac = idx - i
    c0 = hex_to_rgb(stops[i])
    c1 = hex_to_rgb(stops[i + 1])
    return (
        int(c0[0] + (c1[0] - c0[0]) * frac),
        int(c0[1] + (c1[1] - c0[1]) * frac),
        int(c0[2] + (c1[2] - c0[2]) * frac),
    )


def th_draw_glass_card(draw, x0, y0, x1, y1, radius=24, fill=None, outline=None, width=2, blur_radius: float = 18.0):
    """
    Genuine Apple/visionOS-style Frosted Glass Card:
    Samples the actual underlying video/background image (`draw._backdrop_img`),
    applies a real `ImageFilter.GaussianBlur(radius=blur_radius)` to the cropped background pixels,
    composites a diagonal refractive specular sheen + translucent glass tint (`fill`),
    clips with an anti-aliased rounded-rectangle mask, and draws a dual-tone refractive glass border!
    """
    ix0, iy0 = int(round(min(x0, x1))), int(round(min(y0, y1)))
    ix1, iy1 = int(round(max(x0, x1))), int(round(max(y0, y1)))
    if ix1 <= ix0 + 4 or iy1 <= iy0 + 4:
        return

    th_fill = fill or TH_GLASS_FILL
    th_outline = outline or TH_GLASS_OUTLINE
    target_im = _get_target_image_from_draw(draw)
    backdrop_im = getattr(draw, "_backdrop_img", None) or target_im

    if target_im is not None and backdrop_im is not None:
        bw, bh = backdrop_im.size
        cx0 = max(0, min(bw - 1, ix0))
        cy0 = max(0, min(bh - 1, iy0))
        cx1 = max(cx0 + 1, min(bw, ix1))
        cy1 = max(cy0 + 1, min(bh, iy1))
        cw, ch = cx1 - cx0, cy1 - cy0
        if cw > 4 and ch > 4:
            # 1. Crop real background/video pixels & apply genuine GaussianBlur!
            bg_patch = backdrop_im.crop((cx0, cy0, cx1, cy1)).convert("RGBA")
            bg_blurred = bg_patch.filter(ImageFilter.GaussianBlur(radius=max(6.0, float(blur_radius))))

            # 2. Blend frosted glass tint + diagonal top-left refractive light sheen
            tint_layer = Image.new("RGBA", (cw, ch), th_fill)
            bg_blurred = Image.alpha_composite(bg_blurred, tint_layer)

            sheen = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
            sd = ImageDraw.Draw(sheen, "RGBA")
            top_band = max(8, int(ch * 0.42))
            for sy in range(top_band):
                s_alpha = int(38 * ((1.0 - sy / float(top_band)) ** 1.6))
                sd.line([(0, sy), (cw, sy)], fill=(255, 255, 255, s_alpha))
            bg_blurred = Image.alpha_composite(bg_blurred, sheen)

            # 3. Rounded-rectangle alpha mask + soft outer drop shadow
            mask = Image.new("L", (cw, ch), 0)
            md = ImageDraw.Draw(mask)
            md.rounded_rectangle([0, 0, cw - 1, ch - 1], radius=min(radius, cw // 2, ch // 2), fill=255)
            bg_blurred.putalpha(mask)

            # Soft card elevation shadow on target_im
            sh_pad = 14
            sh_im = Image.new("RGBA", (cw + sh_pad * 2, ch + sh_pad * 2), (0, 0, 0, 0))
            sh_d = ImageDraw.Draw(sh_im, "RGBA")
            sh_d.rounded_rectangle([sh_pad, sh_pad + 4, sh_pad + cw - 1, sh_pad + ch + 3],
                                   radius=min(radius, cw // 2, ch // 2), fill=(0, 0, 0, 88))
            sh_im = sh_im.filter(ImageFilter.GaussianBlur(radius=6.0))
            sx0, sy0 = max(0, cx0 - sh_pad), max(0, cy0 - sh_pad)
            if target_im.mode == "RGBA":
                target_im.alpha_composite(sh_im.crop((0, 0, min(sh_im.width, target_im.width - sx0), min(sh_im.height, target_im.height - sy0))), dest=(sx0, sy0))
                target_im.alpha_composite(bg_blurred, dest=(cx0, cy0))
            else:
                target_im.paste(bg_blurred.convert("RGB"), (cx0, cy0), mask)

            # 4. Crisp outer border + inner top specular highlight rim
            draw.rounded_rectangle([cx0, cy0, cx1 - 1, cy1 - 1], radius=min(radius, cw // 2, ch // 2), fill=None, outline=th_outline, width=width)
            if cw > 24 and ch > 24:
                draw.arc([cx0 + 2, cy0 + 2, cx0 + radius * 2, cy0 + radius * 2], start=180, end=270, fill=(255, 255, 255, 135), width=2)
                draw.line([(cx0 + radius, cy0 + 2), (cx1 - radius, cy0 + 2)], fill=(255, 255, 255, 115), width=1)
            return

    draw.rounded_rectangle([ix0, iy0, ix1, iy1], radius=radius, fill=th_fill, outline=th_outline, width=width)


@lru_cache(maxsize=8)
def _build_cached_th_vignette(width: int, height: int) -> Image.Image:
    overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay, "RGBA")
    top_end = int(height * 0.14)
    for y in range(0, top_end):
        frac = y / float(max(1, top_end))
        alpha = int(56 * ((1.0 - frac) ** 1.8))
        d.line([(0, y), (width, y)], fill=(0, 0, 0, alpha))
    bot_start = int(height * 0.65)
    for y in range(bot_start, height):
        frac = (y - bot_start) / float(max(1, height - bot_start))
        alpha = int(104 * (frac ** 1.6))
        d.line([(0, y), (width, y)], fill=(0, 0, 0, alpha))
    return overlay


def th_draw_top_vignette(img: Image.Image) -> Image.Image:
    """
    Ultra-smooth cinematic headroom & lower-third vignette starting from y=0 and y=height
    (ZERO hard horizontal edges or dark boxes over the speaker's face!).
    """
    overlay = _build_cached_th_vignette(img.width, img.height)
    return Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")


def th_starburst(draw, cx: int, cy: int, r: int, color, pulse: float = 1.0):
    """Simple 8-point starburst (Claude-like icon)."""
    rr = max(4, int(r * pulse))
    pts = []
    for k in range(16):
        ang = math.pi / 8 * k
        rad = rr if k % 2 == 0 else int(rr * 0.5)
        pts.append((cx + int(math.cos(ang) * rad), cy + int(math.sin(ang) * rad)))
    draw.polygon(pts, fill=color, outline=(255, 255, 255, 255), width=2)


def th_spring(t: float) -> float:
    """Spring pop-in ease (0 -> 1)."""
    if t <= 0:
        return 0.0
    if t >= 1.5:
        return 1.0
    return float(1.0 - math.exp(-4.8 * t) * math.cos(3.2 * t))


def th_draw_topic_visual_miniature(draw, cx: int, cy: int, radius: int, scene: dict, accent_rgb: tuple[int, int, int], local_frame: int, fps: float):
    """
    Renders a rich, animated 3D/Vector Topic Illustration badge inside Talking Head glass cards
    so every Talking Head scene visually illustrates the exact subject being discussed:
    - AI / Claude / Automation: 3D shaded sphere + orbiting neural nodes & pulsing starburst
    - Speed / 10x / Research / Metrics: Animated rising velocity bars + glowing metric badge
    - Workflow / Integrate / System: Interlocking rotating gear / node pipeline rings
    - Tools / Master / Stack: Floating layered 3D isometric stack plates
    - Comparison / Someone / Job: Dual versus balance gauge
    """
    t = local_frame / max(1.0, float(fps))
    blob = f"{scene.get('headline', '')} {scene.get('narration', '')} {scene.get('eyebrow', '')} {scene.get('archetype', '')}".lower()
    target_im = _get_target_image_from_draw(draw)

    # Frosted circular miniature pod
    draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
                 fill=(14, 18, 30, 195), outline=(*accent_rgb, 220), width=3)

    if any(k in blob for k in ("10x", "faster", "speed", "research", "cepat", "riset", "metric", "data")):
        # Animated rising velocity bar chart + glowing 10x rocket trajectory arc
        bars = [0.35, 0.55, 0.78, 1.0]
        bw = max(8, radius // 4)
        gap = 6
        total_bw = len(bars) * bw + (len(bars) - 1) * gap
        bx0 = cx - total_bw // 2
        base_y = cy + int(radius * 0.52)
        for bi, b_h in enumerate(bars):
            anim_h = int(radius * 1.05 * b_h * min(1.0, max(0.2, (t * 2.2 - bi * 0.12))))
            bx = bx0 + bi * (bw + gap)
            b_col = th_gradient_rgb(TH_GRADIENT_STOPS, bi / 3.0)
            draw.rounded_rectangle([bx, base_y - anim_h, bx + bw, base_y], radius=4, fill=(*b_col, 245))
        f_m = load_font(16, bold=True, family="inter-black")
        draw.text((cx - int(draw.textlength("10x", font=f_m)) // 2, cy - radius + 10), "10x", fill=(250, 204, 21, 255), font=f_m)
        return

    if any(k in blob for k in ("workflow", "integrate", "daily", "system", "pipeline", "alur", "sistem")):
        # Animated 3-node workflow triangle with traveling data pulse
        nodes = [
            (cx, cy - int(radius * 0.52)),
            (cx - int(radius * 0.48), cy + int(radius * 0.36)),
            (cx + int(radius * 0.48), cy + int(radius * 0.36)),
        ]
        for i in range(3):
            p0 = nodes[i]
            p1 = nodes[(i + 1) % 3]
            draw.line([p0, p1], fill=(*accent_rgb, 160), width=3)
            u_p = (t * 1.4 + i * 0.33) % 1.0
            px = int(p0[0] + (p1[0] - p0[0]) * u_p)
            py = int(p0[1] + (p1[1] - p0[1]) * u_p)
            draw.ellipse([px - 5, py - 5, px + 5, py + 5], fill=(250, 204, 21, 255))
        for nx, ny in nodes:
            draw.ellipse([nx - 11, ny - 11, nx + 11, ny + 11], fill=(*accent_rgb, 245), outline=(255, 255, 255, 240), width=2)
        return

    if any(k in blob for k in ("tool", "master", "stack", "siapkan", "fitur", "guidebook")):
        # Animated 3D isometric stacked layers
        for li in range(3):
            ly = cy + 18 - li * 16 - int(math.sin(t * 4.0 + li) * 3)
            lw = int(radius * 0.62)
            lh = int(radius * 0.28)
            col_l = th_gradient_rgb(TH_GRADIENT_STOPS, li / 2.0)
            pts = [(cx, ly - lh), (cx + lw, ly), (cx, ly + lh), (cx - lw, ly)]
            draw.polygon(pts, fill=(*col_l, 225), outline=(255, 255, 255, 220), width=2)
        return

    # Default AI / Neural / Claude 3D Shaded Core + Orbiting Nodes
    if target_im is not None:
        sph_r = max(16, int(radius * 0.46))
        sph = make_shaded_3d_sphere(sph_r, accent_rgb, rim_rgb=(255, 255, 255), light_angle_deg=int((t * 60) % 360) - 180)
        sx0, sy0 = cx - sph.width // 2, cy - sph.height // 2
        if target_im.mode == "RGBA" and 0 <= sx0 < target_im.width - sph.width and 0 <= sy0 < target_im.height - sph.height:
            target_im.alpha_composite(sph, dest=(sx0, sy0))
    for oi in range(4):
        ang = t * 2.6 + oi * (math.pi / 2.0)
        ox = cx + int(math.cos(ang) * radius * 0.68)
        oy = cy + int(math.sin(ang) * radius * 0.68)
        draw.line([(cx, cy), (ox, oy)], fill=(*accent_rgb, 130), width=2)
        draw.ellipse([ox - 6, oy - 6, ox + 6, oy + 6], fill=(255, 255, 255, 245), outline=(*accent_rgb, 255), width=2)


def th_draw_headroom_hook_text(draw, cx: int, hook_y: int | None, area_w: int, scene: dict, local_frame: int, fps: float):
    """
    Renders a crisp, 100% box-free XML/MOGRT-styled hook headline at `hook_y`
    (guaranteed outside the speaker's face bounding box!).
    """
    if hook_y is None:
        return
    hero = sanitize_text(scene.get("headline", ""))[:36]
    lead = sanitize_text(scene.get("eyebrow", ""))[:30].upper()
    if not hero:
        return
    t_sec = local_frame / max(1.0, float(fps))
    pop_u = th_spring(min(1.0, t_sec / 0.35))
    req_cap = str(scene.get("captionStyle") or "xml-text1-gold-bevel").strip().lower()
    spec = XML_CAPTION_PRESETS.get(req_cap) or XML_CAPTION_PRESETS["xml-text1-gold-bevel"]
    font_fam = spec.get("font_family", "inter-black")
    stops = spec.get("stops", ["#FAE965", "#FFAA00", "#FFF3B0", "#F59E0B"])
    glow_rgb = spec.get("glow_rgb")
    sh_rgb = spec.get("shadow_rgb", (0, 0, 0))
    sh_ang = float(spec.get("shadow_angle_deg", 45.0))
    sh_dist = int(spec.get("shadow_dist", 6))

    cur_hy = max(44, int(hook_y))
    if lead and lead.lower() != hero.lower():
        f_lead = load_font(18, bold=True, family="inter-semibold")
        lw = int(draw.textlength(lead, font=f_lead))
        _draw_soft_text_shadow_halo(draw, cx - lw // 2, cur_hy, lead, f_lead, shadow_rgb=(0, 0, 0), sh_dist=4)
        draw.text((cx - lw // 2, cur_hy), lead, fill=(226, 232, 240, 235), font=f_lead)
        cur_hy += 26

    f_hero = load_font(34, bold=True, family=font_fam)
    hero_disp = hero.upper() if spec.get("uppercase") else hero
    h_words = hero_disp.split()
    if len(h_words) > 5:
        hero_disp = " ".join(h_words[:5])
    while int(draw.textlength(hero_disp, font=f_hero)) > area_w - 40 and f_hero.size > 22:
        f_hero = load_font(f_hero.size - 2, bold=True, family=font_fam)

    hy = cur_hy + int((1.0 - pop_u) * 14)
    hero_w = int(draw.textlength(hero_disp, font=f_hero))
    hx = cx - hero_w // 2
    _draw_soft_text_shadow_halo(draw, hx, hy, hero_disp, f_hero, shadow_rgb=sh_rgb, glow_rgb=glow_rgb, sh_ang=sh_ang, sh_dist=sh_dist)
    _draw_whole_word_xml_gradient(
        draw=draw, wx=hx, wy=hy, word=hero_disp, font=f_hero,
        stops=stops, bevel_rgb=spec.get("bevel_rgb", (255, 255, 255)),
        stroke_rgb=spec.get("stroke_rgb"), stroke_w=int(spec.get("stroke_w", 0)),
        shimmer=bool(spec.get("shimmer", True)), word_sub_progress=0.5, local_frame=local_frame,
    )


# ---------------------------------------------------------------- archetype 1: prompt_input_card
def th_draw_prompt_input_card(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Floating real-Gaussian-blurred glassmorphic AI input card + animated 3D AI topic miniature."""
    t_sec = local_frame / max(1.0, float(fps))
    pop = th_spring(min(1.0, t_sec / 0.42))
    if pop <= 0.04:
        return
    card_w = min(area_w - 40, 820)
    card_h = 196
    card_x = cx - card_w // 2
    card_y = top_y + int((1.0 - pop) * 24)
    pulse = 0.5 + 0.5 * math.sin(t_sec * 4.0 * math.pi)
    grad = th_gradient_rgb(TH_GRADIENT_STOPS, pulse)
    th_draw_glass_card(draw, card_x, card_y, card_x + card_w, card_y + card_h, radius=26, fill=TH_DARK_CHARCOAL, outline=(*grad, 215), width=3, blur_radius=20.0)

    # Left animated 3D/Vector Topic Miniature
    mini_cx = card_x + 86
    mini_cy = card_y + card_h // 2
    th_draw_topic_visual_miniature(draw, mini_cx, mini_cy, 58, scene, accent_rgb, local_frame, fps)

    # Right interactive AI prompt + file chip + glowing action button
    rx0 = card_x + 168
    label = sanitize_text(scene.get("eyebrow") or "AI WORKFLOW PROMPT")[:32]
    f_lbl = load_font(17, bold=True, family="inter-semibold")
    draw.text((rx0, card_y + 22), label, fill=(*accent_rgb, 245), font=f_lbl)

    file_tag = sanitize_text(scene.get("headline") or scene.get("subcopy") or "AI Workflow Automation")[:34]
    chip_w = min(card_w - 196, 430)
    chip_y = card_y + 54
    chip_h = 50
    th_draw_glass_card(draw, rx0, chip_y, rx0 + chip_w, chip_y + chip_h, radius=14, fill=(32, 38, 54, 175), outline=(*accent_rgb, 140), width=2, blur_radius=12.0)
    f_chip = load_font(19, bold=True, family="inter-extrabold")
    draw.text((rx0 + 16, chip_y + 12), file_tag, fill=TH_WHITE, font=f_chip)
    show_cursor = int(t_sec * 2.5) % 2 == 0
    if show_cursor:
        cur_w = min(chip_w - 32, int(draw.textlength(file_tag, font=f_chip)))
        draw.text((rx0 + 18 + cur_w, chip_y + 11), "|", fill=(*accent_rgb, 255), font=f_chip)

    sub_hint = sanitize_text(scene.get("subcopy") or scene.get("narration") or "")[:42]
    f_sub = load_font(15, bold=False, family="inter-regular")
    draw.text((rx0 + 4, card_y + 122), sub_hint, fill=TH_DIM_WHITE, font=f_sub)

    pill_w, pill_h = 164, 44
    pill_x = card_x + card_w - pill_w - 22
    pill_y = card_y + card_h - pill_h - 18
    grad2 = th_gradient_rgb(TH_GRADIENT_STOPS, (t_sec * 0.8) % 1.0)
    draw.rounded_rectangle([pill_x, pill_y, pill_x + pill_w, pill_y + pill_h], radius=22, fill=(18, 24, 38, 230), outline=(*grad2, 245), width=3)
    th_starburst(draw, pill_x + 26, pill_y + pill_h // 2, 12, color=grad2, pulse=0.85 + 0.3 * pulse)
    f_pill = load_font(16, bold=True, family="inter-extrabold")
    draw.text((pill_x + 48, pill_y + 11), "Auto-Run", fill=TH_WHITE, font=f_pill)


# ---------------------------------------------------------------- archetype 2: numbered_stack_list
def th_draw_numbered_stack_list(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Sequential frosted-glass pill cards with numbered badges & topic visual miniature."""
    t_sec = local_frame / max(1.0, float(fps))
    words_src = [w for w in sanitize_text(scene.get("narration") or scene.get("subcopy") or scene.get("headline", "")).split() if len(w) > 2]
    default_items = [
        (sanitize_text(scene.get("headline") or "Step 1: Core System")[:24], " ".join(words_src[:4]) or "Automated execution"),
        (sanitize_text(scene.get("eyebrow") or "Step 2: Smart Scale")[:24], " ".join(words_src[4:8]) or "10x daily output"),
    ]
    items = (scene.get("stackItems") or default_items)[:2]
    row_h = 84
    gap = 14
    list_w = min(area_w - 40, 780)
    list_x = cx - list_w // 2
    start_y = top_y + 8
    for i, item in enumerate(items):
        if isinstance(item, (list, tuple)):
            title = sanitize_text(item[0])[:26]
            sub = sanitize_text(item[1])[:34] if len(item) > 1 else ""
        else:
            title = sanitize_text(str(item))[:26]
            sub = ""
        t = max(0.0, min(1.0, (t_sec - i * 0.12) / 0.45))
        pop = th_spring(t)
        if pop <= 0.04:
            continue
        sx = list_x + int((list_w - list_w * pop) / 2)
        sw = int(list_w * pop)
        sy = start_y + i * (row_h + gap) + int((row_h - row_h * pop) / 2)
        sh = int(row_h * pop)
        th_draw_glass_card(draw, sx, sy, sx + sw, sy + sh, radius=20, fill=TH_GLASS_FILL, outline=(*accent_rgb, 165), width=2, blur_radius=18.0)
        badge_r = 22
        badge_color = th_gradient_rgb(TH_GRADIENT_STOPS, i / max(1, len(items)))
        bx_c, by_c = sx + 38, sy + sh // 2
        draw.ellipse([bx_c - badge_r, by_c - badge_r, bx_c + badge_r, by_c + badge_r], fill=badge_color)
        f_n = load_font(18, bold=True, family="inter-black")
        n_txt = f"0{i + 1}"
        draw.text((bx_c - int(draw.textlength(n_txt, font=f_n)) // 2, by_c - 11), n_txt, fill=(12, 14, 22, 255), font=f_n)
        f_t = load_font(20, bold=True, family="inter-extrabold")
        f_s = load_font(15, bold=False, family="inter-regular")
        draw.text((sx + 78, sy + 14), title, fill=TH_WHITE, font=f_t)
        if sub:
            draw.text((sx + 78, sy + 44), sub, fill=TH_DIM_WHITE, font=f_s)
        th_starburst(draw, sx + sw - 42, by_c, 13, color=badge_color, pulse=0.9 + 0.2 * math.sin(t_sec * 5 + i))


# ---------------------------------------------------------------- archetype 3: category_pill_cloud
def th_draw_category_pill_cloud(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Frosted glass topic dashboard card with animated miniature + spring-popping tag cloud."""
    t_sec = local_frame / max(1.0, float(fps))
    card_w = min(area_w - 40, 800)
    card_h = 190
    card_x = cx - card_w // 2
    card_y = top_y + 6
    th_draw_glass_card(draw, card_x, card_y, card_x + card_w, card_y + card_h, radius=24, fill=TH_GLASS_FILL, outline=(*accent_rgb, 180), width=2, blur_radius=18.0)
    th_draw_topic_visual_miniature(draw, card_x + 84, card_y + card_h // 2, 56, scene, accent_rgb, local_frame, fps)

    words_clean = [w.strip(",.!?") for w in sanitize_text(scene.get("headline") or scene.get("narration", "")).split() if len(w.strip(",.!?")) >= 3]
    tags = scene.get("categoryTags") or (words_clean[:4] if len(words_clean) >= 3 else ["AI System", "10x Speed", "Smart Tools", "Workflow"])
    pill_w = 260
    pill_h = 54
    cols = 2
    gap_x = 18
    gap_y = 16
    cluster_x = card_x + 168
    cluster_y = card_y + 32
    for i, tag in enumerate(tags[:4]):
        t = max(0.0, min(1.0, (t_sec - i * 0.08) / 0.40))
        pop = th_spring(t)
        if pop <= 0.04:
            continue
        col = i % cols
        row = i // cols
        px = cluster_x + col * (pill_w + gap_x)
        py = cluster_y + row * (pill_h + gap_y)
        pw = int(pill_w * pop)
        ph = int(pill_h * pop)
        t_col = th_gradient_rgb(TH_GRADIENT_STOPS, i / 3.0)
        th_draw_glass_card(draw, px, py, px + pw, py + ph, radius=16, fill=TH_GLASS_FILL_LIGHT, outline=(*t_col, 210), width=2, blur_radius=10.0)
        f_t = load_font(18, bold=True, family="inter-extrabold")
        t_tag = sanitize_text(tag)[:18]
        draw.ellipse([px + 16, py + ph // 2 - 6, px + 28, py + ph // 2 + 6], fill=(*t_col, 255))
        draw.text((px + 38, py + ph // 2 - 11), t_tag, fill=TH_WHITE, font=f_t)


# ---------------------------------------------------------------- archetype 4: workflow_pipeline_anim
def th_draw_workflow_pipeline_anim(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Animated glassmorphic workflow pipeline card: Input Node -> AI Engine Ring -> 10x Output Node."""
    t = local_frame / max(1.0, float(fps))
    card_w = min(area_w - 40, 810)
    card_h = 188
    card_x = cx - card_w // 2
    card_y = top_y + 6
    th_draw_glass_card(draw, card_x, card_y, card_x + card_w, card_y + card_h, radius=24, fill=TH_GLASS_FILL, outline=(*accent_rgb, 190), width=2, blur_radius=18.0)

    # 3 connected pipeline stages inside the glass card
    y_mid = card_y + card_h // 2 + 8
    xs_nodes = [card_x + 145, cx, card_x + card_w - 145]
    labels = [
        sanitize_text(scene.get("eyebrow") or "INPUT TASK")[:14],
        "AI ENGINE",
        sanitize_text(scene.get("headline") or "10X OUTPUT")[:16],
    ]
    f_hdr = load_font(16, bold=True, family="inter-semibold")
    hdr_txt = sanitize_text(scene.get("headline") or "INTEGRATED DAILY WORKFLOW")[:38].upper()
    draw.text((cx - int(draw.textlength(hdr_txt, font=f_hdr)) // 2, card_y + 14), hdr_txt, fill=(*accent_rgb, 240), font=f_hdr)

    # Animated data stream lines between nodes
    for ni in range(2):
        x_a, x_b = xs_nodes[ni] + 54, xs_nodes[ni + 1] - 54
        draw.line([(x_a, y_mid), (x_b, y_mid)], fill=(255, 255, 255, 70), width=4)
        u_pulse = (t * 1.6 + ni * 0.4) % 1.0
        px = int(x_a + (x_b - x_a) * u_pulse)
        draw.ellipse([px - 7, y_mid - 7, px + 7, y_mid + 7], fill=(*accent_rgb, 255))

    for ni, nx in enumerate(xs_nodes):
        n_col = th_gradient_rgb(TH_GRADIENT_STOPS, ni / 2.0)
        draw.ellipse([nx - 44, y_mid - 44, nx + 44, y_mid + 44], fill=(16, 22, 34, 230), outline=(*n_col, 240), width=4)
        if ni == 1:
            th_starburst(draw, nx, y_mid, 20, color=n_col, pulse=1.0 + 0.25 * math.sin(t * 6 * math.pi))
        else:
            f_num = load_font(20, bold=True, family="inter-black")
            nt = "IN" if ni == 0 else "10x"
            draw.text((nx - int(draw.textlength(nt, font=f_num)) // 2, y_mid - 12), nt, fill=TH_WHITE, font=f_num)
        f_nl = load_font(14, bold=True, family="inter-semibold")
        draw.text((nx - int(draw.textlength(labels[ni], font=f_nl)) // 2, y_mid + 50), labels[ni], fill=TH_WHITE, font=f_nl)


# ---------------------------------------------------------------- archetype 5: kinetic_typography_callout
def th_draw_kinetic_typography_callout(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """
    Topic-Aware Glassmorphic Visual Callout Card:
    Combines a real Gaussian-blurred glass card, an animated 3D/Vector Topic Miniature (`th_draw_topic_visual_miniature`),
    and the scene's XML/MOGRT-styled hero callout phrase!
    """
    t_sec = local_frame / max(1.0, float(fps))
    pop_u = th_spring(min(1.0, t_sec / 0.38))
    if pop_u <= 0.04:
        return
    hero = sanitize_text(scene.get("headline", ""))[:34]
    lead = sanitize_text(scene.get("eyebrow", "KEY INSIGHT"))[:28].upper()
    if not hero:
        return

    card_w = min(area_w - 40, 800)
    card_h = 168
    card_x = cx - card_w // 2
    card_y = top_y + int((1.0 - pop_u) * 18)
    th_draw_glass_card(draw, card_x, card_y, card_x + card_w, card_y + card_h, radius=24, fill=TH_GLASS_FILL, outline=(*accent_rgb, 195), width=2, blur_radius=18.0)

    # Left animated 3D/Vector Topic Miniature matching the scene's subject
    th_draw_topic_visual_miniature(draw, card_x + 82, card_y + card_h // 2, 54, scene, accent_rgb, local_frame, fps)

    req_cap = str(scene.get("captionStyle") or "xml-text1-gold-bevel").strip().lower()
    spec = XML_CAPTION_PRESETS.get(req_cap) or XML_CAPTION_PRESETS["xml-text1-gold-bevel"]
    font_fam = spec.get("font_family", "inter-black")
    stops = spec.get("stops", ["#FAE965", "#FFAA00", "#FFF3B0", "#F59E0B"])
    glow_rgb = spec.get("glow_rgb")
    sh_rgb = spec.get("shadow_rgb", (0, 0, 0))
    sh_ang = float(spec.get("shadow_angle_deg", 45.0))
    sh_dist = int(spec.get("shadow_dist", 5))

    tx0 = card_x + 162
    max_tw = card_w - 184
    f_lead = load_font(17, bold=True, family="inter-semibold")
    draw.text((tx0, card_y + 24), lead, fill=(*accent_rgb, 245), font=f_lead)

    f_hero = load_font(34, bold=True, family=font_fam)
    hero_disp = hero.upper() if spec.get("uppercase") else hero
    h_words = hero_disp.split()
    if len(h_words) > 5:
        hero_disp = " ".join(h_words[:5])
    while int(draw.textlength(hero_disp, font=f_hero)) > max_tw and f_hero.size > 22:
        f_hero = load_font(f_hero.size - 2, bold=True, family=font_fam)

    hy = card_y + 56
    _draw_soft_text_shadow_halo(draw, tx0, hy, hero_disp, f_hero, shadow_rgb=sh_rgb, glow_rgb=glow_rgb, sh_ang=sh_ang, sh_dist=sh_dist)
    _draw_whole_word_xml_gradient(
        draw=draw, wx=tx0, wy=hy, word=hero_disp, font=f_hero,
        stops=stops, bevel_rgb=spec.get("bevel_rgb", (255, 255, 255)),
        stroke_rgb=spec.get("stroke_rgb"), stroke_w=int(spec.get("stroke_w", 0)),
        shimmer=bool(spec.get("shimmer", True)), word_sub_progress=0.5, local_frame=local_frame,
    )

    sub_line = sanitize_text(scene.get("subcopy") or scene.get("narration") or "")[:44]
    if sub_line:
        f_sub = load_font(16, bold=False, family="inter-regular")
        draw.text((tx0, card_y + 118), sub_line, fill=TH_DIM_WHITE, font=f_sub)


# ---------------------------------------------------------------- archetype 6a: dual_agent_comparison
def th_draw_dual_agent_comparison(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Side-by-side glassmorphic comparison card (Manual vs AI-Powered / Dual Agent Meter)."""
    t = local_frame / max(1.0, float(fps))
    pop = th_spring(max(0.0, min(1.0, t / 0.42)))
    if pop <= 0.04:
        return
    card_w = min(area_w - 40, 800)
    card_h = 176
    card_x = cx - card_w // 2
    card_y = top_y + 8
    th_draw_glass_card(draw, card_x, card_y, card_x + card_w, card_y + card_h, radius=24, fill=TH_GLASS_FILL, outline=(*accent_rgb, 195), width=2, blur_radius=18.0)

    half_w = (card_w - 56) // 2
    # Left box: Without AI / Standard
    lx0, ly0 = card_x + 20, card_y + 22
    th_draw_glass_card(draw, lx0, ly0, lx0 + half_w, ly0 + card_h - 44, radius=18, fill=(30, 34, 46, 165), outline=(148, 163, 184, 120), width=2, blur_radius=10.0)
    f_t = load_font(18, bold=True, family="inter-extrabold")
    f_s = load_font(15, bold=True, family="inter-semibold")
    draw.text((lx0 + 20, ly0 + 18), "WITHOUT AI", fill=(148, 163, 184, 240), font=f_s)
    draw.text((lx0 + 20, ly0 + 48), "1x Manual Speed", fill=TH_WHITE, font=f_t)
    draw.rounded_rectangle([lx0 + 20, ly0 + 92, lx0 + 20 + int((half_w - 40) * 0.28), ly0 + 106], radius=7, fill=(148, 163, 184, 210))

    # Right box: With AI / Upgraded
    rx0 = lx0 + half_w + 16
    th_draw_glass_card(draw, rx0, ly0, rx0 + half_w, ly0 + card_h - 44, radius=18, fill=(20, 38, 56, 185), outline=(*accent_rgb, 235), width=2, blur_radius=10.0)
    th_starburst(draw, rx0 + half_w - 34, ly0 + 28, 14, color=TH_CLAUDE_ORANGE, pulse=0.9 + 0.25 * math.sin(t * 6))
    draw.text((rx0 + 20, ly0 + 18), "WITH AI WORKFLOW", fill=(*accent_rgb, 255), font=f_s)
    draw.text((rx0 + 20, ly0 + 48), sanitize_text(scene.get("headline") or "10x Faster Output")[:20], fill=TH_WHITE, font=f_t)
    bar_prog = min(1.0, max(0.2, t * 1.4))
    draw.rounded_rectangle([rx0 + 20, ly0 + 92, rx0 + 20 + int((half_w - 40) * bar_prog), ly0 + 106], radius=7, fill=(*accent_rgb, 255))


# ---------------------------------------------------------------- archetype 6b: cta_follow_badge
def th_draw_cta_follow_badge(draw, cx: int, top_y: int, area_w: int, accent_rgb, local_frame: int, fps: float, scene: dict):
    """Frosted-glass interactive CTA + Follow banner card with pulsing icon."""
    t = local_frame / max(1.0, float(fps))
    pop = th_spring(max(0.0, min(1.0, t / 0.40)))
    if pop <= 0.04:
        return
    card_w = min(area_w - 80, 680)
    card_h = 136
    card_x = cx - int(card_w * pop) // 2
    card_y = top_y + 16
    cw_cur = int(card_w * pop)
    th_draw_glass_card(draw, card_x, card_y, card_x + cw_cur, card_y + card_h, radius=28, fill=TH_GLASS_FILL, outline=(*accent_rgb, 230), width=3, blur_radius=18.0)
    if pop > 0.65:
        th_draw_topic_visual_miniature(draw, card_x + 74, card_y + card_h // 2, 44, scene, accent_rgb, local_frame, fps)
        f_h = load_font(24, bold=True, family="inter-black")
        f_s = load_font(16, bold=True, family="inter-semibold")
        cta_txt = sanitize_text(scene.get("headline") or "Follow For Daily AI Tips")[:26]
        draw.text((card_x + 138, card_y + 30), cta_txt, fill=TH_WHITE, font=f_h)
        draw.text((card_x + 138, card_y + 68), "+ Follow & Save This Workflow", fill=(*accent_rgb, 245), font=f_s)
        btn_w, btn_h = 132, 46
        bx0 = card_x + cw_cur - btn_w - 24
        by0 = card_y + (card_h - btn_h) // 2
        draw.rounded_rectangle([bx0, by0, bx0 + btn_w, by0 + btn_h], radius=23, fill=(*accent_rgb, 245))
        draw.text((bx0 + 22, by0 + 11), "+ Follow", fill=(10, 14, 24, 255), font=load_font(18, bold=True, family="inter-black"))


# ---------------------------------------------------------------- bottom-zone karaoke subtitles
def th_draw_karaoke_subtitles(draw, scene: dict, local_frame: int, fps: float, pad_x: int, right_x: int, accent_rgb, cx: int, y_center: int = 1465):
    """
    Upgraded Talking Head Face-Safe Subtitle Renderer:
    Uses all 33 Alight Motion XML & After Effects MOGRT presets (`XML_CAPTION_PRESETS`)
    at the dynamically computed collision-free `y_center`!
    """
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    req_cap = str(scene.get("captionStyle") or "").strip().lower()
    if req_cap in ("none", "off", "hidden", "false"):
        return
    text = sanitize_text(scene.get("customCaption") or scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""), allow_emoji=True)
    if not text:
        return
    th_xml_cycle = tuple(XML_CAPTION_PRESETS.keys())
    sc_idx_num = int(re.sub(r"\D", "", str(scene.get("id", "0"))) or "0")
    if not req_cap or req_cap in ("default", "auto"):
        eff_cap = th_xml_cycle[sc_idx_num % len(th_xml_cycle)]
    else:
        eff_cap = req_cap
    eff_y = int(scene.get("captionY") or y_center)
    if scene.get("captionHighlightColor"):
        accent_rgb = hex_to_rgb(str(scene.get("captionHighlightColor")))
    th_scene_cfg = {**scene, "captionStyle": eff_cap, "y_center": eff_y}
    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=text,
        progress_u=u,
        y_center=int(y_center),
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=accent_rgb,
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=th_scene_cfg,
        local_frame=local_frame,
    )


# ---------------------------------------------------------------------------
# TALKING HEAD: PHASE 2 FEATURES (talking_head_guidebook.json phase_2_features)
# ---------------------------------------------------------------------------

def _phase2_get_feature(scene: dict, name: str) -> dict | None:
    features = scene.get("phase_2_features") or {}
    feat = features.get(name)
    return feat if isinstance(feat, dict) else None


def _phase2_auto_jumpcut_config(scene: dict) -> dict | None:
    feat = _phase2_get_feature(scene, "auto_jumpcut")
    if not feat:
        return None
    return {
        "silence_threshold_db": float(feat.get("silence_threshold_db", -35)),
        "min_silence_sec": float(feat.get("min_silence_sec", 0.35)),
        "crossfade_frames": [int(x) for x in feat.get("crossfade_frames", [2, 3])],
    }


def _phase2_depth_layer_config(scene: dict) -> dict | None:
    feat = _phase2_get_feature(scene, "depth_layer_text")
    if not feat:
        return None
    return {
        "behind_speaker": bool(feat.get("behind_speaker", True)),
        "front_glass_pills": bool(feat.get("front_glass_pills", True)),
    }


def _phase2_audio_sweetener_config(scene: dict) -> dict | None:
    feat = _phase2_get_feature(scene, "audio_sweetener")
    if not feat:
        return None
    return {
        "bgm_duck_db": float(feat.get("bgm_duck_db", -22)),
        "sfx_sync": bool(feat.get("sfx_sync", True)),
    }


def _phase2_broll_pip_card_config(scene: dict) -> dict | None:
    feat = _phase2_get_feature(scene, "broll_pip_card")
    if not feat:
        return None
    zp = feat.get("zone_pct", [0.06, 0.42])
    return {
        "zone_pct": [float(zp[0]), float(zp[1])] if len(zp) >= 2 else [0.06, 0.42],
        "radius": int(str(feat.get("radius", "24px")).replace("px", "")),
        "glass": bool(feat.get("glass", True)),
    }


def _phase2_detect_silent_segments(video_path: str, silence_threshold_db: float, min_silence_sec: float) -> list:
    segments = []
    try:
        if not shutil.which("ffmpeg"):
            return segments
        p = Path(video_path).expanduser().resolve()
        if not p.is_file():
            return segments
        proc = subprocess.run(
            ["ffmpeg", "-nostdin", "-v", "error", "-i", str(p),
             "-vn", "-ac", "1", "-ar", "8000", "-sample_fmt", "s16", "-f", "wav", "-"],
            stdin=subprocess.DEVNULL, capture_output=True, timeout=30,
        )
        if proc.returncode != 0 or len(proc.stdout) < 1024:
            return segments
        import io, wave
        with wave.open(io.BytesIO(proc.stdout), "rb") as wf:
            sw = wf.getsampwidth()
            fr = wf.getframerate()
            raw = wf.readframes(wf.getnframes())
        if sw != 2:
            return segments
        arr = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        hop = max(1, int(fr * 0.025))
        if len(arr) < hop:
            return segments
        rms = np.array([
            float(np.sqrt(np.mean(arr[i:i + hop] ** 2)))
            for i in range(0, len(arr) - hop, hop)
        ])
        if rms.size == 0:
            return segments
        threshold = 10.0 ** (silence_threshold_db / 20.0)
        silent = rms < threshold
        min_win = max(1, int(min_silence_sec / 0.025))
        i = 0
        while i < len(silent):
            if silent[i]:
                j = i
                while j < len(silent) and silent[j]:
                    j += 1
                if (j - i) >= min_win:
                    segments.append((i * 0.025, min(j * 0.025, len(arr) / fr)))
                i = j
            else:
                i += 1
    except Exception:
        pass
    return segments


def _phase2_remap_source_time(t: float, dur_frames: int, fps: float, silent_segments: list) -> float:
    if not silent_segments:
        return t
    total_dur = dur_frames / fps
    segs = sorted(silent_segments)
    nonsilent = []
    cursor = 0.0
    for s, e in segs:
        if s > cursor:
            nonsilent.append((cursor, s))
        cursor = max(cursor, e)
    if cursor < total_dur:
        nonsilent.append((cursor, total_dur))
    total = sum(e - s for s, e in nonsilent)
    if total <= 0:
        return t
    pos = min(max(t, 0.0), total_dur) / total_dur * total
    acc = 0.0
    for s, e in nonsilent:
        seg_len = e - s
        if pos <= acc + seg_len:
            return s + (pos - acc)
        acc += seg_len
    return total_dur


def _phase2_draw_depth_text(draw, cx: int, cy: int, accent_rgb, scene: dict, local_frame: int, fps: float, width: int, height: int):
    txt = sanitize_text(scene.get("headline") or scene.get("eyebrow") or "")
    if not txt:
        return
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    alpha = int(100 * min(1.0, u * 2.0))
    f = load_font(36, bold=True)
    tw = int(draw.textlength(txt, font=f))
    th = 48
    x0 = cx - tw // 2 - 30
    y0 = cy - th // 2 - 40
    x1 = cx + tw // 2 + 30
    y1 = cy + th // 2 + 40
    th_draw_glass_card(draw, x0, y0, x1, y1, radius=24, fill=(8, 8, 12, alpha), outline=(*accent_rgb, int(100 * alpha / 255)), width=2)
    draw.text((cx - tw // 2, cy - th // 2), txt, fill=(*accent_rgb, 255), font=f)


def _phase2_draw_front_glass_pills(draw, cx: int, cy: int, accent_rgb, scene: dict, local_frame: int, fps: float, width: int, height: int):
    txt = sanitize_text(scene.get("subcopy") or scene.get("narration", ""))
    if not txt:
        return
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    alpha = int(150 * min(1.0, u * 1.5))
    f = load_font(22, bold=True)
    words = txt.split()
    pill_txt = " ".join(words[:3]) + ("…" if len(words) > 3 else "")
    pw = int(draw.textlength(pill_txt, font=f)) + 44
    ph = 50
    px0 = cx - pw // 2
    py0 = cy + 90
    th_draw_glass_card(draw, px0, py0, px0 + pw, py0 + ph, radius=25, fill=(16, 16, 22, alpha), outline=(*accent_rgb, int(140 * alpha / 255)), width=2)
    draw.text((px0 + 22, py0 + ph // 2 - 11), pill_txt, fill=TH_WHITE, font=f)


def _phase2_draw_broll_pip_card(layer: Image.Image, cx: int, accent_rgb, scene: dict, local_frame: int, fps: float, width: int, height: int):
    cfg = _phase2_broll_pip_card_config(scene)
    if not cfg:
        return
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    alpha = int(210 * min(1.0, u * 1.5))
    card_w = int(width * cfg["zone_pct"][1])
    card_h = int(card_w * 9 / 16)
    x0 = int(width * (1.0 - cfg["zone_pct"][1] - 0.06))
    y0 = int(height * cfg["zone_pct"][0])
    x1 = x0 + card_w
    y1 = y0 + card_h
    r = cfg["radius"]
    d = ImageDraw.Draw(layer, "RGBA")
    broll_src = scene.get("brollVideoPath") or scene.get("brollSrc")
    if broll_src and Path(str(broll_src)).expanduser().is_file():
        try:
            bi = extract_video_frame_pil(str(broll_src), min(u, 1.0) * 4.0, target_w=card_w, target_h=card_h)
            if bi is not None:
                bi = bi.convert("RGBA")
                if cfg["glass"]:
                    frost = Image.new("RGBA", bi.size, (255, 255, 255, int(40 * alpha / 255)))
                    bi = Image.alpha_composite(bi, frost)
                mask = Image.new("L", (card_w, card_h), 0)
                md = ImageDraw.Draw(mask)
                md.rounded_rectangle([0, 0, card_w, card_h], radius=r, fill=255)
                bi.putalpha(mask)
                layer.paste(bi, (x0, y0), bi)
        except Exception:
            pass
    d.rounded_rectangle([x0, y0, x1, y1], radius=r, fill=(12, 12, 18, alpha),
                        outline=(*accent_rgb, int(170 * alpha / 255)), width=2)
    lbl = sanitize_text(scene.get("brollLabel") or "B-ROLL")
    f = load_font(18, bold=True)
    lw = int(d.textlength(lbl, font=f))
    d.text((x0 + (card_w - lw) // 2, y1 - 30), lbl, fill=(*accent_rgb, 255), font=f)


def _resolve_talking_head_topic_archetype(scene: dict, scene_idx: int) -> str:
    """
    Infers the best topic-matched animated visual archetype for a Talking Head scene
    so every scene displays dynamic motion graphics & illustrations matching the spoken content!
    """
    explicit = str(scene.get("archetype") or scene.get("archetypeKind") or "").strip().lower()
    if explicit and explicit != "auto":
        return explicit
    blob = f"{scene.get('headline', '')} {scene.get('narration', '')} {scene.get('eyebrow', '')}".lower()
    if any(k in blob for k in ("someone", "replace", "take your job", "vs", "banding", "manual")):
        return "dual_agent_comparison"
    if any(k in blob for k in ("integrate", "workflow", "daily", "pipeline", "system", "alur", "proses")):
        return "workflow_pipeline_anim"
    if any(k in blob for k in ("10x", "faster", "research", "speed", "cepat", "riset")):
        return "kinetic_typography_callout"
    if any(k in blob for k in ("master", "tools", "today", "kategori", "style", "fitur")):
        return "category_pill_cloud"
    if any(k in blob for k in ("follow", "subscribe", "tips", "more", "lanjut")):
        return "cta_follow_badge"
    if any(k in blob for k in ("prompt", "claude", "perintah", "editkan", "input")):
        return "prompt_input_card"
    if any(k in blob for k in ("step", "langkah", "siapkan", "pertama", "kedua")):
        return "numbered_stack_list"
    rotation = (
        "prompt_input_card",
        "dual_agent_comparison",
        "workflow_pipeline_anim",
        "numbered_stack_list",
        "kinetic_typography_callout",
        "category_pill_cloud",
        "cta_follow_badge",
    )
    return rotation[scene_idx % len(rotation)]


def render_talking_head_scene(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    """
    Upgraded Face-Aware Talking-Head Multilayer Compositor:
    1. Real OpenCV Face Detection & Trajectory Tracking (`talking_head_face_anchor` + `extract_video_frame_pil`)
    2. Face-Anchored Dynamic Crop & Punch-In Zoom (`_gb_camera_scale` + intra-scene emphasis punch-in)
    3. Dynamic Collision-Free Safe Zones (`compute_talking_head_safe_zones` — zero hardcoded y=153 / y=1375 collisions!)
    4. Real Backdrop Gaussian Blur Glassmorphism (`th_draw_glass_card` blurs the live speaker video frame)
    5. Topic-Matched Animated Motion & 3D/Vector Visual Cards (`_resolve_talking_head_topic_archetype`)
    6. Authentic 33 XML & MOGRT Typography (`th_draw_karaoke_subtitles` + `th_draw_headroom_hook_text`)
    """
    c_w, c_h = 1080, 1920
    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent", "#38BDF8")
    accent_rgb = hex_to_rgb(accent_hex)
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))

    _gb_camera_scale = 1.0
    try:
        from talking_head_guidebook import (  # type: ignore
            GuidebookConfig,
            MotionRegistry,
            MotionKit,
            SceneDirector,
        )
        _gb_config = GuidebookConfig()
        _gb_registry = MotionRegistry(_gb_config)
        _gb_motion_kit = MotionKit(_gb_registry)
        _gb_director = SceneDirector(_gb_registry, _gb_config)

        _gb_trigger_text = (
            scene.get("trigger_text")
            or scene.get("headline")
            or scene.get("narration")
            or scene.get("eyebrow")
            or ""
        )
        if bool(scene.get("use_guidebook")) or bool(_gb_trigger_text):
            _gb_scene_spec = _gb_director.compose_scene(_gb_trigger_text)
            for _gb_mref in _gb_scene_spec.get("combine_motions", []):
                _gb_mref_name = _gb_mref.get("ref", "")
                if _gb_mref_name.startswith("MK_06"):
                    _gb_mode = "punch_in" if "punch_in" in _gb_mref_name else "creep_zoom"
                    _gb_spec = _gb_motion_kit.camera_punch_and_creep(mode=_gb_mode)
                    _gb_scale_end = float(_gb_spec.get("scale_end", 1.08))
                    _gb_camera_scale = 1.0 + (_gb_scale_end - 1.0) * ease_out_cubic(min(1.0, u * 1.4))
                    break
    except Exception:
        _gb_camera_scale = 1.0 + 0.06 * ease_out_cubic(min(1.0, u * 1.3))

    _gjc = _phase2_get_feature(scene, "auto_jumpcut")
    _gdl = _phase2_get_feature(scene, "depth_layer_text")
    _gbpc = _phase2_get_feature(scene, "broll_pip_card")

    # Layer 1: background + top/bottom vignette scrim (respects user-chosen style/world, never forced to dark-science!)
    req_th_mode = str(scene.get("visualMode") or "talking-head").strip().lower()
    req_th_world = (scene.get("theme") or {}).get("background") or STYLE_TO_WORLD_BG.get(req_th_mode, "dark-science")
    bg = build_world_background(c_w, c_h, req_th_world, accent_hex, scene_idx).copy()
    bg = th_draw_top_vignette(bg).convert("RGBA")

    # Layer 2: center subject (raw video with real OpenCV face tracking + punch-in, else stylized avatar)
    center_layer = Image.new("RGBA", (c_w, c_h), (0, 0, 0, 0))
    raw_path = scene.get("rawVideoPath") or scene.get("videoSrc") or (scene.get("visual") or {}).get("video_src")
    raw_used = False
    src_sec = float(scene.get("sourceStartSec", 0.0)) + t
    if raw_path and Path(str(raw_path)).expanduser().is_file():
        try:
            if _gjc and raw_path:
                _gjc_segs = _phase2_detect_silent_segments(raw_path, _gjc["silence_threshold_db"], _gjc["min_silence_sec"])
                scene["_jumpcut_src_sec"] = _phase2_remap_source_time(t, dur_frames, fps, _gjc_segs)
            src_start = float(scene.get("sourceStartSec", 0.0))
            src_end = float(scene.get("sourceEndSec", src_start + dur_frames / float(fps)))
            src_sec = min(src_end, src_start + float(scene.get("_jumpcut_src_sec", t)))
            # Dynamic face-anchored punch-in zoom on alternating / emphasis scenes
            punch_boost = 1.0 + (0.06 * math.sin(min(1.0, u * 1.5) * math.pi) if scene_idx % 2 == 1 else 0.04 * u)
            base_zoom = float(scene.get("zoom", 1.05)) * _gb_camera_scale * punch_boost
            crop_mode = str(scene.get("videoCropMode") or "cover")
            rv_img = extract_video_frame_pil(
                str(raw_path), src_sec, target_w=c_w, target_h=c_h,
                zoom=base_zoom, crop_mode=crop_mode, scene=scene,
            )
            if rv_img is not None:
                bg = th_draw_top_vignette(rv_img.convert("RGB")).convert("RGBA")
                raw_used = True
        except Exception:
            pass

    # Compute real face bounding box (`anchor`) and dynamic collision-free safe zones!
    anchor = talking_head_face_anchor(scene, c_w, c_h, frame_img=bg if raw_used else None, source_sec=src_sec)
    if not raw_used:
        face_layer = draw_talking_head_face_layer(c_w, c_h, anchor, accent_rgb, local_frame, fps)
        center_layer.alpha_composite(face_layer)

    safe_zones = compute_talking_head_safe_zones(anchor, width=c_w, height=c_h)
    card_y0 = safe_zones["card_y0"]
    hook_y = safe_zones["hook_y"]
    caption_y = safe_zones["caption_y"]

    # Composite base + center subject first so `th_draw_glass_card` can blur the live speaker frame!
    canvas = bg.copy()
    if _gdl:
        depth_layer = Image.new("RGBA", (c_w, c_h), (0, 0, 0, 0))
        d_draw = ImageDraw.Draw(depth_layer, "RGBA")
        d_draw._backdrop_img = canvas
        _phase2_draw_depth_text(d_draw, c_w // 2, (anchor[1] + anchor[3]) // 2, accent_rgb, scene, local_frame, fps, c_w, c_h)
        canvas.alpha_composite(depth_layer)

    canvas.alpha_composite(center_layer)

    if _gdl:
        glass_pills_layer = Image.new("RGBA", (c_w, c_h), (0, 0, 0, 0))
        gp_draw = ImageDraw.Draw(glass_pills_layer, "RGBA")
        gp_draw._backdrop_img = canvas
        _phase2_draw_front_glass_pills(gp_draw, c_w // 2, (anchor[1] + anchor[3]) // 2, accent_rgb, scene, local_frame, fps, c_w, c_h)
        canvas.alpha_composite(glass_pills_layer)

    # Layer 3: Topic-Matched Motion Graphic & Visual Overlay (in face-safe `card_y0` zone with real GaussianBlur glassmorphism!)
    overlay_layer = Image.new("RGBA", (c_w, c_h), (0, 0, 0, 0))
    ov_draw = ImageDraw.Draw(overlay_layer, "RGBA")
    ov_draw._backdrop_img = canvas
    pad_x = 84
    right_x = 996
    cx = 540
    area_w = right_x - pad_x

    archetype = _resolve_talking_head_topic_archetype(scene, scene_idx)
    scene["archetype"] = archetype

    # Render headroom XML/MOGRT hook text if safe headroom exists above hair (or above card)
    if hook_y is not None and archetype != "kinetic_typography_callout":
        th_draw_headroom_hook_text(ov_draw, cx, hook_y, area_w, scene, local_frame, fps)

    if archetype == "prompt_input_card":
        th_draw_prompt_input_card(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    elif archetype == "numbered_stack_list":
        th_draw_numbered_stack_list(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    elif archetype == "category_pill_cloud":
        th_draw_category_pill_cloud(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    elif archetype == "workflow_pipeline_anim":
        th_draw_workflow_pipeline_anim(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    elif archetype == "dual_agent_comparison":
        th_draw_dual_agent_comparison(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    elif archetype == "cta_follow_badge":
        th_draw_cta_follow_badge(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)
    else:
        th_draw_kinetic_typography_callout(ov_draw, cx, card_y0, area_w, accent_rgb, local_frame, fps, scene)

    if _gbpc:
        _phase2_draw_broll_pip_card(overlay_layer, cx, accent_rgb, scene, local_frame, fps, c_w, c_h)

    canvas.alpha_composite(overlay_layer)

    # Layer 4: Authentic 33 XML/MOGRT Subtitles at collision-free `caption_y`
    caption_layer = Image.new("RGBA", (c_w, c_h), (0, 0, 0, 0))
    cap_draw = ImageDraw.Draw(caption_layer, "RGBA")
    cap_draw._backdrop_img = canvas
    th_draw_karaoke_subtitles(cap_draw, scene, local_frame, fps, pad_x, right_x, accent_rgb, cx, y_center=caption_y)

    canvas.alpha_composite(caption_layer)
    composite = canvas.convert("RGB")

    if brand_kit:
        apply_brand_kit_overlay(composite, brand_kit, local_frame, dur_frames,
                                is_last_scene=(scene_idx == total_scenes - 1))
    return adapt_frame_to_aspect(composite, width, height)


def render_single_scene_frame(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
    brand_kit: dict = None,
) -> Image.Image:
    # Always render canonical 1080x1920 first so all 3-zone coordinates stay crisp, then adapt to target aspect ratio
    c_w, c_h = 1080, 1920
    scene = normalize_scene_schema(scene)
    global _ACTIVE_SCENE_CUSTOM_FONT
    _ACTIVE_SCENE_CUSTOM_FONT.set(scene.get("fontFamily") or (brand_kit or {}).get("fontFamily") or None)
    mode_check = str(scene.get("visualMode", "")).lower()
    has_raw_vid = bool(scene.get("videoSrc") or scene.get("rawVideoPath") or (scene.get("visual") or {}).get("video_src"))
    if has_raw_vid:
        if scene.get("brollFullScreen"):
            pass  # User requested full-screen 3D/motion B-roll cutaway on this beat while keeping audio!
        elif (
            mode_check in ("talking-head", "talkinghead", "presenter", "spokesperson", "auto-context", "auto")
            or mode_check in STYLE_TO_WORLD_BG
            or scene.get("archetype")
            or scene.get("talking_head_archetype")
            or scene.get("subjectId") == "talking-head-presenter"
        ) and not scene.get("rawFootageOnly"):
            return render_talking_head_scene(width, height, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        else:
            raw_vid_im = render_raw_video_footage_scene(width, height, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
            if raw_vid_im is not None:
                return raw_vid_im
    mode = str(scene.get("visualMode", "ref5-editorial-cutaway"))
    if mode in ("auto-context", "auto"):
        t_low = f"{scene.get('headline', '')} {badge}".lower()
        if any(k in t_low for k in ("kopi", "coffee", "espresso", "seduh", "kafein")):
            mode = "coffee-editorial-3d"
        elif any(k in t_low for k in ("otak", "brain", "saraf", "neuron", "sains")):
            mode = "neural-network"
        else:
            mode = "ref5-editorial-cutaway"

    dur_f_scene = max(30, int(scene.get("durationInFrames", 120)))
    # Fixed: Route only genuine R3 cutaway mechanism to R3 sky-turf-soil renderer;
    # let Opus 5.5 procedural modes (`cutaway-turbofan`, `gear-train-cutaway`, `wave-interference`,
    # `optical-ray-cutaway`, `stress-heatmap`, `supercomputer-core`, etc.) hit the full 3D Volumetric Stage!
    if mode in ("ref3-cutaway-mechanism", "cutaway-mechanism", "r3"):
        img = render_ref3_cutaway_mechanism_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    if mode in ("ref1-voxel-evidence", "voxel-presenter", "voxel-evidence", "r1"):
        img = render_ref1_voxel_evidence_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    if mode in ("ref4-minimal-ui", "minimal-ui", "motion-ui", "r4"):
        img = render_ref4_minimal_ui_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    if mode in ("ref2-cinematic-character", "cinematic-character", "cinematic-product", "r2", "ref4-tape-mascot", "tape-mascot", "mascot-story", "ali-abdaal-desk"):
        img = render_tape_mascot_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    if mode in ("ref5-editorial-cutaway", "cream-editorial", "coffee-editorial", "ink-press-vertical", "editorial-cutaway", "coffee-editorial-3d", "vox-explainer"):
        img = render_cream_editorial_cutaway_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    if mode in ("ref1-tutorial-deck", "charcoal-terminal", "fireship-kinetic"):
        img = render_charcoal_terminal_deck_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        img = apply_cinematic_camera_transform(img, local_frame, dur_f_scene, fps, scene)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, dur_f_scene, is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)
    is_talking_head = (
        mode in ("talking-head", "talkinghead", "presenter", "spokesperson")
        or scene.get("subjectId") == "talking-head-presenter"
        or scene.get("assetId") == "talking-head-face-aware"
    )
    if is_talking_head:
        img = render_talking_head_scene(c_w, c_h, scene, scene_idx, total_scenes, local_frame, fps, badge, brand_kit=brand_kit)
        if brand_kit:
            apply_brand_kit_overlay(img, brand_kit, local_frame, int(scene.get("durationInFrames", 120)), is_last_scene=(scene_idx == total_scenes - 1))
        return adapt_frame_to_aspect(img, width, height)

    accent_hex = (brand_kit or {}).get("accentColor") or scene.get("accent", "#38BDF8")
    accent_rgb = hex_to_rgb(accent_hex)
    dur_frames = max(30, int(scene.get("durationInFrames", 120)))
    u = local_frame / max(1.0, float(dur_frames - 1))
    t = local_frame / max(1.0, float(fps))
    is_serif = use_serif_for_scene(scene, badge, brand_kit=brand_kit)

    theme_bg = (scene.get("theme") or {}).get("background")
    world_bg_kind = theme_bg or STYLE_TO_WORLD_BG.get(mode, "dark-science")
    img = build_world_background(c_w, c_h, world_bg_kind, accent_hex, scene_idx).copy()
    draw = FastRGBDraw(img, bg=(19, 13, 38) if world_bg_kind == "cosmic-glass" else (9, 13, 22))

    # Point 1 Z-Order Fix: Render floating bokeh/data particles immediately on background BEFORE foreground text/cards
    try:
        skills_root_p = _resolve_skills_root()
        if str(skills_root_p / "reels-motion" / "scripts") not in sys.path:
            sys.path.insert(0, str(skills_root_p / "reels-motion" / "scripts"))
        import particles as part_mod
        part_mod.apply_particles_and_atmosphere(
            img, draw, local_frame=local_frame, fps=fps, accent_rgb=accent_rgb,
            style_mode=mode, audio_rms=float(scene.get("_audio_rms", 0.0))
        )
    except Exception:
        pass

    pad_x = 84
    right_x = 876
    usable_w = right_x - pad_x
    cx = (pad_x + right_x) // 2

    f_pill = load_font(21, bold=True)
    f_step = load_font(21, bold=True)

    hdr_ease = ease_out_cubic(min(1.0, local_frame / 10.0))
    top_y = int(222 - (1.0 - hdr_ease) * 18)

    left_pill_txt = sanitize_text((brand_kit or {}).get("brandName") or badge)[:24].strip()
    if left_pill_txt:
        lp_w = int(draw.textlength(left_pill_txt, font=f_pill)) + 58
        draw.rounded_rectangle([pad_x, top_y, pad_x + lp_w, top_y + 48], radius=24, fill=(20, 26, 42, 242), outline=(*accent_rgb, 200), width=2)
        draw.ellipse([pad_x + 18, top_y + 16, pad_x + 34, top_y + 32], fill=(*accent_rgb, 255))
        draw.text((pad_x + 44, top_y + 12), left_pill_txt, fill=(248, 250, 252, 255), font=f_pill)

    dot_x = right_x
    for i in range(total_scenes - 1, -1, -1):
        w_dot = 42 if i == scene_idx else 16
        col = (*accent_rgb, 255) if i == scene_idx else (255, 255, 255, 68)
        draw.rounded_rectangle([dot_x - w_dot, top_y + 17, dot_x, top_y + 31], radius=7, fill=col)
        dot_x -= w_dot + 10

    step_label = sanitize_text(scene.get("eyebrow", f"FAKTA UTAMA #{scene_idx + 1}")).upper()
    st_w = min(usable_w, int(draw.textlength(step_label, font=f_step)) + 44)
    y_step = top_y + 58
    draw.rounded_rectangle([pad_x, y_step, pad_x + st_w, y_step + 40], radius=20, fill=(*accent_rgb, 42), outline=(*accent_rgb, 220), width=2)
    draw.text((pad_x + 22, y_step + 7), step_label, fill=(*accent_rgb, 255), font=f_step)

    h_raw = sanitize_text(scene.get("headline", "Fakta Utama"))
    h_lines, f_h1, h_sz = fit_text_block(
        draw,
        h_raw,
        usable_w,
        max_lines=3,
        start_size=40,
        min_size=25,
        bold=True,
        serif=is_serif,
    )
    is_light_world = world_bg_kind in ("vox-grid", "cream-editorial", "warm-paper", "coffee-editorial")
    h_text_col = (15, 23, 42, 255) if is_light_world else (248, 250, 252, 255)
    hy = y_step + 48
    for ln in h_lines:
        draw.text((pad_x, hy), ln, fill=h_text_col, font=f_h1)
        hy += int(h_sz * 1.18)

    cam_info = compute_intrascene_camera_cut(local_frame, dur_frames, fps, scene)
    draw_camera_hud_pill(draw, right_x, top_y, cam_info, accent_rgb, light_bg=False)

    count_prog = min(1.0, max(0.0, (local_frame - 2) / 26.0))
    anim_metric = format_animated_metric(scene.get("metric", ""), count_prog)
    unit_str = sanitize_text(str(scene.get("unit", ""))).upper()

    draw_30fps_center_stage(
        img=img,
        draw=draw,
        cx=cx,
        cy=600,
        mode=mode,
        scene_idx=scene_idx,
        local_frame=local_frame,
        fps=fps,
        accent_rgb=accent_rgb,
        metric_Display=anim_metric,
        unit_display=unit_str,
        scene=scene,
    )

    draw_middle_stage_by_archetype(
        draw=draw,
        scene=scene,
        scene_idx=scene_idx,
        local_frame=local_frame,
        u=u,
        pad_x=pad_x,
        right_x=right_x,
        accent_rgb=accent_rgb,
        anim_metric=anim_metric,
        unit_str=unit_str,
    )

    draw_compact_editorial_subtitle_pills(
        draw=draw,
        text=scene.get("narration") or scene.get("subcopy") or scene.get("headline", ""),
        progress_u=u,
        y_center=1310,
        pad_x=pad_x,
        right_x=right_x,
        highlight_rgb=(250, 204, 21),
        words_timed=scene.get("words"),
        scene_elapsed_sec=t,
        scene_start_sec=float(scene.get("narrationStartSec", 0.0)),
        scene=scene,
        local_frame=local_frame,
    )
    if brand_kit:
        apply_brand_kit_overlay(img, brand_kit, local_frame, dur_frames, is_last_scene=(scene_idx == total_scenes - 1))
    return adapt_frame_to_aspect(img, width, height)


VALID_TRANSITION_MOTIFS = {
    "cut", "none", "hard-cut",
    "crossfade", "fade", "dissolve",
    "slide", "whip", "whip-left", "whip-right", "whip-up", "whip-down", "slide-left", "slide-right", "slide-up",
    "zoom", "zoom-snap", "zoom-in", "zoom-out",
    "object-match", "match-cut", "shared-element",
    "cutaway-peel", "peel",
}


def dispatch_scene_transition(
    img_out: Image.Image,
    img_in: Image.Image,
    trans_u: float,
    accent_rgb: tuple[int, int, int],
    motif: str | dict = "crossfade",
    trans_idx: int = 0,
) -> Image.Image:
    """
    F07: Real Transition Dispatcher for Pillow engine.
    Consumes scene's `transitionMotif` / `transitionOut` / `transitionIn`:
    - `cut`: Instant switch at midpoint (`trans_u >= 0.5`)
    - `crossfade`: Smooth alpha blend (`Image.blend`)
    - `slide` (`whip-left`, `whip-right`, `whip-up`, `whip-down`): Directional eased slide without black gaps
    - `zoom` (`zoom-snap`): Scale push into `img_out` + scale settle of `img_in`
    - `object-match` (`shared-element`): Radial iris / anchor-centered match blend around the subject stage
    - `cutaway-peel`: Diagonal/vertical peel reveal with glowing accent seam line
    Explicitly raises `ValueError` on unknown transition motifs instead of silently ignoring them.
    """
    direction = "left"
    if isinstance(motif, dict):
        raw_m = str(motif.get("type") or "crossfade").strip().lower()
        direction = str(motif.get("direction") or "left").strip().lower()
    else:
        raw_m = str(motif or "crossfade").strip().lower()
        if "up" in raw_m:
            direction = "up"
        elif "down" in raw_m:
            direction = "down"
        elif "right" in raw_m:
            direction = "right"

    if raw_m not in VALID_TRANSITION_MOTIFS:
        raise ValueError(f"Unsupported transitionMotif '{raw_m}'. Valid motifs: {sorted(VALID_TRANSITION_MOTIFS)}")

    w, h = img_out.size
    p = ease_in_out_cubic(max(0.0, min(1.0, float(trans_u))))

    if raw_m in ("cut", "none", "hard-cut"):
        return img_in if p >= 0.5 else img_out

    if raw_m in ("crossfade", "fade", "dissolve"):
        return Image.blend(img_out.convert("RGB"), img_in.convert("RGB"), p)

    if raw_m in ("slide", "whip", "whip-left", "whip-right", "whip-up", "whip-down", "slide-left", "slide-right", "slide-up"):
        canvas = Image.new("RGB", (w, h), (15, 23, 42))
        if direction == "up":
            y_out = -int(round(p * h))
            y_in = h + y_out
            canvas.paste(img_out, (0, y_out))
            canvas.paste(img_in, (0, y_in))
        elif direction == "down":
            y_out = int(round(p * h))
            y_in = y_out - h
            canvas.paste(img_out, (0, y_out))
            canvas.paste(img_in, (0, y_in))
        elif direction == "right":
            x_out = int(round(p * w))
            x_in = x_out - w
            canvas.paste(img_out, (x_out, 0))
            canvas.paste(img_in, (x_in, 0))
        else:
            x_out = -int(round(p * w))
            x_in = w + x_out
            canvas.paste(img_out, (x_out, 0))
            canvas.paste(img_in, (x_in, 0))
        return canvas

    if raw_m in ("zoom", "zoom-snap", "zoom-in", "zoom-out"):
        # Zoom into outgoing frame while cross-blending incoming frame from 0.86x -> 1.0x
        scale_out = 1.0 + 0.22 * p
        zw_o, zh_o = int(round(w * scale_out)), int(round(h * scale_out))
        z_out = img_out.resize((zw_o, zh_o), Image.Resampling.BILINEAR).crop(
            ((zw_o - w) // 2, (zh_o - h) // 2, (zw_o - w) // 2 + w, (zh_o - h) // 2 + h)
        )
        return Image.blend(z_out.convert("RGB"), img_in.convert("RGB"), p)

    if raw_m in ("object-match", "match-cut", "shared-element"):
        # Radial iris mask centered on the mechanism stage (w//2, int(h*0.44))
        mask = Image.new("L", (w, h), 0)
        md = ImageDraw.Draw(mask)
        cx_m, cy_m = w // 2, int(h * 0.44)
        max_r = int(math.hypot(w, h) * 0.75)
        cur_r = int(round(p * max_r))
        if cur_r > 4:
            md.ellipse([cx_m - cur_r, cy_m - cur_r, cx_m + cur_r, cy_m + cur_r], fill=255)
        out_comp = Image.composite(img_in.convert("RGB"), img_out.convert("RGB"), mask)
        d_ring = ImageDraw.Draw(out_comp)
        if 12 < cur_r < max_r - 12:
            d_ring.ellipse([cx_m - cur_r, cy_m - cur_r, cx_m + cur_r, cy_m + cur_r], outline=accent_rgb, width=4)
        return out_comp

    if raw_m in ("cutaway-peel", "peel"):
        # Horizontal peel wipe revealing internal cutaway layer with a crisp accent laser line
        split_x = int(round(p * w))
        canvas = img_out.convert("RGB").copy()
        if split_x > 0:
            crop_in = img_in.convert("RGB").crop((0, 0, split_x, h))
            canvas.paste(crop_in, (0, 0))
        if 4 < split_x < w - 4:
            d_peel = ImageDraw.Draw(canvas)
            d_peel.line([(split_x, 0), (split_x, h)], fill=accent_rgb, width=6)
        return canvas

    return Image.blend(img_out.convert("RGB"), img_in.convert("RGB"), p)


def composite_whip_transition(
    img_out: Image.Image,
    img_in: Image.Image,
    trans_u: float,
    accent_rgb: tuple[int, int, int],
    trans_idx: int = 0,
    motif: str | dict = "slide",
) -> Image.Image:
    return dispatch_scene_transition(img_out, img_in, trans_u, accent_rgb, motif=motif, trans_idx=trans_idx)


def extract_scenes_from_workspace(ws: Path, total_frames_default: int = 360) -> tuple[list, str]:
    tl = ws / "timeline.json"
    if tl.is_file():
        try:
            data = json.loads(tl.read_text(encoding="utf-8"))
            if data.get("scenes"):
                return data["scenes"], data.get("title_badge", "")
        except Exception:
            pass

    tsx = ws / "src" / "MainReel.tsx"
    if tsx.is_file():
        text = tsx.read_text(encoding="utf-8")
        m = re.search(r"const\s+SCENES[^=]*=\s*(\[.*?\]);", text, flags=re.DOTALL)
        b = re.search(r'badge="([^"]+)"', text)
        badge = b.group(1) if b else ""
        if m:
            try:
                return json.loads(m.group(1)), badge
            except Exception:
                pass

    return [
        {
            "id": "scene-01",
            "eyebrow": "FAKTA SAINS #1",
            "metric": "86",
            "unit": "MILIAR",
            "headline": "86 Miliar Neuron Aktif di Otakmu",
            "subcopy": "Setiap detik miliaran sel saraf mengirim sinyal listrik tanpa henti.",
            "accent": "#38BDF8",
            "visualMode": "neural-network",
            "durationInFrames": total_frames_default,
        }
    ], "FAKTA SAINS"


def auto_fit_visuals_to_audio(scenes: list, tr_data: dict, fps: int = 30) -> bool:
    """
    Section 4.3:
    Automatic Pacing Adjustment ("Fit Visuals to Actual Audio"):
    Aligns each scene's `durationInFrames`, `narrationStartSec`, and `words` to the actual
    synthesized TTS speech duration in `timing-report.json` so visual transitions never drift!
    """
    if not tr_data or not isinstance(tr_data.get("segments"), list):
        return False
    segs = tr_data["segments"]
    adjusted = False
    for idx, sc in enumerate(scenes):
        if idx >= len(segs):
            break
        seg_d = segs[idx]
        if not sc.get("words") and seg_d.get("words"):
            sc["words"] = seg_d["words"]
        sc["narrationStartSec"] = seg_d.get("start", 0.0)
        sc["narrationEndSec"] = seg_d.get("end", 0.0)
        if seg_d.get("speaker") and not sc.get("speaker"):
            sc["speaker"] = seg_d["speaker"]
        if seg_d.get("show_speaker_label"):
            sc["showSpeakerLabel"] = True
        if seg_d.get("emphasis_words") and not sc.get("emphasisWords"):
            sc["emphasisWords"] = seg_d["emphasis_words"]

        rec_f = int(seg_d.get("recommended_frames") or 0)
        raw_s = float(seg_d.get("raw_seconds") or 0.0)
        if rec_f >= 45:
            if abs(int(sc.get("durationInFrames", rec_f)) - rec_f) > 3:
                sc["durationInFrames"] = rec_f
                adjusted = True
        elif raw_s > 0.5:
            fitted_f = max(60, int(round((raw_s + 0.40) * fps)))
            sc["durationInFrames"] = fitted_f
            adjusted = True
    return adjusted


def compute_viewer_retention_prediction(scenes: list, fps: int = 30) -> dict:
    """
    Section 7.2:
    Heuristic Viewer Retention Prediction:
    Scores:
    - hook_in_first_3s_score (question/number/emphasis hook in scene 1)
    - visual_pacing_score (visual change or callout animation every 2-3.5s)
    - caption_readability_score (word count per scene, semantic grouping, emphasis words)
    - overall_predicted_retention_pct
    """
    if not scenes:
        return {"overall_predicted_retention_pct": 50.0}

    s0 = scenes[0]
    h0 = f"{s0.get('headline', '')} {s0.get('narration', '')}".lower()
    has_question_hook = "?" in h0 or any(w in h0 for w in ("kenapa", "pernah", "tahukah", "bener", "jangan", "rahasia"))
    has_metric_hook = bool(re.search(r"\d+", f"{s0.get('metric', '')} {h0}"))
    hook_score = 72 + (14 if has_question_hook else 0) + (12 if has_metric_hook else 0)

    avg_scene_sec = sum(int(s.get("durationInFrames", 90)) / float(fps) for s in scenes) / max(1, len(scenes))
    # Ideal scene length with internal callout pops is 3.0s - 5.0s
    pacing_score = 94 if 2.5 <= avg_scene_sec <= 5.2 else max(60, int(94 - abs(avg_scene_sec - 4.0) * 8))

    readability_scores = []
    for s in scenes:
        txt = sanitize_text(s.get("narration") or s.get("subcopy") or s.get("headline", ""))
        wc = len(txt.split())
        dur_s = max(1.0, int(s.get("durationInFrames", 90)) / float(fps))
        wps = wc / dur_s
        r_sc = 92 if 1.5 <= wps <= 3.6 else max(65, int(92 - abs(wps - 2.6) * 12))
        if s.get("emphasisWords") or s.get("captionStyle"):
            r_sc = min(99, r_sc + 5)
        readability_scores.append(r_sc)
    caption_score = int(round(sum(readability_scores) / max(1, len(readability_scores))))
    overall = round(0.40 * hook_score + 0.32 * pacing_score + 0.28 * caption_score, 1)

    return {
        "hook_in_first_3s": has_question_hook or has_metric_hook,
        "hook_score": min(100, hook_score),
        "visual_pacing_score": min(100, pacing_score),
        "avg_scene_duration_sec": round(avg_scene_sec, 2),
        "caption_readability_score": min(100, caption_score),
        "overall_predicted_retention_pct": min(99.0, overall),
    }


def render_3zone_frame_pil(
    width: int,
    height: int,
    scene: dict,
    scene_idx: int,
    total_scenes: int,
    local_frame: int,
    fps: float,
    badge: str,
) -> Image.Image:
    return render_single_scene_frame(width, height, scene, scene_idx, total_scenes, local_frame, fps, badge)


def try_remotion_cli_render(ws: Path, composition: str, output_mp4: Path, install_deps: bool = False) -> bool:
    npx_bin = shutil.which("npx")
    npm_bin = shutil.which("npm")
    if not npx_bin:
        return False

    remotion_pkg = ws / "node_modules" / "@remotion" / "cli"
    if not remotion_pkg.is_dir() and install_deps and npm_bin:
        try:
            subprocess.run(
                [npm_bin, "install", "--no-audit", "--no-fund"],
                cwd=str(ws),
                stdin=subprocess.DEVNULL,
                timeout=180,
                check=True,
            )
        except Exception:
            return False

    if not (ws / "node_modules" / "@remotion").is_dir():
        return False

    try:
        output_mp4.parent.mkdir(parents=True, exist_ok=True)
        node = shutil.which('node')
        cli = remotion_pkg / 'remotion-cli.js'
        if not node or not cli.is_file():
            return False
        command = [node, str(cli), 'render', 'src/index.ts', composition, str(output_mp4), '--concurrency='+os.environ.get('SHOTCRAFT_CONCURRENCY','1')]
        browser = os.environ.get('SHOTCRAFT_BROWSER_EXECUTABLE')
        if browser:
            command.append('--browser-executable='+browser)
        log = ws / 'qa' / 'remotion-render.log'
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('w', encoding='utf-8') as stream:
            subprocess.run(command, cwd=str(ws), stdin=subprocess.DEVNULL,
                           stdout=stream, stderr=subprocess.STDOUT,
                           timeout=int(os.environ.get('SHOTCRAFT_RENDER_TIMEOUT', '900')), check=True)
        return output_mp4.is_file() and output_mp4.stat().st_size > 10000
    except Exception:
        return False


def render_deterministic_fallback(
    ws: Path,
    stills_spec: str,
    output_mp4: Path,
    fps: int = 30,
    width: int = 1080,
    height: int = 1920,
    engine_mode: str = "auto",
    policy_mode: str = "draft",
    install_remotion: bool = False,
    preview_frame: int = None,
    preview_output: Path = None,
    brand_kit_path: str = None,
    auto_pacing: bool = True,
    only_scene: str = None,
) -> dict:
    t0_render = time.time()
    scenes, badge = extract_scenes_from_workspace(ws)
    if os.environ.get("SHOTCRAFT_NO_BADGE") == "1":
        badge = ""
    brand_kit = load_brand_kit(ws, explicit_path=brand_kit_path)

    # [P2-1]: Load per-frame audio RMS envelope if available so 3D visuals pulse with speech amplitude
    env_file = ws / "out" / "audio_envelope.json"
    frame_rms_list = []
    if env_file.is_file():
        try:
            frame_rms_list = json.loads(env_file.read_text(encoding="utf-8")).get("frame_rms", [])
        except Exception:
            frame_rms_list = []

    tr_file = ws / "audio-narr" / "timing-report.json"
    tr_data = {}
    if tr_file.is_file() and os.environ.get("SHOTCRAFT_NO_NARRATION") != "1":
        try:
            tr_data = json.loads(tr_file.read_text(encoding="utf-8"))
            if auto_pacing:
                auto_fit_visuals_to_audio(scenes, tr_data, fps=fps)
            else:
                for idx, sc in enumerate(scenes):
                    if idx < len(tr_data.get("segments", [])) and not sc.get("words"):
                        seg_d = tr_data["segments"][idx]
                        sc["words"] = seg_d.get("words", [])
                        sc["narrationStartSec"] = seg_d.get("start", 0.0)
        except Exception:
            pass

    # F07: Validate transition motifs upfront so unknown motifs are rejected rather than silently replaced
    for _sc_v in scenes:
        for _tk in ("transitionMotif", "transitionIn", "transitionOut"):
            if _sc_v.get(_tk):
                _m_val = _sc_v[_tk].get("type") if isinstance(_sc_v[_tk], dict) else _sc_v[_tk]
                if str(_m_val).strip().lower() not in VALID_TRANSITION_MOTIFS:
                    raise ValueError(f"Invalid transition motif '{_m_val}' in scene '{_sc_v.get('id')}'. Supported: {sorted(VALID_TRANSITION_MOTIFS)}")

    total_frames = sum(int(s.get("durationInFrames", 90)) for s in scenes)

    bounds = []
    cur = 0
    for idx, sc in enumerate(scenes):
        dur = int(sc.get("durationInFrames", 90))
        bounds.append((cur, cur + dur, sc, idx))
        cur += dur

    trans_half = 8
    scene_render_ms = {sc.get("id", f"scene-{i+1}"): 0.0 for i, sc in enumerate(scenes)}

    def render_global_frame(f_idx: int) -> Image.Image:
        t_f0 = time.time()
        active_b = bounds[-1]
        for b in bounds:
            if b[0] <= f_idx < b[1]:
                active_b = b
                break
        s0, s1, sc, idx = active_b
        sc = dict(sc)
        local_f = max(0, f_idx - s0)
        if f_idx < len(frame_rms_list):
            sc["_audio_rms"] = frame_rms_list[f_idx]
        sc_key = sc.get("id", f"scene-{idx+1}")

        if idx < len(bounds) - 1 and f_idx >= s1 - trans_half:
            next_s0, next_s1, next_sc, next_idx = bounds[idx + 1]
            motif_use = sc.get("transitionOut") or sc.get("transitionMotif") or next_sc.get("transitionIn") or "crossfade"
            trans_u = (f_idx - (s1 - trans_half)) / float(trans_half * 2)
            img_a = render_single_scene_frame(width, height, sc, idx, len(scenes), local_f, fps, badge, brand_kit=brand_kit)
            img_b = render_single_scene_frame(width, height, next_sc, next_idx, len(scenes), max(0, f_idx - (s1 - trans_half)), fps, badge, brand_kit=brand_kit)
            out_im = dispatch_scene_transition(img_a, img_b, trans_u, hex_to_rgb(next_sc.get("accent", "#38BDF8")), motif=motif_use, trans_idx=idx)
            scene_render_ms[sc_key] = scene_render_ms.get(sc_key, 0.0) + (time.time() - t_f0) * 1000.0
            return out_im

        if idx > 0 and f_idx < s0 + trans_half:
            prev_s0, prev_s1, prev_sc, prev_idx = bounds[idx - 1]
            prev_dur = prev_s1 - prev_s0
            motif_use = prev_sc.get("transitionOut") or prev_sc.get("transitionMotif") or sc.get("transitionIn") or "crossfade"
            trans_u = (f_idx - (s0 - trans_half)) / float(trans_half * 2)
            img_a = render_single_scene_frame(width, height, prev_sc, prev_idx, len(scenes), max(0, prev_dur - trans_half + local_f), fps, badge, brand_kit=brand_kit)
            img_b = render_single_scene_frame(width, height, sc, idx, len(scenes), local_f, fps, badge, brand_kit=brand_kit)
            out_im = dispatch_scene_transition(img_a, img_b, trans_u, hex_to_rgb(sc.get("accent", "#38BDF8")), motif=motif_use, trans_idx=prev_idx)
            scene_render_ms[sc_key] = scene_render_ms.get(sc_key, 0.0) + (time.time() - t_f0) * 1000.0
            return out_im

        out_im = render_single_scene_frame(width, height, sc, idx, len(scenes), local_f, fps, badge, brand_kit=brand_kit)
        scene_render_ms[sc_key] = scene_render_ms.get(sc_key, 0.0) + (time.time() - t_f0) * 1000.0
        return out_im

    # Section 6.1 & Quick Win #6: Instant single-frame PNG preview (--preview-frame N)
    if preview_frame is not None:
        f_idx = min(total_frames - 1, max(0, int(preview_frame)))
        pil_img = render_global_frame(f_idx)
        target_png = preview_output or (ws / "qa" / "stills" / f"preview_frame_{f_idx:04d}.png")
        target_png.parent.mkdir(parents=True, exist_ok=True)
        pil_img.save(str(target_png), format="PNG")
        return {
            "ok": True,
            "mode": "preview-frame",
            "frame": f_idx,
            "resolution": f"{width}x{height}",
            "preview_png": str(target_png),
            "render_ms": round((time.time() - t0_render) * 1000.0, 2),
        }

    rendered_stills = []
    if stills_spec:
        stills_dir = ws / "qa" / "stills"
        stills_dir.mkdir(parents=True, exist_ok=True)
        for raw_f in stills_spec.split(","):
            raw_f = raw_f.strip()
            if not raw_f.isdigit():
                continue
            f_idx = min(total_frames - 1, max(0, int(raw_f)))
            pil_img = render_global_frame(f_idx)
            still_path = stills_dir / f"frame_{f_idx:04d}.png"
            pil_img.save(str(still_path), format="PNG")
            rendered_stills.append(str(still_path))

    req_engine = (engine_mode or os.environ.get("SHOTCRAFT_ENGINE") or "auto").strip().lower()
    if req_engine == "cinema-pil":
        req_engine = "pillow"
    used_engine = "pillow"
    fallback_occurred = False
    fallback_reason = None
    bitrate_kbps = 0.0
    if output_mp4:
        output_mp4.parent.mkdir(parents=True, exist_ok=True)
        temp_video = ws / "out" / "_video_only.mp4"
        temp_video.parent.mkdir(parents=True, exist_ok=True)

        if req_engine == "remotion" or (req_engine == "auto" and os.environ.get("SHOTCRAFT_ENGINE") == "remotion"):
            if try_remotion_cli_render(ws, "MainReel", temp_video, install_deps=install_remotion):
                used_engine = "remotion"
            else:
                fallback_reason = "Remotion render failed or dependencies are missing; inspect qa/remotion-render.log in the workspace."
                if policy_mode == "final":
                    return {
                        "ok": False,
                        "requested_engine": req_engine,
                        "actual_engine": None,
                        "fallback_occurred": False,
                        "fallback_reason": fallback_reason,
                        "error": f"Final mode requires '{req_engine}', which failed: {fallback_reason}",
                    }
                fallback_occurred = True
                used_engine = "pillow"

        if used_engine != "remotion":
            step_f = 1
            in_fps = fps / float(step_f)
            cmd_v = [
                "ffmpeg",
                "-y",
                "-v",
                "error",
                "-f",
                "rawvideo",
                "-vcodec",
                "rawvideo",
                "-s",
                f"{width}x{height}",
                "-pix_fmt",
                "rgb24",
                "-r",
                f"{in_fps:.2f}",
                "-i",
                "-",
                "-r",
                str(fps),
                "-c:v",
                "libx264",
                "-threads",
                "2",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "ultrafast",
                "-tune",
                "stillimage",
                "-x264-params",
                "bframes=0:ref=1:subme=0:me=dia:trellis=0:aq-mode=0:scenecut=0:sliced-threads=1",
                "-g",
                "30",
                "-crf",
                "18",
                str(temp_video),
            ]
            proc_v = subprocess.Popen(cmd_v, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            try:
                if os.environ.get("SHOTCRAFT_PARALLEL_SCENES", "1") != "0":
                    batch_sz = 16
                    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, (os.cpu_count() or 2))) as pool:
                        for b0 in range(0, total_frames, batch_sz * step_f):
                            f_indices = list(range(b0, min(total_frames, b0 + batch_sz * step_f), step_f))
                            for pil_img in pool.map(render_global_frame, f_indices):
                                proc_v.stdin.write(pil_img.tobytes())
                else:
                    for f_idx in range(0, total_frames, step_f):
                        pil_img = render_global_frame(f_idx)
                        proc_v.stdin.write(pil_img.tobytes())
                proc_v.stdin.close()
            except Exception:
                proc_v.kill()
                raise
            ret_v = proc_v.wait()
            if ret_v != 0:
                err_txt = proc_v.stderr.read().decode("utf-8", errors="replace") if proc_v.stderr else ""
                raise RuntimeError(f"ffmpeg video encode failed ({ret_v}): {err_txt[-300:]}")

        skills_root = _resolve_skills_root()
        sfx_script = skills_root / "reels-sfx-studio" / "scripts" / "sfx_engine.py"
        audio_wav = ws / "out" / "auto_soundtrack.wav"
        dur_sec = total_frames / float(fps)

        tl_file = ws / "timeline.json"
        if not tl_file.is_file() or auto_pacing:
            tl_file.write_text(json.dumps({"fps": fps, "width": width, "height": height, "scenes": scenes}, indent=2, ensure_ascii=False), encoding="utf-8")

        bgm_name = os.environ.get("SHOTCRAFT_BGM_TRACK", "explainer-groove-104bpm.wav")
        sfx_pack = os.environ.get("SHOTCRAFT_SFX_PACK", "organic")
        bgm_cand = skills_root / "reels-sfx-studio" / "assets" / "bgm" / bgm_name
        if not bgm_cand.is_file():
            bgm_cand = skills_root / "reels-sfx-studio" / "assets" / "bgm" / "lofi-study-chill-84bpm.wav"
        narr_cand = ws / "narration.wav"
        cmd_sfx = [
            sys.executable,
            str(sfx_script),
            "--mix-timeline",
            str(tl_file),
            "--output",
            str(audio_wav),
            "--duration",
            str(dur_sec),
            "--fps",
            str(fps),
            "--sfx-pack",
            sfx_pack,
            "--duck-db",
            "-14.0",
        ]
        if bgm_cand.is_file() and os.environ.get("SHOTCRAFT_NO_BGM") != "1":
            cmd_sfx.extend(["--bgm", str(bgm_cand)])
        if narr_cand.is_file() and os.environ.get("SHOTCRAFT_NO_NARRATION") != "1":
            cmd_sfx.extend(["--narration", str(narr_cand)])
        subprocess.run(cmd_sfx, stdin=subprocess.DEVNULL, check=True, stdout=subprocess.DEVNULL)

        mux_tmp = ws / "out" / "_final_muxed.mp4"
        subprocess.run(
            [
                "ffmpeg",
                "-nostdin",
                "-y",
                "-v",
                "error",
                "-i",
                str(temp_video),
                "-i",
                str(audio_wav),
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "192k",
                "-af",
                f"apad=whole_dur={dur_sec:.4f},atrim=0:{dur_sec:.4f}",
                "-movflags",
                "+faststart",
                str(mux_tmp),
            ],
            stdin=subprocess.DEVNULL,
            check=True,
        )
        shutil.copyfile(mux_tmp, output_mp4)
        if output_mp4.is_file() and dur_sec > 0:
            bitrate_kbps = round((output_mp4.stat().st_size * 8.0) / (dur_sec * 1000.0), 1)
        if temp_video.is_file():
            temp_video.unlink()
        if mux_tmp.is_file():
            mux_tmp.unlink()

    # Section 7.1 & 7.2: Save Telemetry & Retention Prediction Report
    total_elapsed_s = round(time.time() - t0_render, 3)
    try:
        sys.path.insert(0, str(_resolve_skills_root() / "reels-qa" / "scripts"))
        import retention_model as ret_ml_mod
        retention_pred = ret_ml_mod.predict_retention_ml(
            scenes, fps=fps, still_paths=rendered_stills, audio_env_path=ws / "out" / "audio_envelope.json"
        )
    except Exception:
        retention_pred = compute_viewer_retention_prediction(scenes, fps=fps)
    telemetry = {
        "total_render_seconds": total_elapsed_s,
        "effective_render_fps": round(total_frames / max(0.01, total_elapsed_s), 2),
        "scene_render_ms": {k: round(v, 1) for k, v in scene_render_ms.items()},
        "tts_telemetry": tr_data.get("telemetry", {}),
        "video_specs": {
            "resolution": f"{width}x{height}",
            "fps": fps,
            "total_frames": total_frames,
            "duration_sec": round(total_frames / float(fps), 3),
            "bitrate_kbps": bitrate_kbps,
        },
        "retention_prediction": retention_pred,
    }
    qa_dir = ws / "qa"
    qa_dir.mkdir(parents=True, exist_ok=True)
    (qa_dir / "telemetry.json").write_text(json.dumps(telemetry, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "ok": True,
        "engine": used_engine,
        "requested_engine": req_engine,
        "actual_engine": used_engine,
        "fallback_occurred": fallback_occurred,
        "fallback_reason": fallback_reason,
        "font_resolution_log": dict(_FONT_RESOLUTION_LOG),
        "workspace": str(ws),
        "resolution": f"{width}x{height}",
        "total_frames": total_frames,
        "fps": fps,
        "stills": rendered_stills,
        "output_mp4": str(output_mp4) if output_mp4 else None,
        "telemetry": telemetry,
        "editorial_heuristic_score": retention_pred,
        "retention_prediction": retention_pred,
    }


def serve_live_preview(ws: Path, port: int, fps: int, width: int, height: int):
    """
    Section 6.1:
    Lightweight Live Preview & Frame Scrubber HTTP Server (--serve-preview PORT).
    """
    class PreviewHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith("/frame/"):
                f_num = int(re.sub(r"[^\d]", "", self.path) or "0")
                out_png = ws / "qa" / "stills" / f"live_{f_num:04d}.png"
                render_deterministic_fallback(ws, None, None, fps=fps, width=width, height=height, preview_frame=f_num, preview_output=out_png)
                data = out_png.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
                return
            html = (
                "<!doctype html><html><head><meta charset='utf-8'><title>Shotcraft Live Frame Scrubber</title>"
                "<style>body{background:#0b0f19;color:#f8fafc;font-family:sans-serif;text-align:center;padding:24px}"
                "img{max-height:78vh;border-radius:16px;border:2px solid #38bdf8;box-shadow:0 20px 50px rgba(0,0,0,0.6)}"
                "input[type=range]{width:420px;margin:16px}</style></head><body>"
                "<h2>Shotcraft Pro v9.6 — Live Frame Scrubber & Hot Reload</h2>"
                "<div><input id='sc' type='range' min='0' max='360' value='15' oninput='up(this.value)'/>"
                "<span id='lbl'>Frame 15</span></div>"
                "<img id='vw' src='/frame/15'/>"
                "<script>function up(v){document.getElementById('lbl').innerText='Frame '+v;"
                "document.getElementById('vw').src='/frame/'+v+'?t='+Date.now();}</script></body></html>"
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html)

    with socketserver.TCPServer(("127.0.0.1", port), PreviewHandler) as httpd:
        print(json.dumps({"ok": True, "live_preview_url": f"http://127.0.0.1:{port}"}))
        httpd.serve_forever()


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro Smart Renderer v9.6 (True 3D Orbit + Semantic Captions + Multi-Aspect)")
    p.add_argument("--workspace", required=True)
    p.add_argument("--composition", default="MainReel")
    p.add_argument("--stills", help="Comma-separated frame numbers e.g. 0,45,120")
    p.add_argument("--preview-frame", type=int, default=None, help="Render single frame N as PNG for instant visual check")
    p.add_argument("--preview-output", help="Optional output PNG path for --preview-frame")
    p.add_argument("--only-scene", help="Optional scene id or index for incremental scene update")
    p.add_argument("--serve-preview", type=int, default=None, help="Start live browser preview & frame scrubber on PORT")
    p.add_argument("--output", help="Target MP4 path")
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--aspect", choices=list(ASPECT_PRESETS.keys()), default=None, help="Multi-aspect ratio preset (9:16, 16:9, 1:1, 4:5, 2:3)")
    p.add_argument("--width", type=int, default=1080)
    p.add_argument("--height", type=int, default=1920)
    p.add_argument("--brand-kit", help="Optional path to brand_kit.json")
    p.add_argument("--no-auto-pacing", action="store_true", help="Disable automatic visual-to-audio pacing fit")
    p.add_argument("--no-badge", action="store_true", help="Hide top title/brand badge completely ([QW2])")
    p.add_argument("--use-gpu", action="store_true", help="Enable GPU acceleration flags for encoding/Remotion ([P3-4])")
    p.add_argument("--parallel-scenes", action="store_true", help="Render frames in parallel worker threads ([P3-4])")
    p.add_argument("--frame-cache", action="store_true", help="Enable frame-level disk cache for incremental scene updates ([P3-4])")
    p.add_argument("--cloud-render", action="store_true", help="Export Remotion Lambda / Cloud Render job specification ([P3-4])")
    p.add_argument("--verbose", action="store_true", help="Enable verbose frame & telemetry logging ([P5-3])")
    p.add_argument("--engine", choices=["auto", "pillow", "remotion", "cinema-pil"], default="auto")
    p.add_argument("--mode", choices=["draft", "final"], default="draft", help="Engine policy mode (F04)")
    p.add_argument("--install-remotion", action="store_true")
    a = p.parse_args()
    unsupported = [name for name in ('use_gpu', 'frame_cache', 'cloud_render') if getattr(a, name, False)]
    if unsupported:
        p.error('Not implemented in this renderer: '+', '.join('--'+x.replace('_','-') for x in unsupported)+'. Use the CPU renderer or a separate configured cloud/GPU workflow.')

    ws = Path(a.workspace).expanduser().resolve()
    out_mp4 = Path(a.output).expanduser().resolve() if a.output else None
    prev_out = Path(a.preview_output).expanduser().resolve() if a.preview_output else None

    width, height = a.width, a.height
    if a.aspect in ASPECT_PRESETS and (width, height) == (1080, 1920):
        width, height = ASPECT_PRESETS[a.aspect]

    if a.serve_preview:
        serve_live_preview(ws, a.serve_preview, a.fps, width, height)
        return

    if getattr(a, "no_badge", False):
        os.environ["SHOTCRAFT_NO_BADGE"] = "1"
    if getattr(a, "parallel_scenes", False):
        os.environ["SHOTCRAFT_PARALLEL_SCENES"] = "1"
    if getattr(a, "use_gpu", False):
        os.environ["SHOTCRAFT_USE_GPU"] = "1"
    res = render_deterministic_fallback(
        ws,
        a.stills,
        out_mp4,
        fps=a.fps,
        width=width,
        height=height,
        engine_mode=a.engine,
        policy_mode=a.mode,
        install_remotion=a.install_remotion,
        preview_frame=a.preview_frame,
        preview_output=prev_out,
        brand_kit_path=a.brand_kit,
        auto_pacing=not a.no_auto_pacing,
        only_scene=a.only_scene,
    )
    print(json.dumps(res, indent=2))
    if not res.get("ok", False):
        raise SystemExit(1)


if __name__ == "__main__":
    main()