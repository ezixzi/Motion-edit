"""
Shotcraft Pro v9.8.0 — Talking Head Guidebook & Motion Registry (`talking_head_guidebook.py`).

Implements Section 5 of claude_talking_head_instructions-rev.md:
- Pillar 1: MotionRegistry — discovers & bridges all existing codebase motion features
- Pillar 2: Style & Design Tokens (style_tokens) — glassmorphism, borders, typography, colors
- Pillar 3: Animation Timing & Physics Curves (animation_curves)
- Pillar 4: Composable Motion Kit (MK_01 – MK_08) + codebase native motions
- Pillar 5: Scene Composition & Combination Matrix (composition_matrix)

Every talking_head_scene can combine:
  [Entrance Motion] + [Idle/Continuous Motion] + [Emphasis Trigger Motion] +
  [Camera/Canvas Motion] + [Exit Motion]

The MotionRegistry auto-discovers existing motions from smart_render.py, style_map.py,
and script_writer.py so talking_head_scenes can mix-and-match them dynamically.
"""

from __future__ import annotations

import importlib
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
if str(SKILLS_ROOT / "mcp" / "core") not in sys.path:
    sys.path.insert(0, str(SKILLS_ROOT / "mcp" / "core"))


# ---------------------------------------------------------------------------
# Guidebook Configuration
# ---------------------------------------------------------------------------

class GuidebookConfig:
    """Loads and provides access to talking_head_guidebook.json."""

    def __init__(self, config_path: Path | None = None):
        self.config_path = config_path or (HERE / "talking_head_guidebook.json")
        self._data: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                self._data = json.load(f)
        except FileNotFoundError:
            self._data = {}

    @property
    def version(self) -> str:
        return str(self._data.get("guidebook_version", "2.0"))

    @property
    def default_preset(self) -> str:
        return str(self._data.get("default_preset", "claude_glass_dark"))

    @property
    def canvas(self) -> dict[str, Any]:
        return self._data.get("canvas", {})

    @property
    def safe_zones(self) -> dict[str, Any]:
        return self.canvas.get("safe_zones", {})

    @property
    def style_tokens(self) -> dict[str, Any]:
        return self._data.get("style_tokens", {})

    @property
    def animation_curves(self) -> dict[str, Any]:
        return self._data.get("animation_curves", {})

    @property
    def motion_kit(self) -> dict[str, Any]:
        return self._data.get("motion_kit", {})

    @property
    def composition_matrix(self) -> list[dict[str, Any]]:
        return self._data.get("composition_matrix", [])

    @property
    def phase_2_features(self) -> dict[str, Any]:
        return self._data.get("phase_2_features", {})

    def get_style_token(self, category: str, name: str) -> dict[str, Any]:
        return self.style_tokens.get(category, {}).get(name, {})

    def get_animation_curve(self, name: str) -> dict[str, Any]:
        return self.animation_curves.get(name, {})

    def get_motion_kit(self, motion_id: str) -> dict[str, Any]:
        return self.motion_kit.get(motion_id, {})

    def find_composition_rule(self, trigger_text: str) -> dict[str, Any] | None:
        """Find the first composition rule whose trigger_patterns match the text."""
        text = (trigger_text or "").lower()
        for rule in self.composition_matrix:
            patterns = rule.get("trigger_patterns", [])
            if any(p.lower() in text for p in patterns):
                return rule
        return None


# ---------------------------------------------------------------------------
# Existing Codebase Motion Discovery
# ---------------------------------------------------------------------------

class MotionRegistry:
    """
    Discovers and bridges all existing motion features from the codebase
    into the Talking Head Guidebook composable motion system.
    """

    def __init__(self, config: GuidebookConfig | None = None):
        self.config = config or GuidebookConfig()
        self.registered_motions: dict[str, dict[str, Any]] = {}
        self._discover_codebase_motions()
        self._register_guidebook_motions()

    def _discover_codebase_motions(self) -> None:
        """Scan existing modules for motion/easing/animation utilities."""
        # 1. smart_render.py easing functions
        try:
            sys.path.insert(0, str(HERE))
            import smart_render as sr_mod  # type: ignore

            if hasattr(sr_mod, "ease_out_cubic"):
                self.register("codebase_ease_out_cubic", {
                    "fn": sr_mod.ease_out_cubic,
                    "kind": "easing",
                    "target": "any",
                    "params": {"x": "float 0-1"},
                    "description": "Cubic ease-out from smart_render.py",
                })
            if hasattr(sr_mod, "ease_in_out_cubic"):
                self.register("codebase_ease_in_out_cubic", {
                    "fn": sr_mod.ease_in_out_cubic,
                    "kind": "easing",
                    "target": "any",
                    "params": {"x": "float 0-1"},
                    "description": "Cubic ease-in-out from smart_render.py",
                })
            if hasattr(sr_mod, "spring_ease"):
                self.register("codebase_spring_ease", {
                    "fn": sr_mod.spring_ease,
                    "kind": "easing",
                    "target": "any",
                    "params": {"frame": "int", "delay": "float", "dur": "float"},
                    "description": "Spring ease from smart_render.py",
                })
            if hasattr(sr_mod, "hex_to_rgb"):
                self.register("codebase_hex_to_rgb", {
                    "fn": sr_mod.hex_to_rgb,
                    "kind": "color_util",
                    "target": "any",
                    "params": {"hex_str": "str"},
                    "description": "Hex to RGB converter from smart_render.py",
                })
            if hasattr(sr_mod, "load_font"):
                self.register("codebase_load_font", {
                    "fn": sr_mod.load_font,
                    "kind": "font_util",
                    "target": "any",
                    "params": {"size": "int", "bold": "bool"},
                    "description": "Font loader from smart_render.py",
                })
            if hasattr(sr_mod, "sanitize_text"):
                self.register("codebase_sanitize_text", {
                    "fn": sr_mod.sanitize_text,
                    "kind": "text_util",
                    "target": "any",
                    "params": {"text": "str", "allow_emoji": "bool"},
                    "description": "Text sanitizer from smart_render.py",
                })
            if hasattr(sr_mod, "build_world_background"):
                self.register("codebase_build_world_background", {
                    "fn": sr_mod.build_world_background,
                    "kind": "background",
                    "target": "canvas",
                    "params": {"w": "int", "h": "int", "kind": "str", "accent": "str", "scene_idx": "int"},
                    "description": "World background builder from smart_render.py",
                })
            if hasattr(sr_mod, "composite_talking_head_layers"):
                self.register("codebase_composite_layers", {
                    "fn": sr_mod.composite_talking_head_layers,
                    "kind": "compositor",
                    "target": "canvas",
                    "params": {"bg": "Image", "face": "Image", "captions": "Image", "overlay": "Image"},
                    "description": "Talking head layer compositor from smart_render.py",
                })
            if hasattr(sr_mod, "apply_brand_kit_overlay"):
                self.register("codebase_apply_brand_kit", {
                    "fn": sr_mod.apply_brand_kit_overlay,
                    "kind": "brand_kit",
                    "target": "canvas",
                    "params": {"img": "Image", "kit": "dict", "frame": "int", "dur": "int", "is_last": "bool"},
                    "description": "Brand kit overlay applier from smart_render.py",
                })
            if hasattr(sr_mod, "adapt_frame_to_aspect"):
                self.register("codebase_adapt_aspect", {
                    "fn": sr_mod.adapt_frame_to_aspect,
                    "kind": "aspect",
                    "target": "canvas",
                    "params": {"img": "Image", "w": "int", "h": "int"},
                    "description": "Aspect ratio adapter from smart_render.py",
                })
            if hasattr(sr_mod, "draw_talking_head_face_layer"):
                self.register("codebase_draw_face_layer", {
                    "fn": sr_mod.draw_talking_head_face_layer,
                    "kind": "face_layer",
                    "target": "center_subject",
                    "params": {"w": "int", "h": "int", "anchor": "tuple", "accent": "tuple", "frame": "int", "fps": "float"},
                    "description": "Face-aware talking head layer from smart_render.py",
                })
            if hasattr(sr_mod, "talking_head_face_anchor"):
                self.register("codebase_face_anchor", {
                    "fn": sr_mod.talking_head_face_anchor,
                    "kind": "face_anchor",
                    "target": "center_subject",
                    "params": {"scene": "dict", "w": "int", "h": "int"},
                    "description": "Face-aware framing anchor from smart_render.py",
                })
        except Exception:
            pass

        # 2. style_map.py style families & transitions
        try:
            sys.path.insert(0, str(SKILLS_ROOT / "mcp" / "core"))
            import style_map as sm_mod  # type: ignore

            if hasattr(sm_mod, "STYLE_FAMILIES"):
                for fam_id, fam_spec in sm_mod.STYLE_FAMILIES.items():
                    self.register(f"style_{fam_id}", {
                        "spec": fam_spec,
                        "kind": "style_family",
                        "target": "scene",
                        "description": f"Style family {fam_id} from style_map.py",
                    })
            if hasattr(sm_mod, "VALID_TRANSITION_TYPES"):
                self.register("codebase_transitions", {
                    "transitions": list(sm_mod.VALID_TRANSITION_TYPES),
                    "kind": "transitions",
                    "target": "scene",
                    "description": f"Valid transitions: {', '.join(sm_mod.VALID_TRANSITION_TYPES)}",
                })
        except Exception:
            pass

        # 3. script_writer.py talking head scenes
        try:
            sys.path.insert(0, str(SKILLS_ROOT / "reels-narration" / "scripts"))
            import script_writer as sw_mod  # type: ignore

            if hasattr(sw_mod, "_build_talking_head_scenes"):
                self.register("codebase_build_talking_head_scenes", {
                    "fn": sw_mod._build_talking_head_scenes,
                    "kind": "scene_generator",
                    "target": "timeline",
                    "params": {"topic": "str", "style_id": "str", "fps": "int", "duration_sec": "float", "lang": "str"},
                    "description": "Talking head scene generator from script_writer.py",
                })
            if hasattr(sw_mod, "generate_indonesian_scenes"):
                self.register("codebase_generate_indonesian_scenes", {
                    "fn": sw_mod.generate_indonesian_scenes,
                    "kind": "scene_generator",
                    "target": "timeline",
                    "params": {"topic": "str", "style": "str", "duration_sec": "float"},
                    "description": "Indonesian scene generator from script_writer.py",
                })
        except Exception:
            pass

    def _register_guidebook_motions(self) -> None:
        """Register the new Guidebook motion kit primitives (MK_01 to MK_08)."""
        for mk_id, mk_spec in self.config.motion_kit.items():
            key = mk_id.replace("MK_", "mk_").lower()
            self.register(key, {
                "spec": mk_spec,
                "kind": "motion_kit",
                "target": mk_spec.get("layer_target", "any"),
                "description": mk_spec.get("behavior", ""),
            })

    def register(self, motion_id: str, spec: dict[str, Any]) -> None:
        self.registered_motions[motion_id] = spec

    def get(self, motion_id: str) -> dict[str, Any] | None:
        return self.registered_motions.get(motion_id)

    def list_motions(self, kind: str | None = None) -> list[str]:
        if kind:
            return [mid for mid, spec in self.registered_motions.items()
                    if spec.get("kind") == kind]
        return list(self.registered_motions.keys())

    def apply_easing(self, name: str, x: float) -> float:
        """Apply an easing function by name, returning value in [0, 1]."""
        spec = self.get(name)
        if not spec or spec.get("kind") != "easing":
            return x
        fn = spec.get("fn")
        if fn is None:
            return x
        try:
            return float(fn(x))
        except Exception:
            return x

    def apply_spring(self, name: str, frame: float, delay: float = 0.0, dur: float = 18.0) -> float:
        """Apply a spring ease by name (frame-based)."""
        spec = self.get(name)
        if not spec or spec.get("kind") != "easing":
            return 1.0
        fn = spec.get("fn")
        if fn is None:
            return 1.0
        try:
            return float(fn(frame, delay=delay, dur=dur))
        except Exception:
            return 1.0


# ---------------------------------------------------------------------------
# Motion Kit Applicator
# ---------------------------------------------------------------------------

class MotionKit:
    """Applies motion kit primitives (MK_01 to MK_08) to talking head layers."""

    def __init__(self, registry: MotionRegistry):
        self.registry = registry

    def spring_stagger_stack(self, items: list[Any], base_delay_ms: int = 120,
                             stagger_ms: int = 120) -> list[dict[str, Any]]:
        """MK_01: Stagger child items (rows/tags) with spring_pop entrance."""
        result = []
        for i, item in enumerate(items):
            delay_ms = base_delay_ms + i * stagger_ms
            result.append({
                "item": item,
                "motion": "MK_01:spring_stagger_stack",
                "entrance": "spring_pop",
                "delay_ms": delay_ms,
                "transform": "scale(0.82->1.03->1.0), translateY(18px->0), opacity(0->1)",
            })
        return result

    def rainbow_border_pulse(self, target: str = "full_frame",
                             pulse_speed: float = 4.0) -> dict[str, Any]:
        """MK_02: Animated rotating 4-color gradient stroke + bloom."""
        return {
            "motion": "MK_02:rainbow_border_pulse",
            "target": target,
            "gradient": ["#60A5FA", "#A855F7", "#EC4899", "#F97316"],
            "pulse_speed": pulse_speed,
            "bloom": "0 0 16px rgba(236,72,153,0.65)",
        }

    def svg_ring_and_arrow_flow(self, center: tuple[int, int],
                                ring_radius: int = 64) -> dict[str, Any]:
        """MK_03: Circular SVG progress stroke + directional arrows."""
        return {
            "motion": "MK_03:svg_ring_and_arrow_flow",
            "center": center,
            "ring_radius": ring_radius,
            "stroke": "stroke-dashoffset 100% -> 0%",
            "arrow": "translateX(-12px -> 0) with opacity trail",
        }

    def gradient_shimmer_text(self, text: str, gradient_stops: list[str] | None = None) -> dict[str, Any]:
        """MK_04: Horizontal panning gradient mask + text glow."""
        stops = gradient_stops or ["#60A5FA", "#A855F7", "#EC4899", "#FB923C"]
        return {
            "motion": "MK_04:gradient_shimmer_text",
            "text": text,
            "gradient_stops": stops,
            "mask": "background-position: 0% -> 100%",
        }

    def floating_idle_bob(self, cx: int, cy: int, amplitude_px: int = 4,
                          freq_hz: float = 0.6, rotation_deg: float = 180.0) -> dict[str, Any]:
        """MK_05: Continuous sine-wave vertical float + slow rotation."""
        return {
            "motion": "MK_05:floating_idle_bob",
            "center": (cx, cy),
            "amplitude_px": amplitude_px,
            "freq_hz": freq_hz,
            "rotation_deg": rotation_deg,
        }

    def camera_punch_and_creep(self, mode: str = "creep_zoom",
                               scale_start: float = 1.0, scale_end: float = 1.06,
                               duration_ms: int = 180) -> dict[str, Any]:
        """MK_06: punch_in / creep_zoom / zoom_reset on raw video layer."""
        return {
            "motion": "MK_06:camera_punch_and_creep",
            "mode": mode,
            "scale_start": scale_start,
            "scale_end": scale_end,
            "duration_ms": duration_ms,
        }

    def transition_exposure_dip(self, dip_min: float = 0.65,
                                duration_ms: int = 250) -> dict[str, Any]:
        """MK_07: Brightness dip or cross-fade between chapters."""
        return {
            "motion": "MK_07:transition_exposure_dip",
            "dip_min": dip_min,
            "duration_ms": duration_ms,
        }

    def codebase_native_motion(self, motion_name: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """MK_08: Apply a discovered codebase-native motion by name."""
        spec = self.registry.get(motion_name)
        if not spec:
            return {"motion": "MK_08:codebase_native_motion", "error": f"Motion {motion_name} not found"}
        return {
            "motion": "MK_08:codebase_native_motion",
            "source": motion_name,
            "kind": spec.get("kind"),
            "params": params or {},
        }


# ---------------------------------------------------------------------------
# Scene Director / Combinator
# ---------------------------------------------------------------------------

class SceneDirector:
    """
    Reads transcript + audio energy and builds rich multi-layered talking head
    scenes by combining the Guidebook composition matrix with registered motions.
    """

    def __init__(self, registry: MotionRegistry, config: GuidebookConfig | None = None):
        self.registry = registry
        self.config = config or GuidebookConfig()

    def compose_scene(self, trigger_text: str, beat_type: str | None = None,
                      context: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Build a complete scene spec from trigger text or beat_type.
        Returns archetype + combine_motions + sfx_triggers + layout hints.
        """
        context = context or {}
        rule = None

        if beat_type:
            for r in self.config.composition_matrix:
                if r.get("beat_type") == beat_type:
                    rule = r
                    break

        if rule is None and trigger_text:
            rule = self.config.find_composition_rule(trigger_text)

        if rule is None:
            # Default fallback
            rule = {
                "archetype": "kinetic_typography_callout",
                "combine_motions": ["MK_04:gradient_shimmer_text", "MK_01:spring_stagger_stack"],
                "sfx_triggers": ["text_tick"],
                "top_vignette": True,
            }

        # Resolve motion specs
        resolved_motions = []
        for mref in rule.get("combine_motions", []):
            # Parse "MK_XX:name" or bare name
            parts = mref.split(":", 1)
            mk_name = parts[1] if len(parts) > 1 else parts[0]
            spec = self.registry.get(mk_name)
            if spec:
                resolved_motions.append({"ref": mref, "spec": spec})
            else:
                resolved_motions.append({"ref": mref, "spec": None})

        return {
            "archetype": rule.get("archetype", "kinetic_typography_callout"),
            "beat_type": rule.get("beat_type", "generic"),
            "combine_motions": resolved_motions,
            "sfx_triggers": rule.get("sfx_triggers", []),
            "top_vignette": rule.get("top_vignette", True),
            "extra_elements": rule.get("extra_elements", []),
            "guidebook_version": self.config.version,
        }

    def apply_motion_stack(self, scene_spec: dict[str, Any],
                           frame: int, fps: float) -> dict[str, Any]:
        """
        Given a composed scene spec and current frame/fps, return per-layer
        motion transforms (entrance, idle, emphasis, camera, exit).
        """
        stack = {
            "entrance": None,
            "idle": None,
            "emphasis": None,
            "camera": None,
            "exit": None,
        }

        for mref_entry in scene_spec.get("combine_motions", []):
            mref = mref_entry.get("ref", "")
            if mref.startswith("MK_01"):
                stack["entrance"] = {
                    "kind": "spring_pop",
                    "delay_ms": (mref_entry.get("spec") or {}).get("description", ""),
                }
            elif mref.startswith("MK_02"):
                stack["emphasis"] = {
                    "kind": "rainbow_border_pulse",
                    "motion": "MK_02:rainbow_border_pulse",
                }
            elif mref.startswith("MK_05"):
                stack["idle"] = {
                    "kind": "floating_idle_bob",
                }
            elif mref.startswith("MK_06"):
                stack["camera"] = {
                    "kind": "camera_punch_and_creep",
                    "frame": frame,
                    "fps": fps,
                }
            elif mref.startswith("MK_07"):
                stack["exit"] = {
                    "kind": "transition_exposure_dip",
                }

        return stack


# Module-level singletons for convenient import
_guidebook_config = None
_motion_registry = None


def get_guidebook_config() -> GuidebookConfig:
    global _guidebook_config
    if _guidebook_config is None:
        _guidebook_config = GuidebookConfig()
    return _guidebook_config


def get_motion_registry() -> MotionRegistry:
    global _motion_registry
    if _motion_registry is None:
        _motion_registry = MotionRegistry(get_guidebook_config())
    return _motion_registry


def compose_talking_head_scene(trigger_text: str, beat_type: str | None = None,
                                context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Convenience function: compose a talking head scene from trigger text."""
    director = SceneDirector(get_motion_registry(), get_guidebook_config())
    return director.compose_scene(trigger_text, beat_type, context)
