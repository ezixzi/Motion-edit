---
name: reels-templates
description: 8 Blueprint Templates, 7 Reusable Remotion TSX Stages (OpusProceduralStage, DepthParallaxStage, KineticTypographyStage, TransitionBridge, CutawayRigStage, SmartFootageStage, SoundtrackStage), Workspace Scaffolder, and Hardware-Aware Smart Renderer with Deterministic Frame Fallback.
---

# Remotion Templates, Reusable TSX Stages & Smart Renderer (`reels-templates` v5.0)

Provides complete local Remotion project scaffolding (`scripts/scaffold_project.py`) and rendering (`scripts/smart_render.py`) with 7 pre-wired TSX components and 8 blueprint templates.

## 8 Blueprint Templates (`blueprints/templates_catalog.json`)

1. `kinetic-fact-story` — 3-Zone anti-collision vertical fact/science explainer with Opus 5.5 procedural SVG visuals & single clean hero metrics.
2. `technical-cutaway-reel` — Multi-stage mechanism/anatomy cutaway explainer (`CutawayRigStage.tsx` + `OpusProceduralStage.tsx`).
3. `saas-product-launch` — Dual-device browser + mobile showreel (`opus-dual-device-showreel` + `deconstructed-ui`).
4. `ink-press-vertical` — Editorial serif & warm paper vertical adaptation of the classic `video-shotcraft` Ink Press template.
5. `footage-carousel-showcase` — Owned clips + 3D card carousel + whip-pan handoffs (`SmartFootageStage.tsx`).
6. `luxury-editorial-glass` — Frosted glass callouts, split-shutter transitions, and 3D depth parallax (`DepthParallaxStage.tsx`).
7. `opus-shader-launch` — Retro-CRT / GLSL metaball atmosphere + kinetic typography (`opus-retro-crt-launch`).
8. `audio-reactive-podcast` — Voiceover-driven waveform rings + word-by-word karaoke pills (`SoundtrackStage.tsx`).
