import React from 'react';

/**
 * Custom Plugin Component Registry (`reels-templates/components/custom/index.ts`).
 * Register user-defined visualMode stage components here to extend VISUAL_MODE_REGISTRY without modifying core files.
 */
export const CUSTOM_STAGE_PLUGINS: Record<string, React.FC<{scene: any; index: number; total: number; badge?: string}>> = {};
export default CUSTOM_STAGE_PLUGINS;
