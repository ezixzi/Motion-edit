import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

export type TransitionStyle =
  | 'cut'
  | 'crossfade'
  | 'slide'
  | 'zoom'
  | 'object-match'
  | 'cutaway-peel'
  | 'iris-aperture'
  | 'whip-pan-blur'
  | 'depth-z-pass';

export interface TransitionBridgeProps {
  style?: TransitionStyle;
  motif?: string;
  durationInFrames?: number;
  accent?: string;
  originX?: number;
  originY?: number;
  children: React.ReactNode;
}

export const TransitionBridge: React.FC<TransitionBridgeProps> = ({
  style,
  motif,
  durationInFrames = 90,
  accent = '#38BDF8',
  originX = 540,
  originY = 960,
  children,
}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const activeStyle = (motif || style || 'crossfade').toLowerCase();
  const transDur = 12;
  const enterProgress = interpolate(frame, [0, transDur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const maxR = Math.hypot(Math.max(originX, width - originX), Math.max(originY, height - originY));

  if (activeStyle === 'cut') {
    return <AbsoluteFill data-transition-motif="cut">{children}</AbsoluteFill>;
  }

  if (activeStyle === 'crossfade' && frame < transDur) {
    return (
      <AbsoluteFill data-transition-motif="crossfade" style={{opacity: enterProgress}}>
        {children}
      </AbsoluteFill>
    );
  }

  if ((activeStyle === 'slide' || activeStyle === 'whip-pan-blur' || activeStyle.startsWith('whip')) && frame < transDur) {
    const dx = (1 - enterProgress) * 240;
    return (
      <AbsoluteFill data-transition-motif="slide" style={{transform: `translateX(${dx.toFixed(1)}px)`}}>
        {children}
      </AbsoluteFill>
    );
  }

  if ((activeStyle === 'zoom' || activeStyle === 'depth-z-pass') && frame < transDur) {
    const scale = 0.84 + 0.16 * enterProgress;
    return (
      <AbsoluteFill data-transition-motif="zoom" style={{transform: `scale(${scale.toFixed(3)})`, opacity: enterProgress}}>
        {children}
      </AbsoluteFill>
    );
  }

  if ((activeStyle === 'object-match' || activeStyle === 'iris-aperture') && frame < transDur) {
    const r = Math.max(48, enterProgress * maxR);
    return (
      <AbsoluteFill data-transition-motif="object-match" style={{clipPath: `circle(${r.toFixed(1)}px at ${originX}px ${originY}px)`}}>
        {children}
      </AbsoluteFill>
    );
  }

  if (activeStyle === 'cutaway-peel' && frame < transDur) {
    const splitX = Math.round(enterProgress * width);
    return (
      <AbsoluteFill
        data-transition-motif="cutaway-peel"
        style={{
          clipPath: `inset(0px ${width - splitX}px 0px 0px)`,
          borderRight: `4px solid ${accent}`,
        }}
      >
        {children}
      </AbsoluteFill>
    );
  }

  return <AbsoluteFill data-transition-motif={activeStyle}>{children}</AbsoluteFill>;
};
export default TransitionBridge;
