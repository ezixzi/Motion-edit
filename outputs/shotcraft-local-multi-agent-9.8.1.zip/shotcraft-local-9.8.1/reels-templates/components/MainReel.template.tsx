import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {SceneCard, CleanSceneSpec} from './components/SceneCard';
import {TransitionBridge} from './components/TransitionBridge';
import {Soundtrack} from './components/Soundtrack';
import {SfxCueItem} from './components/SoundtrackStage';

const SCENES: CleanSceneSpec[] = {{SCENES_JSON}};
const TITLE_BADGE: string = {{TITLE_BADGE_JSON}};
const SFX_CUES: SfxCueItem[] = {{SFX_CUES_JSON}};

export const MainReel: React.FC = () => {
  let cursor = 0;

  return (
    <AbsoluteFill style={{backgroundColor: '#070B14'}}>
      {/* Audio is mixed locally by smart_render.py after visual rendering */}
      {SCENES.map((sc, idx) => {
        const start = cursor;
        const dur = sc.durationInFrames;
        const transMotif = (sc as any).transitionMotif || ((sc as any).transitionOut && (sc as any).transitionOut.type) || 'crossfade';
        cursor += dur;
        return (
          <Sequence key={sc.id} from={start} durationInFrames={dur}>
            <TransitionBridge motif={transMotif} durationInFrames={dur} accent={sc.accent || '#38BDF8'}>
              <SceneCard scene={sc} index={idx} total={SCENES.length} badge={TITLE_BADGE} />
            </TransitionBridge>
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

export default MainReel;
