import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';

export interface ThreeFiberStageProps {
  mode: string;
  accent: string;
  modelPath?: string;
  subjectId?: string;
  mechanismStep?: string;
  cameraPreset?: 'orbit' | 'dolly' | 'focus-pull' | 'crane';
  audioPulse?: number;
}

export const MODEL_PATH_BY_MODE: Record<string, string> = {
  'ref3-cutaway-mechanism': 'assets/models/lawnmower_rotary.glb',
  'ref5-editorial-cutaway': 'assets/models/lawnmower_rotary.glb',
  'ref1-voxel-evidence': 'assets/models/voxel_presenter.glb',
  'ref1-tutorial-deck': 'assets/models/voxel_presenter.glb',
  'ref2-cinematic-character': 'assets/models/character_mascot.glb',
  'ref4-tape-mascot': 'assets/models/character_mascot.glb',
  'ref4-minimal-ui': 'assets/models/ui_card_stack.glb',
  'ref2-floating-glass': 'assets/models/ui_card_stack.glb',
  'coffee-editorial-3d': 'assets/models/coffee_cup.glb',
  'neural-network': 'assets/models/neuron.glb',
};

export const VALID_BUNDLED_GLB_MODELS = new Set([
  'assets/models/lawnmower_rotary.glb',
  'assets/models/engine_piston.glb',
  'assets/models/crankshaft.glb',
  'assets/models/coffee_cup.glb',
  'assets/models/bean.glb',
  'assets/models/steam.glb',
  'assets/models/neuron.glb',
  'assets/models/axon.glb',
  'assets/models/synapse.glb',
  'assets/models/voxel_presenter.glb',
  'assets/models/character_mascot.glb',
  'assets/models/ui_card_stack.glb',
]);

/**
 * Shotcraft Pro v9.7.0 — Deterministic 2.5D Projected Vector & Submesh Rig Stage (`ThreeFiberStage.tsx`).
 * Implements Audit Fix F05:
 * - Selects geometry strictly by `modelPath` or `subjectId` (`lawnmower_rotary.glb`, `engine_piston.glb`,
 *   `coffee_cup.glb`, `voxel_presenter.glb`, `character_mascot.glb`, `ui_card_stack.glb`, `neuron.glb`).
 * - Changing `modelPath` changes the rendered geometry (never returns a neuron for non-AI subjects!).
 * - If an unknown/missing `modelPath` is passed, renders an explicit structured error state (`data-model-error`).
 * - Honestly declares `data-render-capability="deterministic-2.5d-svg-projection"` rather than claiming unused GLSL shaders.
 */
export const ThreeFiberStage: React.FC<ThreeFiberStageProps> = ({
  mode,
  accent,
  modelPath,
  subjectId = '',
  mechanismStep = 'step-1',
  cameraPreset = 'orbit',
  audioPulse = 0,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / Math.max(1, fps);

  const resolvedModel =
    modelPath ||
    (subjectId === 'lawnmower-rotary'
      ? 'assets/models/lawnmower_rotary.glb'
      : subjectId === 'combustion-engine' || subjectId === 'motorcycle-warmup'
      ? 'assets/models/engine_piston.glb'
      : subjectId === 'coffee-extraction'
      ? 'assets/models/coffee_cup.glb'
      : subjectId === 'neural-network-ai'
      ? 'assets/models/neuron.glb'
      : MODEL_PATH_BY_MODE[mode] || 'assets/models/lawnmower_rotary.glb');

  const isKnownModel = VALID_BUNDLED_GLB_MODELS.has(resolvedModel);

  // Explicit structured error if modelPath is missing or invalid (F05 / T06)
  if (!isKnownModel) {
    return (
      <svg
        width={900}
        height={620}
        viewBox="0 0 900 620"
        data-gltf-model={resolvedModel}
        data-model-status="ERROR_MODEL_NOT_FOUND"
        data-render-capability="deterministic-2.5d-svg-projection"
      >
        <rect x={120} y={140} width={660} height={340} rx={24} fill="#1E1B2E" stroke="#EF4444" strokeWidth={4} />
        <text x={450} y={280} textAnchor="middle" fill="#EF4444" fontSize={28} fontWeight="bold" fontFamily="monospace">
          MODEL ASSET NOT FOUND
        </text>
        <text x={450} y={330} textAnchor="middle" fill="#F8FAFC" fontSize={20} fontFamily="monospace">
          {resolvedModel}
        </text>
      </svg>
    );
  }

  const dolly = (cameraPreset === 'dolly' ? 0.96 + Math.min(0.14, t * 0.04) : 1.0) * (1 + audioPulse * 0.08);
  const spinDeg = (t * 360 * 1.8) % 360;
  const pistonDy = Math.sin(t * 10) * 34;

  return (
    <svg
      width={900}
      height={620}
      viewBox="0 0 900 620"
      data-gltf-model={resolvedModel}
      data-model-status="OK"
      data-subject-id={subjectId}
      data-mechanism-step={mechanismStep}
      data-camera-preset={cameraPreset}
      data-render-capability="deterministic-2.5d-svg-projection"
    >
      {resolvedModel.includes('lawnmower_rotary') ? (
        <g transform={`translate(450, 320) scale(${dolly})`}>
          {/* Grass & Soil Layer */}
          <rect x={-380} y={95} width={760} height={70} rx={12} fill="#74B843" />
          <rect x={-380} y={155} width={760} height={85} rx={12} fill="#9E6230" />
          {/* Rear Chute & Collector Bag */}
          <path d="M 140 -20 L 310 -65 L 330 75 L 140 75 Z" fill="#1E293B" stroke={accent} strokeWidth={3} />
          {/* Protective Deck Housing (Cutaway) */}
          <rect x={-210} y={-25} width={360} height={95} rx={36} fill="#334155" stroke="#94A3B8" strokeWidth={4} />
          {/* Upper Motor Unit */}
          <rect x={-95} y={-155} width={130} height={130} rx={20} fill={accent} stroke="#F8FAFC" strokeWidth={3} />
          {/* Vertical Drive Shaft */}
          <rect x={-42} y={-25} width={24} height={68} fill="#CBD5E1" />
          {/* Horizontal Rotating Blade around Pivot (-30, 42) */}
          <g transform={`translate(-30, 42)`}>
            <ellipse
              cx={0}
              cy={0}
              rx={135 * Math.abs(Math.cos((spinDeg * Math.PI) / 180)) + 28}
              ry={16}
              fill="#F8FAFC"
              stroke={accent}
              strokeWidth={3}
            />
            <circle cx={0} cy={0} r={14} fill="#F59E0B" />
          </g>
        </g>
      ) : resolvedModel.includes('engine_piston') || resolvedModel.includes('crankshaft') ? (
        <g transform={`translate(450, 310) scale(${dolly})`}>
          <rect x={-160} y={-190} width={320} height={360} rx={28} fill="#1E293B" stroke="#64748B" strokeWidth={4} />
          <rect x={-95} y={-130 + pistonDy} width={190} height={110} rx={14} fill="#CBD5E1" stroke="#F8FAFC" strokeWidth={3} />
          <line x1={0} y1={-20 + pistonDy} x2={Math.cos(t * 10) * 45} y2={95 + Math.sin(t * 10) * 45} stroke="#94A3B8" strokeWidth={18} strokeLinecap="round" />
          <circle cx={0} cy={95} r={58} fill="#475569" stroke={accent} strokeWidth={4} />
        </g>
      ) : resolvedModel.includes('coffee_cup') || resolvedModel.includes('bean') || resolvedModel.includes('steam') ? (
        <g transform={`translate(450, 330) scale(${dolly})`}>
          <ellipse cx={0} cy={110} rx={210} ry={38} fill="#D6C2A8" />
          <rect x={-130} y={-70} width={260} height={165} rx={48} fill="#78350F" stroke="#FDE68A" strokeWidth={3} />
          <ellipse cx={0} cy={-65} rx={122} ry={32} fill="#B45309" stroke="#FEF3C7" strokeWidth={4} />
        </g>
      ) : resolvedModel.includes('voxel_presenter') ? (
        <g transform={`translate(450, 340) scale(${dolly})`}>
          <rect x={-85} y={-175} width={170} height={60} rx={10} fill="#2563EB" />
          <rect x={-75} y={-115} width={150} height={125} rx={8} fill="#EAB308" />
          <rect x={-85} y={10} width={170} height={150} rx={10} fill="#F8FAFC" stroke="#2563EB" strokeWidth={4} />
        </g>
      ) : resolvedModel.includes('character_mascot') ? (
        <g transform={`translate(450, 320) scale(${dolly})`}>
          <rect x={-130} y={-130} width={260} height={180} rx={18} fill="#D97757" stroke="#FDE68A" strokeWidth={3} />
          <rect x={-134} y={-30} width={268} height={85} rx={10} fill="#1E1B18" />
          <rect x={-90} y={55} width={32} height={80} fill="#9A3412" />
          <rect x={-20} y={55} width={32} height={80} fill="#9A3412" />
          <rect x={55} y={55} width={32} height={80} fill="#9A3412" />
        </g>
      ) : resolvedModel.includes('ui_card_stack') ? (
        <g transform={`translate(450, 310) scale(${dolly})`}>
          <rect x={-280} y={-150} width={560} height={300} rx={24} fill="#FFFFFF" stroke="#E2E8F0" strokeWidth={4} />
          <rect x={-240} y={-100} width={480} height={36} rx={10} fill="#FCE7F3" />
          <rect x={-240} y={-40} width={360} height={36} rx={10} fill="#DBEAFE" />
          <rect x={-240} y={20} width={420} height={36} rx={10} fill="#DCFCE7" />
        </g>
      ) : (
        /* Neural Network Stage (Strictly when neuron/axon/synapse model is requested) */
        <g transform={`translate(450, 310) scale(${dolly})`}>
          {[-220, 220, -180, 190].map((bx, idx) => (
            <line key={idx} x1={0} y1={0} x2={bx} y2={idx % 2 === 0 ? -110 : 110} stroke={accent} strokeWidth={8} />
          ))}
          <circle cx={0} cy={0} r={68} fill={accent} />
        </g>
      )}
    </svg>
  );
};

export default ThreeFiberStage;
