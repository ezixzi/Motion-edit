import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';

export interface SafeZoneWrapperProps {
  children: React.ReactNode;
  showGuide?: boolean;
  rtl?: boolean;
  style?: React.CSSProperties;
}

/**
 * [P3-1] & [6]: Adaptive Multi-Aspect Safe-Zone Wrapper
 * Automatically adapts padding to 9:16 (1080x1920), 16:9 (1920x1080), 1:1 (1080x1080), 4:5 (1080x1350), and 2:3 (1080x1620).
 */
export const SafeZoneWrapper: React.FC<SafeZoneWrapperProps> = ({
  children,
  showGuide = false,
  rtl = false,
  style,
}) => {
  const {width, height} = useVideoConfig();
  const isVertical = height > width * 1.2;
  const isLandscape = width > height * 1.2;

  const padTop = isVertical ? Math.round(height * 0.114) : Math.round(height * 0.08);
  const padBottom = isVertical ? Math.round(height * 0.115) : Math.round(height * 0.10);
  const padLeft = Math.round(width * 0.078);
  const padRight = isVertical ? Math.round(width * 0.188) : Math.round(width * 0.078);

  return (
    <AbsoluteFill
      dir={rtl ? 'rtl' : 'ltr'}
      style={{
        paddingTop: padTop,
        paddingBottom: padBottom,
        paddingLeft: padLeft,
        paddingRight: isLandscape ? padLeft : padRight,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        unicodeBidi: 'plaintext',
        ...style,
      }}
    >
      {children}
      {showGuide ? (
        <div
          style={{
            position: 'absolute',
            top: padTop,
            bottom: padBottom,
            left: padLeft,
            right: isLandscape ? padLeft : padRight,
            border: '2px dashed rgba(56, 189, 248, 0.45)',
            pointerEvents: 'none',
          }}
        />
      ) : null}
    </AbsoluteFill>
  );
};

export default SafeZoneWrapper;
