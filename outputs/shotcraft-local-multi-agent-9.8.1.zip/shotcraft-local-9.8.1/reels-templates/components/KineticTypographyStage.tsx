import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';

export interface TimedWord {
  word: string;
  startSec: number;
  endSec: number;
  emphasis?: 'strong' | 'moderate' | 'none';
  speaker?: string;
  animation?: 'scale-bounce' | 'pop-rotate' | 'glow-pulse' | 'slide-up';
  intensity?: number;
}

export interface KineticTypographyStageProps {
  variant?:
    | 'karaoke-pill'
    | 'typewriter'
    | 'slide-up'
    | 'glitch'
    | 'handwritten'
    | 'neon'
    | 'minimal'
    | 'brutalist-stagger'
    | 'editorial-serif'
    | 'glass-callout'
    | 'counter-shock'
    | 'asymmetric-ragged'
    | 'kinetic-slam'
    | 'leader-callout';
  eyebrow?: string;
  metric?: string;
  unit?: string;
  headline: string;
  subcopy?: string;
  accent?: string;
  speaker?: 'narrator' | 'expert' | 'user' | 'host' | 'guest';
  emphasisWords?: string[];
  words?: TimedWord[];
}

export const KineticTypographyStage: React.FC<KineticTypographyStageProps> = ({
  variant = 'counter-shock',
  eyebrow,
  metric,
  unit,
  headline,
  subcopy,
  accent = '#38BDF8',
  speaker,
  emphasisWords = [],
  words = [],
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 120}});

  const emphasisSet = React.useMemo(
    () => new Set(emphasisWords.map((w) => w.toLowerCase().replace(/[^\w]/g, ''))),
    [emphasisWords]
  );

  const isCaptionVariant =
    variant === 'karaoke-pill' ||
    variant === 'typewriter' ||
    variant === 'slide-up' ||
    variant === 'glitch' ||
    variant === 'handwritten' ||
    variant === 'neon' ||
    variant === 'minimal';

  if (isCaptionVariant && words.length > 0) {
    return (
      <div
        style={{
          backgroundColor:
            variant === 'handwritten'
              ? '#FAF5E8'
              : variant === 'neon'
              ? 'rgba(8, 10, 24, 0.95)'
              : 'rgba(15, 23, 42, 0.94)',
          border: `2px solid ${accent}`,
          borderRadius: variant === 'handwritten' ? 16 : 28,
          padding: '28px 36px',
          display: 'flex',
          flexWrap: 'wrap',
          gap: 12,
          alignItems: 'center',
          boxShadow: variant === 'neon' ? `0 0 28px ${accent}88` : '0 16px 40px rgba(0,0,0,0.45)',
        }}
      >
        {speaker ? (
          <span
            style={{
              backgroundColor: accent,
              color: '#020617',
              fontFamily: 'Inter, system-ui, sans-serif',
              fontSize: 20,
              fontWeight: 900,
              padding: '4px 14px',
              borderRadius: 999,
              marginRight: 8,
            }}
          >
            {speaker.toUpperCase()}:
          </span>
        ) : null}
        {words.map((w, idx) => {
          const active = t >= w.startSec && t <= w.endSec;
          const spoken = t > w.endSec;
          const cleanW = w.word.toLowerCase().replace(/[^\w]/g, '');
          const isEmph = w.emphasis === 'strong' || emphasisSet.has(cleanW);
          const intensity = w.intensity || (isEmph ? 1.3 : 1.12);
          const scale = active ? intensity : spoken ? 0.97 : 1.0;
          const slideY = variant === 'slide-up' && active ? -6 : 0;

          return (
            <span
              key={idx}
              style={{
                display: 'inline-block',
                fontFamily:
                  variant === 'typewriter' || variant === 'glitch'
                    ? 'ui-monospace, SFMono-Regular, Menlo, monospace'
                    : variant === 'handwritten'
                    ? 'Georgia, serif'
                    : 'Inter, system-ui, sans-serif',
                fontSize: isEmph ? 48 : 44,
                fontWeight: 800,
                padding: '4px 14px',
                borderRadius: 14,
                backgroundColor: active && variant !== 'typewriter' ? accent : 'transparent',
                color:
                  active && variant !== 'typewriter'
                    ? '#020617'
                    : variant === 'handwritten'
                    ? '#1C1917'
                    : spoken
                    ? 'rgba(248,250,252,0.78)'
                    : isEmph
                    ? accent
                    : '#F8FAFC',
                transform: `translateY(${slideY}px) scale(${scale.toFixed(2)})`,
                textShadow:
                  variant === 'glitch' && active
                    ? '-3px 0 #EC4899, 3px 0 #38BDF8'
                    : variant === 'neon' && active
                    ? `0 0 18px ${accent}`
                    : undefined,
              }}
            >
              {w.word}
            </span>
          );
        })}
      </div>
    );
  }

  return (
    <div
      style={{
        backgroundColor: 'rgba(15, 23, 42, 0.92)',
        border: `2px solid ${accent}`,
        borderRadius: 32,
        padding: '36px 42px',
        transform: `translateY(${((1 - enter) * 32).toFixed(1)}px)`,
        boxShadow: '0 24px 60px rgba(0,0,0,0.55)',
      }}
    >
      {eyebrow ? (
        <div
          style={{
            fontFamily: 'Inter, system-ui, sans-serif',
            fontSize: 24,
            fontWeight: 700,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: accent,
            marginBottom: 12,
          }}
        >
          {eyebrow}
        </div>
      ) : null}
      {metric ? (
        <div
          style={{
            fontFamily: 'Inter, system-ui, sans-serif',
            fontSize: 104,
            fontWeight: 900,
            lineHeight: 1.0,
            letterSpacing: '-0.03em',
            color: '#F8FAFC',
            textShadow: `0 0 32px ${accent}66`,
            marginBottom: 16,
          }}
        >
          {metric}
          {unit ? <span style={{fontSize: 60, color: accent, marginLeft: 12}}>{unit}</span> : null}
        </div>
      ) : null}
      <div
        style={{
          fontFamily: variant === 'editorial-serif' ? 'Georgia, serif' : 'Inter, system-ui, sans-serif',
          fontSize: 42,
          fontWeight: 800,
          lineHeight: 1.18,
          color: '#F8FAFC',
          marginBottom: subcopy ? 12 : 0,
        }}
      >
        {headline}
      </div>
      {subcopy ? (
        <div
          style={{
            fontFamily: 'Inter, system-ui, sans-serif',
            fontSize: 28,
            fontWeight: 500,
            lineHeight: 1.38,
            color: '#CBD5E1',
          }}
        >
          {subcopy}
        </div>
      ) : null}
    </div>
  );
};
export default KineticTypographyStage;
