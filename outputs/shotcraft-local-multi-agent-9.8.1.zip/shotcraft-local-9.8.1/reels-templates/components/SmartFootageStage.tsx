import React from 'react';
import {AbsoluteFill, OffthreadVideo, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export interface SmartFootageStageProps {
  videoSrc: string;
  startFromFrame?: number;
  punchInZoom?: number;
  caption?: string;
  accent?: string;
}

export const SmartFootageStage: React.FC<SmartFootageStageProps> = ({
  videoSrc,
  startFromFrame = 0,
  punchInZoom = 1.12,
  caption,
  accent = '#38BDF8',
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 18, stiffness: 120}});
  const zoom = 1 + (punchInZoom - 1) * s;

  return (
    <AbsoluteFill style={{backgroundColor: '#070B14', overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `scale(${zoom.toFixed(3)})`}}>
        <OffthreadVideo src={videoSrc} startFrom={startFromFrame} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
      </AbsoluteFill>
      {caption ? (
        <div
          style={{
            position: 'absolute',
            left: 84,
            right: 84,
            bottom: 280,
            backgroundColor: 'rgba(15, 23, 42, 0.92)',
            border: `2px solid ${accent}`,
            borderRadius: 28,
            padding: '28px 36px',
            color: '#F8FAFC',
            fontFamily: 'Inter, sans-serif',
            fontSize: 40,
            fontWeight: 800,
            textAlign: 'center',
          }}
        >
          {caption}
        </div>
      ) : null}
    </AbsoluteFill>
  );
};
export default SmartFootageStage;
