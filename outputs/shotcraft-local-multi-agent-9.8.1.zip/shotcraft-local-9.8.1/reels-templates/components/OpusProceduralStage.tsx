import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';

export type OpusVisualMode =
  | 'neural-network'
  | 'node-network'
  | 'energy-waves'
  | 'wave-interference'
  | 'speed-pulse'
  | 'supercomputer-core'
  | '3d-isometric-growth'
  | 'stress-heatmap'
  | 'audio-reactive-rings'
  | 'deconstructed-ui'
  | 'dual-device-showreel'
  | 'cutaway-turbofan';

export interface OpusProceduralStageProps {
  mode: OpusVisualMode;
  accent?: string;
  secondaryAccent?: string;
  label?: string;
}

export const OpusProceduralStage: React.FC<OpusProceduralStageProps> = ({
  mode,
  accent = '#38BDF8',
  secondaryAccent = '#A855F7',
  label = 'OPUS 5.5 ENGINE',
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 100}});

  if (mode === 'neural-network' || mode === 'node-network') {
    const nodes = Array.from({length: 12}, (_, i) => {
      const angle = (i / 12) * Math.PI * 2 + t * 0.35;
      const rad = (i % 2 === 0 ? 185 : 112) * enter;
      return {
        x: 450 + Math.cos(angle) * rad,
        y: 310 + Math.sin(angle) * rad,
        r: i % 3 === 0 ? 14 : 9,
      };
    });
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        {nodes.map((n, i) => {
          const next = nodes[(i + 1) % nodes.length];
          const opp = nodes[(i + 5) % nodes.length];
          const pulseU = (t * 0.9 + i * 0.17) % 1;
          return (
            <g key={i}>
              <line x1={n.x} y1={n.y} x2={next.x} y2={next.y} stroke={accent} strokeOpacity={0.35} strokeWidth={2.5} />
              <line x1={n.x} y1={n.y} x2={opp.x} y2={opp.y} stroke="#94A3B8" strokeOpacity={0.18} strokeWidth={1.5} />
              <circle
                cx={n.x + (next.x - n.x) * pulseU}
                cy={n.y + (next.y - n.y) * pulseU}
                r={5.5}
                fill={accent}
              />
              <circle cx={n.x} cy={n.y} r={n.r * 1.8} fill={accent} fillOpacity={0.15} />
              <circle cx={n.x} cy={n.y} r={n.r} fill="#F8FAFC" stroke={accent} strokeWidth={3} />
            </g>
          );
        })}
        <circle cx={450} cy={310} r={38 * enter} fill={accent} fillOpacity={0.22} stroke={accent} strokeWidth={4} />
      </svg>
    );
  }

  if (mode === 'energy-waves' || mode === 'wave-interference' || mode === 'audio-reactive-rings') {
    const bars = 32;
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        {Array.from({length: bars}, (_, i) => {
          const angle = (i / bars) * Math.PI * 2 + t * 0.4;
          const len = 35 + (Math.sin(t * 6 + i * 0.5) * 0.5 + 0.5) * 80 * enter;
          const x1 = 450 + Math.cos(angle) * 120;
          const y1 = 310 + Math.sin(angle) * 120;
          const x2 = 450 + Math.cos(angle) * (120 + len);
          const y2 = 310 + Math.sin(angle) * (120 + len);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={i % 2 === 0 ? accent : secondaryAccent} strokeWidth={8} strokeLinecap="round" />;
        })}
        <circle cx={450} cy={310} r={96 * enter} fill="none" stroke={accent} strokeWidth={4} strokeOpacity={0.65} />
        <circle cx={450} cy={310} r={(56 + Math.sin(t * 5) * 12) * enter} fill={accent} fillOpacity={0.18} />
      </svg>
    );
  }

  if (mode === 'speed-pulse' || mode === 'stress-heatmap') {
    const pts = Array.from({length: 64}, (_, i) => {
      const u = i / 63;
      const x = 60 + u * 780;
      const y = 310 + Math.sin(u * Math.PI * 4 - t * 8) * 115 * enter;
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        <path d={pts} fill="none" stroke={accent} strokeWidth={9} strokeLinecap="round" />
      </svg>
    );
  }

  if (mode === 'deconstructed-ui' || mode === 'dual-device-showreel') {
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        <rect x={110} y={80} width={500 * enter} height={340} rx={24} fill="#0F172A" stroke={accent} strokeWidth={3} />
        <circle cx={145} cy={115} r={7} fill="#EF4444" />
        <circle cx={170} cy={115} r={7} fill="#F59E0B" />
        <circle cx={195} cy={115} r={7} fill="#10B981" />
        <rect x={540} y={150} width={250 * enter} height={410} rx={32} fill="#1E293B" stroke={secondaryAccent} strokeWidth={3.5} />
        <text x={150} y={240} fill="#F8FAFC" fontSize={28} fontWeight={800} fontFamily="Inter, sans-serif">
          {label}
        </text>
      </svg>
    );
  }

  if (mode === 'cutaway-turbofan') {
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        {[0, 1, 2, 3].map((stage) => {
          const x = 160 + stage * 175 * enter;
          const col = stage < 2 ? '#38BDF8' : '#F97316';
          return (
            <g key={stage}>
              <rect x={x} y={170} width={120} height={280} rx={18} fill="rgba(15,23,42,0.88)" stroke={col} strokeWidth={3.5} />
              <circle cx={x + 60} cy={310} r={38} fill="none" stroke={col} strokeWidth={3} strokeDasharray="10 8" />
            </g>
          );
        })}
      </svg>
    );
  }

  return (
    <svg width={900} height={620} viewBox="0 0 900 620">
      {[0, 1, 2, 3].map((idx) => {
        const s = spring({frame: frame - idx * 4, fps, config: {damping: 14, stiffness: 110}});
        const sz = (210 - idx * 28) * s;
        const y0 = 380 - idx * 55 * s;
        const poly = `450,${y0 - sz * 0.5} ${450 + sz},${y0} 450,${y0 + sz * 0.5} ${450 - sz},${y0}`;
        return <polygon key={idx} points={poly} fill="rgba(15,23,42,0.9)" stroke={accent} strokeWidth={4} />;
      })}
    </svg>
  );
};
export default OpusProceduralStage;
