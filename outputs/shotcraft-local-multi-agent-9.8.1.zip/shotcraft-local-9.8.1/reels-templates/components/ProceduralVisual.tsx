import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeFiberStage} from './ThreeFiberStage';

export interface ProceduralVisualProps {
  mode: string;
  accent: string;
  audioPulse?: number;
}

export const ProceduralVisual: React.FC<ProceduralVisualProps> = ({mode, accent, audioPulse = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / Math.max(1, fps);
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 100}}) * (1 + audioPulse * 0.15);

  if (mode === 'neural-network') {
    return <ThreeFiberStage mode={mode} accent={accent} cameraPreset="orbit" audioPulse={audioPulse} />;
  }

  if (mode === 'energy-waves') {
    const bars = 32;
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        {Array.from({length: bars}, (_, i) => {
          const angle = (i / bars) * Math.PI * 2 + t * 0.4;
          const len = 35 + (Math.sin(t * 6 + i * 0.5) * 0.5 + 0.5) * 78 * enter;
          const x1 = 450 + Math.cos(angle) * 120;
          const y1 = 310 + Math.sin(angle) * 120;
          const x2 = 450 + Math.cos(angle) * (120 + len);
          const y2 = 310 + Math.sin(angle) * (120 + len);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={accent} strokeWidth={8} strokeLinecap="round" />;
        })}
        <circle cx={450} cy={310} r={96 * enter} fill="none" stroke={accent} strokeWidth={4} strokeOpacity={0.7} />
      </svg>
    );
  }

  if (mode === 'speed-pulse') {
    const pts = Array.from({length: 60}, (_, i) => {
      const u = i / 59;
      const x = 60 + u * 780;
      const y = 310 + Math.sin(u * Math.PI * 4 - t * 8) * 110 * enter;
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
    return (
      <svg width={900} height={620} viewBox="0 0 900 620">
        <path d={pts} fill="none" stroke={accent} strokeWidth={8} strokeLinecap="round" />
      </svg>
    );
  }

  return (
    <svg width={900} height={620} viewBox="0 0 900 620">
      {[0, 1, 2, 3].map((idx) => {
        const s = spring({frame: frame - idx * 4, fps, config: {damping: 14, stiffness: 110}});
        const sz = (210 - idx * 28) * s;
        const y0 = 380 - idx * 55 * s;
        const poly = `450,${y0 - sz * 0.5} ${450 + sz},${y0} 450,${y0 + sz * 0.5} ${450 - sz},${y0}`;
        return <polygon key={idx} points={poly} fill="rgba(15,23,42,0.9)" stroke={accent} strokeWidth={4} />;
      })}
    </svg>
  );
};

export default ProceduralVisual;
