import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {
  CaptionStyleKind,
  SemanticAnimatedSubtitle,
  SpeakerRole,
  WordAnimationConfig,
} from './ReferenceShowreelStage';

export interface EditorialCalloutSpec {
  label: string;
  tx: number;
  ty: number;
  px: number;
  py: number;
}

export interface EditorialCutawaySceneSpec {
  id: string;
  eyebrow: string;
  stateBadge?: string;
  headline: string;
  metric: string;
  unit: string;
  subcopy: string;
  narration?: string;
  cutawayKind?: 'engine' | 'brain' | 'coffee';
  evidenceCardKind?: 'bars' | 'quote' | 'checklist';
  windowTitle?: string;
  windowContentLines?: string[];
  callouts?: EditorialCalloutSpec[];
  captionStyle?: CaptionStyleKind;
  emphasisWords?: string[];
  wordAnimations?: WordAnimationConfig[];
  speaker?: SpeakerRole;
  y_center?: number;
  bottom3DOccupied?: boolean;
  captionEmoji?: string;
  accent?: string;
  durationInFrames: number;
}

export const EditorialCutawayStage: React.FC<{
  scene: EditorialCutawaySceneSpec;
  badge?: string;
}> = ({scene, badge = 'SHOTCRAFT PRO'}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const t = frame / Math.max(1, fps);
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 120}});

  const cutawayKind = scene.cutawayKind || 'engine';
  const isCoffee = cutawayKind === 'coffee';
  const bgColor = isCoffee ? '#F6EFE4' : '#F2EDE0';
  const primaryGreen = isCoffee ? '#92400E' : '#1D7A46';
  const accent = scene.accent || primaryGreen;
  const cardKind = scene.evidenceCardKind || 'bars';

  const ctxLines =
    scene.windowContentLines && scene.windowContentLines.length >= 2
      ? scene.windowContentLines
      : [
          `Metrik Utama: ${scene.metric} ${scene.unit}`.trim(),
          `Inti: ${scene.headline.slice(0, 48)}`,
          `Detail: ${scene.subcopy.slice(0, 52)}`,
          'Status: Terverifikasi & Aktif',
        ];

  const subtitleWords = React.useMemo(
    () =>
      (scene.narration || scene.subcopy || scene.headline)
        .replace(/<[^>]+>/g, ' ')
        .split(/\s+/)
        .filter(Boolean),
    [scene.narration, scene.subcopy, scene.headline]
  );

  const pistonOffset = Math.sin(t * 14) * 34;

  return (
    <AbsoluteFill
      style={{
        backgroundColor: bgColor,
        padding: '220px 84px 180px 84px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      {/* Top Editorial Header & Headline */}
      <div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 20,
            fontWeight: 800,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: isCoffee ? '#6C5C4C' : '#625E54',
            marginBottom: 8,
          }}
        >
          {scene.eyebrow || badge}
        </div>
        <div
          style={{
            fontFamily: isCoffee ? 'Georgia, serif' : 'Inter, sans-serif',
            fontSize: 40,
            fontWeight: 900,
            lineHeight: 1.18,
            color: isCoffee ? '#261810' : '#1C1B18',
            marginBottom: 14,
          }}
        >
          {scene.headline}
        </div>
        <div
          style={{
            display: 'inline-block',
            backgroundColor: accent,
            color: '#FFFFFF',
            borderRadius: 999,
            padding: '7px 20px',
            fontFamily: 'Inter, sans-serif',
            fontSize: 19,
            fontWeight: 800,
            letterSpacing: '0.05em',
            textTransform: 'uppercase',
          }}
        >
          {scene.stateBadge || scene.windowTitle || 'BEDAH MEKANISME 3D'}
        </div>
      </div>

      {/* Middle Evidence Card (Bars / Quote / Checklist) */}
      <div
        style={{
          backgroundColor: '#FFFFFF',
          border: '3px solid #E0D9CA',
          borderRadius: 24,
          padding: '22px 28px',
          boxShadow: '4px 8px 0 rgba(205, 198, 182, 0.65)',
          transform: `translateY(${((1 - enter) * 22).toFixed(1)}px)`,
        }}
      >
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 18,
            fontWeight: 800,
            color: '#656157',
            textTransform: 'uppercase',
            marginBottom: 14,
          }}
        >
          {scene.windowTitle || `DATA TERUKUR — ${badge}`}
        </div>

        {cardKind === 'bars' ? (
          <div style={{display: 'flex', flexDirection: 'column', gap: 14}}>
            {ctxLines.slice(0, 2).map((rowTxt, rIdx) => {
              const parts = rowTxt.split(':');
              const lbl = parts[0]?.trim() || `Data #${rIdx + 1}`;
              const val = parts.slice(1).join(':').trim() || rowTxt;
              const widthPct = rIdx === 0 ? 92 * enter : 34 * enter;
              return (
                <div key={rIdx} style={{display: 'flex', alignItems: 'center', gap: 16}}>
                  <div
                    style={{
                      width: 210,
                      fontFamily: isCoffee ? 'Georgia, serif' : 'Inter, sans-serif',
                      fontSize: 22,
                      fontWeight: 800,
                      color: '#1C1B18',
                    }}
                  >
                    {lbl}
                  </div>
                  <div style={{flex: 1, backgroundColor: '#F3EFE6', borderRadius: 10, height: 44, position: 'relative'}}>
                    <div
                      style={{
                        width: `${Math.max(18, widthPct)}%`,
                        height: '100%',
                        borderRadius: 10,
                        backgroundColor: rIdx === 0 ? '#D6CEBE' : '#EAB308',
                        display: 'flex',
                        alignItems: 'center',
                        paddingLeft: 14,
                        fontFamily: 'Inter, sans-serif',
                        fontSize: 20,
                        fontWeight: 800,
                        color: '#1C1B18',
                      }}
                    >
                      {val}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : cardKind === 'quote' ? (
          <div>
            <div
              style={{
                fontFamily: isCoffee ? 'Georgia, serif' : 'Inter, sans-serif',
                fontSize: 44,
                fontWeight: 900,
                color: primaryGreen,
                marginBottom: 8,
              }}
            >
              {scene.metric} {scene.unit}
            </div>
            <div
              style={{
                fontFamily: isCoffee ? 'Georgia, serif' : 'Inter, sans-serif',
                fontSize: 23,
                fontWeight: 700,
                color: '#1C1B18',
                lineHeight: 1.32,
              }}
            >
              “{ctxLines[0]}”
            </div>
          </div>
        ) : (
          <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
            {ctxLines.slice(0, 3).map((rowTxt, rIdx) => {
              const parts = rowTxt.split(':');
              return (
                <div
                  key={rIdx}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    paddingBottom: 8,
                    borderBottom: rIdx < 2 ? '2px solid #E7E2D6' : undefined,
                  }}
                >
                  <span style={{fontFamily: 'Inter, sans-serif', fontSize: 22, fontWeight: 800, color: '#1C1B18'}}>
                    {parts[0]?.trim()}
                  </span>
                  <span style={{fontFamily: 'Inter, sans-serif', fontSize: 22, fontWeight: 800, color: primaryGreen}}>
                    ✓ {parts.slice(1).join(':').trim() || rowTxt}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 3D Cutaway Visual Stage (Engine / Coffee / Brain) */}
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative'}}>
        {cutawayKind === 'coffee' ? (
          <svg width={760} height={300} viewBox="0 0 760 300">
            <ellipse cx={380} cy={240} rx={190} ry={34} fill="#D6C6B2" stroke="#FFFFFF" strokeWidth={3} />
            <rect x={245} y={90} width={270} height={140} rx={36} fill="#78350F" stroke="#FEF3C7" strokeWidth={3} />
            <ellipse cx={380} cy={95} rx={125} ry={34} fill="#C26A1C" stroke="#F5EBDA" strokeWidth={4} />
            <ellipse cx={380} cy={95} rx={75} ry={20} fill="#D9842D" />
          </svg>
        ) : cutawayKind === 'brain' ? (
          <svg width={760} height={300} viewBox="0 0 760 300">
            <rect x={60} y={20} width={640} height={240} rx={44} fill="#12192A" stroke="#38BDF8" strokeWidth={4} />
            <circle cx={380} cy={140} r={54 * enter} fill="#38BDF8" fillOpacity={0.35} stroke="#E0F2FE" strokeWidth={4} />
            {[-190, -110, 110, 190].map((dx, i) => (
              <g key={i}>
                <line x1={380} y1={140} x2={380 + dx} y2={70 + (i % 2) * 140} stroke="#38BDF8" strokeWidth={6} />
                <circle cx={380 + dx} cy={70 + (i % 2) * 140} r={16} fill="#FACC15" stroke="#FFFFFF" strokeWidth={3} />
              </g>
            ))}
          </svg>
        ) : (
          <svg width={760} height={300} viewBox="0 0 760 300">
            <rect x={80} y={30} width={290} height={220} rx={20} fill="#334155" stroke="#1E293B" strokeWidth={4} />
            <rect x={370} y={60} width={290} height={150} rx={14} fill="#263040" stroke="#1E293B" strokeWidth={3} />
            <rect x={95} y={165} width={260} height={70} rx={10} fill="#B45309" />
            <circle cx={210} cy={130} r={46} fill="#64748B" stroke="#E2E8F0" strokeWidth={4} />
            <line
              x1={210 + Math.cos(t * 14) * 22}
              y1={130 + Math.sin(t * 14) * 22}
              x2={450 + pistonOffset}
              y2={130}
              stroke="#94A3B8"
              strokeWidth={14}
              strokeLinecap="round"
            />
            <rect x={420 + pistonOffset} y={88} width={76} height={84} rx={10} fill="#CBD5E1" stroke="#F8FAFC" strokeWidth={3} />
            <circle cx={525 + pistonOffset} cy={130} r={22} fill="#EA580C" />
          </svg>
        )}
      </div>

      {/* Bottom Semantic Animated Subtitles */}
      <SemanticAnimatedSubtitle
        scene={{
          id: scene.id,
          styleMode: 'ref1-tutorial-deck',
          stepBadge: scene.eyebrow,
          headlineTop: scene.headline,
          headlineAccent: `${scene.metric} ${scene.unit}`.trim(),
          subtitleWords,
          captionStyle: scene.captionStyle || 'karaoke-pill',
          emphasisWords: scene.emphasisWords,
          wordAnimations: scene.wordAnimations,
          speaker: scene.speaker,
          y_center: scene.y_center,
          bottom3DOccupied: scene.bottom3DOccupied,
          captionEmoji: scene.captionEmoji,
          accent: '#FACC15',
          durationInFrames,
        }}
        accent="#FACC15"
      />
    </AbsoluteFill>
  );
};

export default EditorialCutawayStage;
