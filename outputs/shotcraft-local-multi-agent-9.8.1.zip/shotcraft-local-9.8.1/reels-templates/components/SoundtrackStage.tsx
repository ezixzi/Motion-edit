import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';

/**
 * Official `@remotion/sfx` studio-recorded CDN URLs (`https://remotion.media/*.wav`)
 * Works directly inside Remotion `<Audio src={REMOTION_CDN_SFX.whoosh} />` when online!
 */
export const REMOTION_CDN_SFX = {
  whoosh: 'https://remotion.media/whoosh.wav',
  whip: 'https://remotion.media/whip.wav',
  pageTurn: 'https://remotion.media/page-turn.wav',
  uiSwitch: 'https://remotion.media/switch.wav',
  mouseClick: 'https://remotion.media/mouse-click.wav',
  shutterModern: 'https://remotion.media/shutter-modern.wav',
  shutterOld: 'https://remotion.media/shutter-old.wav',
  ding: 'https://remotion.media/ding.wav',
  bruh: 'https://remotion.media/bruh.wav',
  vineBoom: 'https://remotion.media/vine-boom.wav',
  windowsXpError: 'https://remotion.media/windows-xp-error.wav',
} as const;

export type UISFXPack =
  | 'minimal'
  | 'soft'
  | 'glass'
  | 'arcade'
  | 'mechanical'
  | 'organic'
  | 'dreamy'
  | 'scifi'
  | 'rubber'
  | 'cinematic'
  | 'studio'
  | 'zen';

export type SemanticSfxCue =
  | 'hover'
  | 'press'
  | 'release'
  | 'select'
  | 'check'
  | 'open'
  | 'close'
  | 'swipe'
  | 'whip'
  | 'whoosh'
  | 'snap'
  | 'drop'
  | 'typing'
  | 'notification'
  | 'success'
  | 'complete'
  | 'progress-step'
  | 'checkpoint'
  | 'level-up'
  | 'badge'
  | 'reward'
  | 'pageTurn'
  | 'uiSwitch'
  | 'mouseClick'
  | 'shutterModern'
  | 'ding'
  | 'vineBoom';

export const SEMANTIC_TO_LOCAL_WAV: Record<SemanticSfxCue, string> = {
  hover: 'audio/sfx/text/type-key.wav',
  press: 'audio/sfx/ui/tactile-click.wav',
  release: 'audio/sfx/ui/toggle-pop.wav',
  select: 'audio/sfx/ui/toggle-pop.wav',
  check: 'audio/sfx/ui/toggle-pop.wav',
  open: 'audio/sfx/paper/page-slide.wav',
  close: 'audio/sfx/paper/card-deal.wav',
  swipe: 'audio/sfx/transition/whoosh-soft.wav',
  whip: 'audio/sfx/transition/whip-fast.wav',
  whoosh: 'audio/sfx/transition/whoosh-soft.wav',
  snap: 'audio/sfx/mech/servo-lock.wav',
  drop: 'audio/sfx/impact/sub-hit.wav',
  typing: 'audio/sfx/text/type-key.wav',
  notification: 'audio/sfx/light/sparkle-chime.wav',
  success: 'audio/sfx/counter/metric-land.wav',
  complete: 'audio/sfx/counter/metric-land.wav',
  'progress-step': 'audio/sfx/ui/toggle-pop.wav',
  checkpoint: 'audio/sfx/data/chart-lock.wav',
  'level-up': 'audio/sfx/glass/crystal-ping.wav',
  badge: 'audio/sfx/counter/metric-land.wav',
  reward: 'audio/sfx/light/sparkle-chime.wav',
  pageTurn: 'audio/sfx/paper/page-slide.wav',
  uiSwitch: 'audio/sfx/ui/toggle-pop.wav',
  mouseClick: 'audio/sfx/ui/tactile-click.wav',
  shutterModern: 'audio/sfx/camera/shutter-clean.wav',
  ding: 'audio/sfx/glass/crystal-ping.wav',
  vineBoom: 'audio/sfx/impact/cinematic-slam.wav',
};

export const SEMANTIC_TO_REMOTION_CDN: Partial<Record<SemanticSfxCue, string>> = {
  swipe: REMOTION_CDN_SFX.whoosh,
  whoosh: REMOTION_CDN_SFX.whoosh,
  whip: REMOTION_CDN_SFX.whip,
  open: REMOTION_CDN_SFX.pageTurn,
  pageTurn: REMOTION_CDN_SFX.pageTurn,
  select: REMOTION_CDN_SFX.uiSwitch,
  check: REMOTION_CDN_SFX.uiSwitch,
  'progress-step': REMOTION_CDN_SFX.uiSwitch,
  uiSwitch: REMOTION_CDN_SFX.uiSwitch,
  press: REMOTION_CDN_SFX.mouseClick,
  mouseClick: REMOTION_CDN_SFX.mouseClick,
  shutterModern: REMOTION_CDN_SFX.shutterModern,
  complete: REMOTION_CDN_SFX.ding,
  success: REMOTION_CDN_SFX.ding,
  badge: REMOTION_CDN_SFX.ding,
  ding: REMOTION_CDN_SFX.ding,
  drop: REMOTION_CDN_SFX.vineBoom,
  vineBoom: REMOTION_CDN_SFX.vineBoom,
};

export type BgmPresetTrack =
  | 'audio/bgm/lofi-study-chill-84bpm.wav'
  | 'audio/bgm/ambient-dreamscape-72bpm.wav'
  | 'audio/bgm/kinetic-120bpm.wav'
  | 'audio/bgm/cyber-pulse-128bpm.wav'
  | 'audio/bgm/warm-editorial-96bpm.wav'
  | 'audio/bgm/suspense-tech-110bpm.wav';

export interface SfxCueItem {
  id: string;
  frame: number;
  cue?: SemanticSfxCue;
  sfxFile?: string;
  remoteUrl?: string;
  volume?: number;
}

export interface SoundtrackStageProps {
  narrationFile?: string;
  bgmFile?: BgmPresetTrack | string;
  bgmVolume?: number;
  pack?: UISFXPack;
  useOnlineRemotionSfx?: boolean;
  sfxCues?: SfxCueItem[];
}

export const SoundtrackStage: React.FC<SoundtrackStageProps> = ({
  narrationFile,
  bgmFile = 'audio/bgm/lofi-study-chill-84bpm.wav',
  bgmVolume = 0.22,
  useOnlineRemotionSfx = false,
  sfxCues = [],
}) => {
  const resolveSrc = (pathOrUrl: string) =>
    pathOrUrl.startsWith('http://') || pathOrUrl.startsWith('https://') ? pathOrUrl : staticFile(pathOrUrl);

  return (
    <>
      {bgmFile ? <Audio src={resolveSrc(bgmFile)} volume={bgmVolume} loop /> : null}
      {narrationFile ? <Audio src={resolveSrc(narrationFile)} volume={1.0} /> : null}
      {sfxCues.map((item) => {
        const cdnUrl = useOnlineRemotionSfx && item.cue ? SEMANTIC_TO_REMOTION_CDN[item.cue] : undefined;
        const resolved =
          item.remoteUrl ||
          cdnUrl ||
          item.sfxFile ||
          (item.cue ? SEMANTIC_TO_LOCAL_WAV[item.cue] : 'audio/sfx/ui/toggle-pop.wav');
        return (
          <Sequence key={item.id} from={item.frame}>
            <Audio src={resolveSrc(resolved)} volume={item.volume ?? 0.55} />
          </Sequence>
        );
      })}
    </>
  );
};
export default SoundtrackStage;
