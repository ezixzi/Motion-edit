import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export interface ParallaxPin {
  id: string;
  label: string;
  xPercent: number;
  yPercent: number;
  depth01?: number;
  appearFrame?: number;
}

export interface DepthParallaxStageProps {
  backgroundSrc: string;
  midgroundSrc?: string;
  foregroundSrc?: string;
  accent?: string;
  camXAmplitude?: number;
  camYAmplitude?: number;
  pins?: ParallaxPin[];
}

export const DepthParallaxStage: React.FC<DepthParallaxStageProps> = ({
  backgroundSrc,
  midgroundSrc,
  foregroundSrc,
  accent = '#38BDF8',
  camXAmplitude = 22,
  camYAmplitude = 12,
  pins = [],
}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const u = frame / Math.max(1, durationInFrames - 1);
  const camX = Math.sin(u * Math.PI * 2) * camXAmplitude;
  const camY = Math.cos(u * Math.PI * 2) * camYAmplitude;
  const baseScale = interpolate(u, [0, 1], [1.06, 1.12]);

  const layerStyle = (depth01: number, blurPx: number): React.CSSProperties => {
    const rel = depth01 - 0.5;
    return {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      transform: `translate3d(${(-camX * rel).toFixed(1)}px, ${(-camY * rel).toFixed(1)}px, 0) scale(${(baseScale + rel * 0.04).toFixed(3)})`,
      filter: blurPx > 0.2 ? `blur(${blurPx.toFixed(1)}px)` : undefined,
    };
  };

  return (
    <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#070B14'}}>
      <AbsoluteFill>
        <Img src={backgroundSrc} style={layerStyle(0.15, 2.5)} />
      </AbsoluteFill>
      {midgroundSrc ? (
        <AbsoluteFill>
          <Img src={midgroundSrc} style={layerStyle(0.52, 0.5)} />
        </AbsoluteFill>
      ) : null}
      {foregroundSrc ? (
        <AbsoluteFill>
          <Img src={foregroundSrc} style={layerStyle(0.88, 0)} />
        </AbsoluteFill>
      ) : null}
      {pins.map((pin) => {
        const s = spring({frame: frame - (pin.appearFrame ?? 8), fps, config: {damping: 15, stiffness: 140}});
        const d = pin.depth01 ?? 0.75;
        const rel = d - 0.5;
        return (
          <div
            key={pin.id}
            style={{
              position: 'absolute',
              left: `${pin.xPercent}%`,
              top: `${pin.yPercent}%`,
              transform: `translate3d(${(-camX * rel).toFixed(1)}px, ${(-camY * rel).toFixed(1)}px, 0) scale(${s.toFixed(3)})`,
              backgroundColor: 'rgba(15,23,42,0.92)',
              border: `2px solid ${accent}`,
              borderRadius: 999,
              padding: '10px 22px',
              color: '#F8FAFC',
              fontFamily: 'Inter, sans-serif',
              fontSize: 24,
              fontWeight: 800,
            }}
          >
            {pin.label}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
export default DepthParallaxStage;
