import React from 'react';
import {SoundtrackStage, SfxCueItem} from './SoundtrackStage';

export interface SoundtrackProps {
  cues: SfxCueItem[];
  bgmTrack?: string;
  useOnlineRemotionSfx?: boolean;
}

export const Soundtrack: React.FC<SoundtrackProps> = ({
  cues,
  bgmTrack = 'audio/bgm/explainer-groove-104bpm.wav',
  useOnlineRemotionSfx = false,
}) => {
  return <SoundtrackStage bgmFile={bgmTrack} useOnlineRemotionSfx={useOnlineRemotionSfx} sfxCues={cues} />;
};

export default Soundtrack;
