import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export type ReferenceStyleMode =
  | 'ref1-tutorial-deck'
  | 'ref2-floating-glass'
  | 'ref3-pricing-voxel'
  | 'ref4-tape-mascot';

export type CaptionStyleKind =
  | 'karaoke-pill'
  | 'typewriter'
  | 'slide-up'
  | 'glitch'
  | 'handwritten'
  | 'neon'
  | 'minimal';

export type SpeakerRole = 'narrator' | 'expert' | 'user' | 'host' | 'guest';

export interface WordAnimationConfig {
  word: string;
  animation: 'scale-bounce' | 'pop-rotate' | 'glow-pulse' | 'slide-up';
  intensity?: number;
}

export interface ReferenceSceneSpec {
  id: string;
  styleMode: ReferenceStyleMode;
  stepBadge: string;
  headlineTop: string;
  headlineAccent: string;
  windowTitle?: string;
  windowContentLines?: string[];
  highlightBadge?: string;
  stickerText?: string;
  subtitleWords: string[];
  captionStyle?: CaptionStyleKind;
  emphasisWords?: string[];
  wordAnimations?: WordAnimationConfig[];
  speaker?: SpeakerRole;
  y_center?: number;
  bottom3DOccupied?: boolean;
  captionEmoji?: string;
  accent?: string;
  durationInFrames: number;
}

const COMPOUND_PAIRS = new Set([
  'tidak:boleh',
  'tidak:bisa',
  'tidak:perlu',
  'jangan:pernah',
  'jangan:sampai',
  'jangan:digeber',
  'sama:sekali',
  'lebih:dari',
  'kurang:dari',
  'di:dalam',
  'di:atas',
  'ke:atas',
  'bukan:cuma',
]);

const METRIC_UNITS = new Set([
  'miliar',
  'juta',
  'ribu',
  'triliun',
  'persen',
  '%',
  '°c',
  'celcius',
  'km/jam',
  'watt',
  'menit',
  'detik',
  'jam',
  'gram',
  'ml',
  'kali',
  'x',
  'rupiah',
]);

const SPEAKER_COLORS: Record<SpeakerRole, {label: string; color: string}> = {
  narrator: {label: 'NARATOR', color: '#38BDF8'},
  expert: {label: 'EXPERT', color: '#F59E0B'},
  user: {label: 'USER', color: '#10B981'},
  host: {label: 'HOST', color: '#A855F7'},
  guest: {label: 'GUEST', color: '#EC4899'},
};

/**
 * Section 2.2: Semantic Caption Grouping
 * Groups words into phrase-aware chunks so compound negations ("tidak boleh")
 * and metric pairs ("86 MILIAR") are never split across subtitle rows.
 */
export function groupWordsSemantically(
  words: string[],
  maxWordsPerRow = 3
): Array<Array<{index: number; word: string}>> {
  const units: Array<Array<{index: number; word: string}>> = [];
  let i = 0;
  while (i < words.length) {
    const wCur = words[i];
    const cleanCur = wCur.toLowerCase().replace(/[^\w%/°]/g, '');
    if (i + 1 < words.length) {
      const wNext = words[i + 1];
      const cleanNext = wNext.toLowerCase().replace(/[^\w%/°]/g, '');
      const isCompound = COMPOUND_PAIRS.has(`${cleanCur}:${cleanNext}`);
      const isNumUnit = /\d/.test(wCur) && METRIC_UNITS.has(cleanNext);
      if ((isCompound || isNumUnit) && !/[,.;:!?]$/.test(wCur)) {
        units.push([
          {index: i, word: wCur},
          {index: i + 1, word: wNext},
        ]);
        i += 2;
        continue;
      }
    }
    units.push([{index: i, word: wCur}]);
    i += 1;
  }

  const rows: Array<Array<{index: number; word: string}>> = [];
  let curRow: Array<{index: number; word: string}> = [];
  for (const unit of units) {
    if (curRow.length + unit.length > maxWordsPerRow && curRow.length > 0) {
      rows.push(curRow);
      curRow = [...unit];
    } else {
      curRow.push(...unit);
    }
    const lastWord = curRow[curRow.length - 1]?.word || '';
    if (/[,.;:!?]$/.test(lastWord) && curRow.length >= 2) {
      rows.push(curRow);
      curRow = [];
    }
  }
  if (curRow.length > 0) {
    rows.push(curRow);
  }
  return rows;
}

/**
 * Sections 2.1 - 2.6: Unified Semantic & Animated Subtitle Renderer for Remotion
 */
export const SemanticAnimatedSubtitle: React.FC<{
  scene: ReferenceSceneSpec;
  accent: string;
}> = ({scene, accent}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const words = React.useMemo(() => {
    const base = [...(scene.subtitleWords || [])];
    if (scene.captionEmoji && !base.includes(scene.captionEmoji)) {
      base.unshift(scene.captionEmoji);
    }
    return base;
  }, [scene.subtitleWords, scene.captionEmoji]);

  if (words.length === 0) return null;

  const exactWordPos = (frame / Math.max(1, durationInFrames)) * words.length;
  const activeWordIdx = Math.min(words.length - 1, Math.floor(exactWordPos));
  const wordSubProg = exactWordPos - activeWordIdx;

  const rows = React.useMemo(() => groupWordsSemantically(words, 3), [words]);
  const activeRowIdx = Math.max(
    0,
    rows.findIndex((r) => r.some((item) => item.index === activeWordIdx))
  );
  const winStart = Math.floor(activeRowIdx / 2) * 2;
  const visibleRows = rows.slice(winStart, winStart + 2);

  const emphasisSet = React.useMemo(() => {
    const s = new Set<string>();
    (scene.emphasisWords || []).forEach((w) =>
      s.add(w.toLowerCase().replace(/[^\w]/g, ''))
    );
    return s;
  }, [scene.emphasisWords]);

  const animLookup = React.useMemo(() => {
    const map: Record<string, WordAnimationConfig> = {};
    (scene.wordAnimations || []).forEach((wa) => {
      map[wa.word.toLowerCase().replace(/[^\w]/g, '')] = wa;
    });
    return map;
  }, [scene.wordAnimations]);

  const captionStyle: CaptionStyleKind = scene.captionStyle || 'karaoke-pill';
  const speakerInfo = scene.speaker ? SPEAKER_COLORS[scene.speaker] : null;
  const bottomShift = scene.bottom3DOccupied ? 90 : 0;

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 10,
        marginTop: 18,
        transform: bottomShift ? `translateY(-${bottomShift}px)` : undefined,
      }}
    >
      {speakerInfo ? (
        <div
          style={{
            backgroundColor: speakerInfo.color,
            color: '#090D16',
            padding: '4px 16px',
            borderRadius: 999,
            fontFamily: 'Inter, sans-serif',
            fontSize: 18,
            fontWeight: 900,
            letterSpacing: '0.08em',
          }}
        >
          {speakerInfo.label}:
        </div>
      ) : null}

      {captionStyle === 'minimal' ? (
        <div
          style={{
            backgroundColor: 'rgba(10, 14, 24, 0.76)',
            padding: '10px 28px',
            borderRadius: 14,
            color: '#F8FAFC',
            fontFamily: 'Inter, sans-serif',
            fontSize: 38,
            fontWeight: 800,
            opacity: interpolate(
              frame,
              [0, 8, durationInFrames - 8, durationInFrames],
              [0, 1, 1, 0],
              {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}
            ),
          }}
        >
          {(rows[activeRowIdx] || []).map((it) => it.word).join(' ')}
        </div>
      ) : (
        visibleRows.map((row, rIdx) => (
          <div
            key={rIdx}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 12,
              padding: '10px 24px',
              borderRadius: captionStyle === 'handwritten' ? 12 : 16,
              backgroundColor:
                captionStyle === 'handwritten'
                  ? '#FAF5E8'
                  : captionStyle === 'neon'
                  ? 'rgba(8, 10, 24, 0.94)'
                  : 'rgba(24, 24, 27, 0.94)',
              border:
                captionStyle === 'neon'
                  ? `2.5px solid ${accent}`
                  : captionStyle === 'typewriter'
                  ? `2px solid ${accent}`
                  : undefined,
              boxShadow:
                captionStyle === 'neon'
                  ? `0 0 24px ${accent}88, 0 8px 24px rgba(0,0,0,0.6)`
                  : '0 8px 20px rgba(0,0,0,0.42)',
            }}
          >
            {row.map(({index, word}) => {
              const cleanW = word.toLowerCase().replace(/[^\w]/g, '');
              const isCurrent = index === activeWordIdx;
              const isSpoken = index < activeWordIdx;
              const isEmph =
                emphasisSet.has(cleanW) ||
                (word === word.toUpperCase() && cleanW.length >= 4);
              const wAnim = animLookup[cleanW];
              const intensity = wAnim?.intensity || (isEmph ? 1.3 : 1.14);
              const bounce = isCurrent ? Math.sin(wordSubProg * Math.PI) : 0;
              const scaleVal = isCurrent
                ? 1 + (intensity - 1) * bounce
                : isSpoken
                ? 0.97
                : 1.0;
              const rotDeg =
                isCurrent && (wAnim?.animation === 'pop-rotate' || isEmph)
                  ? Math.sin(wordSubProg * Math.PI * 2) * 3.5
                  : 0;
              const slideY =
                captionStyle === 'slide-up' && isCurrent
                  ? (1 - Math.min(1, wordSubProg * 1.8)) * 14
                  : 0;

              const displayStr =
                captionStyle === 'typewriter' && isCurrent
                  ? word.slice(
                      0,
                      Math.max(1, Math.ceil(word.length * Math.min(1, wordSubProg * 1.35)))
                    ) + (Math.floor(frame / 4) % 2 === 0 ? '█' : '')
                  : captionStyle === 'typewriter' && !isSpoken
                  ? ''
                  : word;

              return (
                <span
                  key={index}
                  style={{
                    display: 'inline-block',
                    fontFamily:
                      captionStyle === 'typewriter' || captionStyle === 'glitch'
                        ? 'ui-monospace, SFMono-Regular, Menlo, monospace'
                        : captionStyle === 'handwritten'
                        ? 'Georgia, serif'
                        : 'Inter, sans-serif',
                    fontSize: isEmph ? 40 : 36,
                    fontWeight: 900,
                    padding: isCurrent ? '2px 10px' : '2px 4px',
                    borderRadius: 10,
                    backgroundColor:
                      isCurrent && captionStyle !== 'typewriter'
                        ? accent
                        : 'transparent',
                    color:
                      isCurrent && captionStyle !== 'typewriter'
                        ? '#121210'
                        : captionStyle === 'handwritten'
                        ? '#1C1917'
                        : isSpoken
                        ? 'rgba(248,250,252,0.82)'
                        : isEmph
                        ? accent
                        : '#FFFFFF',
                    transform: `translateY(${slideY.toFixed(1)}px) scale(${scaleVal.toFixed(3)}) rotate(${rotDeg.toFixed(1)}deg)`,
                    textShadow:
                      captionStyle === 'glitch' && isCurrent
                        ? '-3px 0 #EC4899, 3px 0 #38BDF8'
                        : captionStyle === 'neon' && isCurrent
                        ? `0 0 16px ${accent}`
                        : undefined,
                  }}
                >
                  {displayStr}
                </span>
              );
            })}
          </div>
        ))
      )}
    </div>
  );
};

export const TutorialDeckStage: React.FC<{scene: ReferenceSceneSpec; brandLeft?: string; brandRight?: string}> = ({
  scene,
  brandLeft = 'REMOTION × CLAUDE',
  brandRight = 'ShotcraftPro',
}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 120}});
  const accent = scene.accent || '#D97757';
  const progressPct = Math.min(100, Math.round((frame / Math.max(1, durationInFrames * 0.75)) * 100));

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#121210',
        backgroundImage: `radial-gradient(circle at 50% 42%, ${accent}26 0%, transparent 58%), radial-gradient(rgba(255,255,255,0.08) 1.5px, transparent 1.5px)`,
        backgroundSize: '100% 100%, 36px 36px',
        padding: '72px 84px 180px 84px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      {/* Top Brand Header */}
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
        <div
          style={{
            backgroundColor: '#1E1E1A',
            border: '1.5px solid rgba(255,255,255,0.15)',
            borderRadius: 999,
            padding: '10px 24px',
            color: '#F5F2EB',
            fontFamily: 'Inter, sans-serif',
            fontSize: 22,
            fontWeight: 800,
            letterSpacing: '0.08em',
          }}
        >
          <span style={{color: '#D97757', marginRight: 10}}>✳</span>
          {brandLeft}
        </div>
        <div
          style={{
            backgroundColor: '#1E1E1A',
            border: '1.5px solid rgba(217,119,87,0.45)',
            borderRadius: 999,
            padding: '10px 24px',
            color: '#F5F2EB',
            fontFamily: 'Inter, sans-serif',
            fontSize: 22,
            fontWeight: 800,
          }}
        >
          <span style={{color: '#D97757', marginRight: 8}}>✳</span>
          {brandRight}
        </div>
      </div>

      {/* Step Pill & 2-Tone Headline */}
      <div style={{marginTop: 36, transform: `translateY(${((1 - enter) * 24).toFixed(1)}px)`}}>
        <div
          style={{
            display: 'inline-block',
            backgroundColor: `${accent}22`,
            border: `1.5px solid ${accent}`,
            borderRadius: 999,
            padding: '8px 22px',
            color: accent,
            fontFamily: 'Inter, sans-serif',
            fontSize: 22,
            fontWeight: 800,
            letterSpacing: '0.1em',
            marginBottom: 18,
          }}
        >
          {scene.stepBadge}
        </div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 74,
            fontWeight: 900,
            lineHeight: 1.06,
            color: '#F5F2EB',
            textTransform: 'uppercase',
          }}
        >
          <div>{scene.headlineTop}</div>
          <div style={{color: accent}}>{scene.headlineAccent}</div>
        </div>
      </div>

      {/* Center macOS Window Mockup */}
      <div
        style={{
          position: 'relative',
          backgroundColor: '#1C1C19',
          border: '2px solid rgba(255,255,255,0.14)',
          borderRadius: 28,
          padding: '28px 36px 40px 36px',
          boxShadow: '0 28px 70px rgba(0,0,0,0.65)',
          transform: `scale(${(0.92 + 0.08 * enter).toFixed(3)})`,
        }}
      >
        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28, paddingBottom: 18, borderBottom: '1px solid rgba(255,255,255,0.1)'}}>
          <div style={{width: 16, height: 16, borderRadius: 999, backgroundColor: '#FF5F56'}} />
          <div style={{width: 16, height: 16, borderRadius: 999, backgroundColor: '#FFBD2E'}} />
          <div style={{width: 16, height: 16, borderRadius: 999, backgroundColor: '#27C93F'}} />
          <span style={{marginLeft: 12, color: '#A8A29E', fontFamily: 'monospace', fontSize: 24, fontWeight: 700}}>
            {scene.windowTitle || 'TERMINAL'}
          </span>
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
          {(scene.windowContentLines || ['$ npx create-video@latest', '$ npm install', '✓ SELESAI, SIAP DIPAKAI']).map((ln, idx) => (
            <div
              key={idx}
              style={{
                fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
                fontSize: 30,
                fontWeight: 700,
                color: ln.startsWith('$') ? '#F5F2EB' : accent,
              }}
            >
              {ln}
            </div>
          ))}
          <div style={{marginTop: 18, height: 14, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 999, overflow: 'hidden'}}>
            <div style={{width: `${progressPct}%`, height: '100%', backgroundColor: accent, borderRadius: 999}} />
          </div>
        </div>
        {scene.stickerText ? (
          <div
            style={{
              position: 'absolute',
              right: 28,
              bottom: -24,
              transform: 'rotate(-6deg)',
              backgroundColor: '#F5F0E6',
              color: '#121210',
              padding: '10px 24px',
              borderRadius: 12,
              fontFamily: 'Inter, sans-serif',
              fontSize: 24,
              fontWeight: 900,
              boxShadow: '0 10px 25px rgba(0,0,0,0.45)',
            }}
          >
            {scene.stickerText}
          </div>
        ) : null}
      </div>

      {/* Bottom Semantic & Animated Subtitle */}
      <SemanticAnimatedSubtitle scene={scene} accent={accent} />
    </AbsoluteFill>
  );
};

export const FloatingGlassOverlayStage: React.FC<{scene: ReferenceSceneSpec}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 120}});
  const accent = scene.accent || '#C084FC';

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#18191E',
        backgroundImage: 'radial-gradient(circle at 50% 22%, rgba(192,132,252,0.22), transparent 55%)',
        padding: '140px 84px 180px 84px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      {/* Upper Headroom Floating Frosted Glass Zone */}
      <div
        style={{
          backgroundColor: 'rgba(34, 37, 46, 0.76)',
          backdropFilter: 'blur(24px)',
          border: '1.5px solid rgba(255,255,255,0.22)',
          borderRadius: 36,
          padding: '36px 42px',
          transform: `translateY(${((1 - enter) * 28).toFixed(1)}px)`,
          boxShadow: '0 24px 60px rgba(0,0,0,0.45)',
        }}
      >
        <div style={{fontFamily: 'Inter, sans-serif', fontSize: 28, fontWeight: 600, color: '#E2E8F0', textAlign: 'center', marginBottom: 14}}>
          {scene.headlineTop}
        </div>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 68,
            fontWeight: 900,
            textAlign: 'center',
            background: `linear-gradient(90deg, ${accent}, #F472B6, #38BDF8)`,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            marginBottom: 24,
          }}
        >
          {scene.headlineAccent}
        </div>
        <div style={{display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 14}}>
          {(scene.windowContentLines || ['1 · Claude Editor', '2 · Guidebook Style', '3 · Motion Kit']).map((pill, i) => (
            <div
              key={i}
              style={{
                backgroundColor: 'rgba(255,255,255,0.12)',
                border: '1px solid rgba(255,255,255,0.24)',
                borderRadius: 999,
                padding: '12px 28px',
                color: '#F8FAFC',
                fontFamily: 'Inter, sans-serif',
                fontSize: 26,
                fontWeight: 700,
              }}
            >
              {pill}
            </div>
          ))}
        </div>
      </div>

      {/* Speaker Studio Frame Indicator */}
      <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: 520}}>
        <div
          style={{
            width: 240,
            height: 240,
            borderRadius: 999,
            border: `4px solid ${accent}`,
            backgroundColor: 'rgba(15,23,42,0.75)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#F8FAFC',
            fontSize: 72,
            fontWeight: 900,
          }}
        >
          ✳
        </div>
      </div>

      {/* Bottom Semantic & Animated Subtitle */}
      <SemanticAnimatedSubtitle scene={scene} accent={accent} />
    </AbsoluteFill>
  );
};

export const SplitPricingVoxelStage: React.FC<{scene: ReferenceSceneSpec; brand?: string}> = ({
  scene,
  brand = 'classai.id',
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 15, stiffness: 120}});
  const accent = scene.accent || '#3B82F6';

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#060A12',
        backgroundImage:
          'linear-gradient(rgba(56,189,248,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(56,189,248,0.06) 1px, transparent 1px)',
        backgroundSize: '40px 40px',
        padding: '64px 72px 0 72px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      {/* Top Brand Bar + Service Chapter Header */}
      <div>
        <div style={{display: 'flex', justifyContent: 'space-between', color: '#94A3B8', fontFamily: 'Inter, sans-serif', fontSize: 24, fontWeight: 700, marginBottom: 28}}>
          <span style={{color: '#F8FAFC'}}>C {brand}</span>
          <span>@{brand.replace('.', '_')}</span>
        </div>
        <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
          <div style={{fontFamily: 'Inter, sans-serif', fontSize: 88, fontWeight: 900, color: 'transparent', WebkitTextStroke: '3px #64748B'}}>
            {scene.stepBadge}
          </div>
          <div>
            <div style={{fontFamily: 'Inter, sans-serif', fontSize: 56, fontWeight: 900, color: '#F8FAFC'}}>{scene.headlineTop}</div>
            <div style={{fontFamily: 'Inter, sans-serif', fontSize: 22, fontWeight: 800, color: accent, letterSpacing: '0.08em'}}>
              {scene.headlineAccent}
            </div>
          </div>
        </div>
      </div>

      {/* Browser Pricing Inspector Card */}
      <div
        style={{
          position: 'relative',
          backgroundColor: '#0D1322',
          border: '2px solid rgba(255,255,255,0.15)',
          borderRadius: 24,
          padding: '24px 32px',
          transform: `scale(${(0.94 + 0.06 * enter).toFixed(3)})`,
        }}
      >
        <div style={{fontFamily: 'monospace', fontSize: 22, color: '#94A3B8', marginBottom: 18, paddingBottom: 12, borderBottom: '1px solid rgba(255,255,255,0.1)'}}>
          {scene.windowTitle || 'https://developers.cloudflare.com/pages'}
        </div>
        {(scene.windowContentLines || ['Free Tier: $0 / month', '✓ Unlimited static requests', '✓ 500 builds per month']).map((ln, idx) => (
          <div
            key={idx}
            style={{
              padding: '12px 18px',
              marginBottom: 10,
              borderRadius: 12,
              border: idx === 1 ? `2.5px solid ${accent}` : '1px solid rgba(255,255,255,0.06)',
              backgroundColor: idx === 1 ? `${accent}22` : 'transparent',
              color: '#F8FAFC',
              fontFamily: 'Inter, sans-serif',
              fontSize: 28,
              fontWeight: 700,
            }}
          >
            {ln}
          </div>
        ))}
        {scene.highlightBadge ? (
          <div
            style={{
              position: 'absolute',
              right: 24,
              bottom: -24,
              backgroundColor: accent,
              color: '#FFFFFF',
              padding: '14px 28px',
              borderRadius: 18,
              fontFamily: 'Inter, sans-serif',
              fontSize: 30,
              fontWeight: 900,
              boxShadow: '0 14px 30px rgba(0,0,0,0.5)',
            }}
          >
            {scene.highlightBadge}
          </div>
        ) : null}
      </div>

      {/* Middle Semantic Caption + Bottom 3D Voxel Presenter */}
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <SemanticAnimatedSubtitle scene={scene} accent={accent} />
        <svg width={460} height={420} viewBox="0 0 460 420">
          <rect x={130} y={40} width={200} height={75} rx={16} fill="#1D4ED8" stroke="#3B82F6" strokeWidth={4} />
          <rect x={115} y={95} width={230} height={38} rx={10} fill="#2563EB" />
          <rect x={130} y={133} width={200} height={145} rx={12} fill="#FDBA74" stroke="#EA580C" strokeWidth={3} />
          <rect x={168} y={175} width={24} height={28} rx={4} fill="#0F172A" />
          <rect x={268} y={175} width={24} height={28} rx={4} fill="#0F172A" />
          <rect x={205} y={225} width={50} height={18} rx={6} fill="#7C2D12" />
          <rect x={115} y={278} width={230} height={140} rx={14} fill="#F8FAFC" />
          <rect x={115} y={305} width={230} height={26} fill="#2563EB" />
          <rect x={115} y={355} width={230} height={26} fill="#2563EB" />
          <rect x={345} y={190} width={55} height={125} rx={12} fill="#FDBA74" />
        </svg>
      </div>
    </AbsoluteFill>
  );
};

export const TapeStickerMascotStage: React.FC<{scene: ReferenceSceneSpec}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 14, stiffness: 130}});
  const accent = scene.accent || '#C85A3A';

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#1A1822',
        backgroundImage: 'radial-gradient(circle at 50% 45%, rgba(200,90,58,0.22), transparent 65%)',
        padding: '150px 72px 180px 72px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      {/* Top Masking-Tape Cream Paper Banner */}
      <div
        style={{
          position: 'relative',
          backgroundColor: '#EDE8DC',
          padding: '22px 48px',
          borderRadius: 8,
          boxShadow: '0 16px 40px rgba(0,0,0,0.55)',
          transform: `scale(${(0.92 + 0.08 * enter).toFixed(3)})`,
        }}
      >
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: 34,
            fontWeight: 900,
            color: '#18181B',
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            textAlign: 'center',
          }}
        >
          {scene.headlineTop}
        </div>
      </div>

      {/* Center 3D Blocky Claude Mascot + Monitor + Hole-Punch Skill Card */}
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 28}}>
        <svg width={520} height={380} viewBox="0 0 520 380">
          <rect x={180} y={20} width={310} height={200} rx={16} fill="#0F172A" stroke="#334155" strokeWidth={6} />
          <rect x={210} y={55} width={160} height={18} rx={6} fill="#F4A261" />
          <rect x={210} y={88} width={220} height={18} rx={6} fill="#38BDF8" />
          <rect x={210} y={121} width={130} height={18} rx={6} fill="#A855F7" />
          <rect x={60} y={90} width={200} height={160} rx={18} fill="#E07A5F" stroke="#9A3412" strokeWidth={5} />
          <rect x={115} y={135} width={22} height={46} rx={6} fill="#1E293B" />
          <rect x={185} y={135} width={22} height={46} rx={6} fill="#1E293B" />
          <rect x={50} y={240} width={220} height={70} rx={12} fill="#262626" />
        </svg>

        <div
          style={{
            position: 'relative',
            backgroundColor: '#F3EFE6',
            borderRadius: 22,
            padding: '26px 48px 26px 64px',
            minWidth: 560,
            boxShadow: '0 20px 45px rgba(0,0,0,0.5)',
          }}
        >
          <div
            style={{
              position: 'absolute',
              left: 22,
              top: '50%',
              transform: 'translateY(-50%)',
              width: 22,
              height: 22,
              borderRadius: 999,
              backgroundColor: '#27272A',
            }}
          />
          <div
            style={{
              position: 'absolute',
              right: -18,
              top: -18,
              width: 56,
              height: 56,
              borderRadius: 999,
              backgroundColor: accent,
              color: '#FFFFFF',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: 'Inter, sans-serif',
              fontSize: 28,
              fontWeight: 900,
            }}
          >
            {scene.stepBadge}
          </div>
          <div style={{fontFamily: 'Inter, sans-serif', fontSize: 44, fontWeight: 900, color: '#18181B'}}>{scene.headlineAccent}</div>
          <div style={{fontFamily: 'Inter, sans-serif', fontSize: 26, fontWeight: 600, color: '#52525B'}}>
            {scene.stickerText || 'motion graphic & video editor'}
          </div>
        </div>
      </div>

      {/* Bottom Tilted Torn-Paper Word Stickers or Custom Caption Style */}
      {scene.captionStyle && scene.captionStyle !== 'karaoke-pill' ? (
        <SemanticAnimatedSubtitle scene={scene} accent={accent} />
      ) : (
        <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 16}}>
          {scene.subtitleWords.map((w, idx) => {
            const isOrange = idx % 2 === 0;
            const rot = idx % 2 === 0 ? -2.5 : 2.2;
            return (
              <div
                key={idx}
                style={{
                  backgroundColor: isOrange ? accent : '#F4EFE6',
                  color: isOrange ? '#F4EFE6' : accent,
                  padding: '10px 26px',
                  borderRadius: 8,
                  transform: `rotate(${rot}deg)`,
                  fontFamily: 'Georgia, serif',
                  fontSize: 44,
                  fontWeight: 900,
                  boxShadow: '0 10px 24px rgba(0,0,0,0.45)',
                }}
              >
                {w}
              </div>
            );
          })}
        </div>
      )}
    </AbsoluteFill>
  );
};
export default TutorialDeckStage;
