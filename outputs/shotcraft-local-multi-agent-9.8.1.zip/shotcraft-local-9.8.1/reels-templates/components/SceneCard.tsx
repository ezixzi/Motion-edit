import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {
  TutorialDeckStage,
  FloatingGlassOverlayStage,
  SplitPricingVoxelStage,
  TapeStickerMascotStage,
  ReferenceSceneSpec,
  SemanticAnimatedSubtitle,
  CaptionStyleKind,
  WordAnimationConfig,
  SpeakerRole,
} from './ReferenceShowreelStage';
import {EditorialCutawayStage} from './EditorialCutawayStage';
import {ProceduralVisual} from './ProceduralVisual';
import {SafeZoneWrapper} from './SafeZoneWrapper';
import CUSTOM_STAGE_PLUGINS from './custom';

export interface CleanSceneSpec {
  id: string;
  eyebrow: string;
  stateBadge?: string;
  cutawayKind?: 'engine' | 'brain' | 'coffee';
  evidenceCardKind?: 'bars' | 'quote' | 'checklist';
  metric: string;
  unit: string;
  headline: string;
  subcopy: string;
  narration?: string;
  accent: string;
  windowTitle?: string;
  windowContentLines?: string[];
  stickerText?: string;
  captionStyle?: CaptionStyleKind;
  emphasisWords?: string[];
  wordAnimations?: WordAnimationConfig[];
  speaker?: SpeakerRole;
  y_center?: number;
  bottom3DOccupied?: boolean;
  captionEmoji?: string;
  visualMode: string;
  videoSrc?: string;
  sourceStartSec?: number;
  zoom?: number;
  durationInFrames: number;
}

export const STYLE_TYPOGRAPHY_MAP: Record<
  string,
  {heading: string; mono: string; body: string; defaultCaption: CaptionStyleKind}
> = {
  'neural-network': {
    heading: '"Space Grotesk", Inter, system-ui, sans-serif',
    mono: '"JetBrains Mono", ui-monospace, monospace',
    body: '"Space Grotesk", Inter, system-ui, sans-serif',
    defaultCaption: 'glitch',
  },
  'coffee-editorial-3d': {
    heading: '"Playfair Display", Georgia, serif',
    mono: '"Fira Code", ui-monospace, monospace',
    body: '"DM Sans", Inter, sans-serif',
    defaultCaption: 'slide-up',
  },
  'ref5-editorial-cutaway': {
    heading: 'Charter, Georgia, serif',
    mono: '"Fira Code", ui-monospace, monospace',
    body: 'Inter, system-ui, sans-serif',
    defaultCaption: 'karaoke-pill',
  },
  'ref1-tutorial-deck': {
    heading: '"IBM Plex Sans", Inter, sans-serif',
    mono: '"IBM Plex Mono", ui-monospace, monospace',
    body: '"IBM Plex Sans", Inter, sans-serif',
    defaultCaption: 'typewriter',
  },
};

export const hasRtlCharacters = (s: string): boolean => /[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/.test(s || '');

export const toReferenceSpec = (sc: CleanSceneSpec, idx: number): ReferenceSceneSpec => ({
  id: sc.id,
  styleMode: (sc.visualMode.startsWith('ref') ? sc.visualMode : 'ref1-tutorial-deck') as ReferenceSceneSpec['styleMode'],
  stepBadge: sc.eyebrow || `0${idx + 1}`,
  headlineTop: sc.headline,
  headlineAccent: `${sc.metric} ${sc.unit}`.trim(),
  windowTitle: sc.windowTitle,
  windowContentLines: sc.windowContentLines,
  highlightBadge: `${sc.metric} ${sc.unit}`.trim(),
  stickerText: sc.stickerText || 'INTI',
  subtitleWords: (sc.narration || sc.subcopy || sc.headline)
    .replace(/<[^>]+>/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 14),
  captionStyle: sc.captionStyle || STYLE_TYPOGRAPHY_MAP[sc.visualMode]?.defaultCaption || 'karaoke-pill',
  emphasisWords: sc.emphasisWords,
  wordAnimations: sc.wordAnimations,
  speaker: sc.speaker,
  y_center: sc.y_center,
  bottom3DOccupied: sc.bottom3DOccupied,
  captionEmoji: sc.captionEmoji,
  accent: sc.accent,
  durationInFrames: sc.durationInFrames,
});

export const Science3ZoneStage: React.FC<{scene: CleanSceneSpec; index: number; total: number; badge?: string}> = ({
  scene,
  index,
  total,
  badge = '',
}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 16, stiffness: 120}});
  const exitOpacity = interpolate(frame, [durationInFrames - 8, durationInFrames], [1, 0.94], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const typo = STYLE_TYPOGRAPHY_MAP[scene.visualMode] || STYLE_TYPOGRAPHY_MAP['neural-network'];
  const refSpec = toReferenceSpec(scene, index);
  const isRtl = hasRtlCharacters(scene.headline) || hasRtlCharacters(scene.subcopy);

  return (
    <SafeZoneWrapper
      rtl={isRtl}
      style={{
        background: `radial-gradient(circle at 50% 34%, ${scene.accent}33 0%, #0F172A 48%, #060B18 100%)`,
        opacity: exitOpacity,
      }}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: badge ? 'space-between' : 'flex-end',
          borderBottom: '1.5px solid rgba(255,255,255,0.12)',
          paddingBottom: 20,
          zIndex: 2,
        }}
      >
        {badge ? (
          <div
            style={{
              backgroundColor: 'rgba(255,255,255,0.06)',
              border: `1.5px solid ${scene.accent}`,
              borderRadius: 999,
              padding: '10px 24px',
              fontFamily: typo.heading,
              fontSize: 22,
              fontWeight: 800,
              letterSpacing: '0.12em',
              color: scene.accent,
            }}
          >
            {badge}
          </div>
        ) : null}
        <div style={{display: 'flex', gap: 10}}>
          {Array.from({length: total}, (_, i) => (
            <div
              key={i}
              style={{
                width: i === index ? 36 : 12,
                height: 12,
                borderRadius: 999,
                backgroundColor: i === index ? scene.accent : 'rgba(255,255,255,0.22)',
              }}
            />
          ))}
        </div>
      </div>

      <div style={{height: 520, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2}}>
        <ProceduralVisual mode={scene.visualMode} accent={scene.accent} />
      </div>

      <div
        style={{
          backgroundColor: 'rgba(15, 23, 42, 0.90)',
          backdropFilter: 'blur(18px)',
          border: `2px solid ${scene.accent}`,
          borderRadius: 32,
          padding: '28px 36px',
          transform: `translateY(${((1 - enter) * 28).toFixed(1)}px)`,
          boxShadow: '0 24px 60px rgba(0,0,0,0.55)',
          zIndex: 2,
        }}
      >
        <div
          style={{
            fontFamily: typo.mono,
            fontSize: 21,
            fontWeight: 700,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: scene.accent,
            marginBottom: 8,
          }}
        >
          {scene.eyebrow}
        </div>
        <div
          style={{
            fontFamily: typo.heading,
            fontSize: 86,
            fontWeight: 900,
            lineHeight: 1.0,
            letterSpacing: '-0.03em',
            color: '#F8FAFC',
            textShadow: `0 0 32px ${scene.accent}66`,
            marginBottom: 12,
          }}
        >
          {scene.metric}
          <span style={{fontSize: 46, color: scene.accent, marginLeft: 12}}>{scene.unit}</span>
        </div>
        <div
          style={{
            fontFamily: typo.heading,
            fontSize: 36,
            fontWeight: 800,
            lineHeight: 1.18,
            color: '#F8FAFC',
            marginBottom: 8,
          }}
        >
          {scene.headline}
        </div>
        <div style={{fontFamily: typo.body, fontSize: 24, fontWeight: 500, lineHeight: 1.36, color: '#CBD5E1'}}>
          {scene.subcopy}
        </div>
      </div>

      <div style={{zIndex: 3}}>
        <SemanticAnimatedSubtitle scene={refSpec} accent={scene.accent} />
      </div>
    </SafeZoneWrapper>
  );
};

export const VISUAL_MODE_REGISTRY: Record<
  string,
  React.FC<{scene: CleanSceneSpec; index: number; total: number; badge?: string}>
> = {
  'ref5-editorial-cutaway': ({scene, index, badge}) => (
    <EditorialCutawayStage
      badge={badge}
      scene={{
        id: scene.id,
        eyebrow: scene.eyebrow,
        stateBadge: scene.stateBadge || scene.windowTitle || `BAGIAN 0${index + 1}`,
        headline: scene.headline,
        metric: scene.metric,
        unit: scene.unit,
        subcopy: scene.subcopy,
        narration: scene.narration,
        cutawayKind: scene.cutawayKind || 'engine',
        evidenceCardKind: scene.evidenceCardKind || 'bars',
        windowTitle: scene.windowTitle,
        windowContentLines: scene.windowContentLines,
        captionStyle: scene.captionStyle,
        emphasisWords: scene.emphasisWords,
        wordAnimations: scene.wordAnimations,
        speaker: scene.speaker,
        y_center: scene.y_center,
        bottom3DOccupied: scene.bottom3DOccupied,
        captionEmoji: scene.captionEmoji,
        accent: scene.accent,
        durationInFrames: scene.durationInFrames,
      }}
    />
  ),
  'ink-press-vertical': ({scene, index, badge}) =>
    VISUAL_MODE_REGISTRY['ref5-editorial-cutaway']({scene, index, total: 1, badge}),
  'cutaway-turbofan': ({scene, index, badge}) =>
    VISUAL_MODE_REGISTRY['ref5-editorial-cutaway']({scene, index, total: 1, badge}),
  'coffee-editorial-3d': ({scene, index, badge}) =>
    VISUAL_MODE_REGISTRY['ref5-editorial-cutaway']({
      scene: {...scene, cutawayKind: scene.cutawayKind || 'coffee'},
      index,
      total: 1,
      badge,
    }),
  'ref1-tutorial-deck': ({scene, index, badge}) => (
    <TutorialDeckStage scene={toReferenceSpec(scene, index)} brandRight={badge || ''} />
  ),
  'ref2-floating-glass': ({scene, index}) => <FloatingGlassOverlayStage scene={toReferenceSpec(scene, index)} />,
  'ref3-pricing-voxel': ({scene, index, badge}) => (
    <SplitPricingVoxelStage scene={toReferenceSpec(scene, index)} brand={badge || ''} />
  ),
  'ref4-tape-mascot': ({scene, index}) => <TapeStickerMascotStage scene={toReferenceSpec(scene, index)} />,
  ...CUSTOM_STAGE_PLUGINS,
};

export const SceneCard: React.FC<{scene: CleanSceneSpec; index: number; total: number; badge?: string}> = (props) => {
  const StageComponent = VISUAL_MODE_REGISTRY[props.scene.visualMode] || Science3ZoneStage;
  return <StageComponent {...props} />;
};

export default SceneCard;
