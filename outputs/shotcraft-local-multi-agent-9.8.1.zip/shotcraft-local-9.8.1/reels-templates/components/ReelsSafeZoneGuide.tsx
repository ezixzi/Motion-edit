import React from 'react';
import {AbsoluteFill} from 'remotion';

export const REELS_SAFE_ZONE = {left: 84, right: 204, top: 220, bottom: 430, width: 792, height: 1270} as const;

export const ReelsSafeZoneGuide: React.FC<{showDebugOverlay?: boolean; children: React.ReactNode}> = ({
  showDebugOverlay = false,
  children,
}) => (
  <AbsoluteFill>
    <div style={{position: 'absolute', left: 84, top: 220, width: 792, height: 1270, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
      {children}
    </div>
    {showDebugOverlay ? (
      <AbsoluteFill style={{pointerEvents: 'none'}}>
        <div style={{position: 'absolute', left: 84, top: 220, width: 792, height: 1270, border: '3px solid #10B981'}} />
      </AbsoluteFill>
    ) : null}
  </AbsoluteFill>
);
export default ReelsSafeZoneGuide;
