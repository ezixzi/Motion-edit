import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';

export interface CutawayCallout {
  id: string;
  label: string;
  targetX: number;
  targetY: number;
  cardX: number;
  cardY: number;
}

export interface CutawayRigStageProps {
  title: string;
  shellPeelProgress?: number;
  accent?: string;
  callouts?: CutawayCallout[];
}

export const CutawayRigStage: React.FC<CutawayRigStageProps> = ({
  title,
  accent = '#38BDF8',
  callouts = [],
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const peel = spring({frame: frame - 8, fps, config: {damping: 16, stiffness: 90}});

  return (
    <svg width={900} height={620} viewBox="0 0 900 620">
      <rect x={180} y={140} width={540} height={340} rx={36} fill="#0F172A" stroke={accent} strokeWidth={4} />
      <circle cx={340} cy={310} r={85} fill="none" stroke={accent} strokeWidth={5} strokeDasharray="16 10" />
      <circle cx={550} cy={310} r={85} fill="none" stroke="#F59E0B" strokeWidth={5} strokeDasharray="16 10" />
      <rect
        x={180 + peel * 260}
        y={140 - peel * 40}
        width={540}
        height={340}
        rx={36}
        fill="#1E293B"
        fillOpacity={Math.max(0.12, 1 - peel * 0.82)}
        stroke="#94A3B8"
        strokeWidth={3}
      />
      <text x={220} y={205} fill="#F8FAFC" fontSize={26} fontWeight={800} fontFamily="Inter, sans-serif">
        {title}
      </text>
      {callouts.map((c) => (
        <g key={c.id}>
          <line
            x1={c.targetX}
            y1={c.targetY}
            x2={c.cardX}
            y2={c.cardY}
            stroke={accent}
            strokeWidth={3}
            strokeDasharray="8 6"
          />
          <circle cx={c.targetX} cy={c.targetY} r={8} fill={accent} />
          <rect x={c.cardX - 10} y={c.cardY - 28} width={220} height={44} rx={12} fill="#0F172A" stroke={accent} strokeWidth={2} />
          <text x={c.cardX + 6} y={c.cardY + 2} fill="#F8FAFC" fontSize={20} fontWeight={700} fontFamily="Inter, sans-serif">
            {c.label}
          </text>
        </g>
      ))}
    </svg>
  );
};
export default CutawayRigStage;
