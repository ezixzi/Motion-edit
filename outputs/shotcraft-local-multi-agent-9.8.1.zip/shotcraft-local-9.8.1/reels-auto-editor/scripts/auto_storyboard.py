#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — Media-to-Storyboard Mapper (`auto_storyboard.py`).

Maps analyzed raw video clips or voiceover phrases into a validated Shotcraft v9.7 `timeline.json`
with:
- Zero fabricated metrics (`metric: ""`, `unit: ""`)
- Explicit `videoSrc`, `sourceStartSec`, `sourceEndSec`, and `zoom` when editing a raw video
- Acoustic word timestamps (`words`) synced to the kept audio timeline
- Real transition motifs (`crossfade`, `slide`, `cutaway-peel`, `object-match`, `zoom`) between scenes!
"""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
for _p in (HERE, SKILLS_ROOT / "mcp" / "core", SKILLS_ROOT.parent / "mcp" / "core"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import style_map as sm_mod

ACCENTS = ["#1D7A46", "#2563EB", "#D97706", "#0284C7", "#16A34A", "#9333EA"]
TRANSITIONS = ["crossfade", "cutaway-peel", "slide", "object-match", "zoom", "cut"]


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7 Auto-Storyboard Mapper")
    p.add_argument("--analysis-json", required=True)
    p.add_argument("--output-timeline", required=True)
    p.add_argument("--style", default="ref3-cutaway-mechanism")
    p.add_argument("--caption-style", default="auto", help="Caption preset (auto uses 33 Premium Text XML/MOGRT presets for raw video talking head, or slide-up/minimal/neon for motion)")
    p.add_argument("--video-crop", choices=["cover", "blur-pad"], default="cover")
    p.add_argument("--fps", type=int, default=30)
    a = p.parse_args()

    analysis = json.loads(Path(a.analysis_json).read_text(encoding="utf-8"))
    phrases = analysis.get("phrases", [])
    resolved_style = sm_mod.resolve_style_id(a.style, default_style="ref3-cutaway-mechanism")

    scenes = []
    cur_f = 0
    for i, ph in enumerate(phrases):
        dur_f = max(45, int(round(float(ph["duration"]) * a.fps / 3.0)) * 3)
        trans_in = "cut" if i == 0 else TRANSITIONS[(i - 1) % len(TRANSITIONS)]
        trans_out = "cut" if i == len(phrases) - 1 else TRANSITIONS[i % len(TRANSITIONS)]

        raw_sc = {
            "id": ph.get("id", f"scene-{i+1:02d}"),
            "eyebrow": ph.get("eyebrow") or f"BAGIAN 0{i+1}",
            "metric": "",
            "unit": "",
            "headline": ph.get("headline") or ph["text"][:64],
            "subcopy": ph["text"],
            "narration": ph["text"],
            "narrationStartSec": ph.get("timeline_start", 0.0),
            "narrationEndSec": ph.get("timeline_end", float(ph["duration"])),
            "words": ph.get("words", []),
            "windowTitle": ph.get("windowTitle") or f"TAHAP 0{i+1}",
            "windowContentLines": ph.get("windowContentLines") or [
                f"Inti: {(ph.get('headline') or ph['text'])[:42]}",
                f"Rentang Waktu: {ph.get('source_start', 0.0):.1f}s - {ph.get('source_end', 0.0):.1f}s",
                f"Mode Visual: {resolved_style}",
            ],
            "callouts": ph.get("callouts", []),
            "archetype": ph.get("archetype", ""),
            "stackItems": ph.get("stackItems", []),
            "categoryTags": ph.get("categoryTags", []),
            "subjectId": ph.get("subjectId", "system-mechanism"),
            "mechanismStep": ph.get("mechanismStep", f"step-{i+1}"),
            "captionStyle": a.caption_style,
            "accent": ACCENTS[i % len(ACCENTS)],
            "visualMode": resolved_style,
            "transitionIn": trans_in,
            "transitionOut": trans_out,
            "transitionMotif": trans_out,
            "startFrame": cur_f,
            "durationInFrames": dur_f,
        }
        if ph.get("video_src"):
            raw_sc["videoSrc"] = ph["video_src"]
            raw_sc["sourceStartSec"] = ph.get("source_start", 0.0)
            raw_sc["sourceEndSec"] = ph.get("source_end", float(ph["duration"]))
            raw_sc["zoom"] = ph.get("zoom", 1.08)
            raw_sc["videoCropMode"] = a.video_crop
            raw_sc["subjectId"] = "talking-head-presenter"
            if a.style in ("auto-context", "auto", "talking-head", ""):
                raw_sc["visualMode"] = "talking-head"
            if a.caption_style in ("", "auto", "karaoke-pill"):
                raw_sc["captionStyle"] = sm_mod.resolve_caption_style("", idx=i, is_talking_head=True)

        norm_sc = sm_mod.normalize_and_validate_scene_contract(
            raw_sc, idx=i, default_subject_id=raw_sc["subjectId"], default_style_id=resolved_style, fps=a.fps
        )
        scenes.append(norm_sc)
        cur_f += dur_f

    timeline = {
        "schema_version": "9.7.0",
        "topic": analysis.get("topic", "Edited Reel"),
        "fps": a.fps,
        "totalFrames": sum(s["durationInFrames"] for s in scenes),
        "scenes": scenes,
    }
    Path(a.output_timeline).write_text(json.dumps(timeline, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"ok": True, "timeline": str(a.output_timeline), "scenes_count": len(scenes)}, indent=2))


if __name__ == "__main__":
    main()
