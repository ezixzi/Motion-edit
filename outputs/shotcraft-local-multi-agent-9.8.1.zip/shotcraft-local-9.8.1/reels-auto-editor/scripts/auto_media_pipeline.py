#!/usr/bin/env python3
"""
Shotcraft Pro v9.7.0 — End-to-End Raw Video Editor, Voiceover-to-Video Producer & Drop-Folder Pipeline (`auto_media_pipeline.py`).

Supports:
1. Direct single-file or combined inputs:
   - `--raw-video <path.mp4>`: Auto-cuts dead-air silences, slices into dynamic multi-shot scenes, applies 9:16 smart crop (`cover` or `blur-pad`), punch-in zoom, transitions, animated subtitles, BGM ducking, and SFX!
   - `--voiceover <path.wav/.mp3/.m4a>`: Uses your recorded voiceover directly (bypassing robotic offline TTS!), cuts dead-air, aligns word-by-word captions to your voice, and renders either 3D/Cutaway/Opus procedural visuals OR overlays your raw video!
   - `--transcript <path.txt/.srt or text>` & `--topic "<Topik>"`: Pairs your audio/video with exact script text or domain-grounded visual scenes.
2. Drop-folder input (`--input-dir <folder>`): Automatically discovers `.mp4/.mov`, `.wav/.mp3/.m4a`, `.png/.jpg`, and `.txt/.srt`.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILLS_ROOT = HERE.parents[1]
for _p in (HERE, SKILLS_ROOT / "mcp" / "core", SKILLS_ROOT.parent / "mcp" / "core"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import style_map as sm_mod


def run_step(cmd: list) -> dict:
    res = subprocess.run(
        cmd,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    out = res.stdout.strip()
    try:
        parsed = json.loads(out) if out.startswith("{") else {"stdout": out[-500:]}
    except Exception:
        parsed = {"stdout": out[-500:]}
    if res.returncode != 0:
        return {"ok": False, "exit_code": res.returncode, "error": res.stderr.strip()[-450:], **parsed}
    return {"ok": True, **parsed}


# ============================================================================
# RAW FOLDER INGESTION PIPELINE (drop-folder talking-head editor)
# ============================================================================

RAW_VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm"}


def load_processed_manifest(manifest_path: Path) -> dict:
    if manifest_path.is_file():
        try:
            return json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_processed_manifest(manifest_path: Path, manifest: dict):
    try:
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def scan_raw_folder(folder: Path, manifest: dict) -> list:
    """Return unprocessed raw video files in folder (skips hidden/.part/tmp and already-done entries)."""
    results = []
    if not folder.is_dir():
        return results
    for f in sorted(folder.iterdir()):
        if not f.is_file() or f.name.startswith("."):
            continue
        if f.suffix.lower() not in RAW_VIDEO_EXTS:
            continue
        if f.suffix.lower() in (".part", ".tmp", ".download", ".crdownload"):
            continue
        if manifest.get(f.name, {}).get("status") == "done":
            continue
        results.append(f)
    return results


def ffprobe_json(path: Path) -> dict | None:
    if not shutil.which("ffprobe"):
        return None
    cmd = ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", str(path)]
    res = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if res.returncode != 0:
        return None
    try:
        return json.loads(res.stdout)
    except Exception:
        return None


def normalize_raw_video(video_path: Path, output_path: Path, aspect: str = "9:16") -> dict:
    """Probe raw video, then normalize to 9:16 (center-crop), loudnorm audio, trim silence."""
    info = ffprobe_json(video_path)
    if info is None:
        return {"ok": False, "error": "ffprobe unavailable or failed"}
    vs = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), None)
    if not vs:
        return {"ok": False, "error": "No video stream found"}
    width = int(vs.get("width", 0))
    height = int(vs.get("height", 0))
    fps_raw = vs.get("r_frame_rate", "30/1")
    try:
        num, den = fps_raw.split("/")
        fps = float(num) / float(den) if float(den) > 0 else 30.0
    except Exception:
        fps = 30.0
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-nostdin", "-y", "-v", "error",
        "-i", str(video_path),
        "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,fps=" + str(int(round(fps))),
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k",
        str(output_path),
    ]
    res = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if res.returncode != 0:
        return {"ok": False, "error": res.stderr[-400:]}
    return {"ok": True, "output": str(output_path), "width": width, "height": height, "fps": fps}


def extract_audio(video_path: Path, wav_out: Path, sr: int = 16000) -> bool:
    if not shutil.which("ffmpeg"):
        return False
    wav_out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(video_path), "-vn", "-acodec", "pcm_s16le", "-ar", str(sr), "-ac", "1", str(wav_out)]
    res = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return res.returncode == 0


def transcribe_words(wav_path: Path) -> list:
    """Return word-level timestamps [{word, start, end}] using the project's narration engine."""
    try:
        sys.path.insert(0, str(SKILLS_ROOT / "reels-narration" / "scripts"))
        import script_writer as sw_mod
        if hasattr(sw_mod, "transcribe_words"):
            return sw_mod.transcribe_words(str(wav_path))
    except Exception:
        pass
    return []


def map_transcript_to_archetype(word: str, context_words: list) -> str:
    """Heuristic keyword-based mapping from transcript word + context to a talking-head archetype."""
    blob = f"{word} {' '.join(context_words)}".lower()
    if any(k in blob for k in ("prompt", "perintah", "file", "editkan", "claude", "ai", "input")):
        return "prompt_input_card"
    if any(k in blob for k in ("pertama", "kedua", "ketiga", "langkah", "siapkan", "hal", "hal-hal")):
        return "numbered_stack_list"
    if any(k in blob for k in ("style", "desain", "animasi", "fitur", "komponen", "kategori", "tag")):
        return "category_pill_cloud"
    if any(k in blob for k in ("suruh", "alur", "pipeline", "workflow", "node", "agent", "proses")):
        return "workflow_pipeline_anim"
    if any(k in blob for k in ("pribadi", "tidak", "akan", "pernah", "wajib", "harus", "detail", "jangan")):
        return "kinetic_typography_callout"
    if any(k in blob for k in ("claude", "openai", "ikut", "follow", "brand", "tool", "banding")):
        return "dual_agent_comparison"
    return "cta_follow_badge"


def build_talking_head_scenes_from_transcript(words: list, topic: str, duration_sec: float) -> list:
    """Group transcript words into semantic beats (~4s each) and assign archetypes."""
    scenes = []
    if not words:
        scenes.append({
            "id": "scene-1",
            "archetype": "kinetic_typography_callout",
            "eyebrow": topic,
            "headline": topic,
            "subcopy": "",
            "narration": topic,
            "words": [],
            "durationInFrames": int(duration_sec * 30),
            "narrationStartSec": 0.0,
        })
        return scenes
    beat_sec = 4.0
    cur_beat = []
    beat_start = float(words[0]["start"])
    beat_idx = 0
    for w in words:
        if float(w["start"]) - beat_start > beat_sec and cur_beat:
            contexts = [x["word"] for x in cur_beat[:-1]]
            scenes.append({
                "id": f"scene-{beat_idx + 1}",
                "visualMode": "talking-head",
                "subjectId": "talking-head-presenter",
                "captionStyle": sm_mod.resolve_caption_style("", idx=beat_idx, is_talking_head=True),
                "archetype": map_transcript_to_archetype(cur_beat[-1]["word"], contexts),
                "eyebrow": topic,
                "headline": " ".join(x["word"] for x in cur_beat[:6]),
                "subcopy": " ".join(x["word"] for x in cur_beat[6:12]),
                "narration": " ".join(x["word"] for x in cur_beat),
                "words": cur_beat,
                "durationInFrames": int((float(cur_beat[-1]["end"]) - beat_start) * 30),
                "narrationStartSec": beat_start,
            })
            beat_idx += 1
            cur_beat = []
            beat_start = float(w["start"])
        cur_beat.append(w)
    if cur_beat:
        contexts = [x["word"] for x in cur_beat[:-1]]
        scenes.append({
            "id": f"scene-{beat_idx + 1}",
            "archetype": map_transcript_to_archetype(cur_beat[-1]["word"], contexts),
            "eyebrow": topic,
            "headline": " ".join(x["word"] for x in cur_beat[:6]),
            "subcopy": " ".join(x["word"] for x in cur_beat[6:12]),
            "narration": " ".join(x["word"] for x in cur_beat),
            "words": cur_beat,
            "durationInFrames": int((float(cur_beat[-1]["end"]) - beat_start) * 30),
            "narrationStartSec": beat_start,
        })
    return scenes


def process_raw_folder_entry(raw_video: Path, out_dir: Path, manifest: dict, aspect: str = "9:16", style: str = "auto-context") -> dict:
    """Process one raw video: normalize, transcribe, map to archetypes, render talking head."""
    name = raw_video.name
    entry = {"name": name, "status": "processing", "raw_video": str(raw_video)}
    try:
        # 1. Normalize raw video (center-crop to 9:16, loudnorm)
        norm_dir = out_dir / "normalized"
        norm_dir.mkdir(parents=True, exist_ok=True)
        norm_path = norm_dir / f"{raw_video.stem}_norm.mp4"
        norm_result = normalize_raw_video(raw_video, norm_path, aspect=aspect)
        if not norm_result.get("ok"):
            entry["status"] = "error"
            entry["error"] = norm_result.get("error", "normalization failed")
            return entry
        # 2. Extract audio for transcription
        wav_path = out_dir / "audio" / f"{raw_video.stem}.wav"
        if not extract_audio(raw_video, wav_path):
            entry["status"] = "error"
            entry["error"] = "audio extraction failed"
            return entry
        # 3. Transcribe to word-level timestamps
        words = transcribe_words(wav_path)
        # 4. Build talking head scenes from transcript
        info = ffprobe_json(raw_video)
        duration_sec = 18.0
        try:
            duration_sec = float(info.get("format", {}).get("duration", 18.0))
        except Exception:
            pass
        topic = raw_video.stem.replace("_", " ").replace("-", " ")
        scenes = build_talking_head_scenes_from_transcript(words, topic, duration_sec)
        # 5. Write timeline for rendering
        timeline = {
            "ok": True,
            "topic": topic,
            "total_duration": duration_sec,
            "scenes": scenes,
            "raw_video": str(norm_path),
            "style": style,
            "aspect": aspect,
        }
        timeline_path = out_dir / "timeline.json"
        timeline_path.write_text(json.dumps(timeline, indent=2, ensure_ascii=False), encoding="utf-8")
        # 6. Render using smart_render.py (talking head renderer)
        render_script = HERE.parents[2] / "reels-templates" / "scripts" / "smart_render.py"
        edited_dir = out_dir / "edited"
        edited_dir.mkdir(parents=True, exist_ok=True)
        target_mp4 = edited_dir / f"{raw_video.stem}_edited.mp4"
        render_cmd = [
            sys.executable, str(render_script),
            "--workspace", str(out_dir),
            "--aspect", aspect,
            "--output", str(target_mp4),
        ]
        render_res = subprocess.run(render_cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=240)
        entry["status"] = "done" if render_res.returncode == 0 else "error"
        entry["output_mp4"] = str(target_mp4) if target_mp4.is_file() else None
        if render_res.returncode != 0:
            entry["error"] = render_res.stderr[-400:]
    except Exception as exc:
        entry["status"] = "error"
        entry["error"] = str(exc)[:400]
    return entry


def run_raw_folder_ingestion(raw_dir: Path, out_dir: Path, aspect: str = "9:16", style: str = "auto-context", watch: bool = False, poll_sec: float = 5.0) -> int:
    """Scan raw_dir for unprocessed videos, ingest each through the talking-head pipeline."""
    raw_dir = raw_dir.expanduser().resolve()
    out_dir = out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = out_dir / ".processed_videos.json"
    manifest = load_processed_manifest(manifest_path)
    results = []

    def process_once():
        nonlocal manifest
        pending = scan_raw_folder(raw_dir, manifest)
        if not pending:
            return []
        batch = []
        for raw_video in pending:
            entry = process_raw_folder_entry(raw_video, out_dir, manifest, aspect=aspect, style=style)
            manifest[entry["name"]] = entry
            batch.append(entry)
        save_processed_manifest(manifest_path, manifest)
        return batch

    results = process_once()
    summary = {
        "ok": True,
        "raw_dir": str(raw_dir),
        "out_dir": str(out_dir),
        "processed": results,
        "manifest_path": str(manifest_path),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if all(e["status"] == "done" for e in results) or not results else 1


def main():
    p = argparse.ArgumentParser(description="Shotcraft Pro v9.7 Raw Video Editor & Voiceover-to-Video Pipeline")
    p.add_argument("--input-dir", help="Optional folder containing voiceover (.mp3/.wav/.m4a), video (.mp4/.mov), or images")
    p.add_argument("--raw-dir", help="Folder to scan/watch for raw talking-head videos (.mp4/.mov/.mkv/.webm) to auto-ingest and edit")
    p.add_argument("--raw-video", help="Direct path to raw video file (.mp4/.mov/.mkv/.webm) to edit")
    p.add_argument("--watch", action="store_true", help="Keep watching --raw-dir for new files (polls every --poll-sec seconds)")
    p.add_argument("--poll-sec", type=float, default=5.0, help="Poll interval in seconds when --watch is enabled")
    p.add_argument("--voiceover", help="Direct path to recorded voiceover file (.wav/.mp3/.m4a/.ogg) to edit/sync")
    p.add_argument("--transcript", help="Optional path to .txt/.srt transcript file or raw script text")
    p.add_argument("--topic", default="", help="Optional topic description (e.g. 'Cara kerja mesin potong rumput')")
    p.add_argument("--out-dir", required=True, help="Target workspace directory")
    p.add_argument("--aspect", default="9:16", choices=["9:16", "16:9", "1:1", "4:5", "2:3"])
    p.add_argument("--style", default="auto-context", help="Any visual style ID or comma-separated per-scene styles")
    p.add_argument("--caption-style", default="auto", help="Any caption preset, comma-separated per-scene presets, or 'none'")
    p.add_argument("--font-family", default="", help="Custom font family override")
    p.add_argument("--accent-color", default="", help="Custom hex accent color override")
    p.add_argument("--headline-text", default="", help="Custom headline text override ('|'-separated per scene)")
    p.add_argument("--subcopy-text", default="", help="Custom subcopy text override ('|'-separated per scene)")
    p.add_argument("--caption-text", default="", help="Custom caption text override ('|'-separated per scene)")
    p.add_argument("--eyebrow-text", default="", help="Custom eyebrow text override ('|'-separated per scene)")
    p.add_argument("--caption-y", type=int, default=0, help="Custom vertical Y coordinate for captions")
    p.add_argument("--caption-highlight-color", default="", help="Custom hex color for active caption word highlight")
    p.add_argument("--archetype", default="", help="Custom talking-head overlay archetype")
    p.add_argument("--broll-mode", default="auto", choices=["auto", "fullscreen", "pip", "none"], help="B-roll display mode")
    p.add_argument("--video-crop", choices=["cover", "blur-pad"], default="cover", help="How raw video is framed in 9:16: cover (center crop + zoom) or blur-pad (blurred background extension)")
    p.add_argument("--noise-db", type=float, default=-35.0, help="Silence threshold in dB for dead-air removal")
    p.add_argument("--min-silence", type=float, default=0.45, help="Minimum silence duration in seconds to cut")
    p.add_argument("--max-segment-sec", type=float, default=6.0, help="Maximum scene length before splitting at acoustic valley")
    p.add_argument("--bgm-track", default="", help="Optional BGM track filename")
    p.add_argument("--sfx-pack", default="", help="Optional SFX pack name")
    p.add_argument("--generate-3d-clips", action="store_true")
    p.add_argument("--render-mp4", action="store_true", help="Automatically scaffold, render final MP4, and run QA")
    p.add_argument("--output-mp4", help="Optional target MP4 path when --render-mp4 is enabled")
    a = p.parse_args()

    out_dir = Path(a.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    audios = []
    videos = []
    images = []
    texts = []

    if a.raw_video:
        rv = Path(a.raw_video).expanduser().resolve()
        if not rv.is_file():
            print(json.dumps({"ok": False, "error": f"Raw video file not found: {rv}"}))
            return 1
        videos.append(rv)

    if a.voiceover:
        vo = Path(a.voiceover).expanduser().resolve()
        if not vo.is_file():
            print(json.dumps({"ok": False, "error": f"Voiceover file not found: {vo}"}))
            return 1
        audios.append(vo)

    if a.input_dir:
        in_dir = Path(a.input_dir).expanduser().resolve()
        if in_dir.is_file():
            if in_dir.suffix.lower() in (".mp4", ".mov", ".mkv", ".webm"):
                videos.append(in_dir)
            elif in_dir.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg", ".flac"):
                audios.append(in_dir)
        elif in_dir.is_dir():
            audios.extend(sorted([f for f in in_dir.iterdir() if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg", ".flac")]))
            videos.extend(sorted([f for f in in_dir.iterdir() if f.is_file() and f.suffix.lower() in (".mp4", ".mov", ".mkv", ".webm")]))
            images.extend(sorted([f for f in in_dir.iterdir() if f.is_file() and f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")]))
            texts.extend(sorted([f for f in in_dir.iterdir() if f.is_file() and f.suffix.lower() in (".txt", ".md", ".srt", ".vtt")]))

    # --- Raw folder ingestion mode (--raw-dir takes priority) ---
    if a.raw_dir:
        raw_dir = Path(a.raw_dir).expanduser().resolve()
        return run_raw_folder_ingestion(raw_dir, out_dir, aspect=a.aspect, style=a.style, watch=a.watch, poll_sec=a.poll_sec)

    # Determine editing mode:
    # - `raw-video-with-voiceover`: Both raw video AND custom voiceover provided (cuts & timing driven by voiceover, visuals from raw video)
    # - `raw-video-edit`: Raw video provided (cuts & timing driven by video's audio track, visuals from raw video)
    # - `voiceover-to-video`: Voiceover provided without raw video (cuts & timing driven by voiceover, visuals generated by 3D/Cutaway/Opus stage)
    if videos and audios:
        mode = "raw-video-with-voiceover"
        timing_master = audios[0]
    elif videos:
        mode = "raw-video-edit"
        timing_master = videos[0]
    elif audios:
        mode = "voiceover-to-video"
        timing_master = audios[0]
    else:
        mode = "zero-asset-procedural"
        timing_master = None

    cuts_json = out_dir / "auto_cuts.json"
    analysis_json = out_dir / "media_analysis.json"
    timeline_json = out_dir / "timeline.json"
    trimmed_narr_wav = out_dir / "narration.wav"

    eff_transcript = a.transcript or (str(texts[0]) if texts else "")
    eff_topic = a.topic or (Path(timing_master).stem.replace("_", " ").replace("-", " ") if timing_master else "Cara kerja mesin potong rumput")

    if timing_master:
        subprocess.run(
            [
                sys.executable,
                str(HERE / "auto_cut_video.py"),
                "--input", str(timing_master),
                "--output-json", str(cuts_json),
                "--noise-db", str(a.noise_db),
                "--min-silence", str(a.min_silence),
                "--max-segment-sec", str(2.4 if (videos and a.max_segment_sec == 6.0) else a.max_segment_sec),
                "--export-trimmed-audio", str(trimmed_narr_wav),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            check=True,
        )
        # If both raw video and voiceover were supplied, ensure cuts_json references the raw video for visual frame extraction
        if not trimmed_narr_wav.is_file() and shutil.which("ffmpeg"):
            subprocess.run(
                ["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", str(timing_master), "-ar", "48000", "-ac", "1", "-c:a", "pcm_s16le", str(trimmed_narr_wav)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                check=False,
            )
        if videos and audios:
            c_data = json.loads(cuts_json.read_text(encoding="utf-8"))
            c_data["input"] = str(videos[0])
            c_data["voiceover_input"] = str(audios[0])
            cuts_json.write_text(json.dumps(c_data, indent=2, ensure_ascii=False), encoding="utf-8")

        cmd_an = [
            sys.executable,
            str(HERE / "analyze_media.py"),
            "--cuts-json", str(cuts_json),
            "--topic", eff_topic,
            "--audio-wav", str(trimmed_narr_wav),
            "--output-json", str(analysis_json),
        ]
        if eff_transcript:
            cmd_an.extend(["--transcript-file", eff_transcript])
        subprocess.run(cmd_an, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, check=True)
    else:
        sys.path.insert(0, str(SKILLS_ROOT / "reels-narration" / "scripts"))
        import script_writer as sw_mod
        gen = sw_mod.generate_indonesian_scenes(eff_topic, style=a.style, duration_sec=18.0)
        phrases = []
        cur_t = 0.0
        for i, sc in enumerate(gen["scenes"]):
            dur = round(int(sc.get("durationInFrames", 120)) / 30.0, 3)
            phrases.append({
                "id": sc["id"],
                "source_start": cur_t,
                "source_end": round(cur_t + dur, 3),
                "timeline_start": cur_t,
                "timeline_end": round(cur_t + dur, 3),
                "duration": dur,
                "headline": sc["headline"],
                "text": sc["subcopy"],
                "eyebrow": sc.get("eyebrow", f"TAHAP 0{i+1}"),
                "windowTitle": sc.get("windowTitle", ""),
                "windowContentLines": sc.get("windowContentLines", []),
                "callouts": sc.get("callouts", []),
                "subjectId": sc.get("subjectId", "system-mechanism"),
                "mechanismStep": sc.get("mechanismStep", f"step-{i+1}"),
                "zoom": 1.08,
            })
            cur_t = round(cur_t + dur, 3)
        analysis_json.write_text(json.dumps({"ok": True, "topic": eff_topic, "total_duration": cur_t, "phrases": phrases}, indent=2, ensure_ascii=False), encoding="utf-8")

    resolved_style = sm_mod.resolve_style_id(a.style, default_style="ref3-cutaway-mechanism")
    subprocess.run(
        [
            sys.executable,
            str(HERE / "auto_storyboard.py"),
            "--analysis-json", str(analysis_json),
            "--output-timeline", str(timeline_json),
            "--style", resolved_style,
            "--caption-style", a.caption_style,
            "--video-crop", a.video_crop,
        ],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        check=True,
    )

    generated_3d = []
    if a.generate_3d_clips and images:
        depth_script = skills_root / "reels-depth-motion" / "scripts" / "depth_engine.py"
        clips_dir = out_dir / "public" / "depth_clips"
        clips_dir.mkdir(parents=True, exist_ok=True)
        for idx, img in enumerate(images[:4]):
            out_clip = clips_dir / f"depth_{idx:02d}.mp4"
            subprocess.run(
                [sys.executable, str(depth_script), "--input", str(img), "--output", str(out_clip), "--frames", "60", "--fps", "30"],
                stdin=subprocess.DEVNULL,
                check=True,
            )
            generated_3d.append(str(out_clip))

    render_result = None
    if a.render_mp4 and timeline_json.is_file():
        one_shot_script = skills_root / "reels-production" / "scripts" / "one_shot_produce.py"
        target_mp4 = Path(a.output_mp4).expanduser().resolve() if a.output_mp4 else (out_dir / "out" / "final_reel.mp4")
        os_cmd = [
            sys.executable,
            str(one_shot_script),
            "--workspace", str(out_dir),
            "--topic", eff_topic,
            "--scenes-json", str(timeline_json),
            "--style", resolved_style,
            "--aspect", a.aspect,
            "--output-mp4", str(target_mp4),
        ]
        if a.bgm_track:
            os_cmd.extend(["--bgm-track", a.bgm_track])
        if a.sfx_pack:
            os_cmd.extend(["--sfx-pack", a.sfx_pack])
        if a.caption_style and a.caption_style != "auto":
            os_cmd.extend(["--caption-style", a.caption_style])
        for _flag_attr, _cli_flag in [
            ("font_family", "--font-family"),
            ("accent_color", "--accent-color"),
            ("headline_text", "--headline-text"),
            ("subcopy_text", "--subcopy-text"),
            ("caption_text", "--caption-text"),
            ("eyebrow_text", "--eyebrow-text"),
            ("caption_highlight_color", "--caption-highlight-color"),
            ("archetype", "--archetype"),
            ("broll_mode", "--broll-mode"),
        ]:
            val = getattr(a, _flag_attr, None)
            if val:
                os_cmd.extend([_cli_flag, str(val)])
        if getattr(a, "caption_y", 0) and int(a.caption_y) > 0:
            os_cmd.extend(["--caption-y", str(a.caption_y)])
        if trimmed_narr_wav.is_file():
            os_cmd.append("--no-narration")
        render_result = run_step(os_cmd)

    cuts_summary = json.loads(cuts_json.read_text(encoding="utf-8")) if cuts_json.is_file() else {}
    summary = {
        "ok": True if not render_result else render_result.get("ok", False),
        "mode": mode,
        "topic": eff_topic,
        "workspace": str(out_dir),
        "raw_video_used": str(videos[0]) if videos else None,
        "voiceover_used": str(audios[0]) if audios else None,
        "trimmed_narration_wav": str(trimmed_narr_wav) if trimmed_narr_wav.is_file() else None,
        "auto_cuts": {
            "original_duration_sec": cuts_summary.get("original_duration"),
            "active_duration_sec": cuts_summary.get("active_duration"),
            "scenes_cut_count": cuts_summary.get("segments_count"),
        },
        "timeline_json": str(timeline_json),
        "generated_3d_clips": generated_3d,
        "rendered_video": render_result,
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if summary["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
