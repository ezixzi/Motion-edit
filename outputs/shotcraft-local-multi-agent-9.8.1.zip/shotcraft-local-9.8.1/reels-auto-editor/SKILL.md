---
name: reels-auto-editor
description: Smart Drop-Folder Voiceover-to-Video & Raw Video Auto-Cut pipeline. Scans a folder for audio (.mp3/.wav/.m4a) or video (.mp4/.mov), removes dead-air silences, segments speech, and builds a ready-to-render Remotion project with Opus 5.5 procedural visuals, 3D depth parallax, punch-in zooms, and karaoke subtitles.
---

# Smart Drop-Folder Auto-Editor (`reels-auto-editor` v5.0)

Drop any voiceover recording (`.mp3`, `.wav`, `.m4a`) or raw talking-head/screen-recording video (`.mp4`, `.mov`) plus optional images into a folder, then run `scripts/auto_media_pipeline.py`:

```sh
python "<this-skill>/scripts/auto_media_pipeline.py"   --input-dir "./drop-folder"   --out-dir "./workspace-auto"   --aspect 9:16   --generate-3d-clips
```

## Pipeline Stages

1. **Silence Detection & Dead-Air Auto-Cut (`auto_cut_video.py`)**:
   - Uses `ffmpeg silencedetect` (`-35dB`, `> 0.45s`) with a `0.08s` natural breath buffer to strip dead air from raw video or audio.
2. **Speech Segmentation & Landmark Extraction (`analyze_media.py`)**:
   - Detects speech phrases, computes energy envelopes, and generates deterministic word-level karaoke timestamps (`remotion-subtitles.json`).
3. **Content-Aware Storyboard & Opus 5.5 / 3D Mapping (`auto_storyboard.py`)**:
   - Maps each phrase to a visual mode (`neural-network`, `energy-waves`, `speed-pulse`, `supercomputer-core`, or 3D Depth Parallax if images are present in the folder) and generates a ready-to-render Remotion workspace!
