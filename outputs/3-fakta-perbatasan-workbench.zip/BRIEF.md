# Three borders / geography dossier

Mode: autonomous creation, inherited explicit user preference. Use video-shotcraft. New authoring in /tmp/borders-shotcraft only; no application/repository source changes. Deliver final MP4s to ezixzi/Motion-edit/outputs, and a standalone generated-project ZIP because the new request explicitly asks for Motion Workbench readiness.

## Requirements and decisions

1080x1920 vertical, 30fps, 1200 frames / exactly 40.000s. No logos, watermarks, crests, brand marks, flag graphics, or third-party UI. Indonesian synthetic voice, exact requested sentences and slots, instrumental background plus camera/paper/air Foley. First five seconds are an intentional visual/music introduction; specified voice sentences start at 5s. No extra opening narration. Voice sentence durations fitted independently, with phrase boundaries exported for captions and animations.

Direction candidates: (1) warm paper atlas, (2) dark diplomatic dossier, (3) bright travel magazine. Choose (2) with a porcelain opening and deep ocean-blue dossier interiors. Existing geography output used paper/terracotta; this request's mask, camera flash, spotlight and exploded layers suit ocean ink, cyan geographic lines and orange borders. Tokens: background #071727, surface #102d43, white #f4f4ee, muted #b4c7d1, cyan #79e3ec, orange #ffad67; sans bold / semibold / regular local WOFF2. Sharp cartographic diagrams and abundant negative space. 96px horizontal margin, 150px top, primary title 76–118px, captions64px anchored80px above bottom, auxiliary40–44px. No actual product/web UI is represented: all diagrams are original schematic illustrations, not precise maps/cadastral boundaries.

Styleframes skipped because all six specified motion recipes already constrain framing; first rendered stills validate the adapted portrait design before full rendering.

## Single-source timeline / storyboard

| Shot | Frames | Seconds | Motion, content, source |
|---|---|---|---|
| hook | 0–104 | 0–3.5 | text-as-mask: complete requested title cut into porcelain; dark animated atlas drifts inside thick strokes; 8f breath and logarithmic 46x counter-compensated takeover; exact visual hook below |
| stack | 105–149 | 3.5–5 | card-stack: three representative geography cards spring from below into a pile, fan as one object then select; original diagrams |
| fact1 | 150–449 | 5–15 | paparazzi three views/three flashes at local0/22/40; same house diagram cropped wide/medium/detail, 70f settled hold; spotlight text begins local114, 113f pendulum +20f iris; exact requested card text |
| fact2 | 450–749 | 15–25 | paparazzi same island diagram wide/medium/detail and same22/18f spacing; spotlight after114; original river island and alternating administration tags; exact requested card text |
| fact3 | 750–1049 | 25–35 | paparazzi same island-pair diagram, hold; exploded-view local114–284 with54° tilt, five150/270/400/520/640-depth components, spring15/120,5f stagger, reverse14f assembly/3f stagger and8px seat response; requested card text kept in readable editorial heading |
| outro | 1050–1199 | 35–40 | card-flock-tumble: same3geography cards, Catmull-Rom44f flight, continuous idle,10f contraction, single turbulent ring,14f headline landing and CTA hold; exact CTA |

## Recipe mapping and fidelity

Library lookup: text-as-mask → opening/text-as-mask/TextAsMask.tsx; card-stack → ui-entrance/card-stack/CardStack.tsx; paparazzi-flash → rhythm/beat-cut-moves/PaparazziFlash.tsx; spotlight-sweep → effects/light-play-moves/SpotlightSweepReveal.tsx; exploded-view → camera/space-camera-moves/ExplodedView.tsx; card-flock-tumble → transition/card-flock-tumble/CardFlockTumble.tsx. All main instructions, six cards and exact TSX read; reference MP4s/contact sheets in reference/.

Explicit adaptations imposed by user timing: mask recipe165f compressed to105f, maintaining8f breath,24f rush,46x and inverse content transform; drift time/landing hold reduced. Three-card stack45f vs nine-card150f: spring13/150 preserved; compressed3starts then fan20/95 with130%pivot. Paparazzi30f lead-in removed so first flash lands at segment start, then22f/18f spacing,4f decay,6f settle,70f final hold; spotlight follows after the held photo. User explicitly requests paparazzi three times and spotlight twice, overriding recipe one-use/P4 and aggregate light-effect limits. Keep three crops of the same subject, not unrelated footage. Three flash set-pieces count three R4 uses; final core is localized with no full-screen exposure to avoid fourth global hit. No music-driven camera pumping. Original slow instrumental instead of strong drums to serve voice, deliberately adapted S1.

Explicit R1/R2 exceptions: the user's3.5s mask slot has only5frames of full takeover hold (f100–104), below the recipe30frames; title itself is held legibly earlier. The user's1.5s stack slot leaves no0.5s settled fan hold. Preserve exact segment boundaries over the longer recipe's rest budgets; settling continues up to the cut. C3 adaptation: the full requested fact headline is an editorial screen-space heading, separate from the3D diagram; the diagram's own labels remain within its perspective.

Factual context: supplied narration is preserved word for word. On-screen factual context distinguishes shared sovereignty/rotating administration for Pheasant (1659 treaty;1861 rotation convention), front-door nationality/address for Baarle (tax follows applicable jurisdiction), and21h standard/20h daylight-saving difference for Diomede. These clarify supplied simplifications rather than presenting animated diagrams as maps. No claim of fresh external legal/historical verification. No claim that shared ownership literally changes every6months beyond user-supplied wording.

## Workbench

src/timeline.ts is sole timing source. src/workbench.ts imports SHOTS, TRANSITIONS, CAPTIONS and audio registry; scene text/colors/font sizes exposed with schema. Scenes, camera flash transitions, captions, voice, Foley and music on separate tracks. original points to Main for parity. Project ZIP contains all source and media needed to reproduce; no node_modules or raw voice intermediates. Reusable setup README includes npm install, render and Workbench open command.

## Audio and review

Voice generated offline with existing Piper Indonesian news_tts/sherpa ONNX, tempo fitted to10/10/10/5s with5s opening silence. Raw and processed durations recorded. This is synthetic speech; no listening/subjective pronunciation claim unless actually audited. Original deterministic music, licensed skill Foley with provenance. AAC48k stereo same Remotion4.0.484 pipeline; prior2048sample delay to be cross-checked on final output and compensated for Foley. Final MP4 must decode, contain1200video frames,40.000s video, no clipping, and end cleanly. Independent fresh-context review per video-shotcraft mandatory before delivery.

Final packaging: raw renders retained in reference/main-rendered.mp4 and reference/nobgm-rendered.mp4. Remotion output video40.000000s/1200frames but AAC40.042667s. Final pair preserves main video packets byte-for-byte; each version retains its own independently rendered audio, decoded and trimmed at1,920,000samples and encoded AAC192k/48k stereo with a proper edit list. Both final video/audio/container durations40.000000s. No-BGM is not a music-removal operation: bgm=false was independently rendered from the same composition. Supplied finalize.mjs reproduces exact-duration tail packaging on new exports. Original rendering source remains the40s manifest.

Workbench verification: original/imported pixels matched at60/145/190/330/725/930/1140 before last notes/crop polish; final rerun330/635/930/1140 matched exactly except ≤1 intensity-level raster noise at330. Browser import reported no page errors and exported motion-workbench.json. Actual Workbench8frame MP4 export via its /api/export endpoint succeeded. Cloud's isolated Workbench copy replaces unavailable rsync with Node cpSync and points its render browser to existing Chromium; no application or upstream skill source modified. The editor intentionally adds1s preview headroom; renderExact exports content toframe1200.

Independent first-pair QA found13px bottom glyph margin on long Baarle caption and a Diomede diagram/footnote collision at930/960. V3 corrects all captions to64px bottom80 anchored layout (long Baarle wraps to3lines), moves Baarle note to1395, raises Diomede plate80px and gives its note an opaque padded scrim. Full corrected visual master rendered; timeline and original independent voice/Foley/music assets unchanged. V3 Workbench sampled parity265/635/930/960/1140 passes (≤1 intensity-level raster rounding); f265 rerun after final Baarle-note movement matches exactly. Final pair uses corrected master video with each previously finalized40s independent audio stream losslessly muxed, preserving audio packets and measured synchronization.
