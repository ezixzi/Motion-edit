# 3 Fakta Perbatasan — Motion Workbench

Video vertikal 1080×1920, 30 fps, tepat 1200 frame / 40 detik. Tanpa logo atau watermark.

## Render ulang

Gunakan Node.js 20 atau lebih baru. Dari folder proyek ini:

```sh
npm install
npm run render
npx remotion render src/index.tsx Borders out/3-fakta-perbatasan-tanpa-musik.mp4 --props=props-nobgm.json
```

Narasi, musik dan efek suara sudah tersedia di `public/audio/`. Tidak memerlukan layanan TTS atau API berbayar untuk render ulang. `voice.py` dan `audio.py` adalah catatan proses pembuatan; tidak perlu dijalankan untuk membuka proyek atau mengekspor video.

## Buka di Motion Workbench

Unduh/pasang video-shotcraft dari https://github.com/Vincentwei1021/video-shotcraft, lalu jalankan dari folder video-shotcraft:

```sh
node workbench/scripts/open.mjs /path/ke/borders-shotcraft
```

Workbench otomatis membaca `src/workbench.ts` dan mengimpor film menjadi track shot, transisi, subtitle, narasi, efek suara, dan musik. Teks kartu, warna aksen, ukuran huruf dan subtitle dapat diubah lewat panel Properties. `motion-workbench.json` adalah salinan timeline yang telah diimpor; gunakan setelah proyek ini ditautkan agar semua komponen tersedia.

Pratinjau editor bisa menampilkan 41 detik karena Workbench memberi ruang kosong 1 detik untuk mengedit. Tombol **Export video** memakai akhir konten yang tepat, yaitu 40 detik. Jangan menambahkan klip setelah frame 1199 jika ingin mempertahankan durasi.

Berkas final yang dikirim sudah memiliki durasi video, audio dan container tepat40,000detik. Saat mengekspor ulang, beberapa encoder AAC menambah sekitar43milidetik padding di metadata audio. Jika perlu menghapus padding itu tanpa mengubah gambar, pasang FFmpeg lalu jalankan `node finalize.mjs hasil-export.mp4 hasil-export-40s.mp4`.

Di cloud sesi pembuatan ini, proyek telah ditautkan dan berjalan di http://localhost:5200/?import=project. Alamat tersebut hanya berlaku ketika environment masih aktif dan portnya dapat diakses oleh klien.

## Isi dan waktu

0–3,5: text-as-mask; 3,5–5: card-stack; 5–15: Baarle; 15–25: Pheasant; 25–35: Diomede; 35–40: card-flock-tumble. Ketiga fakta diawali paparazzi-flash; dua fakta pertama memakai spotlight-sweep, fakta ketiga memakai exploded-view.

Naskah narasi pengguna dipertahankan. Catatan layar menambahkan konteks: Pheasant berada di bawah kedaulatan bersama dengan pengelolaan bergilir (perjanjian 1659, konvensi pergiliran 1861); pintu depan Baarle menentukan alamat/kewarganegaraan rumah; selisih Diomede 21 jam saat waktu standar AS dan 20 jam saat daylight saving di Alaska. Ilustrasi bersifat skematis.

## Sumber aset

Ilustrasi SVG dan komposisi musik dibuat khusus untuk video ini. Tata gerak diadaptasi dari enam resep video-shotcraft yang diminta pengguna. Efek suara berasal dari perpustakaan skill; daftar berkas dan sumber lisensinya ada di `audio-cues.json` dan `ASSET-PROVENANCE.md`. Font berasal dari aset workspace yang sudah digunakan pada video sebelumnya. Voiceover sintetis Indonesia menggunakan model Piper `id_ID-news_tts-medium` via sherpa-onnx; tidak meniru suara tokoh tertentu. Izin masing-masing mesin/font/model tetap mengikuti pemiliknya.

Kode aplikasi repository Motion-edit tidak dimodifikasi. ZIP ini adalah proyek video baru yang berdiri sendiri.
