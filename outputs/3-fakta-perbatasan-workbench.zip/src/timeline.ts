import phrases from './voice-phrases.json';
export const FPS=30;
export const TOTAL=1200;
export const SHOTS=[
 {id:'hook',label:'01 · Text as mask',from:0,duration:105,kind:'hook',text:'3 PERBATASAN NEGARA PALING ANEH DI DUNIA',accent:'#79e3ec',fontSize:118},
 {id:'stack',label:'02 · Three fact cards',from:105,duration:45,kind:'stack',text:'Tiga tempat. Tiga kejutan.',accent:'#79e3ec',fontSize:78},
 {id:'baarle',label:'03 · Baarle / Spotlight',from:150,duration:300,kind:'baarle',text:'01 • Kota Baarle: Garis Negara Membelah Rumah Warga',accent:'#ffad67',fontSize:82},
 {id:'pheasant',label:'04 · Pheasant / Spotlight',from:450,duration:300,kind:'pheasant',text:'02 • Pulau Pheasant: Ganti Negara Tiap 6 Bulan',accent:'#79e3ec',fontSize:82},
 {id:'diomede',label:'05 · Diomede / Exploded view',from:750,duration:300,kind:'diomede',text:'03 • Pulau Diomede: Jarak 3,8 Km Beda Waktu 21 Jam',accent:'#afbcff',fontSize:82},
 {id:'outro',label:'06 · Card flock tumble',from:1050,duration:150,kind:'outro',text:'Simpan video ini dan bagikan ke temanmu yang suka geografi!',accent:'#79e3ec',fontSize:90},
] as const;
export const FLASH_OFFSETS=[0,22,40];
export const TRANSITIONS=SHOTS.filter(s=>['baarle','pheasant','diomede'].includes(s.kind)).map(s=>({id:`flash-${s.id}`,label:`Paparazzi · ${s.id}`,from:s.from,duration:114}));
export const CAPTIONS=phrases.map((p,i)=>({id:`caption-${i}`,label:p.text,from:p.from,duration:p.group===3?Math.min(p.duration,1124-p.from):p.duration,text:p.text}));
export const AUDIO=[
 {from:0,duration:TOTAL,src:'audio/narration.wav',volume:1,label:'Narasi Indonesia'},
 {from:0,duration:TOTAL,src:'audio/foley.wav',volume:1,label:'Paper · shutters · air'},
];
export const MUSIC=[{from:0,duration:TOTAL,src:'audio/music.wav',volume:1,label:'Original instrumental'}];
