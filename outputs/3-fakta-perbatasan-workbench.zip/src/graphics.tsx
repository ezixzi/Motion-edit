import React from 'react';
export const C={bg:'#071727',surface:'#102d43',white:'#f4f4ee',muted:'#b4c7d1',cyan:'#79e3ec',orange:'#ffad67',violet:'#afbcff'};
export const Atlas:React.FC<{frame:number}>=({frame})=><svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute',inset:0}}>
 <rect width="1080" height="1920" fill={C.bg}/>
 <g transform={`translate(${-110+frame*.35} ${-25+Math.sin(frame/50)*8}) scale(1.2)`}>
  {Array.from({length:13},(_,i)=><path key={'h'+i} d={`M-200 ${i*150} Q540 ${i*150-70} 1300 ${i*150}`} stroke="#37627a" strokeWidth="2" opacity=".45" fill="none"/>)}
  {Array.from({length:11},(_,i)=><path key={'v'+i} d={`M${i*140} -200 Q${i*140-180} 800 ${i*140} 1900`} stroke="#37627a" strokeWidth="2" opacity=".45" fill="none"/>)}
  <path d="M100 480 190 380 330 400 390 490 380 570 300 600 320 700 230 720 190 620 120 590Z M340 750 410 820 450 940 410 1070 350 1130 340 1000 300 900Z M560 390 670 340 790 400 870 380 980 490 900 600 770 620 720 680 650 590 590 560Z M580 660 670 680 730 800 680 950 590 900 550 800Z M880 1040 1000 1020 1030 1120 930 1150 860 1100Z" fill="#20536a" stroke="#79e3ec" strokeWidth="5"/>
  <path d={`M-100 ${730+frame*.15} C260 460 650 1080 1200 650`} fill="none" stroke={C.orange} strokeWidth="10" strokeDasharray="20 18"/>
  <circle cx="640" cy="560" r="18" fill={C.orange}/><circle cx="640" cy="560" r="45" fill="none" stroke={C.orange} strokeWidth="3"/>
 </g>
</svg>;

export const House:React.FC<{frame?:number}>=({frame=0})=><svg viewBox="0 0 820 660" width="100%" height="100%">
 <defs><pattern id="tiles" width="52" height="52" patternUnits="userSpaceOnUse"><path d="M52 0H0V52" fill="none" stroke="#6a99a8" opacity=".2" strokeWidth="2"/></pattern></defs>
 <rect x="42" y="75" width="736" height="500" rx="24" fill="#d8e8e9"/>
 <path d="M430 76H752Q778 76 778 100V551Q778 575 754 575H430Z" fill="#f2d9bf"/>
 <rect x="42" y="75" width="736" height="500" rx="24" fill="url(#tiles)"/>
 <path d="M420 75V575" stroke={C.orange} strokeWidth="10" strokeDasharray="18 16" strokeDashoffset={-frame*.25}/>
 <path d="M50 75H770V575H50Z M50 340H300 M520 340H770" stroke="#557486" strokeWidth="17" fill="none" strokeLinejoin="round"/>
 <rect x="90" y="175" width="235" height="100" rx="22" fill="#365971"/><rect x="72" y="175" width="42" height="135" rx="12" fill="#6c8d9d"/><rect x="300" y="175" width="40" height="135" rx="12" fill="#6c8d9d"/>
 <ellipse cx="430" cy="410" rx="105" ry="62" fill="#fff5dc" stroke="#a78e77" strokeWidth="7"/>
 {[310,550].map(x=><g key={x}><rect x={x} y="385" width="40" height="65" rx="13" fill="#bb8261"/></g>)}
 <rect x="565" y="130" width="155" height="120" rx="13" fill="#7a988d"/><circle cx="606" cy="168" r="20" stroke="#e5f0df" strokeWidth="7" fill="none"/><circle cx="676" cy="213" r="17" stroke="#e5f0df" strokeWidth="7" fill="none"/>
 <path d="M155 575V480A95 95 0 0 1 250 575" fill="none" stroke="#5a7b8c" strokeWidth="6"/>
 <rect x="85" y="600" width="180" height="45" rx="12" fill={C.surface}/>
 <text x="175" y="632" textAnchor="middle" fill={C.white} fontFamily="Arial,sans-serif" fontSize="30" fontWeight="700">PINTU DEPAN</text>
 <text x="230" y="48" textAnchor="middle" fill={C.cyan} fontSize="42" fontFamily="Arial,sans-serif" fontWeight="700">BELANDA</text>
 <text x="600" y="48" textAnchor="middle" fill={C.orange} fontSize="42" fontFamily="Arial,sans-serif" fontWeight="700">BELGIA</text>
</svg>;

export const Island:React.FC<{frame?:number}>=({frame=0})=><svg width="100%" height="100%" viewBox="0 0 820 660">
 <rect x="0" y="30" width="820" height="600" rx="32" fill="#0a243b"/>
 <path d="M0 70Q120 230 290 130T600 130T820 160V0H0Z" fill="#355b61"/>
 <path d="M0 530Q180 440 320 545T600 520T820 530V660H0Z" fill="#355b61"/>
 {[0,1,2,3,4].map(i=><path key={i} d={`M-80 ${220+i*52} Q140 ${195+i*52} 350 ${230+i*52} T900 ${220+i*52}`} transform={`translate(${(frame*.5)%35} 0)`} stroke="#477d93" strokeWidth="3" fill="none" opacity=".45"/>)}
 <path d="M155 330Q190 242 350 254Q540 228 675 325Q592 405 398 414Q250 416 155 330Z" fill="#6da38a" stroke="#b3d4ac" strokeWidth="7"/>
 <path d="M310 321Q390 298 510 325" stroke="#b6d4af" strokeWidth="12" fill="none" strokeLinecap="round"/>
 <rect x="390" y="290" width="37" height="64" rx="3" fill="#ead8bb"/><path d="M379 290 408 268 438 290" fill="#dbc295"/>
 <text x="410" y="95" fill={C.white} textAnchor="middle" fontSize="42" fontFamily="Arial,sans-serif" fontWeight="700">PRANCIS</text>
 <text x="410" y="607" fill={C.white} textAnchor="middle" fontSize="42" fontFamily="Arial,sans-serif" fontWeight="700">SPANYOL</text>
 <text x="410" y="477" fill={C.cyan} textAnchor="middle" fontSize="37" fontFamily="Arial,sans-serif">Sungai Bidasoa</text>
</svg>;

export const Islands:React.FC<{frame?:number}>=({frame=0})=><svg viewBox="0 0 820 660" width="100%" height="100%">
 <rect width="820" height="660" rx="30" fill="#0b2940"/>
 {[0,1,2,3,4,5].map(i=><path key={i} d={`M0 ${70+i*90}Q190 ${20+i*90} 400 ${80+i*90}T820 ${70+i*90}`} fill="none" stroke="#335d75" strokeWidth="2"/>)}
 <path d="M115 310 145 220 227 171 305 239 324 350 276 420 164 416 99 357Z" fill="#729bb6" stroke="#d6e8ed" strokeWidth="7"/>
 <path d="M529 320 583 264 654 279 705 366 662 425 586 412Z" fill="#91a78b" stroke="#dfecdc" strokeWidth="7"/>
 <path d="M420 25V635" stroke={C.orange} strokeWidth="6" strokeDasharray="16 13" strokeDashoffset={-frame*.1}/>
 <path d="M330 328H525M330 314V342M525 314V342" stroke={C.white} strokeWidth="4"/>
 <text className="distance" x="426" y="291" fill={C.white} fontSize="44" textAnchor="middle" fontWeight="700" fontFamily="Arial,sans-serif">3,8 km</text>
 <text x="213" y="495" fill={C.white} fontSize="42" textAnchor="middle" fontWeight="700" fontFamily="Arial,sans-serif">RUSIA</text>
 <text x="615" y="495" fill={C.white} fontSize="42" textAnchor="middle" fontWeight="700" fontFamily="Arial,sans-serif">AMERIKA</text>
 <text x="410" y="594" fill={C.orange} fontSize="34" textAnchor="middle" fontFamily="Arial,sans-serif">GARIS BATAS TANGGAL</text>
</svg>;

export const FactArt:React.FC<{index:number;frame?:number}>=({index,frame=0})=>index===0?<House frame={frame}/>:index===1?<Island frame={frame}/>:<Islands frame={frame}/>;
export const GeographyCard:React.FC<{index:number}>=({index})=><div style={{width:560,height:400,background:C.surface,border:'2px solid #527286',borderRadius:22,overflow:'hidden',boxShadow:'0 28px 58px #0006',color:C.white,position:'relative',fontFamily:'GeoSans, sans-serif'}}>
 <div style={{position:'absolute',left:24,top:20,fontSize:34,fontWeight:700,color:[C.orange,C.cyan,C.violet][index]}}>0{index+1}</div>
 <div style={{position:'absolute',left:90,top:26,fontSize:29,fontWeight:600}}>{['BAARLE','PHEASANT','DIOMEDE'][index]}</div>
 <div style={{position:'absolute',left:28,right:28,top:76,bottom:20}}><FactArt index={index}/></div>
</div>;
