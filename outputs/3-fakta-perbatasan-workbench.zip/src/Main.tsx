import React from 'react';
import {AbsoluteFill,Audio,Sequence,staticFile} from 'remotion';
import {SHOTS,TRANSITIONS,CAPTIONS,AUDIO,MUSIC,TOTAL} from './timeline';
import {Hook,Stack,FactScene,Diomede,Outro,Flash,Caption} from './scenes';
import {C} from './graphics';
export const COMPONENTS={hook:Hook,stack:Stack,baarle:FactScene,pheasant:FactScene,diomede:Diomede,outro:Outro};
export const sceneProps=(s:typeof SHOTS[number])=>({text:s.text,accent:s.accent,fontSize:s.fontSize,...(s.kind==='pheasant'?{index:1}:s.kind==='baarle'?{index:0}:{})});
export const Main:React.FC<{bgm?:boolean}>=({bgm=true})=><AbsoluteFill style={{background:C.bg}}>
 {SHOTS.map(s=>{const Comp=COMPONENTS[s.kind];return <Sequence key={s.id} from={s.from} durationInFrames={s.duration}><Comp {...sceneProps(s)}/></Sequence>})}
 {CAPTIONS.map(c=><Sequence key={c.id} from={c.from} durationInFrames={c.duration}><Caption text={c.text}/></Sequence>)}
 {TRANSITIONS.map(t=><Sequence key={t.id} from={t.from} durationInFrames={t.duration}><Flash/></Sequence>)}
 {[...AUDIO,...(bgm?MUSIC:[])].map(a=><Sequence key={a.src} from={a.from} durationInFrames={Math.min(a.duration,TOTAL-a.from)}><Audio src={staticFile(a.src)} volume={a.volume}/></Sequence>)}
</AbsoluteFill>;
