import json,wave,subprocess
from pathlib import Path
import numpy as np
import sherpa_onnx

r=Path(__file__).parent;sr=48000
m=Path('/tmp/geography-motion/vits-piper-id_ID-news_tts-medium')
tts=sherpa_onnx.OfflineTts(sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'id_ID-news_tts-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=2,provider='cpu'),max_num_sentences=1))
groups=[
 (5,10,[
 'Di kota ini, garis batas negara membelah ruang tamu warga.',
 'Fakta pertama: di Kota Baarle, garis batas Belanda dan Belgia membelah rumah hingga kafe.',
 'Pajak rumah ditentukan dari letak pintu depannya.']),
 (15,10,[
 'Fakta kedua: Pulau Pheasant di perbatasan Prancis dan Spanyol',
 'resmi berganti negara pemilik setiap enam bulan sekali',
 'sejak tahun seribu enam ratus lima puluh sembilan.']),
 (25,10,[
 'Dan fakta ketiga: Pulau Diomede milik Rusia dan Amerika',
 'hanya berjarak tiga koma delapan kilometer,',
 'tapi beda waktunya mencapai dua puluh satu jam.']),
 (35,5,[
 'Unik banget, kan?',
 'Simpan video ini dan bagikan ke temanmu yang suka geografi!'])]

def wav(path,a,rate):
 with wave.open(str(path),'wb') as w:
  w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((np.clip(a,-1,1)*32767).astype('<i2').tobytes())

out=np.zeros(sr*40);meta=[];phrases=[]
for gi,(start,slot,texts) in enumerate(groups):
 arrays=[]
 for pi,text in enumerate(texts):
  a=tts.generate(text,sid=0,speed=1.12);s=np.asarray(a.samples);s=s[:len(s)]
  # Trim only silence at both ends to avoid wasting the tight voice slots.
  active=np.flatnonzero(np.abs(s)>.006)
  if len(active):s=s[max(0,active[0]-int(.025*a.sample_rate)):min(len(s),active[-1]+int(.07*a.sample_rate))]
  arrays.append((s,a.sample_rate,text))
 total=sum(len(s)/rate for s,rate,_ in arrays);gap=.08;available=slot-.24-gap*(len(arrays)-1)
 tempo=total/available
 cursor=start+.06
 for pi,(s,rate,text) in enumerate(arrays):
  raw=r/'qa'/f'voice-raw-{gi}-{pi}.wav';wav(raw,s,rate)
  target=(len(s)/rate)/tempo
  dest=r/'qa'/f'voice-fit-{gi}-{pi}.wav'
  subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',f'atempo={tempo:.9f},loudnorm=I=-17:TP=-2.7:LRA=7,aresample=48000,apad,atrim=0:{target:.9f}','-ar',str(sr),str(dest)],check=True)
  with wave.open(str(dest),'rb') as w:s2=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
  at=round(cursor*sr);out[at:at+len(s2)]+=s2
  phrases.append({'from':round(cursor*30),'duration':max(1,round(target*30)),'text':text,'group':gi})
  cursor+=target+gap
 meta.append({'group':gi,'start':start,'slot':slot,'raw_seconds':total,'tempo':tempo,'speech_end':cursor-gap,'word_count':len(' '.join(texts).split())})
 print(meta[-1],flush=True)
wav(r/'public/audio/narration.wav',out,sr)
(r/'voice-metadata.json').write_text(json.dumps(meta,indent=2))
(r/'src/voice-phrases.json').write_text(json.dumps(phrases,indent=2))
