import json,subprocess,wave
from pathlib import Path
import numpy as np
r=Path(__file__).parent;sr=48000;length=40*sr
t=np.arange(length)/sr;music=np.zeros(length);foley=np.zeros(length)
for start,end,notes in [(0,5,[110,164.8138,220]),(5,15,[110,130.8128,164.8138]),(15,25,[98,146.8324,196]),(25,35,[87.307,130.8128,174.614]),(35,40,[110,164.8138,220])]:
 mask=(t>=start)&(t<end);u=t[mask]-start
 env=np.minimum(1,u/.5)*np.minimum(1,(end-start-u)/.7)
 v=sum(np.sin(2*np.pi*n*t[mask])+.13*np.sin(2*np.pi*n*2.002*t[mask]) for n in notes)/3.4
 music[mask]=v*.060*env*(.92+.08*np.cos(u*.7))
# Very soft organic pulse, subordinate to the narration and physical shutters.
for at in np.arange(.5,39.5,.5):
 n=round(.18*sr);u=np.arange(n)/sr;k=np.sin(2*np.pi*(46*u+35*.02*(1-np.exp(-u/.02))))*np.exp(-u*34)*.022
 off=round(at*sr);music[off:off+n]+=k
music*=np.minimum(1,t/.6)*np.minimum(1,np.maximum(0,(40-t)/.7))
base=Path('/workspace/shotcraft-tools/assets/audio/sfx');cues=[]
shots={'hook':0,'stack':105,'baarle':150,'pheasant':450,'diomede':750,'outro':1050}
delay=2048
def cue(shot,offset,src,duration,amp):
 target=shots[shot]+offset
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(base/src),'-f','f32le','-ac','1','-ar',str(sr),'-'])
 a=np.frombuffer(raw,dtype='<f4').astype(float);peak=int(np.argmax(np.abs(a)));begin=max(0,peak-int(duration*.25*sr));a=a[begin:begin+round(duration*sr)].copy()
 fade=min(480,len(a)//4);a[:fade]*=np.linspace(0,1,fade);a[-fade:]*=np.linspace(1,0,fade)
 a/=max(1e-8,np.max(np.abs(a)));a*=amp;pk=int(np.argmax(np.abs(a)));at=round(target/30*sr)-pk-delay
 if at<0:a=a[-at:];at=0
 n=min(len(a),length-at);foley[at:at+n]+=a[:n]
 cues.append({'shot':shot,'offset':offset,'target_frame':target,'asset':src,'duration':duration,'amplitude':amp,'source_peak_sample':pk,'timeline_start_sample':at,'output_delay_compensation_samples':delay})
cue('hook',88,'transition/whoosh-fast.mp3',.55,.18)
for offset,amp,src in [(7,.12,'paper/paper-move-quick.mp3'),(12,.10,'paper/paper-page-turn.mp3'),(15,.085,'paper/paper-move-quick.mp3'),(25,.15,'paper/paper-slide.mp3')]:cue('stack',offset,src,.23,amp)
for shot in ['baarle','pheasant','diomede']:
 for offset,amp in [(0,.22),(22,.20),(40,.18)]:cue(shot,offset,'camera/click-camera.mp3',.24,amp)
for shot in ['baarle','pheasant']:cue(shot,235,'transition/swoosh-quick.mp3',.5,.10)
for offset,amp in [(138,.15),(158,.12),(248,.18)]:cue('diomede',offset,'paper/paper-slide.mp3',.4,amp)
cue('outro',25,'transition/whoosh-fast.mp3',.65,.18)
cue('outro',64,'riser/riser-cine.mp3',.65,.12)
cue('outro',74,'impact/impact-deep-whoosh.mp3',.9,.26)
cue('outro',98,'light/sparkle.mp3',.65,.07)
for name,a in [('music',music),('foley',foley)]:
 assert np.max(np.abs(a))<.8
 with wave.open(str(r/'public/audio'/f'{name}.wav'),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes((a*32767).astype('<i2').tobytes())
 print(name,'peak',float(np.max(np.abs(a))))
(r/'audio-cues.json').write_text(json.dumps(cues,indent=2))
