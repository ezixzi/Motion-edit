# Independent final review

Status: corrected v3 delivered MP4 pair independently rechecked on 2026-10-17. PASS with documented recipe adaptations and the cannot-verify limits below. No unresolved must-fix items. Both previously found layout defects are resolved in actual delivered frames.

Review basis: `BRIEF.md`, exact user requirements recorded there, `voice.py`, current `src/{scenes,graphics,timeline,Main,workbench}.tsx/.ts`, shotcraft `references/final-review.md` and complete aesthetic rules, six selected recipe cards, Gallery revision `bdd94be16d60fa8f`, corresponding exact demo TSX and `reference/` MP4 contact sheets. Reviewer did not modify production source/assets.

## Baseline and reference conflicts

- S2: The valid Gallery mapping is text-as-mask→opening/TextAsMask; card-stack→ui-entrance/CardStack; beat-cut-moves/paparazzi-flash→rhythm/PaparazziFlash; light-play-moves/spotlight-sweep→effects/SpotlightSweepReveal; space-camera-moves/exploded-view→camera/ExplodedView; card-flock-tumble→transition/CardFlockTumble. `spotlight-sweep-moves` is a different three-style card and is not the selected sweeping-title recipe.
- S3: Preview/source conflict is explicit: provided spotlight preview shows grayscale “SPOTLIGHT ON”, whereas current exact TSX shows velvet “Craft the shot.”; paparazzi preview uses generic 84,213 UI, whereas TSX uses an award card “Take 1”; exploded preview uses grayscale nine-card UI, whereas TSX uses five independently lifted modules on a 3/4 base. Flock preview has outline STRONGER vs current solid CINEMATIC. Thus pixel/subject equivalence to all previews cannot be claimed. Both preview motion and exact TSX timing are reviewed as separate evidence.
- Documented creative adaptations: portrait original schematic atlas; no real product interface is represented. Mask105f and stack45f obey exact user slots but waive recipe landing/rest durations (R1/R2); three paparazzi uses/two spotlight uses are explicit user requests (P4/light count exceptions). Slow instrumental deliberately waives S1 strong-electronic prescription. Editorial fact headings intentionally stay screen-space (C3).

## Workbench verification

Initial sample evidence below is supplemented by current v3 parity near the end of this report.

- Eight supplied parity pairs independently compared in `qa/review/parity.json`: f60/145/190/635/725/930/1140 exact; f330 maximum one intensity unit difference, consistent with rounding. These comparisons substantiate sampled picture parity only, not all-frame or final-audio parity.
- Manifest imports shared single-source timing; scenes, flashes, subtitles and mixed voice/Foley/music assets are separately represented. Main `bgm` controls music without changing picture timing.

## Final MP4 evidence

Both final files were fully decoded. 72 frames extracted directly from `out/3-fakta-perbatasan.mp4`, including every boundary and flash, are under `qa/review/fNNNN.png`; five contact sheets are `final-contact-0.jpg` through `final-contact-4.jpg`. Review script and machine-readable probes are retained in the same directory.

### Product, completeness, visual direction and data

- P1/P2/P4 ✓ Geographic educational topic, three distinct facts and save/share CTA match the brief: f30/425/725/1005/1199.
- P3 ✓ Supplied simplified narration is preserved in source. Factual clarifications appear for front-door address/jurisdiction (f425), shared sovereignty vs rotating administration and1659/1861 distinction (f725), and21h standard/20h daylight saving (f885/1005). This is compliance with the recorded brief, not independent historical/legal verification.
- F1/F2/F3 ✓ All3topics appear with distinct original diagrams; repeated paparazzi/spotlight grammar is explicitly required. Closing recap reuses3representatives without adding a fourth claim.
- V1/V3/V4 ✓ Actual extracted frames follow porcelain→ocean-ink/cyan/orange, consistent local sans typography. No unrelated source-demo logo, watermark, flag, crest or branded interface is visible in inspected frames; source contains original diagrams only. V2 ✓ Deliberate recipe timings and stable holds rather than music-driven camera pumping.
- D1/D2/D3/D4/D5 ✓ Original schematic assets, loaded fonts, no customer/internal data or sensitive screenshot material; real-product screenshot requirements are inapplicable. No private/customer content found in production scene definitions.

### Recipe fidelity and storyboard

- S1/S2 ✓ All6selected variants are present, correctly ordered: mask f0–104; stack105–149; Baarle150–449; Pheasant450–749; Diomede750–1049; flock1050–1199.
- S3/S4 mask ✓ f18/60 preserve thick mask with drifting atlas, f72 breath, f88/94 logarithmic takeover, f96/100 complete takeover; separate inverse content transform,46x and24f rush retained. Landing hold is a documented timing exception, not full165f-demo fidelity.
- S3/S4 stack ✓ f112/125/145 show sequential spring rise, pile, shared fan and middle-card selection; damping13/stiffness150, fan20/95 and130%pivot match exact TSX.3cards/45f is documented adaptation; no claim of full9card/150f reproduction.
- S3/S4 paparazzi ✓ Bright4f flashes at150/172/190,450/472/490,750/772/790; same artwork crops1/1.6/2.8;8f focus prep,6f settle,70f post-cut hold, then reset toward next technique. Final f776/794 confirm clipped AMERIKA text from older stills is fixed: zoomed labels hidden while3,8km stays visible. Omitted30f live prelude/repeated use are recorded exceptions.
- S3/S4 spotlight ✓ f300/330/385/405 and630/685/705 show dark0.07text shadow, pendulum-highlight reveal, damping to center and20f iris to full title. Exact source's50f/2.25cycle timing preserved. Portrait light geometry and editorial reskin differ from both grayscale preview and velvet source look, intentionally.
- S3/S4 exploded ✓ f864/885 assembled base;908/930/960 independently raised layers with shadows, thickness, dashed slots and orbit;998/1005 reassembled.54°→50°tilt,150/270/400/520/640depths,15/120springs,5f up/3f reverse down staggers and8px seating response retained. External numbered callouts omitted; layers carry their own original labels.
- S3/S4 flock ✓ f1050edge-on,1078/1105/1112continuous card flight/idle,1120contraction/core,1124ring,1140/1160/1199solid CTA.44f Catmull-Rom,10f contraction, single turbulent ring and74f/14f headline arrival retained. No blur on cards or particle confetti. Local core replaces full-screen micro-exposure, consistent with3flash-set-piece budget.
- S5 ✓ Original vector diagrams fit portrait compositions. S6 ✓ All6styles have available previews; no unsupported custom-only variant asserted.
- B1/B2/B4 ✓ Exact boundaries0/105/150/450/750/1050/1200, captions/narration and motion mapping match current single-source storyboard. B3: mask/stack rest shortfalls are explicitly recorded in BRIEF; spotlight titles and closing CTA receive readable landing time. CTA fully landed by1138, remains to1199 (>2s).

### Audio, alignment and technical checks

- A1 ✓ On decoded sources, music is a subordinate original instrumental, narration isolated in its own asset. Source narrator is silent0–5s. No subjective listening or pronunciation assessment was performed.
- A2/A9 ✓ Normalized cross-correlation against exact source sums at8windows per final file (2.6–3.2,5–5.3,5.65–5.95,6.2–6.6,15–15.3,25–25.3,37–37.5,38–38.5s) measures a uniform2048sample/42.667ms/1.28f rendered lag, correlation0.9988–0.99998. Foley was advanced2048samples in `audio.py`; therefore its intended attack peaks land on target frames after render lag. Narration remains1.28f after declared source position, within3f tolerance. Final packaging adds no further observed lag. Evidence: `audio-measurements.json`.
- A3: no strong-drum beat-sync claim made; music is explicitly slow instrumental. Shutters are pinned to actual cuts, not inferred music beats.
- A4 ✓ Declared outro riser1114→impact1124→sparkle1148 supports contraction→headline. These assets survive source-to-render correlations; subjective audibility/character is unverified.
- A5 ✓ All long mixed tracks explicitly duration1200f; individual source Foley fragments are clipped0.23–0.9s. A6 ✓ No digital clipping: native-stereo measured peak−5.41dBFS main and−5.6dBFS no-music, zero near-fullscale samples in decoded mono test. Note: `audio-measurements.json` uses ffmpeg mono downmix, which gains3dB relative to either stereo channel; its peak−2.40/−2.61dBFS is not the native stereo peak.
- A7 ✓ No synthetic UI-bleep library asset appears in cue registry. Camera/paper/air/light assets are identified per cue. Subjective texture still unverified without listening.
- A8 ✓ Both versions independently probed40.000000s video/audio/container,1080×1920,30fps,1200decodedvideo frames,AAC48kHzstereo,1,920,000decoded samples/channel. Encoded video-packet MD5 identical in both: `9e8c8d93fe0a3437a32cf0358e00fea3`, stronger evidence than sampled picture parity. Music is excluded by same timeline `bgm` flag and separate source mix.
- S2/S3/S4/S5 audio: cue registry identifies exact frames, durations, assets and decaying shutter amplitudes0.22→0.20→0.18. Shutter uses same sample3times (not alternating), a minor mechanical-repetition risk that cannot be judged without listening. Output-delay constant independently confirmed in final48kAAC/H264MP4 pipeline (Remotion4.0.484, ffmpeg final audio-only trim/reencode, date above).
- Ending: decoded last100ms RMS main0.000409 (mono downmix, about−67.8dBFS), no-music exactly zero; narration fitted to39.82s plus42.667ms output offset, leaving a quiet end. No truncation evident in waveform lengths. Opening no-music silence between Foley events is intentional; no extra narration added.

### Aesthetic checklist

- R1/R2: exceptions documented for exact short mask/stack slots; main titles and CTA have rest/read time. R3 ✓ Opening is3.5s with sustained title display. R4 ✓ Three full-picture paparazzi set-pieces, localized outro core; no beat-pumping.
- Q1 ✓ Original schematic content, no existing webpage imitation. Q2 ✓ Vector/HTML text stays sharp in full-size crops, CSS zoom used for close crops/flock rasterization. Small labels within exploded diagram read as supporting diagram texture; major21JAM/3,8km and editorial heading carry meaning.
- Q3 ✓ Deterministic source has no handheld/random/time noise; inspected motion samples match deliberate springs/orbit. Continuous real-time playback was not performed. Q4 ✓ No per-card glint spam; card masks crop art within rounded boundaries. Spotlight beams intentionally belong to scene, not card borders.
- Q5 ✓ Single title-mask opening. Q6 ✓ Main narrative text stays frontal and legible; explanatory diagram alone takes axis tilt. Q7: dark dimensional scene/orbit applied to exploded diagram; no actual product-object shot requirement. Q8 ✓ Outro recalls all3facts and culminates in CTA/ring; recipe's no-confetti rule governs. Q9/Q10 inapplicable: no real document/dashboard list insertion is represented.
- Q11 ✓ Full-size final f425 captions have roughly58–60px complete line extents including descenders; factual notes37–38px atf425/725/1005, above fixed56/32px criteria. Primary headings and CTA larger. Text was also inspected in270px-wide contacts; factual notes require normal portrait playback size. Corrected long caption has99px bottom glyph margin (f260/265/300/330); factual notes are separated from subtitles. Diomede notes are protected by an opaque scrim and the plate is80px higher (f930/960).
- C1/C2 ✓ Exact requested narration/captions map to the current facts; first5s intentionally intro-only. C3 ✓ Recorded editorial-heading exception; exploded layers' own labels share perspective. P1 ✓ Final MP4 decode,72actualframes and audio measurements performed by independent reviewer. P2 ✓ Card/preview motion conflicts documented. P3 inapplicable (no new ambiguous feedback). P4 exceptions explicitly required by user.

## Must fix / suggestions / cannot verify

**Must fix:** none unresolved in the corrected v3 pair.

**Resolved review findings:** initial f260/265/300/330 had a four-line caption ending at1906, only13px bottom margin. Corrected delivered frames now show3lines ending at1820,99px bottom margin; `text-v3-measurements.json` contains exact measured bounds. Initial Diomede f930/960 placed the plate behind its factual-note first line. Corrected delivered f930/960 show an80px higher plate and an opaque note scrim, with both lines clearly separated. Initial evidence retained in `qa/review/initial/`; root `qa/review/fNNNN.png` and contacts are the corrected final extraction.

**Corrected Workbench parity:** independently checked current f265/635/930/960/1140 pairs:265/635/1140 exact;930/960 max intensity difference1 with no values differing>1. `parity-v3.json` records these results. Manifest/source match v3 bottom80px/64px caption layout.

**Corrected final retest:** both video/audio/container durations40.000000s,1200video frames,1,920,000audio samples/channel. Both encoded video hashes match9e8c8d93fe0a3437a32cf0358e00fea3. All16audio-correlation probes still measure2048samples=1.28f; audio peak/end behavior unchanged. All72corrected extracted frames inspected in5contact sheets, plus native-size260/930/960/1199. Selected timing/motion and logo-free imagery retained.

**Other suggestions:** preview/source assets should eventually be synchronized in the skill gallery; no production change needed for that upstream discrepancy. Alternating shutter samples could reduce mechanical repetition, subject to actual listening.

**Cannot verify:** subjective naturalness/pronunciation of synthetic Indonesian speech; subjective soundtrack/Foley timbre and perceptual balance; uninterrupted normal-speed motion playback; fresh external legal/historical fact verification; all possible frames beyond72extracted visual samples; complete Workbench edit/export operation beyond manifest/source and supplied sampled parity. These limitations are explicit, not passed checks.

