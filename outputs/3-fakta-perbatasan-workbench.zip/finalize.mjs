// Optional exact-container duration packaging for a fresh Remotion/Workbench export.
// Preserves video packets; trims only AAC tail padding and creates a new file.
import {spawnSync} from 'node:child_process';
import {resolve,parse,join} from 'node:path';
const input=process.argv[2];
if(!input)throw new Error('Usage: node finalize.mjs input.mp4 [output-40s.mp4]');
const p=parse(resolve(input));
const output=process.argv[3]||join(p.dir,p.name+'-40s.mp4');
if(resolve(output)===resolve(input))throw new Error('Use a different output filename.');
const result=spawnSync('ffmpeg',['-n','-v','error','-i',input,'-map','0:v:0','-map','0:a:0','-c:v','copy','-af','atrim=end_sample=1920000,asetpts=PTS-STARTPTS','-c:a','aac','-ar','48000','-b:a','192k','-movflags','+faststart',output],{stdio:'inherit'});
if(result.error)throw result.error;
process.exit(result.status??1);
