# Asset provenance

- Diagrams: original SVG, generated for this commission; schematic, not official maps.
- Music: original deterministic instrumental composed in audio.py; no sampled commercial music.
- Foley: video-shotcraft assets/audio/sfx, listed by exact path in audio-cues.json. Copy of upstream audio attribution record included as AUDIO-ATTRIBUTION.md.
- Fonts: OpenAI Sans regular/semibold/bold WOFF2, reused from existing workspace assets. No independent redistribution license is claimed by this project.
- Voice: synthetic Indonesian Piper/sherpa-onnx `id_ID-news_tts-medium`, existing environment installation. Model source https://github.com/k2-fsa/sherpa-onnx/releases (Piper voices). The bundled MODEL_CARD had inconsistent language metadata; use the model publisher's actual license information before separate commercial redistribution of model weights. Model weights are not included in this ZIP.
- Motion recipes: https://github.com/Vincentwei1021/video-shotcraft ; text-as-mask, card-stack, paparazzi-flash, spotlight-sweep, exploded-view, card-flock-tumble. No branded demo artwork or logos used in final composition.
