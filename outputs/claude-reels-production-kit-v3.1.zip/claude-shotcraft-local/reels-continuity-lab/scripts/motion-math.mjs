// Original state-free helpers; no dependency on a renderer or remote service.
const finite = (...v) => {if (!v.every(Number.isFinite)) throw new Error('Finite numeric arguments required');};
export const clamp = (v,a=0,b=1) => Math.min(b,Math.max(a,v));
export function springState(t,{from=0,to=1,velocity=0,frequency=12,damping=1}={}) {
  finite(t,from,to,velocity,frequency,damping);
  if (frequency<=0 || damping<=0) throw new Error('Positive frequency/damping required');
  if (t<=0) return {position:from,velocity};
  const w=frequency,z=damping,d=from-to;
  if(Math.abs(z-1)<1e-7){const b=velocity+w*d,e=Math.exp(-w*t);return {position:to+e*(d+b*t),velocity:e*(b-w*(d+b*t))};}
  if(z<1){const wd=w*Math.sqrt(1-z*z),a=z*w,b=(velocity+a*d)/wd,e=Math.exp(-a*t),c=Math.cos(wd*t),s=Math.sin(wd*t);return {position:to+e*(d*c+b*s),velocity:e*((-a*d+b*wd)*c+(-a*b-d*wd)*s)};}
  const q=Math.sqrt(z*z-1),r1=-w/(z+q),r2=-w*(z+q),a=(velocity-r2*d)/(r1-r2),b=d-a;
  return {position:to+a*Math.exp(r1*t)+b*Math.exp(r2*t),velocity:a*r1*Math.exp(r1*t)+b*r2*Math.exp(r2*t)};
}
export function targetSequence(t,initial,changes,config={}) {
  finite(t,initial); let lastTime=-Infinity,lastTarget=initial,position=initial,velocity=0;
  for(const event of changes){finite(event.time,event.target);if(event.time<lastTime)throw new Error('Changes must be ordered');
    const delta=event.target-lastTarget;
    if(t>=event.time){const s=springState(t-event.time,{...config,from:0,to:delta,velocity:0});position+=s.position;velocity+=s.velocity;}
    lastTime=event.time;lastTarget=event.target;
  }
  return {position,velocity};
}
export function coverRadius(width,height,cx,cy){finite(width,height,cx,cy);if(width<=0||height<=0)throw new Error('Positive dimensions required');return Math.max(...[[0,0],[width,0],[0,height],[width,height]].map(([x,y])=>Math.hypot(x-cx,y-cy)));}
export function subframeTimes(frame,fps,samples=3,shutter=.5,{duration,loop=false}={}){
  finite(frame,fps,samples,shutter);if(!Number.isInteger(frame)||frame<0||fps<=0||!Number.isInteger(samples)||samples<1||shutter<0||shutter>1)throw new Error('Invalid sampling parameters');
  if(duration!==undefined && (!Number.isFinite(duration)||duration<=0))throw new Error('Invalid duration');
  if(loop && duration===undefined)throw new Error('Loops require duration');
  return Array.from({length:samples},(_,i)=>{let t=frame/fps+(samples===1?0:(i/(samples-1)-.5)*shutter/fps);
    if(loop)t=((t%duration)+duration)%duration;else t=Math.max(0,duration===undefined?t:Math.min(duration,t));return t;});
}
export function beatMap({bpm=120,beatsPerBar=4,duration,fps=60,offset=0}){
  finite(bpm,beatsPerBar,duration,fps,offset);if(bpm<=0||!Number.isInteger(beatsPerBar)||beatsPerBar<1||duration<=0||fps<=0)throw new Error('Invalid beat map');
  const step=60/bpm,events=[];const first=Math.ceil(-offset/step);
  for(let i=first;offset+i*step<duration-1e-10;i++){const time=offset+i*step;events.push({beat:i,time,frame:Math.round(time*fps),downbeat:((i%beatsPerBar)+beatsPerBar)%beatsPerBar===0});}
  return {beatSeconds:step,barSeconds:step*beatsPerBar,bars:duration/(step*beatsPerBar),events};
}
// Integrate a piecewise-linear speed curve exactly; immutable knots and random-access time.
export function integratedSpeed(t,knots){
  finite(t);if(knots.length<2)throw new Error('At least two speed knots required');
  for(let i=0;i<knots.length;i++){finite(knots[i].time,knots[i].speed);if(i&&knots[i].time<=knots[i-1].time)throw new Error('Strictly increasing knot times required');}
  if(t<=knots[0].time)return 0;let distance=0;
  for(let i=1;i<knots.length;i++){const a=knots[i-1],b=knots[i],dt=Math.min(t,b.time)-a.time;
    if(dt>0)distance+=a.speed*dt+.5*(b.speed-a.speed)/(b.time-a.time)*dt*dt;
    if(t<=b.time)return distance;
  }
  const end=knots.at(-1);return distance+(t-end.time)*end.speed;
}
