import assert from 'node:assert/strict';
import {springState,targetSequence,coverRadius,subframeTimes,beatMap,integratedSpeed} from './motion-math.mjs';
const near=(a,b,e=1e-7)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
for(const damping of [.8,1,1.3]){
 const cfg={from:14,to:90,velocity:25,frequency:12,damping};
 assert.deepEqual(springState(0,cfg),{position:14,velocity:25});
 near(springState(5,cfg).position,90,1e-6);
 const t=.2,h=1e-6;near((springState(t+h,cfg).position-springState(t-h,cfg).position)/(2*h),springState(t,cfg).velocity,1e-4);
}
const changes=[{time:0,target:1},{time:.25,target:3},{time:.6,target:-1}];
const first=targetSequence(.4,0,changes);targetSequence(4,0,changes);assert.deepEqual(targetSequence(.4,0,changes),first);
near(targetSequence(.25-1e-8,0,changes).position,targetSequence(.25+1e-8,0,changes).position,1e-6);
assert.throws(()=>targetSequence(1,0,[{time:1,target:1},{time:0,target:2}]));
const ts=subframeTimes(60,60,3,.5);near(ts[0],1-1/240);near(ts[1],1);near(ts[2],1+1/240);
assert.equal(subframeTimes(0,60,3,.5)[0],0);assert.ok(subframeTimes(0,60,3,.5,{duration:2,loop:true})[0]>1.9);
near(coverRadius(1080,1920,540,960),Math.hypot(540,960));
const b=beatMap({duration:15});assert.equal(b.events.length,30);assert.equal(b.bars,7.5);assert.equal(b.events[4].downbeat,true);
assert.equal(beatMap({duration:20}).bars,10);assert.equal(beatMap({duration:14}).events.length,28);
const knots=[{time:0,speed:0},{time:1,speed:2},{time:3,speed:2}];near(integratedSpeed(.5,knots),.25);near(integratedSpeed(2,knots),3);near(integratedSpeed(4,knots),7);
console.log('PASS: spring boundaries/velocity, random-access targets, shutter groups, aperture, beats and speed integral');
