# Claude Reels Production Kit v3.1

Paket pendamping khusus untuk Claude Code lokal. Memakai repo resmi Vincentwei1021/video-shotcraft sebagai sumber resep/demo/aset; bukan fork atau rilis resmi upstream. Tidak menimpa skill di repo. Semua kemampuan mengikuti versi clone lokal.

## Baru di v3.1: referensi visual dan prompt singkat

Video penjelasan motor yang kamu kirim telah dipelajari lewat frame: objek utuh → bagian dalam → aliran kerja → data → kesimpulan. Resep `technical-cutaway-explainer` dan panduan aset visual mencakup gambar konsisten, layer, cutaway, jalur aliran, label yang mengikuti objek, serta subtitle sesuai narasi bila diminta. Ini panduan produksi yang baru ditambahkan, belum demo animasi siap render.

Cukup gunakan prompt sederhana, misalnya:

```text
Buat Reels 45 detik tentang cara kerja kulkas, seperti referensi motor tadi.
Pakai ilustrasi bagian dalam, narasi Indonesia, dan motion yang jelas.
```

Tidak harus menyebut nama shot atau menulis JSON. Director hanya memuat skill produksi ringkas; detail motion, aset, TTS, dan referensi dibaca saat diperlukan. Inventory lengkap disimpan di disk, pencarian mengembalikan 3–5 kandidat. Ini mengurangi konteks yang dimuat di awal, bukan jaminan angka token tertentu. QA tetap dijalankan.

## Continuity motion library

Materi Prompt Motion yang kamu tempel diolah menjadi enam resep lokal. Ini panduan adaptasi, bukan plugin resmi atau salinan kode/preview situs.

| Recipe ID | Motion |
|---|---|
| continuity-product-object | Satu objek produk berubah menjadi UI/scene berikutnya |
| single-shape-ui-relay | Button, slider, toggle, tabs, chart dan command berbagi satu bentuk |
| kinetic-architecture-loop | Tipografi → bentuk → ruang3D → data → loop |
| footage-drop-carousel | Klip nyata, scan selection, carousel3D dan hero clip |
| landing-depth-flyover | Fly-over landing page dengan layer terangkat dan camera glide |
| photo-glass-print-loop | Wordmark/dot/iris/foto/glass/device/print dalam alur berkelanjutan |
| technical-cutaway-explainer | Objek utuh → cutaway → aliran/sinyal → data → kesimpulan |

Resep tetap opt-in. Tema neon, tanpa logo, SFX-only atau pilihan narrator pada brief tidak ditimpa. Contoh Dub/Distilbook tidak otomatis dijalankan. Aspect landscape/square sumber dipertahankan bila diminta; untuk Reels, layout dikomposisi ulang ke vertikal.

Tambahan teknis: helper closed-form spring, perubahan target, aperture radius, beat map, integral kecepatan kamera dan waktu subframe; panduan seek deterministik, decoding video, grup motion blur yang benar, serta batas GPU/audio/loop. Tidak ada complete renderer atau rendered demo baru yang diklaim sudah tersedia.

Contoh pemakaian:

```text
/reels-continuity-lab
Gunakan single-shape-ui-relay untuk Reels vertikal.
Satu objek berubah terus, tanpa cut. Audio mengikuti brief di bawah: narasi, musik, SFX atau kombinasinya.
Sesuaikan state dan timing dengan brief berikut lalu produksi dengan reels-director.
[TEMPEL BRIEF]
```

Discovery kini memasukkan `companion_motion_catalog` selain katalog upstream. Instruksi lengkap ada di `reels-continuity-lab/SKILL.md`; atribusi dan batas bukti ada di `references/provenance.md`. Enam resep Prompt Motion bersumber dari teks pengguna, bukan pemeriksaan demo situs. Resep ketujuh bersumber dari frame video yang diunggah; audio dan klaim teknisnya belum diverifikasi.

## Isi

| Agent | Peran |
|---|---|
| reels-director | Produksi dari brief sampai MP4 dan handoff review |
| reels-motion-director | Pemilihan shot, tipografi, motion3D dan transisi |
| reels-narrator | Naskah/narasi Indonesia, pelafalan, tempo dan timing |
| reels-reviewer | Review independen visual, teknis dan audio |

| Skill | Fungsi |
|---|---|
| shotcraft-local | Discovery seluruh katalog lokal, render terisolasi |
| reels-production | Alur produksi vertikal, safe zones, revisi dan delivery |
| reels-motion | Motion bermakna, variasi transisi, kesinambungan antarshot |
| reels-narration | Adaptor ElevenLabs/Edge TTS/Piper dan fitting waktu segmen |
| reels-qa | Pemeriksaan MP4 dan checklist visual/audio |
| reels-continuity-lab | Tujuh resep, termasuk cutaway dari studi video; beat map dan render deterministik |

Agent memakai `model: inherit`. Untuk model kuat, pilih model Opus yang tersedia di akunmu melalui `/model` sebelum mulai. Paket tidak mengaktifkan paket berbayar, mengubah provider, atau menjamin hasil identik antar-model. Orkestrasi beberapa agent dilakukan sesi Claude utama; subagent tidak diasumsikan dapat memanggil subagent lain.

## Instalasi / upgrade

Siapkan Claude Code yang sudah login, Git, Python 3.9+, Node.js/npm, FFmpeg/ffprobe. Browser headless dan dependencies render ditangani sesuai template Remotion. Narrator punya dependencies/provider terpisah (di bawah).

Ekstrak ZIP, buka terminal di folder install.py, lalu:

```sh
git clone https://github.com/Vincentwei1021/video-shotcraft.git
python install.py --repo ./video-shotcraft
```

Jika sudah memasang versi sebelumnya:

```sh
python install.py --repo "/path/ke/video-shotcraft" --upgrade
```

Gunakan `python3` di macOS/Linux atau `py` di Windows bila perlu. Repo yang sudah ada tidak perlu di-clone lagi. Installer memasang6skills ke `~/.claude/skills` dan4agents ke `~/.claude/agents`. Upgrade membuat backup versi lama di `~/.claude/.shotcraft-backups/<waktu>/`; file lain tidak disentuh. `--claude-dir <folder>` tersedia untuk instalasi/testing terpisah. Tidak menginstal dependencies, menelepon API, mengedit toolkit, atau mengunggah hasil.

Mulai ulang sesi Claude Code. Periksa `/agents` untuk agent yang terpasang. Skill bisa dipanggil `/shotcraft-local`, `/reels-production`, `/reels-motion`, `/reels-narration`, `/reels-qa`, `/reels-continuity-lab`.

## Prompt produksi

```text
Gunakan reels-director. Buat Reels 3 fakta tentang otak, 40 detik,
visual clean dan dinamis, narasi Indonesia, tanpa musik. Output MP4.
```

Prompt singkat cukup; tambahkan naskah atau aturan spesifik kalau diperlukan. Director memilih sumber motion yang relevan dan melakukan review sebelum penyerahan. Specialist motion/narator dipakai bila membantu, bukan wajib dipanggil untuk setiap video.

Tidak ada aturan permanen harus SFX-only, tanpa narasi, tanpa musik atau selalu60detik. Audio dan gaya mengikuti prompt proyek saat ini; naskah voiceover dapat menjadi dasar penggunaan narasi. Contoh prompt di atas boleh kamu ubah sesuai kebutuhan. Jika hanya SFX, tulis `SFX saja, tanpa narasi/BGM`. Tersedianya narrator tidak mengubah aturan itu. User brief selalu mengalahkan default. Upload GitHub harus kamu minta di sesi lokal; izin sesi cloud tidak otomatis berpindah.

## Narator

| Opsi | Penggunaan | Persyaratan |
|---|---|---|
| ElevenLabs | Opsi untuk audisi narasi ekspresif | Akun, voice berizin, jaringan, API key, otorisasi biaya |
| Edge TTS | Audisi Indonesia cepat | Python package edge-tts, jaringan; klien tidak resmi, layanan/ketentuan dapat berubah |
| Piper | Audio lokal/offline | Executable piper + model Indonesia kompatibel yang lisensinya sesuai; model tidak disertakan |

Jangan kirim API key ke chat. Untuk ElevenLabs, set `ELEVENLABS_API_KEY` dan `ELEVENLABS_VOICE_ID` di environment lokal secara aman; paket hanya mengecek keberadaan, tidak menampilkan nilainya. Tidak ada cloning suara otomatis.

Contoh Edge setelah kamu memilih mengirim naskah ke layanan online:

```sh
python -m venv .venv
# Aktifkan venv sesuai OS kamu, kemudian:
python -m pip install edge-tts
python reels-narration/scripts/narrate.py --manifest reels-narration/example.json --provider edge --voice id-ID-GadisNeural --allow-cloud --out-dir ./voice-demo
```

Voice alternatif: id-ID-ArdiNeural jika tersedia. ElevenLabs: ganti provider menjadi `elevenlabs` dan gunakan environment credentials. Piper: `--provider piper --model /path/model.onnx` tanpa --allow-cloud. Unduh/install model/provider sendiri sesuai dokumentasi dan lisensi; Claude dapat membantumu jika diminta.

Contoh manifest disertakan. Adaptor mengukur setiap segmen, mengizinkan kompresi tempo ringan(max1.12x default), menolak naskah terlalu panjang, lalu menyusun WAV sesuai jendela waktu. Ia tidak membuat word timestamps/forced alignment. Setiap run memakai folder baru. Hasil ini harus diaudisi dan dicampur di proyek video; script tidak menjanjikan suara terbaik tanpa mendengar contoh.

## QA dan batas verifikasi

```sh
python reels-qa/scripts/check_video.py final.mp4 --duration 60 --fps 30 --width 1080 --height 1920 --audio required --report qa/technical.json
```

Mengukur frame, durasi, resolusi,fps,strictdecode dan samplepeak/clipping. Bukan LUFS/truepeak atau penilaian estetika. SFX-only, fakta, pengucapan dan kualitas motion membutuhkan review terpisah. Jangan mengklaim listening bila tidak dilakukan.

Inventory tanpa Claude:

```sh
python shotcraft-local/scripts/discover.py --repo ./video-shotcraft --out ./capabilities.json --summary
python shotcraft-local/scripts/find_motion.py --inventory ./capabilities.json --query "bedah mesin" --limit 5
```

Inventory file tidak sama dengan semua fitur berhasil diuji. Hasil model, voice, dependency dan hardware berbeda; skill mengaudit yang tersedia dan menguji fitur yang dipakai. Untuk upstream saja tetap dapat memakai `npx skills add Vincentwei1021/video-shotcraft`; itu opsional karena wrapper membaca SKILL.md dari clone lengkap.

## Bukti pengujian paket

Lihat VALIDATION.md untuk pemeriksaan yang benar-benar dijalankan, termasuk batas belum diaudisinya TTS/provider cloud. Tidak ada API berbayar dipanggil saat membuat paket.
