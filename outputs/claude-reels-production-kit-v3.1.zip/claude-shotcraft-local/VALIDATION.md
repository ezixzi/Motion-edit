# Validation — v3.1 update

Verified in Linux on2026-10-22:

- Python sources compile;7recipe cards exist and catalog links resolve.
- Six skill directories and four agent skill references are valid.
- Fresh install, refusal to overwrite without --upgrade, and timestamped upgrade backup pass.
- Installed discovery detects seven local companion recipes in addition to the upstream catalog.
- Node math tests pass: spring initial state and analytical velocity, target continuity, seek-order independence, shutter times, aperture coverage, beat arithmetic and integrated speed.
- A synthetic6-image ffmpeg test confirms3subframes are averaged only inside each output-frame group. Two solid-color groups produce exactly two unmixed output frames.

Not verified in this update: seven full rendered recipe demonstrations, comparison to original Prompt Motion previews, browser/WebGL determinism on user hardware, local Claude runtime orchestration, commercial asset rights, or real TTS quality. No original site code, music, footage or logos are bundled. These are source-informed adaptation guides plus tested math/packaging helpers, not a claim of production benchmarks.

## Selective discovery and uploaded-video study

- Installed `--summary` output is bounded and excludes full file lists; the full inventory remains on disk.
- Bounded search tested for exact shot IDs, Indonesian card/mechanism queries and the new cutaway recipe. Result paths resolve; invalid limits and empty queries fail. Video-reference evidence is labeled separately from text-only recipe evidence.
- The director preloads only reels-production and the motion specialist only reels-motion; further instructions are available on demand. Actual Claude token costs were not benchmarked.
- Reference MP4 metadata, 62 roughly one-second frames, selected native stills and a dense 16-frame transition sequence were inspected. Audio and technical claims were not validated. No source footage or extracted stills is packaged.
- New asset and cutaway documents are guides; no new production-quality visual component has been rendered or asserted as tested.

## Earlier v2 checks (historical, not rerun in v3)


Verified in the Linux execution environment on2026-10-21:

- All bundled Python sources compile.
- Fresh installation creates5skill directories and4agent definitions with correct upstream config.
- Reinstall without --upgrade fails without replacing installed files.
- Upgrade preserves a deliberately added user file in timestamped backups.
- Read-only discovery produces catalog/demo/audio inventories from the actual upstream clone.
- Technical QA accepts a1second30fps160x284video with audio, and rejects an expected-duration mismatch.
- Narration media pipeline was tested using a MOCK Piper executable that emits a known test tone, not real speech. Segment compression/padding/offset assembly produces exact1second output.
- Overlength segment is rejected above the speed limit; no final narration master is falsely produced.
- Cloud provider invocation without --allow-cloud is rejected before synthesis.

Not tested:

- Real ElevenLabs/Edge API calls, billing/quotas, commercial license terms or any voice's perceptual quality.
- Actual Piper model inference or availability of a suitable Indonesian model.
- Claude Code runtime loading, model/agent orchestration on the user's account, Windows/macOS execution.
- A full new Reels production with this packaged agent configuration. Prior project renders do not constitute that test.

The installation scripts use Python standard library and platform-neutral paths, but only Linux execution was exercised. Node/Remotion, TTS dependencies and models are not bundled. Technical checks do not substitute for visual review, listening, source attribution or factual verification.

## Prompt-adaptive policy update

Removed the old permanent60s/SFX-only/no-VO/no-BGM/no-logo defaults. Current brief and active-project decisions govern audio/branding/duration. Voiceover-script intent is recognized. Recipe-specific restrictions remain scoped to the selected brief. Technical synthesis/QA code unchanged by this wording update.
