---
name: reels-narration
description: Produce Indonesian narration for Reels with configurable ElevenLabs, Edge TTS, or offline Piper; plan natural script timing, audition pronunciations, fit per-scene windows and sync animations to actual speech. Use when narration is requested or clearly implied by the current brief.
---

# Indonesian narration

Use the upstream video-shotcraft sound-design workflow and this narration adapter. This is an added optional capability; Do not activate it for explicit SFX-only or no-VO briefs; those exclusions are project-scoped, not permanent. Adding/installing this skill does not authorize an API call, audio upload, subscription or paid usage.

## Choose an available voice honestly

- ElevenLabs: suggested option to audition for expressive narration, not a guarantee of quality. Requires network, service account, user-chosen voice ID and `ELEVENLABS_API_KEY` in the local environment. Confirm paid cloud/provider usage is authorized before synthesis. Do not print/save keys in projects or reports. Use a licensed stock or authorized voice; do not clone a real person without permission.
- Edge TTS: quick Indonesian audition using `id-ID-GadisNeural` or `id-ID-ArdiNeural`, subject to availability. `edge-tts` is an unofficial client for an online service; requires network and may change or fail. Do not describe it as offline, guaranteed-free infrastructure, or automatically licensed for every commercial use. Check applicable terms.
- Piper: offline synthesis with an already downloaded compatible model. Verify Indonesian language and the model's license/model card; no model is bundled or promised available. Provide model path explicitly. Quality varies substantially by model. Never label a non-Indonesian voice as native Indonesian.

Choose from explicit user preference and available setup. If cloud permission/provider is missing, continue script/motion work and ask one concise necessary question. No silent paid fallback. API keys belong in secure local environment configuration, not chat. Default audio preferences in other skills must not override an explicit request for narration.

## Script and delivery

1. Preserve meaning, names and important numbers. Resolve unsupported factual claims before synthesizing. Ask before substantially shortening verbatim copy; if user authorizes summary, rewrite for natural Indonesian speech.
2. Use conversational Indonesian, meaningful sentence breaks and pauses. Expand ambiguous numbers/abbreviations for speech while retaining concise on-screen copy. Use provider-specific pronunciation dictionaries only when supported. Do not rely on punctuation to guarantee exact pauses.
3. Plan one segment per scene with absolute `start`/`end` seconds and `text`. Reserve transition space and a comfortable reading/listening pace; words-per-minute estimates are planning tools, not measured duration. A long script may simply not fit60seconds naturally.
4. Audition5–10seconds containing difficult terms/numbers before full synthesis when playback is available. Pick voice and cadence from content. Avoid exaggerated newsreader cadence. Do not claim listening/quality approval if playback was unavailable.
5. Synthesize to isolated segment files, measure duration, then fit each to its allotted window. Use the bundled adapter: `python scripts/narrate.py --manifest <json> --provider <edge|elevenlabs|piper> --out-dir <new-dir> ...`. See `example.json`. Dependencies: ffmpeg/ffprobe; edge additionally requires `edge-tts`; piper requires its executable and a local model. Cloud providers require explicit `--allow-cloud` as a local acknowledgment; this flag does not override Claude's permissions.
6. The adapter uses mild time compression only when necessary (default maximum1.12x), never silently extreme speeding. If it rejects a segment, shorten/revoice with authorization or renegotiate timing. Shorter speech is padded with silence, not slowed arbitrarily. Preserve lead/trailing room in the chosen windows. Never cut off the last word to satisfy duration.
7. The adapter emits narration.wav, raw/per-segment files and timing-report.json. These are narration assets, not a finished video. Mix SFX/BGM underneath speech with measured headroom and intelligibility. Audio-only synthesis does not prove a video was rendered.

## Animation sync and captions

Segment boundaries are exact windows, not word timestamps. The adapter does NOT perform forced alignment or output invented karaoke timing. For word-level timing, use supported provider alignment or an independently installed aligner with Indonesian support; check confidence and listen. If unavailable, use phrase/segment captions and disclose precision.

Move entrance/emphasis/settle to actual speech landmarks after audio is finalized. Let important words/numbers trigger the visual beat. Avoid endless per-word bouncing. Use silent holds where appropriate and duck SFX around consonants. Verify final encoded audio/video alignment, sample peaks and narration audibility. Preserve SFX-only user variants separately; no automatic BGM/VO addition.
