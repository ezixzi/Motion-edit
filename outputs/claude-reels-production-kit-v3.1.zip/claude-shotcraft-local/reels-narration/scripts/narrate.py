#!/usr/bin/env python3
"""Optional TTS adapters + measured scene-window fitting. No bundled voices, no forced alignment."""
import argparse, asyncio, json, math, os, shutil, subprocess, sys, urllib.request, urllib.error
from pathlib import Path

def run(cmd,**kwargs):
    r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kwargs)
    if r.returncode: raise RuntimeError('Media/provider command failed; verify executable, input and provider configuration.')
    return r.stdout

def duration(path):
    return float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)]).decode().strip())

async def edge(text,voice,path):
    try: import edge_tts
    except ImportError: raise RuntimeError('Install edge-tts in your chosen local Python environment first.')
    await asyncio.wait_for(edge_tts.Communicate(text,voice).save(str(path)),timeout=180)

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--out-dir',required=True)
    p.add_argument('--provider',choices=['edge','elevenlabs','piper'],required=True)
    p.add_argument('--allow-cloud',action='store_true');p.add_argument('--voice',default=None)
    p.add_argument('--model',help='Local Piper ONNX model path');p.add_argument('--max-speed',type=float,default=1.12)
    a=p.parse_args()
    if not all(shutil.which(x) for x in ['ffmpeg','ffprobe']): p.error('ffmpeg/ffprobe required on PATH')
    if not math.isfinite(a.max_speed) or not 1<=a.max_speed<=1.2: p.error('max-speed must be between1 and1.2; rewrite/revoice if more is needed')
    if a.provider!='piper' and not a.allow_cloud: p.error('Cloud synthesis sends script to the selected provider; supply --allow-cloud only after authorizing this')
    m=json.loads(Path(a.manifest).read_text(encoding='utf-8')); total=float(m['duration']); segments=m['segments']
    if not math.isfinite(total) or not 0<total<=600 or not isinstance(segments,list) or not 1<=len(segments)<=100: p.error('Use1–100segments and duration up to600seconds')
    previous=0.
    for s in segments:
        start,end=float(s['start']),float(s['end'])
        if not all(math.isfinite(v) for v in [start,end]) or start<previous or end<=start or end>total: p.error('Segments must be ordered, non-overlapping, finite and inside total duration')
        if not isinstance(s['text'],str) or not s['text'].strip(): p.error('Every segment needs nonempty text')
        previous=end
    key=os.environ.get('ELEVENLABS_API_KEY');voice=a.voice or os.environ.get('ELEVENLABS_VOICE_ID') if a.provider=='elevenlabs' else a.voice or 'id-ID-GadisNeural'
    if a.provider=='elevenlabs' and (not key or not voice): p.error('Set ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID locally, or supply --voice')
    if a.provider=='elevenlabs' and not all(c.isalnum() or c in '_-' for c in voice): p.error('Invalid voice ID')
    if a.provider=='piper' and (not a.model or not Path(a.model).is_file() or not shutil.which('piper')): p.error('Piper executable and compatible local --model required')
    out=Path(a.out_dir).expanduser().resolve()
    if out.exists(): p.error('Use a new output directory; existing audio is never overwritten')
    out.mkdir(parents=True); report={'provider':a.provider,'word_alignment':False,'duration':total,'segments':[],'complete':False}
    try:
        for i,s in enumerate(segments):
            raw=out/f'{i:03d}-raw.{"wav" if a.provider=="piper" else "mp3"}'
            if a.provider=='edge': asyncio.run(edge(s['text'],voice,raw))
            elif a.provider=='piper':
                run(['piper','--model',str(Path(a.model).resolve()),'--output_file',str(raw)],input=s['text'].encode('utf-8'))
            else:
                body=json.dumps({'text':s['text'],'model_id':'eleven_multilingual_v2','voice_settings':{'stability':0.5,'similarity_boost':0.75}}).encode()
                req=urllib.request.Request('https://api.elevenlabs.io/v1/text-to-speech/'+voice,data=body,headers={'xi-api-key':key,'Content-Type':'application/json','Accept':'audio/mpeg'})
                try:
                    with urllib.request.urlopen(req,timeout=180) as r: raw.write_bytes(r.read())
                except urllib.error.HTTPError as e: raise RuntimeError('ElevenLabs HTTP '+str(e.code)+'. Check provider account, authorization and quota; response body omitted.') from None
            seconds=duration(raw);window=float(s['end'])-float(s['start']);speed=max(1.,seconds/window)
            rec={'index':i,'id':s.get('id',str(i)),'start':float(s['start']),'end':float(s['end']),'raw_seconds':seconds,'speed':speed,'raw_file':str(raw)};report['segments'].append(rec)
            if speed>a.max_speed: raise RuntimeError(f'Segment {i} needs {speed:.3f}x speed, above {a.max_speed}. Shorten or revoice; raw audition retained.')
            fitted=out/f'{i:03d}-fitted.wav';samples=round(window*48000)
            run(['ffmpeg','-v','error','-n','-i',str(raw),'-af',f'atempo={speed:.10f},apad,atrim=end_sample={samples}','-ar','48000','-ac','1','-c:a','pcm_s16le',str(fitted)])
            rec['fitted_file']=str(fitted)
        cmd=['ffmpeg','-v','error','-n']
        for s in report['segments']: cmd+=['-i',s['fitted_file']]
        graph=[]
        for i,s in enumerate(report['segments']): graph.append(f'[{i}:a]adelay={round(s["start"]*48000)}S:all=1[a{i}]')
        graph.append(''.join(f'[a{i}]' for i in range(len(segments)))+f'amix=inputs={len(segments)}:normalize=0,apad,atrim=end_sample={round(total*48000)}[out]')
        final=out/'narration.wav';cmd+=['-filter_complex',';'.join(graph),'-map','[out]','-ar','48000','-ac','1','-c:a','pcm_s16le',str(final)];run(cmd)
        report.update(complete=True,output=str(final));print(str(final));return 0
    except Exception as e:
        # Provider-library exception messages can contain request metadata. Never print those.
        message=str(e) if isinstance(e,RuntimeError) else type(e).__name__+': synthesis failed; inspect local setup without exposing secrets.'
        report['error']=message;print(message,file=sys.stderr);return 2
    finally: (out/'timing-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
if __name__=='__main__': sys.exit(main())
