#!/usr/bin/env python3
"""Install companion skills/agents. --upgrade backs up existing entries; never edits upstream."""
import argparse, datetime, json, shutil, tempfile
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--repo',required=True)
    p.add_argument('--claude-dir',default=str(Path.home()/'.claude'))
    p.add_argument('--skills-dir',help='Optional override, compatible with v1 installer')
    p.add_argument('--agents-dir',help='Optional override')
    p.add_argument('--upgrade',action='store_true',help='Back up existing bundle entries before replacing')
    a=p.parse_args(); r=Path(a.repo).expanduser().resolve(); root=Path(__file__).resolve().parent
    for name in ['SKILL.md','references/pipeline.md','template/package.json']:
        if not (r/name).is_file(): p.error('Incomplete upstream clone; missing '+name)
    claude=Path(a.claude_dir).expanduser().resolve()
    sd=Path(a.skills_dir).expanduser().resolve() if a.skills_dir else claude/'skills'
    ad=Path(a.agents_dir).expanduser().resolve() if a.agents_dir else claude/'agents'
    skills=['shotcraft-local','reels-production','reels-motion','reels-narration','reels-qa','reels-continuity-lab']
    agents=['reels-director','reels-motion-director','reels-narrator','reels-reviewer']
    entries=[(root/x,sd/x,True) for x in skills]+[(root/'agents'/(x+'.md'),ad/(x+'.md'),False) for x in agents]
    for src,dst,isdir in entries:
        if not src.exists(): p.error('Incomplete bundle: '+str(src))
        if dst.is_symlink(): p.error('Refusing to replace symlink: '+str(dst))
        if dst.exists() and not a.upgrade: p.error('Already installed: '+str(dst)+'; use --upgrade to preserve a backup')
        if dst==src or src in dst.parents: p.error('Destination must be outside bundle source')
        if dst==r or r in dst.parents: p.error('Destination must be outside upstream clone')
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');installed=[];backups=[]
    try:
        with tempfile.TemporaryDirectory(prefix='shotcraft-install-') as td:
            staged=[]
            for i,(src,dst,isdir) in enumerate(entries):
                temp=Path(td)/str(i)
                if isdir: shutil.copytree(src,temp)
                else: shutil.copy2(src,temp)
                if src.name=='shotcraft-local': (temp/'config.json').write_text(json.dumps({'repo_path':str(r),'bundle_version':'3.1.0'},indent=2),encoding='utf-8')
                staged.append((temp,dst,isdir))
            for temp,dst,isdir in staged:
                dst.parent.mkdir(parents=True,exist_ok=True)
                if dst.exists():
                    # Hidden sibling is outside the active skill/agent catalog directories.
                    bdir=dst.parent.parent/'.shotcraft-backups'/stamp/dst.parent.name
                    bdir.mkdir(parents=True,exist_ok=True);backup=bdir/dst.name;dst.rename(backup);backups.append((dst,backup))
                installed.append(dst)
                if isdir: shutil.copytree(temp,dst)
                else: shutil.copy2(temp,dst)
    except Exception:
        for dst in reversed(installed):
            if dst.is_dir(): shutil.rmtree(dst)
            elif dst.exists(): dst.unlink()
        for dst,backup in reversed(backups): backup.rename(dst)
        raise
    print('Installed6 skills and4 agents. Upstream/application source unchanged.')
    for _,backup in backups: print('Backup: '+str(backup))
    print('Start a new Claude Code session. Invoke /reels-production or ask for reels-director.')
if __name__=='__main__': main()
