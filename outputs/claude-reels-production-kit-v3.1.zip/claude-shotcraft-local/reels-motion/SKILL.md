---
name: reels-motion
description: Choose content-led Reels motion and varied transitions from actual video-shotcraft recipes. Works with simple requests such as "lebih dinamis", "clean", "satu objek berubah terus" or named shots.
---

# Motion routing

Read the current brief and sibling shotcraft-local/config.json. Search the on-disk inventory for3–5relevant candidates; read exact selected cards, demos and helpers. Do not load the entire library. Read `references/motion-playbook.md` for implementation and validation.

Interpret "lebih dinamis" as stronger rhythm, focal changes and purposeful transition variety—not shaking, extra effects or less reading time. "Clean/minimal" suggests clear hierarchy and restrained motion; "satu objek berubah terus" routes to a selected reels-continuity-lab recipe. These are suggestions; explicit shot/style/audio rules always win. Avoid rigid topic-to-style mappings.

For "seperti video referensi", "bedah objek", "jelaskan cara kerja" or technical illustration, read the selected sibling reels-continuity-lab `references/technical-cutaway-explainer.md` and this skill's `references/visual-asset-playbook.md`. The reference study is optional evidence, not required preload. A new attached reference takes precedence over the stored scooter example. Do not assume all explainers need this style.

Output a compact shot map: source recipe, content purpose, entry/action/settle/hold/exit frames, safe geometry and sound/speech landmark. Preserve actual recipe grammar. Match contrast and object identity across handoffs. Text alignment and textScale are measured in final output coordinates. A changed style/order requires updated boundaries and audio cues.

Before final encode inspect mask takeover, ripple coverage,3Dextrema, scene handoffs and CTA reading hold. Review encoded evidence after fixes. Do not claim missing previews were checked. Do not modify application/toolkit source.
