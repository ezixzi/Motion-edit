---
name: reels-production
description: Make Reels from a simple Indonesian prompt, script, URL or JSON. Infer a practical brief, load only relevant local video-shotcraft recipes, produce and verify the MP4. Supports narration, music, SFX or combinations according to the current request.
---

# Reels: simple brief, selective context

Accept natural language; never require JSON, shot IDs or a long prompt. Examples: "Buat Reels3fakta otak, narasi Indonesia, clean"; "Promosikan produk di URLini,30detik"; "Versi tadi lebih dinamis, tanpa musik". Preserve active-project decisions; do not carry unrelated previous-video restrictions into a new task.

Extract intent into a small `brief.json`: topic/product, audience if known, output/duration if given, tone, audio, assets, constraints. Infer routine visual decisions. If unspecified, use vertical Reels-safe composition and choose a duration fitting the content. A voiceover script implies narration; SFX-only excludes it only for that brief. Ask one short bundled question only for essential missing material or authorization. Continue independent work. Do not invent product evidence or facts.

## Read only what matters

Locate the upstream clone through sibling `shotcraft-local/config.json`. Read applicable project instructions. Read `references/context-budget.md` for selective discovery. Full capability inventory lives on disk, not in chat context. Search3–5candidates and read the selected recipes/demo imports. Never load all skills, demos, assets or agents merely because installed.

Route on demand:
- First production/setup: sibling `shotcraft-local/SKILL.md`, then upstream SKILL/pipeline and this skill's `references/production-workflow.md`.
- Motion design: sibling `reels-motion/SKILL.md`; continuity/morph requests additionally selected `reels-continuity-lab` card.
- Narration: sibling `reels-narration/SKILL.md` only when requested/implied. Existing provider authorization persists; no repeated questions.
- Final render/review: sibling `reels-qa/SKILL.md` and independent `reels-reviewer`.
- Workbench/export/publishing: only if requested.

Build only in a separate video workspace. Plan frame timing, render representative stills, fix layout, render MP4, verify final frames/audio/metadata. Read the detailed workflow at execution time; do not substitute this summary for required checks. Never change app/toolkit source, silently drop required audio or fabricate a successful output.

Use one production agent plus independent reviewer by default. Specialist motion/narrator agents are optional for meaningful complex subtasks, not mandatory ceremonial calls. A subagent hands independent review to the parent rather than pretending to spawn agents itself. Send compact handoffs with paths and findings, not full transcripts.

Keep progress/final text concise or silent as requested when higher-priority client rules allow. Token savings come from selective loading and reuse, never skipping QA, licenses, missing-credential handling or requested production steps.
