---
name: reels-qa
description: Verify a final Reels MP4 with ffprobe/ffmpeg and independent visual/audio review; check duration, decoded frame count, resolution, fps, decode integrity and sample peak/clipping. Never treat metadata checks as aesthetic or factual approval.
---

# Reels QA

Run `python "<this-skill>/scripts/check_video.py" "<final.mp4>" --duration 60 --fps 30 --width 1080 --height 1920 --audio required --report "<qa>/technical.json"` with actual brief values. `--audio forbidden` validates silent output; `optional` permits either. Required audio does not prove SFX-only. This checker only uses Python stdlib plus ffprobe/ffmpeg on PATH and never edits the video.

The checker reads every video frame, performs strict decode, verifies resolution/fps/count and durations within half a video frame, and measures decoded PCM sample peak/clipped-sample count. This is sample peak, not true-peak/LUFS. Audio presentation duration is distinct from raw AAC padding. Return status2 means a technical check failed. Review report details, not just the command exit code.

Then inspect encoded keyframes and short boundary sequences, using actual recipe/reference paths and latest brief. Essential copy must fit the requested safe area and alignment, be readable on a phone, and contain no unintended logos or legacy topic. Check every palette state, mask handoff,3D extreme and final CTA. Verify shot grammar against demo/reference; disclose unavailable references.

Validate cue-sheet assets, source licenses, SFX/music/VO scope, and final synchronization. Listen if the environment supports playback; otherwise explicitly leave listening unverified. No automated metadata/script can confirm all these perceptual properties. For numerical/factual assertions, require credible evidence or accurate qualifying copy.

Use a fresh `reels-reviewer` agent from the parent Claude session for independent review. Handoff only the current brief, artifact/hash, timeline, selected recipes/demo/previews, asset provenance and cue sheet—not an expected verdict. Report blockers with frame/time, evidence and actionable fix. After fixes, check the final artifact again. Do not claim independent review if only self-review ran.
