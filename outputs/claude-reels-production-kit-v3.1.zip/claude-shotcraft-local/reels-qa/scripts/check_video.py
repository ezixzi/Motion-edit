#!/usr/bin/env python3
"""Technical MP4 QA only. Does not assess aesthetics, facts, listening or source provenance."""
import argparse, array, hashlib, json, math, shutil, subprocess, sys
from fractions import Fraction
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('video'); p.add_argument('--duration',type=float,required=True)
    p.add_argument('--fps',type=str,default='30'); p.add_argument('--width',type=int,default=1080)
    p.add_argument('--height',type=int,default=1920); p.add_argument('--audio',choices=['required','forbidden','optional'],default='required')
    p.add_argument('--report',required=True); a=p.parse_args()
    video=Path(a.video).expanduser().resolve(); report=Path(a.report).expanduser().resolve()
    if report==video: p.error('Report must not overwrite the video')
    if not video.is_file(): p.error('Video does not exist')
    if not math.isfinite(a.duration) or a.duration<=0: p.error('Positive finite duration required')
    try: fps=Fraction(a.fps)
    except (ValueError,ZeroDivisionError): p.error('Invalid fps')
    if fps<=0: p.error('fps must be positive')
    if not all(shutil.which(x) for x in ['ffmpeg','ffprobe']): p.error('ffmpeg and ffprobe must be on PATH')
    checks={}; result={'artifact':str(video),'checks':checks,'limitations':['No visual review','No listening','No shot/factual/provenance validation','Sample peak only, not true peak or LUFS']}
    h=hashlib.sha256()
    with video.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    result['sha256']=h.hexdigest()
    try:
        meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)],stderr=subprocess.PIPE))
        vs=[s for s in meta['streams'] if s['codec_type']=='video']; ads=[s for s in meta['streams'] if s['codec_type']=='audio']
        checks['single_video_stream']=len(vs)==1
        checks['audio_scope']=(bool(ads) if a.audio=='required' else not ads if a.audio=='forbidden' else True)
        tol=.5/float(fps)+1e-5
        result['duration_tolerance_seconds']=tol
        def duration_ok(s):
            try: return abs(float(s.get('duration','nan'))-a.duration)<=tol
            except (ValueError,TypeError): return False
        checks['container_duration']=duration_ok(meta['format'])
        if vs:
            v=vs[0]; result['video']={k:v.get(k) for k in ['codec_name','width','height','avg_frame_rate','duration','nb_read_frames']}
            checks['resolution']=v['width']==a.width and v['height']==a.height
            checks['fps']=Fraction(v.get('avg_frame_rate','0/1'))==fps
            expected=Fraction(str(a.duration))*fps
            checks['integral_expected_frames']=expected.denominator==1
            checks['decoded_frame_count']=int(v.get('nb_read_frames',-1))==expected
            checks['video_duration']=duration_ok(v)
        for i,s in enumerate(ads): checks['audio_duration_'+str(i)]=duration_ok(s)
        decode=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(video),'-f','null','-'],capture_output=True,text=True)
        checks['strict_decode']=decode.returncode==0
        result['decode_errors']=decode.stderr[-2000:]
        audio=[]
        for i,s in enumerate(ads):
            proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(video),'-map',f'0:a:{i}','-f','f32le','-c:a','pcm_f32le','-'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
            peak=0.; clipped=0; count=0; nonfinite=0; pending=b''
            while True:
                chunk=proc.stdout.read(262144)
                if not chunk: break
                chunk=pending+chunk; n=len(chunk)//4*4; pending=chunk[n:]
                data=array.array('f'); data.frombytes(chunk[:n])
                if sys.byteorder!='little': data.byteswap()
                for x in data:
                    count+=1
                    if not math.isfinite(x): nonfinite+=1; continue
                    v=abs(x); peak=max(peak,v); clipped+=v>=1.0
            rc=proc.wait(); checks['audio_decode_'+str(i)]=rc==0 and not pending and count>0
            checks['audio_no_clipping_'+str(i)]=clipped==0 and nonfinite==0
            audio.append({'stream':i,'peak':peak,'peak_dbfs':20*math.log10(peak) if peak else None,'clipped_samples':clipped,'nonfinite_samples':nonfinite,'decoded_channel_samples':count,'presentation_duration':s.get('duration')})
        result['audio']=audio
    except (OSError,ValueError,KeyError,ZeroDivisionError,subprocess.SubprocessError) as e:
        checks['inspection_completed']=False; result['error']=type(e).__name__+': '+str(e)[:1000]
    result['technical_pass']=bool(checks) and all(checks.values())
    report.parent.mkdir(parents=True,exist_ok=True); report.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(str(report)); return 0 if result['technical_pass'] else 2
if __name__=='__main__': sys.exit(main())
