---
name: shotcraft-local
description: Create and render videos using the complete local video-shotcraft repository. Discover actual shot recipes, demos, SFX, music, templates, Workbench and export capabilities before planning. Use for video-shotcraft requests, named shots or JSON video briefs.
---

# Local video-shotcraft director

You are running in Claude Code on the user's computer. Complete authorized video production through a verified MP4. Speak Indonesian unless requested otherwise. A request to generate is authorization to implement and render locally; do not stop at a storyboard or Workbench launcher.

## Locate and discover

1. Read `config.json` beside this skill; `repo_path` identifies the complete local upstream clone. If missing, inspect an explicitly supplied path or `VIDEO_SHOTCRAFT_ROOT`. Ask for a path only if none exists. Do not assume cloud `/workspace` or `/tmp` paths exist locally.
2. Run `python "<this-skill>/scripts/discover.py" --repo "<repo>" --out "<video-project>/capabilities.json" --summary`. Use `python3`/`py` if that is the local interpreter. Keep the full inventory on disk; this inspects files and prerequisite presence without installing or executing repo code.
3. Read upstream `SKILL.md`, applicable `AGENTS.md`/`CLAUDE.md` and `references/pipeline.md`; consult relevant README/setup sections as needed. User instructions take precedence over workflow defaults. Search the inventory with `scripts/find_motion.py --inventory <path> --query <intent-or-shot-ID> --limit 5`, then inspect the selected cards/demos and relevant project manifests. Read targeted portions of gallery catalogs when needed; do not dump the whole library. Follow actual schemas, never invented catalog fields.
4. Do not equate a filename/count with verified functionality. Inventory the full repository, then read exact recipe cards and TSX demos for selected shots, their imported helpers, audio attribution, and relevant export instructions. Search grouped cards when a requested shot has no same-named card. Inspect available preview videos/frames. Record missing media separately from supported capabilities. Resolve typos only when the intended shot is unambiguous.
5. Refresh inventory when the checkout changes. Do not auto-pull over local modifications. Never use static claims such as "149 SFX" as the source of truth.

## Local operation and defaults

Use autonomous creation unless the user explicitly chooses collaborative/template mode. Reuse decisions for the same active project; do not repeatedly ask about narration, duration or approval. For a new project, derive audio, duration, layout, branding and style from the current brief rather than inheriting exclusions from an unrelated previous video. There is no permanent SFX-only/no-VO/no-BGM rule. A supplied voiceover script or a request to narrate is positive evidence for narration; an explicit SFX-only instruction disables it for that project. Music, voice, SFX, silence or any supported combination are valid.

When audio is unspecified, infer intent from the content and authorized creative freedom, record the chosen audio plan, and ask one concise question only if the answer materially affects production or provider authorization is missing. Do not turn recipe-specific bans into global restrictions. For an otherwise unspecified Reels format,1080x1920/30fps with safe typography is a reasonable starting point; duration comes from the requested content rather than an unchangeable60second default. Never silently drop required narration because TTS is unavailable; report the concrete missing prerequisite while progressing independent work.

Before rendering, inspect Node/npm versions, ffmpeg/ffprobe, Python and the selected template's package manifest/lockfile. Install the selected project's actual dependencies, not merely the repository root test dependencies. Use matching lockfiles; detect/download supported headless Chrome through Remotion. Select concurrency for the local machine. Do not hardcode `/usr/bin/chromium`, Linux shell syntax, or global npm paths. Python installer works on Windows/macOS/Linux; adapt shell commands to the active OS.

Keep application and toolkit source unchanged. Create a separate video workspace (e.g. user-selected `video-renders/<slug>`), copying only required template/assets and recording provenance. Inspect Git status before and after. No hard reset, clean, deleting existing outputs, overwriting user changes, or implicit commits/pushes. GitHub upload is opt-in for the local session. If authorized, upload only requested deliverables, not source, secrets or dependencies.

## Production

- Save brief, exact frame timeline, selected source recipes and audio cue sheet in the video workspace.
- Preserve requested shot grammar: study motion, easing, staging and transitions in actual source; do not merely label a generic fade with a library shot name.
- Match ordered shots, text, alignment, textScale and safe-zone settings. Treat durations as exact frame ranges with no gaps/overlap errors. For 60s30fps use1800frames. Reserve Reels UI zones; check actual rendered pixels, not only wrapper bounds.
- Avoid monotonous motion, while honoring explicitly repeated shots. Keep readable holds and text hierarchy. Validate contrast in every palette and mask/3D handoff.
- Flag unsupported factual claims, use accurate wording or clearly visible qualifications; never invent sources or present an illustrative chart as research data.
- SFX-only means no music or synthesized voice. Use actual available licensed assets with finite durations, aligned to meaningful motion beats. Read attribution and track asset provenance. Do not assume a fixed AAC offset: measure final encoded alignment and compensate only if evidence requires it.
- If narration is requested, verify a usable provider/credentials first; do not claim speech was generated when absent. Never print secret values.
- Workbench/JianYing/publishing are capabilities to discover, not mandatory outputs. Do not launch Workbench or browsers when the user requests only MP4.

## Render and verify

Read upstream `references/final-review.md` and `references/aesthetic-rules.md`. Render representative stills first, including transition boundaries, maximum 3D displacement, mask takeover and final CTA. Inspect them visually and fix issues before full encode.

Use an independent Claude subagent for the upstream-required final review when available; provide the explicit brief, artifacts, source paths and review criteria. Keep its report separate. If unavailable, perform and label self-review honestly; never claim independent approval.

Render final MP4, then verify ffprobe video/audio/container durations, frame count, dimensions and strict full decode. Inspect encoded frames at all scene boundaries/holds, text alignment, clipping, safe bounds, logos and legacy copy. Check audio clipping, source mix, unintended layers and synchronization. Distinguish encoded presentation duration from AAC raw decoded padding. Recheck any changed regions after fixes. Do not claim perceptual listening unless actually performed.

Deliver only an existing verified artifact. If the user says SILENT RUN or OUTPUT MP4 PATH ONLY, suppress optional updates and final explanations where higher-priority client rules permit; return the actual MP4 path or confirmed upload URL only. Never fabricate success. If blocked, state the concrete blocker briefly instead of returning a nonexistent path.

## Companion continuity recipes

The installed sibling `reels-continuity-lab` contains seven opt-in recipes: six from supplied Prompt Motion texts and one from an inspected technical-explainer video. Read only relevant cards. Names are local IDs, not upstream shots; the catalog records evidence per recipe. Prefer actual upstream demos for shared primitives; record missing previews. Recipe-specific style/audio/aspect choices never override the current user brief.
