import phrases from './voice-phrases.json';
export const FPS=30;
export const TOTAL=1200;
export const SHOTS=[
 {id:'hook',label:'01 · Text as mask',from:0,duration:105,kind:'hook',text:'3 TRIK RAHASIA KASINO & TAMAN HIBURAN DUNIA',accent:'#e9bb78',fontSize:118},
 {id:'stack',label:'02 · Three design cards',from:105,duration:45,kind:'stack',text:'Tiga desain. Satu tujuan.',accent:'#e9bb78',fontSize:78},
 {id:'casino',label:'03 · Casino / Spotlight',from:150,duration:300,kind:'casino',text:'01 • Desain Kasino: Tanpa Jam & Jendela Agar Lupa Waktu',accent:'#e9bb78',fontSize:82},
 {id:'green',label:'04 · Go Away Green / Spotlight',from:450,duration:300,kind:'green',text:'02 • Go Away Green: Cat Khusus Penyamaran Tiang & Sampah',accent:'#acbd94',fontSize:82},
 {id:'smell',label:'05 · Smellitzer / Exploded view',from:750,duration:300,kind:'smell',text:'03 • Mesin Smellitzer: Semprotan Aroma Pemicu Rasa Lapar',accent:'#e4ada0',fontSize:82},
 {id:'outro',label:'06 · Card flock tumble',from:1050,duration:150,kind:'outro',text:'Trik bisnis mana yang paling cerdik menurutmu? Simpan video ini buat inspirasi!',accent:'#e9bb78',fontSize:86},
] as const;
export const FLASH_OFFSETS=[0,22,40];
export const TRANSITIONS=SHOTS.filter(s=>['casino','green','smell'].includes(s.kind)).map(s=>({id:`flash-${s.id}`,label:`Paparazzi · ${s.id}`,from:s.from,duration:114}));
export const CAPTIONS=phrases.map((p,i)=>({id:`caption-${i}`,label:p.text,from:p.from,duration:p.group===3?Math.min(p.duration,1124-p.from):p.duration,text:p.text})).filter(p=>p.duration>0);
export const AUDIO=[
 {from:0,duration:TOTAL,src:'audio/narration.wav',volume:1,label:'Narasi Indonesia'},
 {from:0,duration:TOTAL,src:'audio/foley.wav',volume:1,label:'Paper · shutters · air'},
];
export const MUSIC=[{from:0,duration:TOTAL,src:'audio/music.wav',volume:1,label:'Original instrumental'}];
