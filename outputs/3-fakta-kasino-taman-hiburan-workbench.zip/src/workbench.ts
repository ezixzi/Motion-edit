import {SHOTS,TRANSITIONS,CAPTIONS,AUDIO,MUSIC,FPS,TOTAL} from './timeline';
import {Main,COMPONENTS,sceneProps} from './Main';
import {Flash,Caption} from './scenes';
import {C} from './graphics';
export const WORKBENCH={
 name:'3 Trik Kasino & Taman Hiburan · 40 detik',fps:FPS,width:1080,height:1920,total:TOTAL,background:C.bg,revision:'casino-40-v1',
 shots:SHOTS.map(s=>({...s,component:COMPONENTS[s.kind],props:sceneProps(s),cardId:s.kind,cardName:s.label,schema:[{type:'textarea',key:'text',label:'Teks kartu',default:s.text},{type:'color',key:'accent',label:'Warna aksen',default:s.accent},{type:'number',key:'fontSize',label:'Ukuran teks',min:48,max:150,step:1,default:s.fontSize},...(['casino','green'].includes(s.kind)?[{type:'number',key:'index',label:'Ilustrasi: 0 Kasino / 1 Green',min:0,max:1,step:1,default:s.kind==='green'?1:0}]:[])]})),
 transitions:TRANSITIONS.map(t=>({...t,component:Flash,cardId:'paparazzi',cardName:'Paparazzi flash'})),
 captions:CAPTIONS.map(c=>({...c,component:Caption,props:{text:c.text,fontSize:64,color:C.white},schema:[{type:'textarea',key:'text',label:'Teks subtitle',default:c.text},{type:'number',key:'fontSize',label:'Ukuran',min:40,max:90,step:1,default:64},{type:'color',key:'color',label:'Warna',default:C.white}]})),
 overlays:[],sfx:AUDIO,bgm:MUSIC,order:['transitions','captions','overlays'],original:Main,
};
