import React from 'react';
export const C={bg:'#18141b',surface:'#2b2430',white:'#f5f0e8',muted:'#c6bdb6',cyan:'#acbd94',orange:'#e9bb78',violet:'#e4ada0'};

export const Ambient:React.FC<{frame:number}>=({frame})=><svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute',inset:0}}>
 <defs><linearGradient id="ambientFill" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#3b2433"/><stop offset="1" stopColor="#121218"/></linearGradient></defs>
 <rect width="1080" height="1920" fill="url(#ambientFill)"/>
 <g transform={`translate(${-80+frame*.25} -20) rotate(-12 540 960)`}>
  {Array.from({length:13},(_,i)=><path key={'h'+i} d={`M-200 ${i*160} H1300`} stroke="#78616a" strokeWidth="2" opacity=".32"/>)}
  {Array.from({length:11},(_,i)=><path key={'v'+i} d={`M${i*140} -200V2200`} stroke="#78616a" strokeWidth="2" opacity=".32"/>)}
  {[0,1,2,3,4].map(i=><g key={i} transform={`translate(${100+(i%2)*470} ${350+Math.floor(i/2)*430})`}><rect width="340" height="210" rx="100" fill={i===2?'#708264':'#57424f'} stroke="#c29d78" strokeWidth="6"/><ellipse cx="170" cy="105" rx="115" ry="62" stroke="#efd4ab" strokeWidth="3" fill="none"/></g>)}
  <path d={`M-80 1200 Q320 ${650+Math.sin(frame/50)*60} 1200 800`} stroke={C.orange} strokeWidth="14" fill="none" strokeDasharray="44 24" strokeDashoffset={-frame*1.1}/>
  <path d="M100 1500C480 1150 520 1530 1000 1200" stroke={C.cyan} strokeWidth="9" fill="none" opacity=".8"/>
 </g>
</svg>;

export const CasinoArt:React.FC<{frame?:number}>=({frame=0})=><svg width="100%" height="100%" viewBox="0 0 820 660">
 <defs>
  <pattern id="carpet" width="80" height="80" patternUnits="userSpaceOnUse"><path d="M0 40 40 0 80 40 40 80Z" fill="none" stroke="#b58b8b" strokeWidth="2" opacity=".2"/></pattern>
  <radialGradient id="pool"><stop stopColor="#f4cf8e" stopOpacity=".26"/><stop offset="1" stopColor="#f4cf8e" stopOpacity="0"/></radialGradient>
 </defs>
 <rect x="40" y="65" width="740" height="525" rx="24" fill="#543745"/>
 <rect x="40" y="65" width="740" height="525" rx="24" fill="url(#carpet)"/>
 <path d="M50 72H770V580H50Z" fill="none" stroke="#baa294" strokeWidth="17" strokeLinejoin="round"/>
 {[0,1,2].map(i=><g key={i} transform={`translate(${135+i*230} 210)`}><ellipse cx="0" cy="85" rx="147" ry="185" fill="url(#pool)"/><path d="M-45 -78H45L58 -30H-58Z" fill="#e6c28e"/><path d="M0 -132V-78" stroke="#ccb798" strokeWidth="8"/><rect x="-92" y="76" width="184" height="110" rx="53" fill="#77917d" stroke="#e6c9a3" strokeWidth="9"/><ellipse cx="0" cy="131" rx="59" ry="27" stroke="#b8c7a3" strokeWidth="3" fill="none"/></g>)}
 <path d="M145 580V515A65 65 0 0 1 210 580" fill="none" stroke="#d4bfa8" strokeWidth="5"/>
 <g transform="translate(670 483)" opacity=".7"><circle r="42" fill="#30252e" stroke="#baa294" strokeWidth="5"/><path d="M0 -24V0L20 13" stroke="#baa294" strokeWidth="5" fill="none" strokeLinecap="round"/><path d="M-44 43 44 -43" stroke={C.orange} strokeWidth="7"/></g>
 <text x="410" y="42" fill={C.orange} fontSize="39" textAnchor="middle" fontWeight="700" fontFamily="Arial,sans-serif">CAHAYA SAMA SEPANJANG HARI</text>
 <text x="410" y="642" fill={C.muted} fontSize="36" textAnchor="middle" fontFamily="Arial,sans-serif">RUANG TERTUTUP · DINDING MASIF</text>
</svg>;

export const GreenArt:React.FC<{frame?:number}>=({frame=0})=>{
 const p=Math.min(1,Math.max(0,(frame-140)/66)),shade='#7b856d';
 return <svg width="100%" height="100%" viewBox="0 0 820 660">
  <defs><clipPath id="paintWipe"><rect x="0" y={660-p*660} width="820" height={p*660}/></clipPath></defs>
  <rect width="820" height="660" rx="28" fill="#d4c9b4"/>
  <path d="M0 90H820M0 190H820M0 290H820M0 390H820M0 490H820" stroke="#a89883" strokeWidth="3" opacity=".25"/>
  <rect y="500" width="820" height="160" fill="#9c9a7d"/>
  <path d="M0 442Q75 235 160 356Q220 222 305 357Q420 260 465 418Q560 220 665 373Q750 215 820 414V550H0Z" fill="#77846b"/>
  <path d="M0 495Q140 380 250 495Q360 380 460 505Q600 380 820 475V565H0Z" fill="#68765e"/>
  <g stroke="#535c4d" strokeWidth="5">
   <path d="M560 130H594V541H560Z" fill="#b8ada0"/><path d="M509 130H645V153H509Z" fill="#b8ada0"/>
   <rect x="252" y="382" width="172" height="194" rx="20" fill="#b8ada0"/><path d="M240 382H438V410H240Z" fill="#c7bcb0"/><rect x="282" y="437" width="112" height="30" rx="10" fill="#485342"/>
  </g>
  <g clipPath="url(#paintWipe)" stroke="#606b55" strokeWidth="5">
   <path d="M560 130H594V541H560Z M509 130H645V153H509Z" fill={shade}/>
   <rect x="252" y="382" width="172" height="194" rx="20" fill={shade}/><path d="M240 382H438V410H240Z" fill={shade}/><rect x="282" y="437" width="112" height="30" rx="10" fill="#485342"/>
  </g>
  <path d="M100 570Q80 320 160 150M160 150Q220 190 202 238M145 205Q75 210 70 263" stroke="#496144" strokeWidth="13" fill="none"/>
  <rect x="45" y="35" width="730" height="76" rx="12" fill="#293027"/>
  <text x="410" y="87" textAnchor="middle" fill="#e8efda" fontSize="44" fontFamily="Arial,sans-serif" fontWeight="700">{p<.5?'OBJEK TERLIHAT KONTRAS':'MENYATU DENGAN LATAR'}</text>
  <rect x="670" y="550" width="95" height="65" rx="12" fill={shade} stroke="#e2e5cd" strokeWidth="4"/>
 </svg>;
};

export const ScentArt:React.FC<{frame?:number}>=({frame=0})=><svg viewBox="0 0 820 660" width="100%" height="100%">
 <rect width="820" height="660" rx="28" fill="#332a32"/>
 <path d="M40 500H780" stroke="#7f6867" strokeWidth="8"/>
 <rect x="65" y="210" width="175" height="220" rx="25" fill="#8d716a" stroke="#ddbaa0" strokeWidth="7"/>
 <rect x="92" y="235" width="120" height="114" rx="12" fill="#d0ae82"/>
 <path d="M145 251Q120 290 149 326M174 252Q145 288 174 325" fill="none" stroke="#755148" strokeWidth="6" strokeLinecap="round"/>
 <circle cx="153" cy="389" r="15" fill={C.orange}/>
 <path d="M241 320H490V220H660" fill="none" stroke="#b5a89c" strokeWidth="40" strokeLinejoin="round"/>
 <path d="M241 311H481V211H660" fill="none" stroke="#e4d3bc" strokeWidth="8" strokeLinejoin="round" opacity=".7"/>
 <path d="M648 190H699L725 215 699 242H648Z" fill="#ddbaa0" stroke="#a08174" strokeWidth="5"/>
 {[0,1,2].map(i=><path key={i} d={`M730 ${210+i*20}Q${770+Math.sin(frame/15+i)*15} ${170+i*36} 813 ${185+i*35}`} fill="none" stroke={C.violet} strokeWidth="6" strokeLinecap="round" opacity={.7-i*.15}/>)}
 <text x="410" y="88" fill={C.white} textAnchor="middle" fontSize="40" fontWeight="700" fontFamily="Arial,sans-serif">SUMBER AROMA → PIPA → NOZEL</text>
 <text x="410" y="595" fill={C.violet} textAnchor="middle" fontSize="39" fontFamily="Arial,sans-serif">VANILA · POPCORN</text>
</svg>;

export const FactArt:React.FC<{index:number;frame?:number}>=({index,frame=0})=>index===0?<CasinoArt frame={frame}/>:index===1?<GreenArt frame={frame}/>:<ScentArt frame={frame}/>;
export const EquipmentPart:React.FC<{index:number}>=({index})=><svg width="100%" height="100%" viewBox="0 0 300 250">
 {index===0?<g><rect x="98" y="55" width="104" height="160" rx="22" fill="#b98d68" stroke="#efcf9e" strokeWidth="7"/><rect x="120" y="25" width="60" height="40" rx="6" fill="#dec6a7"/><path d="M145 100Q120 140 148 185M172 100Q145 140 172 185" fill="none" stroke="#5a3734" strokeWidth="7" strokeLinecap="round"/></g>:index===1?<g><rect x="45" y="25" width="210" height="200" rx="25" fill="#7b7772" stroke="#d8d0bc" strokeWidth="7"/><circle cx="150" cy="125" r="75" fill="#30282e" stroke="#aca99a" strokeWidth="7"/>{[0,120,240].map(a=><path key={a} d="M150 125Q95 110 112 65Q160 52 165 108Z" fill="#b8bc9e" transform={`rotate(${a} 150 125)`}/>)}<circle cx="150" cy="125" r="14" fill="#e4d5bb"/></g>:<g><path d="M45 200H170V70H250" fill="none" stroke="#aca49b" strokeWidth="55" strokeLinejoin="round"/><path d="M45 190H160V60H250" fill="none" stroke="#ead5b9" strokeWidth="10" strokeLinejoin="round"/><path d="M230 36H270L292 60 270 85H230Z" fill="#deb695"/></g>}
</svg>;
export const ContextCard:React.FC<{index:number}>=({index})=><div style={{width:560,height:400,background:C.surface,border:'2px solid #74616d',borderRadius:22,overflow:'hidden',boxShadow:'0 28px 58px #0006',color:C.white,position:'relative',fontFamily:'GeoSans,sans-serif'}}>
 <div style={{position:'absolute',left:24,top:20,fontSize:34,fontWeight:700,color:[C.orange,C.cyan,C.violet][index]}}>0{index+1}</div>
 <div style={{position:'absolute',left:90,top:26,fontSize:29,fontWeight:600}}>{['DESAIN KASINO','GO AWAY GREEN','SMELLITZER'][index]}</div>
 <div style={{position:'absolute',left:28,right:28,top:76,bottom:20}}><FactArt index={index} frame={index===1?220:0}/></div>
</div>;
