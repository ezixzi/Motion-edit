import React from 'react';
import {AbsoluteFill,useCurrentFrame,spring,Easing,staticFile,interpolate} from 'remotion';
import {Ambient,C,FactArt,ContextCard,EquipmentPart} from './graphics';
import {FLASH_OFFSETS} from './timeline';
export const clamp=(v:number)=>Math.min(1,Math.max(0,v));
export const mix=(a:number,b:number,p:number)=>a+(b-a)*p;
const ease=Easing.bezier(.16,1,.3,1);
const smooth=Easing.bezier(.4,0,.6,1);
export const ramp=(f:number,s:number,d:number,e:(n:number)=>number=ease)=>e(clamp((f-s)/d));
const spr=(f:number,s:number,damping:number,stiffness:number)=>f<s?0:spring({frame:f-s,fps:30,config:{damping,stiffness,mass:1}});
export const Fonts:React.FC=()=> <style>{`@font-face{font-family:GeoSans;src:url('${staticFile('sans-regular.woff2')}');font-weight:400}@font-face{font-family:GeoSans;src:url('${staticFile('sans-semibold.woff2')}');font-weight:600}@font-face{font-family:GeoSans;src:url('${staticFile('sans-bold.woff2')}');font-weight:700 950}.geo-crop text{visibility:hidden}.geo-crop .distance{visibility:visible}`}</style>;
export const Base:React.FC<{children?:React.ReactNode;light?:boolean}>=({children,light=false})=><AbsoluteFill style={{background:light?'#f1eae0':C.bg,color:light?C.bg:C.white,fontFamily:'GeoSans, sans-serif',overflow:'hidden'}}><Fonts/>{!light&&<AbsoluteFill style={{background:'radial-gradient(ellipse at 80% 40%,#49324180,transparent 70%)'}}/>}{children}</AbsoluteFill>;
export const Eyebrow:React.FC<{children:React.ReactNode;accent?:string}>=({children,accent=C.cyan})=><div style={{position:'absolute',top:144,left:96,right:96,fontSize:36,fontWeight:600,letterSpacing:'.16em',color:accent}}>{children}</div>;
export const Hook:React.FC<{text?:string;accent?:string;fontSize?:number}>=({text='3 TRIK RAHASIA KASINO & TAMAN HIBURAN DUNIA',accent=C.orange,fontSize=118})=>{
 const f=useCurrentFrame();
 // Adapted TextAsMask.tsx: drift → eight-frame breath →24f logarithmic rush.
 const breath=ramp(f,64,8),rush=Math.pow(clamp((f-72)/24),1.8),s0=mix(1.04,1,ramp(f,0,18))*(1-.035*breath),scale=s0*Math.pow(46/s0,rush);
 const ox=208,oy=680,dx=(540-ox)*rush,dy=(960-oy)*rush;
 const wrap=`translate(${dx}px,${dy}px) scale(${scale})`,inner=`scale(${1/scale}) translate(${-dx}px,${-dy}px)`;
 const land=ramp(f,72,28),drift=ramp(f,18,46,smooth);
 const words=text.split(' '); const lines=text==='3 TRIK RAHASIA KASINO & TAMAN HIBURAN DUNIA'?['3 TRIK','RAHASIA','KASINO &','TAMAN HIBURAN','DUNIA']:[words.slice(0,2).join(' '),words.slice(2,4).join(' '),words.slice(4,6).join(' '),words.slice(6).join(' ')];
 const ys=[530,730,930,1130,1330];
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920">${lines.map((l,i)=>`<text x="540" y="${ys[i]}" fill="white" text-anchor="middle" font-family="DejaVu Sans,Arial,sans-serif" font-size="${[154,154,142,98,170][i]*fontSize/118}" font-weight="900" letter-spacing="-5">${l.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</text>`).join('')}</svg>`;
 const url=`url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
 const world=<AbsoluteFill style={{transform:`translate(${mix(130,-130,drift)*(1-land)}px,${-100*(1-land)}px) scale(${mix(1.32,1,land)})`}}><Ambient frame={f}/></AbsoluteFill>;
 const cover=clamp((rush-.86)/.09);
 return <Base light><Eyebrow accent={C.bg}>DESAIN & PERILAKU / 01—03</Eyebrow>
  <AbsoluteFill style={{transform:wrap,transformOrigin:`${ox}px ${oy}px`,clipPath:`inset(0 0 ${(1-ramp(f,0,16))*1500}px 0)`,WebkitMaskImage:url,maskImage:url,maskSize:'1080px 1920px',WebkitMaskSize:'1080px 1920px',maskRepeat:'no-repeat'}}><AbsoluteFill style={{transform:inner,transformOrigin:`${ox}px ${oy}px`}}>{world}</AbsoluteFill></AbsoluteFill>
  {cover>0&&<AbsoluteFill style={{opacity:cover}}>{world}</AbsoluteFill>}
  <div style={{position:'absolute',left:96,right:96,top:1480,color:C.bg,fontSize:72,fontWeight:700,lineHeight:1.14,letterSpacing:'-.045em',opacity:(1-ramp(f,64,10))*ramp(f,8,18)}}>Kenapa Kasino Tanpa<br/>Jam & Jendela?</div>
  <div style={{position:'absolute',left:96,right:96,top:1750,height:5,background:'#b8c8cd',opacity:1-cover}}><div style={{width:`${clamp(f/105)*100}%`,height:'100%',background:accent}}/></div>
 </Base>;
};

export const Stack:React.FC<{text?:string;accent?:string;fontSize?:number}>=({text='Tiga desain. Satu tujuan.',accent=C.orange,fontSize=78})=>{
 const f=useCurrentFrame(),starts=[0,5,8],fan=spr(f,23,20,95),dip=starts.reduce((a,s)=>a+Math.sin(clamp((f-s-6)/9)*Math.PI)*5,0),cam=mix(1.06,.88,ramp(f,21,21,smooth));
 return <Base><Eyebrow accent={accent}>YANG JARANG KITA SADARI</Eyebrow><div style={{position:'absolute',left:96,right:96,top:310,fontSize,fontWeight:700,lineHeight:1.05,letterSpacing:'-.05em'}}>{text}</div>
  <AbsoluteFill style={{transform:`scale(${cam})`,transformOrigin:'540px 1020px',perspective:1800}}>
   {[0,1,2].map(i=>{const p=spr(f,starts[i],13,150),k=i-1;return <div key={i} style={{position:'absolute',left:260,top:730,width:560,height:400,transformOrigin:'50% 130%',zIndex:i,transform:`translate3d(${mix((i-1)*6,k*185,fan)}px,${(1-p)*1400+dip-(i===1?72*ramp(f,35,8):0)}px,${i*2}px) rotate(${mix((i%2?1:-1)*9*(1-p),k*6.5,fan)}deg)`}}><ContextCard index={i}/></div>})}
  </AbsoluteFill>
  <div style={{position:'absolute',left:96,right:96,top:1400,fontSize:48,color:C.muted,opacity:ramp(f,26,12)}}>Ruang. Warna. Aroma.<br/>Cara desain mengarahkan perhatian.</div>
 </Base>;
};

const cutZoom=(f:number)=>{
 const seg=f<22?0:f<40?1:2,last=[0,22,40][seg];
 const settle=1-ramp(f,last,6);
 const base=[1,1.6,2.8][seg];
 const hold=1+.015*ramp(f,46,64,smooth);
 const release=ramp(f,110,26,smooth);
 return {z:mix(base*(1+.03*settle)*hold,1,release),y:mix(-16*settle,0,release)};
};
const SpotlightTitle:React.FC<{text:string;f:number;fontSize:number;accent:string}>=({text,f,fontSize,accent})=>{
 // Exact damped2.25-cycle50f pendulum followed by20f iris from SpotlightSweepReveal.
 const sf=Math.min(Math.max(f,8),120.5),th=-Math.PI/2+2*Math.PI*(sf-8)/50,env=1-ramp(sf,45.5,75,smooth),u=Math.sin(th)*env;
 const x=444+340*u,y=165+26-44*u*u,iris=ramp(f,120.5,20,Easing.out(Easing.cubic));
 const radius=mix(250,1300,iris),ry=mix(260,800,iris),on=f<4?0:f>=10?1:[0,.55,.15,.8,.45,1][Math.min(5,Math.floor(f-4))];
 const mask=`radial-gradient(ellipse ${radius}px ${ry}px at ${x}px ${y}px,#000 0%,#000e 42%,#0005 72%,transparent 100%)`;
 const title=<div style={{fontSize,fontWeight:700,lineHeight:1.08,letterSpacing:'-.046em',whiteSpace:'pre-line'}}>{text}</div>;
 return <div style={{position:'absolute',left:96,top:248,width:888,minHeight:390}}>
  {f>=0&&<svg width="888" height="430" style={{position:'absolute',left:0,top:-80,overflow:'visible',opacity:on*mix(.8,.18,iris)}}><defs><linearGradient id="spotCone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={accent} stopOpacity=".13"/><stop offset="1" stopColor={accent} stopOpacity="0"/></linearGradient></defs><polygon points={`420,-330 468,-330 ${x+radius},${y+260} ${x-radius},${y+260}`} fill="url(#spotCone)"/></svg>}
  <div style={{color:C.white,opacity:.07}}>{title}</div>
  <div style={{position:'absolute',inset:0,color:C.white,opacity:on,WebkitMaskImage:mask,maskImage:mask}}>{title}</div>
  {f>=0&&f<141&&<div style={{position:'absolute',left:x-250,top:y-220,width:500,height:500,borderRadius:'50%',background:`radial-gradient(ellipse,${accent}13,transparent 67%)`,pointerEvents:'none',opacity:on}}/>}
 </div>;
};

export const FactScene:React.FC<{index?:number;text?:string;accent?:string;fontSize?:number}>=({index=0,text='01 • Desain Kasino: Tanpa Jam & Jendela Agar Lupa Waktu',accent=C.orange,fontSize=82})=>{
 const f=useCurrentFrame(),zoom=cutZoom(f),active=f>=114;
 const annotation=active?ramp(f,114,18):0;
 return <Base><Eyebrow accent={accent}>{index===0?'01 / ARSITEKTUR PERHATIAN':'02 / KAMUFLASE VISUAL'}</Eyebrow>
  <SpotlightTitle text={text.replace(': ',':\n')} f={f-114} fontSize={fontSize} accent={accent}/>
  <div style={{position:'absolute',left:86,top:725,width:908,height:660,overflow:'hidden',borderRadius:32,background:C.bg}}>
   <div className={zoom.z>1.2?'geo-crop':''} style={{position:'absolute',left:454/zoom.z-454,top:330/zoom.z-330+zoom.y,width:908,height:660,zoom:zoom.z}}><FactArt index={index} frame={f<40?f:f<114?40:f}/></div>
  </div>
  {index===0?<div style={{position:'absolute',left:96,right:96,top:1395,fontSize:40,lineHeight:1.25,color:C.muted,opacity:annotation}}>Pola desain yang umum,<br/>bukan aturan semua kasino.</div>:<div style={{position:'absolute',left:96,right:96,top:1418,fontSize:40,lineHeight:1.25,color:C.muted,opacity:annotation}}>Warna menyesuaikan lingkungan;<br/>objek tidak benar-benar menghilang.</div>}
 </Base>;
};

const layers=[
 {x:0,y:450,w:330,h:540,z:150,label:'SUMBER',value:'AROMA'},
 {x:360,y:450,w:530,h:540,z:270,label:'PENDORONG',value:'UDARA'},
 {x:920,y:450,w:330,h:540,z:400,label:'SALURAN',value:'PIPA'},
 {x:0,y:150,w:1250,h:270,z:520,label:'KELUAR DARI NOZEL',value:'VANILA'},
 {x:0,y:0,w:1250,h:120,z:640,label:'DISTRIBUSI AROMA DI RUANG PUBLIK',value:''},
];
const lp=(f:number,i:number)=>spr(f,24+i*5,15,120)*(1-ramp(f,108+(4-i)*3,14,Easing.in(Easing.cubic)));
export const SmellSystem:React.FC<{text?:string;accent?:string;fontSize?:number}>=({text='03 • Mesin Smellitzer: Semprotan Aroma Pemicu Rasa Lapar',accent=C.violet,fontSize=82})=>{
 const f=useCurrentFrame(),ef=f-114,orb=ramp(ef,30,74,smooth),tall=ramp(ef,22,40,smooth)*(1-ramp(ef,106,30,smooth)),scale=mix(.58,.48,tall),since=ef-134,thud=since>=0?8*Math.exp(-since/3)*Math.cos(since*.9):0;
 const zoom=cutZoom(f);const explodeVisible=f>=114;
 return <Base><Eyebrow accent={accent}>03 / DESAIN SENSORIK</Eyebrow><div style={{position:'absolute',left:96,right:96,top:248,fontSize,fontWeight:700,lineHeight:1.08,letterSpacing:'-.046em',whiteSpace:'pre-line'}}>{text.replace(': ',':\n')}</div>
  {!explodeVisible?<div style={{position:'absolute',left:86,top:725,width:908,height:730,overflow:'hidden',borderRadius:32}}><div className={zoom.z>1.2?'geo-crop':''} style={{position:'absolute',left:454/zoom.z-454,top:365/zoom.z-365+zoom.y,width:908,height:730,zoom:zoom.z}}><FactArt index={2} frame={Math.min(40,f)}/></div></div>:<AbsoluteFill style={{perspective:2400}}>
   <div style={{position:'absolute',left:540-625,top:940-500,width:1250,height:1000,transformStyle:'preserve-3d',transform:`translateY(${120*tall+thud}px) scale(${scale}) rotateX(${mix(54,50,orb)}deg) rotateZ(${mix(-34,-22,orb)}deg)`}}>
    <div style={{position:'absolute',inset:-18,borderRadius:30,background:'#0006',filter:`blur(${30-thud}px)`,transform:'translateZ(-30px) translate(30px,40px)'}}/>
    <div style={{position:'absolute',inset:-8,borderRadius:30,background:'#85746f',transform:'translateZ(-14px)'}}/>
    <div style={{position:'absolute',inset:0,borderRadius:26,background:'#e1d2bf'}}/>
    {layers.map((l,i)=>{const p=lp(ef,i),z=p*l.z;return <React.Fragment key={i}>
     <div style={{position:'absolute',left:l.x+10,top:l.y+10,width:l.w-20,height:l.h-20,borderRadius:16,border:'3px dashed #9c8273',background:'#d6bd9f33'}}/>
     {p>.01&&<div style={{position:'absolute',left:l.x+z*.18,top:l.y+z*.26,width:l.w,height:l.h,borderRadius:20,background:'#102b4660',filter:`blur(${10+z*.09}px)`,opacity:.8-z/1400,transform:'translateZ(1px)'}}/>}
     <div style={{position:'absolute',left:l.x,top:l.y,width:l.w,height:l.h,borderRadius:20,background:'#aa8d80',transform:`translateZ(${z-8}px)`}}/>
     <div style={{position:'absolute',left:l.x,top:l.y,width:l.w,height:l.h,borderRadius:20,background:i===3?'#e9c99c':C.surface,color:i===3?C.bg:C.white,overflow:'hidden',transform:`translateZ(${z+2}px)`,border:'2px solid #b8a18a',padding:'30px 24px',boxSizing:'border-box'}}>
      <div style={{fontSize:i===4?52:45,fontWeight:700,letterSpacing:'.025em'}}>{l.label}</div>
      <div style={{fontSize:i===3?140:i===1?100:54,fontWeight:700,lineHeight:1.1,marginTop:22,letterSpacing:'-.04em'}}>{l.value}</div>
      {i<3&&<div style={{position:'absolute',left:15,right:15,bottom:12,height:250}}><EquipmentPart index={i}/></div>}
     </div>
    </React.Fragment>})}
   </div>
  </AbsoluteFill>}
  <div style={{position:'absolute',left:84,right:84,top:1406,padding:'12px',borderRadius:14,background:C.bg,fontSize:40,lineHeight:1.25,color:C.muted,opacity:ramp(f,114,18)}}>Ilustrasi sistem aroma; respons tiap<br/>pengunjung dapat berbeda.</div>
 </Base>;
};

type Pose={x:number;y:number;rx:number;ry:number;rz:number;s:number};
const poseKeys:(keyof Pose)[]=['x','y','rx','ry','rz','s'];
const catmull=(a:number,b:number,c:number,d:number,t:number)=>.5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
const spline=(keys:Pose[],u:number)=>{const seg=u<.55?0:1,t=seg===0?u/.55:(u-.55)/.45,out={} as Pose;for(const k of poseKeys)out[k]=catmull(keys[Math.max(0,seg-1)][k],keys[seg][k],keys[seg+1][k],keys[Math.min(2,seg+2)][k],t);return out;};
const cardPoses=[
 [{x:-8,y:-16,rx:9,ry:88,rz:12,s:.8},{x:-135,y:-92,rx:16,ry:44,rz:-8,s:1},{x:-84,y:-155,rx:4,ry:13,rz:-2,s:1.22}],
 [{x:0,y:0,rx:8,ry:89,rz:12,s:.76},{x:-16,y:-7,rx:13,ry:38,rz:-7,s:1.06},{x:-5,y:-2,rx:3,ry:11,rz:-2,s:1.28}],
 [{x:8,y:16,rx:7,ry:90,rz:12,s:.73},{x:112,y:78,rx:11,ry:34,rz:-6,s:1.1},{x:72,y:145,rx:2,ry:9,rz:-1,s:1.32}],
];
const Smoke:React.FC<{f:number}>=({f})=>{
 const t=f-70;if(t<0)return null;
 const grow=Easing.out(Easing.cubic)(clamp(t/52)),r=46+330*grow+Math.max(0,t-52)*1.6,w=r*mix(.36,.27,clamp(t/52)),op=interpolate(t,[0,4,30,60],[0,1,.94,.76],{extrapolateRight:'clamp'}),disp=60+grow*90;
 return <svg width="1080" height="1920" style={{position:'absolute',inset:0,mixBlendMode:'screen'}}>
  <defs>{[['a','0.013 0.016',11,1],['b','0.021 0.018',37,.85],['c','0.019 0.023',73,1.1]].map(([id,freq,seed,k])=><filter key={id} id={'smoke'+id} x="-60%" y="-60%" width="220%" height="220%"><feTurbulence type="fractalNoise" baseFrequency={String(freq)} numOctaves={4} seed={Number(seed)} result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale={disp*Number(k)} xChannelSelector="R" yChannelSelector="G"/></filter>)}
  <linearGradient id="ring" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f1d9b4"/><stop offset=".4" stopColor="#e9bb78"/><stop offset="1" stopColor="#b47d84"/></linearGradient></defs>
  <g transform={`rotate(${t*.35} 540 920)`} opacity={op}>
   <g filter="url(#smokea)"><circle cx="540" cy="920" r={r} fill="none" stroke="#b58a6866" strokeWidth={w*1.9} style={{filter:'blur(22px)'}}/><circle cx="540" cy="920" r={r} fill="none" stroke="url(#ring)" strokeWidth={w} style={{filter:'blur(9px)'}} opacity=".88"/></g>
   <g filter="url(#smokeb)"><circle cx="540" cy="920" r={r*.99} fill="none" stroke="#fff0d999" strokeWidth={w*.42} style={{filter:'blur(6px)'}}/></g>
   <g filter="url(#smokec)"><circle cx="540" cy="920" r={r*1.005} fill="none" stroke="#24161d88" strokeWidth={w*.4} style={{filter:'blur(7px)'}}/></g>
  </g>
 </svg>;
};
export const Outro:React.FC<{text?:string;accent?:string;fontSize?:number}>=({text='Trik bisnis mana yang paling cerdik menurutmu? Simpan video ini buat inspirasi!',accent=C.orange,fontSize=86})=>{
 const f=useCurrentFrame(),st=f-74,slam=ramp(f,74,14),textScale=mix(1.22,1,slam)+Math.max(0,st-14)*.00035;
 const t=Math.min(f,62)-54*.86,r=Math.min(1,Math.max(0,t)/14)**2;
 const drift={ry:Math.max(0,t)*.34*r,rx:Math.max(0,t)*-.1*r,rz:Math.max(0,t)*.05*r};
 return <Base><Eyebrow accent={accent}>DESAIN KECIL / DAMPAK BESAR</Eyebrow>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at 50% 48%,#6a453e66,transparent 68%)'}}/>
  {f<74&&<AbsoluteFill style={{perspective:1400,alignItems:'center',justifyContent:'center',transform:'translateY(-40px)'}}>
   {cardPoses.map((keys,i)=>{let p=spline(keys,Easing.out(Easing.cubic)(clamp((f-10)/44)));p={...p,ry:p.ry+drift.ry,rx:p.rx+drift.rx,rz:p.rz+drift.rz};let op=1;
    if(f>=62){const e=Easing.in(Easing.quad)(clamp((f-62)/10)),from={...keys[2],ry:keys[2].ry+drift.ry,rx:keys[2].rx+drift.rx,rz:keys[2].rz+drift.rz},to={x:(i-1)*14,y:(i-1)*10,rx:0,ry:55+i*5,rz:4,s:.12};for(const k of poseKeys)p[k]=mix(from[k],to[k],e);op=1-Easing.in(Easing.cubic)(clamp(((f-62)/10-.55)/.45));}
    return <div key={i} style={{position:'absolute',width:980,height:700,opacity:op,zIndex:10+i,transform:`translate3d(${p.x}px,${p.y}px,0) rotateX(${p.rx}deg) rotateY(${p.ry}deg) rotateZ(${p.rz}deg) scale(${p.s/1.75})`}}><div style={{zoom:1.75}}><ContextCard index={i}/></div></div>;
   })}
  </AbsoluteFill>}
  <Smoke f={f}/>
  {f>=69&&f<85&&<div style={{position:'absolute',left:120,top:500,width:840,height:840,borderRadius:'50%',background:`radial-gradient(circle,#fff8ed,#e9bb7888 12%,transparent 66%)`,opacity:Math.exp(-Math.max(0,f-70)/3.2),mixBlendMode:'screen'}}/>}
  {st>=0&&<div style={{position:'absolute',left:102,right:102,top:690,textAlign:'center',fontSize,fontWeight:700,letterSpacing:`${mix(.06,-.035,slam)}em`,lineHeight:1.08,transform:`scale(${textScale})`,opacity:ramp(f,74,5),textShadow:'0 3px 18px #18141b'}}>{text}</div>}
  <div style={{position:'absolute',left:96,right:96,top:1410,textAlign:'center',fontSize:44,color:C.muted,opacity:ramp(f,96,18)}}>RUANG · WARNA · AROMA</div>
 </Base>;
};

export const Flash:React.FC=()=>{
 const f=useCurrentFrame();let a=0;for(const at of FLASH_OFFSETS)if(f>=at&&f<=at+4)a=Math.max(a,.95*(1-ramp(f,at,4)));
 const next=FLASH_OFFSETS.find(at=>at>f&&at-f<=8),p=next===undefined?0:ramp(f,next-8,6),locked=next!==undefined&&f>=next-3;
 return <AbsoluteFill style={{pointerEvents:'none'}}>
  {next!==undefined&&<svg width="1080" height="1920"><g transform={`translate(540 1090) scale(${mix(1.3,1,p)}) translate(-540 -1090)`} stroke={locked?C.orange:C.white} strokeWidth="4" fill="none"><path d="M205 865V800H275M805 800H875V865M205 1315V1380H275M805 1380H875V1315"/></g></svg>}
  {a>.004&&<AbsoluteFill style={{opacity:a,background:'radial-gradient(ellipse at 50% 45%,#fff 0%,#fff 45%,#fafaffdb)'}}/>}
 </AbsoluteFill>;
};
export const Caption:React.FC<{text?:string;fontSize?:number;color?:string}>=({text='',fontSize=64,color=C.white})=><AbsoluteFill style={{pointerEvents:'none',fontFamily:'GeoSans,sans-serif'}}><Fonts/><div style={{position:'absolute',left:86,right:86,bottom:80,minHeight:202,display:'flex',alignItems:'center',justifyContent:'center',textAlign:'center',fontSize,fontWeight:600,lineHeight:1.15,letterSpacing:'-.028em',color,background:'linear-gradient(180deg,#18141bed,#18141bf7)',borderRadius:18,padding:'18px 20px',boxSizing:'border-box'}}>{text}</div></AbsoluteFill>;
