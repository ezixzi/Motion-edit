import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Main} from './Main';
import {TOTAL,FPS} from './timeline';
export const Root:React.FC=()=> <Composition id="Casino" component={Main} width={1080} height={1920} fps={FPS} durationInFrames={TOTAL} defaultProps={{bgm:true}}/>;
registerRoot(Root);
