# Assets

- Original SVG casino interior, camouflage landscape, scent distribution equipment and diagram labels; conceptual illustrations, not actual Disney architecture or manufacturer equipment.
- Original deterministic instrumental in audio.py, no sampled commercial music.
- Physical Foley from video-shotcraft assets/audio/sfx. Exact selected filenames, timing and normalization in audio-cues.json; upstream attribution copied to AUDIO-ATTRIBUTION.md.
- OpenAI Sans regular/semibold/bold WOFF2 reused from existing workspace assets. No independent font redistribution license is claimed here.
- Synthetic Indonesian speech via existing sherpa-onnx/Piper id_ID-news_tts-medium environment. Model weights not included. Voice source model from k2-fsa/sherpa-onnx GitHub releases; the bundled MODEL_CARD has inconsistent language metadata, so no blanket model redistribution license is claimed. Rendering only requires the included WAVs.
- Motion adapted from the six user-selected video-shotcraft recipes: https://github.com/Vincentwei1021/video-shotcraft. No branded demo artwork, logos, character silhouettes, park marks, or watermarks in final video. User-script mention of Disney is spoken/captioned plain text only.
