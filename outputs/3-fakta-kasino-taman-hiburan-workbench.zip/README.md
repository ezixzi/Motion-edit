# 3 Trik Kasino & Taman Hiburan — 40 detik

1080×1920, 30 fps, 1.200 frame. Tanpa logo atau watermark. Narasi Indonesia mengikuti naskah pengguna; ilustrasi asli bersifat skematis. Catatan layar memberi konteks agar klaim desain tidak dibaca sebagai aturan universal.

## Render

Node.js 20 atau lebih baru:

```sh
npm install
npm run render
npx remotion render src/index.tsx Casino out/3-fakta-kasino-taman-hiburan-tanpa-musik.mp4 --props=props-nobgm.json
```

Semua audio dan font untuk merender sudah di `public/`. Tidak perlu TTS/API berbayar. `voice.py` dan `audio.py` hanya catatan proses pembuatan dan tidak wajib dijalankan.

Berkas final kiriman memiliki durasi video, audio, dan container tepat 40 detik. Bila ekspor ulang menambahkan padding AAC sekitar 43 ms, FFmpeg dapat merapikannya: `node finalize.mjs hasil.mp4 hasil-40s.mp4`. Gambar disalin tanpa encoding ulang.

## Motion Workbench

Pasang video-shotcraft dari https://github.com/Vincentwei1021/video-shotcraft, lalu dari folder skill jalankan:

```sh
node workbench/scripts/open.mjs /path/ke/casino-shotcraft
```

`src/workbench.ts` mengimpor shot, transisi, subtitle, narasi, efek suara dan musik ke track terpisah. Teks, warna, dan ukuran huruf dapat diedit. `motion-workbench.json` adalah timeline hasil impor; tautkan proyek terlebih dahulu sebelum mengimpor JSON agar komponennya tersedia.

Editor menyediakan tambahan 1 detik ruang pratinjau sehingga bisa menampilkan 41 detik. Export video memakai akhir konten tepat 40 detik. Pertahankan akhir klip di frame 1200 untuk menjaga durasi.

Dalam environment cloud sesi ini Workbench berjalan di http://localhost:5201/?import=project; URL hanya berlaku selama environment aktif dan port dapat diakses.

## Isi

0–3,5 detik: text-as-mask; 3,5–5: card-stack; 5–15: desain kasino; 15–25: Go Away Green; 25–35: Smellitzer; 35–40: card-flock-tumble. Tiga fakta diawali paparazzi-flash; dua pertama memakai spotlight-sweep, ketiga exploded-view. Naskah VO persis ada di `voice.py` dan `voice-metadata.json`.

Kode aplikasi Motion-edit tidak diubah. ZIP ini proyek video baru yang berdiri sendiri. Lihat BRIEF.md untuk keputusan visual dan qa/INDEPENDENT-REVIEW.md untuk pemeriksaan akhir.
