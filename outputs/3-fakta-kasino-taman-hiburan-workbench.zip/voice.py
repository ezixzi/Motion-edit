import json,wave,subprocess
from pathlib import Path
import numpy as np
import sherpa_onnx

r=Path(__file__).parent;sr=48000
m=Path('/tmp/geography-motion/vits-piper-id_ID-news_tts-medium')
tts=sherpa_onnx.OfflineTts(sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'id_ID-news_tts-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data')),num_threads=2,provider='cpu'),max_num_sentences=1))
groups=[
 (5,10,[
 'Kenapa di dalam kasino tidak pernah ada jam dan jendela?',
 'Fakta pertama: ruangan tertutup dengan cahaya yang sama sepanjang hari',
 'sengaja dibuat agar otak pengunjung lupa waktu.']),
 (15,10,[
 'Fakta kedua: taman hiburan Disney memakai cat khusus bernama Go Away Green',
 'agar mata pengunjung mengabaikan tempat sampah dan tiang listrik.']),
 (25,10,[
 'Dan fakta ketiga: pipa tersembunyi bernama Smellitzer',
 'rutin menyemprotkan aroma vanila dan popcorn di jalan utama',
 'untuk memicu rasa lapar pengunjung.']),
 (35,5,[
 'Trik bisnis mana yang paling cerdik menurutmu?',
 'Simpan video ini buat inspirasi!'])]

def wav(path,a,rate):
 with wave.open(str(path),'wb') as w:
  w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((np.clip(a,-1,1)*32767).astype('<i2').tobytes())

out=np.zeros(sr*40);meta=[];phrases=[]
for gi,(start,slot,texts) in enumerate(groups):
 arrays=[]
 for pi,text in enumerate(texts):
  a=tts.generate(text,sid=0,speed=1.12);s=np.asarray(a.samples);s=s[:len(s)]
  # Trim only silence at both ends to avoid wasting the tight voice slots.
  active=np.flatnonzero(np.abs(s)>.006)
  if len(active):s=s[max(0,active[0]-int(.025*a.sample_rate)):min(len(s),active[-1]+int(.07*a.sample_rate))]
  arrays.append((s,a.sample_rate,text))
 total=sum(len(s)/rate for s,rate,_ in arrays);gap=.08;available=slot-.24-gap*(len(arrays)-1)
 tempo=total/available
 cursor=start+.06
 for pi,(s,rate,text) in enumerate(arrays):
  raw=r/'qa'/f'voice-raw-{gi}-{pi}.wav';wav(raw,s,rate)
  target=(len(s)/rate)/tempo
  dest=r/'qa'/f'voice-fit-{gi}-{pi}.wav'
  subprocess.run(['ffmpeg','-y','-v','error','-i',str(raw),'-af',f'atempo={tempo:.9f},loudnorm=I=-17:TP=-2.7:LRA=7,aresample=48000,apad,atrim=0:{target:.9f}','-ar',str(sr),str(dest)],check=True)
  with wave.open(str(dest),'rb') as w:s2=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
  at=round(cursor*sr);out[at:at+len(s2)]+=s2
  phrases.append({'from':round(cursor*30),'duration':max(1,round(target*30)),'text':text,'group':gi})
  cursor+=target+gap
 meta.append({'group':gi,'start':start,'slot':slot,'raw_seconds':total,'tempo':tempo,'speech_end':cursor-gap,'word_count':len(' '.join(texts).split())})
 print(meta[-1],flush=True)
wav(r/'public/audio/narration.wav',out,sr)
(r/'voice-metadata.json').write_text(json.dumps(meta,indent=2))
(r/'src/voice-phrases.json').write_text(json.dumps(phrases,indent=2))
